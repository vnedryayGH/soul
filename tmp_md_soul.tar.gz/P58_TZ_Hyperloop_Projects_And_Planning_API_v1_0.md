# P58 — ТЗ: Hyperloop Projects & Planning API

Версия: v1.0
Статус: актуально
Назначение: стандартизировать использование Hyperloop DSL для проектного управления Soul (план‑факт P40) и обеспечить наблюдаемость и предсказуемость операций для LLM‑агентов.

## 1. Поддерживаемые команды (обязательный минимум)
- `PROJECT.LIST`
- `PROJECT.GET id=<pid>`
- `PLAN.TASK.ADD project_id=<pid> title="..." [cpm_duration_days=<float>]`
- `PLAN.TASK.DEPEND predecessor=<tid> successor=<tid> dep_type=<FS|SS|FF|SF>`
- `PLAN.CPM.CALC project_id=<pid> WITH TRACE`
- `INSPECTOR.RUN key=planning.enforce`

Тело запроса строго: `{ "commands": "<ONE LINE DSL>" }`. Передача сложных опций — через `--commands` + `--options-json-file` (Powershell quoting‑safe режим).

## 2. Наблюдаемость/метрики
- `dev_connect_latency_ms_p50|p95`, `dev_connect_total{status}`, `dev_connect_error_total{type}`.
- Инциденты P50 при ошибках: `quotes_error|header_missing|url_malformed|timeout|auth_forbidden|other`.

## 3. Безопасность и роли
- Требуемый заголовок: `X-Telegram-User-ID`.
- Операции изменения — под ролью `soul.admin`, Two‑Keys для чувствительных.

## 4. Контракты ответов
- Детерминированный JSON UTF‑8, стабильные поля, отсутствие PII.
- При недоступности rsbus/актора — мгновенный fallback на Python ветку с P27 подписью.

## 5. Критерии приёмки
- Успешное выполнение `PROJECT.LIST` и `PROJECT.GET` на PROD.
- Создание тестовой задачи через `PLAN.TASK.ADD` и успешный `PLAN.CPM.CALC` (WITH TRACE).
- Инспектор `planning.enforce` возвращает зелёное состояние по ключевым проектам.


