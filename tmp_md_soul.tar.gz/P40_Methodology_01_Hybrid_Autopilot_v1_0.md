# P40 — Methodology 01: Hybrid Autopilot v1.0

Дата: 2025-10-04
Статус: draft→active (минимальный комплект реализуем).
Назначение: гибридная методология управления проектами Ядра Соул с детерминированными расчётами (CPM/EVM), автодекомпозицией и автоэскалациями (AGE/RS), интегрированная с P27/P28/P29/P30/P36.

## 1) Цели и область применения

- **Цель**: ускоренное достижение целей проекта при соблюдении качества и сроков, с автоматизацией планирования/реплана.
- **Область**: малые команды, высокочастотные изменения, интеграция RS/AGE, LLM‑помощник.

## 2) Инварианты/политики

- **P27 Delivery Guard**: обязательная подпись шагов до видимого ответа.
- **P28 Feature Flags/Policies**: конфиг через `soul_settings` (без хардкодов).
- **P29 Judge/Gendarme**: Two‑Keys для опасных операций.
- **P30 Processor**: справедливая приоритизация, квоты/карантин, идемпотентность.
- **P36 Hyperloop**: управляемость через DSL.

## 3) Роли и RBAC

- `project.manager`: управление планом/репланом, выбор методологии.
- `project.operator`: админские действия, отчёты, агрегации.
- `developer|tester|analyst|integrator|riskman`: контур работ по P40.

### 3.1 Расширение ролей и интерфейсы

- Manager: права `project.*|plan.*|risk.*|change.*`; доступ к DSL шаблонам CPM/EVM/реплана; панели CPI/SPI/critical.
- Operator: роли инжеста/линковки/очистки; доступ к `/api/admin/qlinks/*`, `/api/admin/rs/*` (RBAC Architect/Operator).
- Developer: интерфейс Задачи→Коммиты/PR/Артефакты; связь с квантом `implements` и навыками (каталог).
- Riskman: CRUD по рискам, скоринг, алерты экспозиции; интеграция P29 (инциденты).

## 4) Дерево процессов (roles→process_tree)

- manager: [init, wbs, schedule, cpm, evm]
- operator: [status_aggregation, publish]
- riskman: [identify, score, plan, monitor]
- integrator: [analyze, route, implement]

### 4.1 Оркестровка шагов (Perceive→Plan→Act)

- Perceive: сбор статусов/метрик/линковки (coverage/duplicates); вывод KPI/alerts.
- Plan: WBS→CPM→EVM; выбор реплана при отклонениях (LLM‑gate по p95/error_rate/queue).
- Act: создание/изменение задач (PLAN.TASK.*), автолинковка (QUANT.LINK.AUTO), апдейт методологии (METHODOLOGY.SET).

## 5) Алгоритмы

- **CPM**: ES/EF/LS/LF, критический путь, slack.
- **EVM**: PV/EV/AC, CPI/SPI, пороги алертов.
- **Риск‑скоринг**: матрица probability×severity + факторы.

### 5.1 SLA/пороговые политики

- Processor e2e p95 ≤ 2000 ms; queue_len контролируется алертами.
- RS p95 ≤ 50 ms; err_rate ≤ 1%; canary_share авто‑тюнинг 0..0.1.
- AGE lag ≤ 60 s; эскалации batch/concurrency/pages_per_tick с rollback.

## 6) Интеграции

- **DSL**: `PROJECT.CREATE|LIST|GET|UPDATE`, `PLAN.TASK.ADD|FIND|DEPEND`, `PLAN.CPM.CALC`, `QUANT.LINK`, `SKILL.LINK.TASK`.
- **Processor**: события `plan_update|neurotrain.report|age.sync|rs.autotune`.
- **Prometheus/Grafana**: панели p95/queue_len/error_rate; алерты Processor/AGE/RS.

### 6.1 Практические сценарии (идемпотентно)

- Приёмка: PROJECT.CREATE → 2×PLAN.TASK.ADD → PLAN.CPM.CALC → QUANT.LINK(.AUTO) → coverage/dedup/projection.
- Реплан: PLAN.TASK.ADD/UPDATE/DEPEND → PLAN.CPM.CALC → публикация статуса в Operator панелях.

## 7) KPI/SLA

- Processor e2e p95 ≤ 2000 ms; RS p95 ≤ 50 ms; AGE lag ≤ 60 s.
- CPI/SPI в допусках; incidents rate низкий; coverage links растёт.

### 7.1 Метрики мониторинга

- processor.stage_ms_{p50,p95}, processor.queue_len, processor.kind_error_rate{kind}.
- rs_actor.p95_ms, rs_actor.error_rate, rs_actor.throughput_rps, fallback_rate.
- age_sync_* (tick_ms_p95, lag_sec, merge_ms_p95, throughput_total).

## 8) Acceptance

- `INSPECTOR.RUN_ALL` зелёный; `PLAN.TASK.ADD` и `PLAN.CPM.CALC` успешно.
- Панели отображают актуальные метрики; алерты срабатывают корректно.

### 8.1 Тест‑кейсы (минимальный набор)

- DSL e2e: PROJECT.LIST/CREATE → PLAN.TASK.ADD ×N → PLAN.CPM.CALC.
- Coverage: `/api/admin/qlinks/coverage` возвращает непустые секции; dedup 200 OK; projection вставляет ≥1.
- RS p95 preview: `/api/admin/rs/report/p95?preview=true` — ошибки=0; canary_share соответствует флагам.

## 9) Примеры DSL

- Создать проект: `PROJECT.CREATE name="P40 Internal LLM Development" owner=468326902`
- Добавить задачи: `PLAN.TASK.ADD project_id=<PID> title="Task A" cpm_duration_days=2`
- Зависимости: `PLAN.TASK.DEPEND predecessor=<T1> successor=<T2> dep_type=FS`
- CPM: `PLAN.CPM.CALC project_id=<PID>`

### 9.1 Линковки

- Автолинк проекта: `QUANT.LINK.AUTO from_quant=<QID> to=project title="P40 Internal LLM Development" relation=supports`.
- Вручную к задачам: `QUANT.LINK from_quant=<QID> to_type=plan_task to_id=<TID> relation=implements`.

## 10) План внедрения

- Приёмка PLAN.TASK.ADD/CPM на PROD; дашборды node‑aware; отчёт нейро‑трейна; RS canary/AGE step‑up.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
