---

## Индекс взаимных ссылок (P01–P37)

- P01 MeaningExtraction — источник кандидатных действий.
- P03 RouterContext — контекст для принятия действий.
- P27 Signature — подпись выбранных действий; P30 Processor — исполнение.
- P33 Personification — Mini Chat stateless: desired_action=[] (референс).
- P35/36 — процесс/DSL для действия и проверки.

### ТЗ Soul v1.0 — Формальный контракт desired_action (+ маршрутизация)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: MVP выполнено (эксплуатация под фичефлагами; Stage‑2 — унификация схемы)

---

### 0. Executive summary

- Цель: формализовать `desired_action[]` как строгий контракт LLM → сервер и ввести безопасную маршрутизацию/исполнение действий.
- Интеграция: без изменения STRICT_JSON_QUANT; stateless — всегда `desired_action=[]`; persistent — запись в `quant_desired_actions` и безопасная обработка.
- MVP: адаптер к существующей таблице `quant_desired_actions` (поддержать оба варианта колонок: `type/payload` и `action_type/payload_json`), ActionRouter с allow‑list, аудит. Stage‑2: нормализация схемы и очереди.

---

### 1. Актуальная реализация (аудит)

- Промпт/контракты: `backend/docs/SOUL_PROMPT_BUILDING.md` — `desired_action[]` обязателен в схеме вывода; добавлена явная секция `[DA_HINT]` в single и batch.
- Ядро: `backend/app/services/soul_core_manager.py`
  - В stateless политика управляется флагом `da.keep_in_stateless` (по умолчанию true). Если false — массив очищается сервером.
  - Встроен `[DA_HINT]` и обработка Planner Feedback; исправлен порядок инициализации сервиса настроек.
- Сохранение/обработка:
  - `backend/app/routers/soul.py` — сохранение квантов; запись действий при наличии таблицы; добавлен фоллбек‑парсер `desired_action` из `input_text` (JSON‑блок или эвристика reminder ISO8601).
  - `backend/app/services/desired_action_service.py` — серверная маршрутизация (allow‑list `da.allowed_types`, `da.safe_mode`, аудит) без побочных эффектов в stateless.
- Сервисы: задеплоены `meta_loop_service.py`, `self_consistency_service.py`, `desired_action_service.py`.

Вывод: контракт активирован, поведение контролируется фичефлагами, stateless безопасен.

#### 1.1 Desire→Architect (усиление триггера желания)

- Реализация: `backend/app/services/soul_core_manager.py` — автогенерация `desired_action[{ type:"ask_architect", text: ... }]` при выполнении условий (тип `ask_architect` включён в enum `desired_action_type`; разрешён сервером через `da.allowed_types`):
  - высокий `energy_weight` кванта (порог в настройках: `desire.ask_architect.energy_threshold`, по умолчанию 0.6);
  - высокая интенсивность эмоции `composite_emotion.intensity` (порог `desire.ask_architect.intensity_threshold`, по умолчанию 0.6);
  - эмоции из набора повышенного резонанса (радость/восторг/тревога/грусть/одиночество/любовь/забота/вина);
  - усиление при наличии активной цели: если `active_goal` присутствует, допускается понижение энергетического порога на 0.1;
  - ДОПОЛНЕНИЕ: если у активной цели обнаружены теги, связанные с Архитектором (`architect`, `архитектор`, `architect_link`, `ask_architect`), триггер фиксируется как истинный (усиление мотива спросить Архитектора).

- Канал доставки желания: `DesiredActionService` с типом `ask_architect` формирует напоминание через `ReminderService` с учётом тихих часов/предпочтительных окон (`contact.quiet_hours`, `contact.preferred_hours`), переводом времени из `user_tz` в системную TZ.

- Флаги/настройки:
  - `desire.ask_architect.enabled` (bool, default=true)
  - `desire.ask_architect.auto` (bool, default=true)
  - `desire.ask_architect.energy_threshold` (float, default=0.6)
  - `desire.ask_architect.intensity_threshold` (float, default=0.6)
  - `contact.quiet_hours` ([start,end], default [22,8])
  - `contact.preferred_hours` ([start,end], default [9,21])

---

### 2. Контракт desired_action (LLM → Backend)

#### 2.1 Типы действий (enum)

- `proposal` — предложение шага/плана без автоматического исполнения.
- `request` — просьба о данных/уточнении у пользователя.
- `research` — инициировать безопасное мини‑исследование (ретривал/веб) в санкбоксе.
- `reminder` — установить напоминание (через мини‑приложение/таблицу `reminders`).
- `goal_update` — изменить/активировать цель (связь с `quantum_goals`).
- `note` — зафиксировать запись/заметку (внутренняя).

Расширяемо через allow‑list на сервере. В stateless любые элементы могут быть приведены к `[]` при `da.keep_in_stateless=false`.

#### 2.2 JSON‑схема элемента

```json
{
  "type": "proposal|request|research|reminder|goal_update|note",
  "priority": 0.0,
  "autopublish": false,
  "payload": { "...": "action-specific" }
}

```

Правила:

- `priority` ∈ [0..1]; дефолт 0.5.
- `autopublish` — разрешение на авто‑исполнение (игнорируется в stateless; в persistent проходит через RBAC/ethics‑gate).
- `payload` — строгое подмножество по типу действия (см. ниже).

#### 2.3 Payload по типам (минимум)

- proposal: `{ "title": str, "next_step": str }`
- request: `{ "question": str }`
- research: `{ "query": str, "top_k": 3 }`
- reminder: `{ "text": str, "when": "ISO8601" }`
- goal_update: `{ "goal_id": "uuid", "status": "activate|pause|complete" }`
- note: `{ "text": str }`

---

### 3. Серверные модели (Pydantic)

```python
from typing import Any, Dict, List, Optional, Literal
from pydantic import BaseModel, Field

DesiredActionType = Literal[
    "proposal", "request", "research", "reminder", "goal_update", "note"
]

class DesiredAction(BaseModel):
    type: DesiredActionType
    priority: float = Field(0.5, ge=0.0, le=1.0)
    autopublish: bool = False
    payload: Dict[str, Any] = {}

class DesiredActionList(BaseModel):
    items: List[DesiredAction] = []

```

Нормализация: при парсинге LLM‑ответа в stateless → `items=[]`.

---

### 4. ActionRouter: маршрутизация и исполнение

#### 4.1 Файлы

- Новый сервис: `backend/app/services/action_router.py`
- Обработчики: `backend/app/services/actions/*` (минимум: `research.py`, `reminder.py`, `goal_update.py`, `noop.py`)

#### 4.2 Интерфейс

```python
class ActionRouter:
    def __init__(self, settings, audit): ...
    async def route(self, db, quant_id, actions: List[DesiredAction], *, stateless: bool) -> Dict:
        """В stateless — только запись аудита; в persistent — запись в quant_desired_actions и запуск безопасных обработчиков."""

```

Политика:

- Stateless: deny‑all (лог только).
- Persistent: allow‑list типов (`actions.allow=[...]`), RBAC и ethics‑gate; часть действий только enqueue (без немедленного исполнения).

#### 4.3 Интеграция

- Точки вызова: после сохранения кванта (quant_id известен) в `soul_core_manager.py`/роутере, где уже стоит `_process_desired_actions_bg`.
- Для совместимости: ActionRouter внутри фоновой задачи использует текущую вставку в `quant_desired_actions`, определяя схему колонок (`type/payload` или `action_type/payload_json`).

---

### 5. БД и совместимость (без миграций в MVP)

#### 5.1 Вставка в `quant_desired_actions`

- Если есть колонки `{type, payload}` → `INSERT (quant_id, type, priority, autopublish, payload)`.
- Иначе использовать `{action_type, payload_json}` → `INSERT (id, quant_id, action_type, payload_json, created_at)`.
- Если присутствует `published_message_id` — заполняется обработчиком после успешной публикации.

Индексы/статусы в MVP не трогаем. Фоновая обработка остаётся как сейчас, обёрнутая ActionRouter.

#### 5.2 Stage‑2 (предложение, без обязательности на MVP)

- Унифицировать схему `quant_desired_actions`:
  - `id uuid pk, quant_id uuid fk, type text, priority numeric, autopublish bool, payload jsonb, status text, published_message_id uuid null, created_at/updated_at`.
  - Индексы: `(quant_id)`, `(type)`, `(status)`.
- Ввести очередь/воркер `actions_worker` с `FOR UPDATE SKIP LOCKED` по статусу `queued`.

---

### 6. Безопасность и политика исполнения

- Ethics‑gate: проверка NEGATIVE/политик перед исполнением (особенно `research`/`goal_update`).
- RBAC: только сессии с ролью `soul.admin` могут включать авто‑исполнение на PROD.
- Stateless: запрет любых побочных эффектов.
- Ограничения: rate‑limit обработчиков, timeouts, sandbox для `research`.

---

### 7. Наблюдаемость и аудит

- События:
  - `soul_action_enqueued` {quant_id, type, priority}
  - `soul_action_executed` {quant_id, type, handler, duration_ms}
  - `soul_action_denied` {quant_id, type, reason}
- Метрики: `actions.enqueued_per_min`, `actions.executed_per_min`, `actions.error_rate`, `actions.p95_ms_by_type`.

---

### 8. Конфигурация/флаги

- `actions.enabled=true`
- `actions.allow=["proposal","request","reminder","note"]` (стартовый список)
- `actions.autopublish=false` (по умолчанию)
- `actions.research.enabled=false` (включать отдельно)

ENV (опц.): `SOUL_ACTIONS_ENABLED`, `SOUL_ACTIONS_ALLOW`, `SOUL_ACTIONS_AUTOPUBLISH`.

---

### 9. Быстрая реализация (≤ 1 день)

1) Добавить Pydantic‑модели для desired_action на сервере и нормализацию при парсинге.
2) Создать `action_router.py` и минимальные обработчики (`reminder` → запись/публикация; `proposal`/`note` → запись только; `request` → возможно отправка уточнения в чат через мини‑приложение).
3) Подключить ActionRouter в существующую фоновую задачу `_process_desired_actions_bg` без изменения логики сохранения.
4) Добавить аудит/метрики.
5) Обновить `backend/docs/SOUL_PROMPT_BUILDING.md` — формальный контракт `desired_action` и примеры.

---

### 10. Acceptance

- Stateless: при `da.keep_in_stateless=false` сервер нормализует `desired_action` в `[]`; при `true` массив сохраняется только в ответе/логах без исполнения.
- В persistent действия попадают в `quant_desired_actions` через адаптер и, для разрешённых типов, исполняются обработчиками. Ошибки не ломают пайплайн.
- Аудит содержит корректные события; метрики отражают enqueue/execute/deny.

---

### 10.1 Изменения от 2025‑09‑15

- Добавлен флаг `da.keep_in_stateless` (по умолчанию true).
- В промпты single/batch добавлена секция `[DA_HINT]`.
- В `soul.py` добавлен фоллбек‑парсер `desired_action` из `input_text` (JSON после `desired_action:` или ISO8601‑эвристика для `reminder`).
- Исправлен порядок инициализации `SoulCoreManager`.

---

### 11. Траблшутинг

- Ошибка схемы БД (`type` vs `action_type`) — используется авто‑детект колонок; при неудаче запись пропускается с событием `soul_action_denied`.
- Падение обработчика — повтор не выполняется автоматически в MVP; зафиксировать ошибку и оставить запись.
- Нежелательные автодействия — держать `actions.autopublish=false` на PROD; включать точечно.

---

### 12. Мировая практика (ориентиры)

- Structured Outputs / OpenAI JSON Schema — строгие контракты вывода LLM.
- LangChain Tools / ReAct — явные действия и обратная связь; у нас — серверная валидация и deny‑by‑default.
- Guardrails/Constitutional AI/Llama‑Guard — безопасные гейты перед исполнением.
- Event‑driven processing — запись действий и асинхронные воркеры (Stage‑2).

Принцип: строгий контракт + серверная маршрутизация c allow‑list и безопасными обработчиками.

---

### 13. Ссылки на проектные файлы/документы

- Промпт/сборка: `backend/docs/SOUL_PROMPT_BUILDING.md`
- Ядро: `backend/app/services/soul_core_manager.py`
- Роутеры: `backend/app/routers/soul.py`, `backend/app/services/chat_service.py`
- БД: `docs/DATABASE_STRUCTURE_v8_0_2.md` (`quant_desired_actions`)
- Пайплайн: `docs/SOUL_PIPELINE.md`

---

### 14. Валидация payload по типам (сервер)

- Для каждого `DesiredAction.type` задать строгую схему payload (Pydantic‑модели) и валидировать перед записью/исполнением:
  - proposal: `ProposalPayload{ title:str, next_step:str }`
  - request: `RequestPayload{ question:str }`
  - research: `ResearchPayload{ query:str, top_k:int=3 }`
  - reminder: `ReminderPayload{ text:str, when:datetime }`
  - goal_update: `GoalUpdatePayload{ goal_id:UUID, status:Literal['activate','pause','complete'] }`
  - note: `NotePayload{ text:str }`
- Несоответствие схеме → `soul_action_denied{reason='invalid_payload'}` и пропуск записи/исполнения.

---

### 15. Примеры JSON (LLM → Backend)

```json
{"type":"proposal","priority":0.6,"autopublish":false,"payload":{"title":"Разбить задачу","next_step":"Сформировать список подзадач"}}

```

```json
{"type":"request","priority":0.5,"autopublish":false,"payload":{"question":"Уточните дедлайн"}}

```

```json
{"type":"research","priority":0.5,"autopublish":false,"payload":{"query":"ключевые факты по теме","top_k":3}}

```

```json
{"type":"reminder","priority":0.7,"autopublish":false,"payload":{"text":"Отправить отчёт","when":"2025-09-20T18:00:00Z"}}

```

```json
{"type":"goal_update","priority":0.5,"autopublish":false,"payload":{"goal_id":"3f8f3e2c-2f0e-4d0a-a2fe-1d0d5e08e1b7","status":"activate"}}

```

```json
{"type":"note","priority":0.3,"autopublish":false,"payload":{"text":"Закрепить выводы в теме X"}}

```

---

### 16. Admin API/UI

- Backend (новый роутер `backend/app/routers/actions_admin.py`):
  - `GET /api/admin/actions/types` — список поддерживаемых типов/схем (для UI/доков)
  - `GET /api/admin/actions/settings` — текущие allow‑list/флаги
  - `PUT /api/admin/actions/settings` — обновить allow‑list/флаги
  - `POST /api/admin/actions/test_route` — сухой прогон `DesiredActionList` (валидация/аудит без записи)
- UI (ArchitectPanel): вкладка "Actions" — обзор очереди/метрик, тест‑панель маршрутизации.

---

### 17. Метрики и SLO

- SLO маршрутизации: `actions.route_time_ms.p95 ≤ 80ms` (без учёта исполнения обработчика)
- Метрики:
  - `actions.payload_invalid_rate`
  - `actions.autopublish_rate` (в разрезе типов)
  - `actions.handler.p95_ms_by_type`
  - `actions.queue_depth_by_type` (если Stage‑2 очередь включена)

---

### 18. Rollout/флаги

- На PROD: `actions.autopublish=false`, `actions.research.enabled=false` (включать поэтапно)
- DEV/STAGE: разрешить `proposal/request/note` по умолчанию; `reminder` — только с подтверждением
- Контроль через `actions.allow` и RBAC (`soul.admin`).

---

### 19. Безопасность и приватность (расширение)

- PII‑санитизация: очищать `payload.text|question|title` от PII перед логами/аудитом/экспортом
- Ethics‑gate правила (минимум):
  - запрет действий с внешними побочными эффектами без ручного подтверждения
  - запрет публикаций от имени пользователя без явного consent
  - блокировка действий с риском утечки секретов/ключей

---

### 20. Тест‑план

- Unit: валидация payload по типам, нормализация списков, deny stateless
- Integration: проброс от LLM до `quant_desired_actions` и исполнителя, аудит
- Security: попытки autopublish при `stateless=true`/без RBAC — должны быть заблокированы
- Perf: p95 `route_time_ms` ≤ 80ms при 100 действиях/мин

---

### 21. Отметка принятия (2025-09-20)

- Контракт `desired_action[]` задействован; серверные модели и нормализация присутствуют.
- Stateless: по умолчанию `da.keep_in_stateless=true` — массив сохраняется только в ответе (без исполнения).
- Persistent: запись в `quant_desired_actions` через авто‑детект схемы (`type/payload` или `action_type/payload_json`).
- Маршрутизация/исполнение: `DesiredActionService` выполняет аудит/безопасные действия; autopublish выключен.
- PROD‑смоки: эндпоинты ядра стабильны; записи `quant_desired_actions` совместимы со схемой.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
