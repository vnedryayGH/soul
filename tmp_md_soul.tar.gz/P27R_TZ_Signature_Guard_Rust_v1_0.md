# P27R — ТЗ: Delivery Guard (Rust core) v1.0

Версия: v1.0
Статус: к внедрению (этап 2)

## 1) Назначение

Чистый валидатор цепочки обязательных шагов подписи (Signature v1) с нулевыми аллокациями на горячем пути.

## 2) Контракты

Вход:

```json
{ "required": ["svc.soul.preanalysis","svc.llm_client.send","svc.llm_client.recv","svc.parser.json_strict","svc.chat.reply_render"], "steps": ["..."] }

```
Выход:

```json
{ "ok": true, "missing": [] }

```
Коды ошибок: `guard_missing_steps`, `invalid_json_contract`.

## 3) SLA

p50 ≤ 0.5 ms; p95 ≤ 2 ms; zero‑alloc в горячем пути; отсутствие всплесков аллокаций.

## 4) Интеграция

- Транспорт: UDS/HTTP JSON, либо PyO3 вызов.
- Python вызывает валидатор перед выдачей ответа; при `ok=false` — блокировка выдачи, отчёт P27.

## 5) Наблюдаемость

Метрики: `p27_rs_validate_latency_ms` (hist), `p27_rs_missing_steps_total{step}` (counter).

## 6) Тесты

- Golden‑набор (≥50+/≥50−): корректные и нарушенные цепочки.
- Property/fuzz: случайные `steps[]`, дубликаты, большие размеры, юникод.

## 7) Безопасность

- Без `unsafe`. Лимиты длины `steps`/`required`. Таймаут общей проверки.

## 8) Acceptance

- Совпадение решений Rust и Python на golden‑наборах.
- Метрики и отсутствие 5xx; инспекторы `signature.required_steps.consistency` зелёные.

## Dual-language инварианты и гейты

- Инварианты: решения RS==Python на golden‑наборах; при mismatch — блок переводов `lang_state` выше shadow.

- Гейты переключений (Жандарм):
  - `shadow→canary`: p95 ≤ цель; `rs.parity` mismatches ≤ 0.5%/24h.
  - `canary→primary_fallback`: mismatches≈0; `guard_missing_steps=0`; soak 24h.
  - `primary_fallback→primary`: без фоллбэков 24–48h.

- Метрики: `p27_rs_validate_latency_ms`, `p27_rs_missing_steps_total{step}`.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
