# M05 — Lean Delivery (v1.0)

Цель: устранение потерь, быстрые циклы ценности.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Identify → Measure → Improve → Control.

Алгоритмы/метрики: VA/NVA, Lead Time, DORA, p95.

Роли: PM, Value Stream Owner, QA.

DSL: PLAN.TASK.ADD, KPI.SET, METHODOLOGY.SET, QUANT.LINK.AUTO, INSPECTOR.RUN_ALL.

Acceptance: KPI в БД; инспекторы зелёные; панели Lean.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
