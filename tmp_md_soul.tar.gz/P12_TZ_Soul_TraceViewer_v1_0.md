---

## Индекс взаимных ссылок (P01–P37)

- P27 Signature/Lineage — источник данных для просмотра.
- P30 Processor — просмотр событий и шагов.
- P33 Personification — Mini Chat трассы.
- P36 Hyperloop DSL — команды получения трасс/шагов.

### ТЗ Soul v1.0 — Трасс‑вьювер (Debug Dashboard)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: MVP backend реализован; UI/расширения — отложены (без миграций; Stage‑2 — причинность активируема флагом)

---

### 0. Executive summary

- Цель: обеспечить наглядный разбор любого ответа/кванта по шагам пайплайна: input → keywords → context → router → planner → tools → core → consistency/contradiction → quant → actions → persist, с привязкой к `trace_id`.
- Интеграция: только серверные агрегаторы поверх уже существующих событий аудита (`soul_*`) и (опц.) provenance; UI — новая вкладка в ArchitectPanel. БД не меняем в MVP.
- Результат: объяснимость, быстрый дебаг, экспорт трассы, ссылки на первичные сущности (message/quant/actions).

---

### 1. Актуальная реализация (аудит)

- Аудит/пайплайн: `docs/SOUL_PIPELINE.md` — события `soul_api_process_start/…/done`, `soul_llm_send/recv/error`, `soul_pipeline_enter/ok/error` и т.д.; таблица `soul_audit_log`.
- Ядро: `backend/app/services/soul_core_manager.py` — 4‑этапный pipeline + (по ТЗ) Planner 2.5/Consistency 4b.
- UI/админка: `frontend/src/pages/ArchitectPanel.tsx` — вкладки Dispatcher/metrics/queue уже есть.

Вывод: достаточно аудита, чтобы собрать трассу без миграций. Добавим агрегатор и UI‑вкладку.

---

### 2. Архитектура и точки интеграции

- Backend агрегатор трасс: `backend/app/services/trace_view_service.py` (новый).
- Admin API:
  - `GET /api/admin/traces/lookup?minutes=60&limit=200&event=optional` — недавние `trace_id` с краткой сводкой.
  - `GET /api/admin/traces/{trace_id}` — подробная трасса (см. модель ниже).
  - (опц.) `POST /api/admin/traces/{trace_id}/tag` — пометить (bookmark) трассу.
- Frontend: вкладка "Traces" в `ArchitectPanel` с поиском/фильтрами/деревом шагов и JSON‑вьювером.
- Источники данных: `soul_audit_log` (+ опц. `provenance_edges`, если включён Stage‑2 по provenance).

Provenance (Stage‑2):

- При активном флаге `provenance.enabled=true` агрегатор дополняет представление трассы ребрами из `provenance_edges` по `trace_id`/`quant_id`.
- API проверки (RBAC: `soul.admin`):
  - `GET /api/admin/provenance/trace/{trace_id}` — рёбра по трассе (ожидаются минимум `input`, `llm:response` в stateless сценариях).
  - `GET /api/admin/provenance/quant/{quant_id}` — рёбра по квант‑результату, если сохранён `quant_id`.
  - `GET /api/admin/provenance/export/openlineage/{trace_id}` — экспорт совместимый с OpenLineage.

---

### 3. Модели (Pydantic, сервер)

```python
from typing import Any, Dict, List, Optional
from pydantic import BaseModel

class TraceEvent(BaseModel):
    ts: str
    event_type: str
    description: Optional[str] = None
    meta: Dict[str, Any] = {}

class ToolUse(BaseModel):
    key: str
    duration_ms: int
    output_excerpt: Optional[str] = None

class PlannerFeedbackView(BaseModel):
    summary: Optional[str] = None
    signals: List[Dict[str, Any]] = []
    attachments: List[Dict[str, str]] = []

class ConsistencyView(BaseModel):
    confidence: Optional[float] = None
    variants_n: Optional[int] = None

class ContradictionView(BaseModel):
    is_contradict: Optional[bool] = None
    severity: Optional[float] = None
    evidence_count: Optional[int] = None

class QuantView(BaseModel):
    quant_id: Optional[str]
    thought_form: Optional[str]
    energy_weight: Optional[float]
    tags: List[str] = []

class ProvenanceEdgeView(BaseModel):
    stage: str
    source_type: str
    source_hash: Optional[str] = None
    weight: Optional[float] = None

class TraceView(BaseModel):
    trace_id: str
    user_id: Optional[int]
    input_text_excerpt: Optional[str]
    model_used: Optional[str]
    stages: List[str]
    planner: Optional[PlannerFeedbackView] = None
    tools: List[ToolUse] = []
    consistency: Optional[ConsistencyView] = None
    contradiction: Optional[ContradictionView] = None
    quant: Optional[QuantView] = None
    actions: List[Dict[str, Any]] = []
    provenance: List[ProvenanceEdgeView] = []
    events: List[TraceEvent]

```

Примечания: поля заполняются best‑effort из аудита/meta; PII удаляются санитайзером.

---

### 4. Реализация сервиса `TraceViewService`

- Файл: `backend/app/services/trace_view_service.py`
- Методы:
  - `lookup_recent(minutes:int, limit:int, event_filter:Optional[str]) -> List[{trace_id, started_at, user_id, brief}]`
  - `get_trace(trace_id:str) -> TraceView`
- Логика `get_trace`:

  1) Выбрать события из `soul_audit_log` по `trace_id` (упорядочить по ts).
  2) Сформировать `stages` по известным типам событий (`soul_pipeline_enter`, `soul_llm_send/recv`, `soul_plan_*`, `soul_tool_*`, `soul_uncertainty_estimated`, `soul_contradiction_found`, `soul_api_process_saved_quant`, ...).
  3) Восстановить `planner`, `tools`, `consistency`, `contradiction`, `quant`, `actions` из `meta`/описаний.
  4) (Если включён provenance Stage‑2) подтянуть `provenance_edges` по `trace_id|quant_id`.
  5) Санитизировать `input_text_excerpt`, `output_excerpt` (удалить PII/секреты/имена модулей).

Производительность: лимитировать выборку событий ≤ 500/трассу; пагинация lookup.

---

### 5. Admin API (роутер)

- Файл: `backend/app/routers/trace_admin.py` (новый)
- Эндпоинты (RBAC: `soul.admin`):
  - `GET /api/admin/traces/lookup`
  - `GET /api/admin/traces/{trace_id}`
  - (опц.) `POST /api/admin/traces/{trace_id}/tag`
- Ответы — модели `lookup`/`TraceView`.

### 5.1 Быстрый TRACE для architect_chat (инструкция)

- Как снять `trace_id` в Hyperloop DSL:

  1) Вызвать `POST /api/hyperloop/execute` с командой: `CORE.PIPELINE.RUN input_text="health check" WITH TRACE`.
  2) В ответе взять `signature.trace_id`.
  3) Получить подробные шаги: `TRACE.STEPS trace_id="<ID>"` через тот же эндпоинт DSL.

- Панель: во вкладке Traces доступен поиск по времени и просмотр шагов по `trace_id` (использует `GET /api/admin/soul/trace/signature/steps/by-trace`).

---

### 6. Frontend (ArchitectPanel)

- Файл: `frontend/src/pages/ArchitectPanel.tsx` (добавить вкладку "Traces")
- UI:
  - Фильтры: период (минуты), строка поиска по event_type, auto‑refresh (10с).
  - Таблица lookup: `trace_id`, время, краткое описание, user_id.
  - Деталь: дерево шагов (стадии), карточки Planner/Tools/Consistency/Contradiction/Quant/Actions; JSON‑вьювер `events`/`provenance`.
  - Кнопки: копия `trace_id`, экспорт JSON/MD.

---

### 7. Безопасность/приватность

- RBAC: только `soul.admin`.
- Санитизация: удаление PII/секретов из excerpts; тримминг до 200–300 символов.
- Ограничение исторического периода в lookup (например, ≤ 48ч).

---

### 8. Настройки/флаги

- `trace_view.enabled=true`
- `trace_view.lookup_limit=200`
- `trace_view.max_events_per_trace=500`
- `trace_view.sanitize_pii=true`

ENV (опц.): `SOUL_TRACE_ENABLED`, `SOUL_TRACE_LIMIT`.

---

### 9. Метрики/аудит (для самого вьювера)

- Метрики: `trace.lookup_count`, `trace.view_count`, `trace.export_count`, `trace.ms_build_trace`.
- Аудит: `trace_view_opened` {trace_id}, `trace_exported` {trace_id, format}.

---

### 10. Acceptance

- По `trace_id` строится полная трасса ≤ 1.5с (p95) на DEV.
- Дерево стадий отображается, доступны карточки Planner/Tools/Consistency/Contradiction/Quant/Actions.
- Экспорт в JSON работает; PII не попадает в UI/экспорт.
- Без миграций; при отключённом флаге UI вкладка скрыта.

Дополнительно при `provenance.enabled=true`:

- `GET /api/admin/provenance/trace/{trace_id}` возвращает непустой список рёбер (минимум 2 для stateless: `input`, `llm:response`).
- OpenLineage экспорт по трассе валиден (JSON.schema‑совместимый подмножество).
- В OpenAPI присутствуют пути `/api/admin/provenance/*`.

---

### 11. Траблшутинг

- Пустые трассы — нет событий: проверить, что `trace_id` прокидывается во все сервисы/аудит.
- Рёбра пустые — проверить флаг `provenance.enabled`, stateless запись минимальных рёбер и привязку `quant_id` в `soul.process`.
- Слишком длинные excerpts — настроить тримминг/санитизацию.
- Высокая латентность — кэшировать TraceView на короткое окно (10–30с), уменьшить `max_events_per_trace`.

---

### 12. Stage‑2 (опционально)

- Интеграция с Provenance (см. `Soul/TZ_Soul_Provenance_v1_0.md`): визуализация источников по слоям, граф вкладов.
- Линки на `messages/quants` с предпросмотром.
- Временная шкала с сегментами латентности по стадиям.

---

### 13. Мировая практика (ориентиры)

- LangSmith/W&B Traces — древовидные трассы LLM‑пайплайнов.
- OpenTelemetry traces — спаны/линки; мы реализуем лёгкий агрегатор по событиям.
- OpenLineage lineage‑графы — применимо в Stage‑2 (provenance).

Принцип: первый MVP на существующем аудите, затем расширение до причинно‑следственных графов.

---

### 14. Ссылки на проектные файлы/документы

- Аудит/пайплайн: `docs/SOUL_PIPELINE.md`
- Ядро: `backend/app/services/soul_core_manager.py`
- Админ‑панель: `frontend/src/pages/ArchitectPanel.tsx`
- Provenance: `Soul/TZ_Soul_Provenance_v1_0.md`
- Admin API: `backend/app/routers/provenance_admin.py`, `backend/app/routers/trace_admin.py`

---

### 15. SLO и алерты

- SLO: `trace.get_trace.p95 ≤ 1500ms` (DEV), `lookup.p95 ≤ 800ms`
- Алерты: `trace.get_trace.p95 > 2s` (10 мин), `lookup.errors_rate > 2%` (10 мин)

---

### 16. Rollout

- DEV: включить вкладку, собрать обратную связь
- STAGE: ограничить `max_events_per_trace=300`, включить авто‑refresh 10с
- PROD: включать по RBAC; экспорт JSON только для `soul.admin`

---

### 17. Статус реализации (итоги)

- Реализовано (MVP, сервер):
  - `backend/app/services/trace_view_service.py`: lookup/get_trace, PII‑санитайзинг, лимиты, кэш‑agnostic.
  - `backend/app/routers/trace_admin.py`: `GET /api/admin/soul/trace/lookup`, `GET /api/admin/soul/trace/by-trace` (RBAC: `soul.admin`).
  - Фоллбеки совместимости: при отсутствии колонки `meta` в `soul_audit_log` — безопасный ответ без 5xx.
  - Фильтр по времени исправлен на `created_at >= NOW() - (INTERVAL '1 minute' * :mins)`.
  - Фичефлаги: `trace_view.enabled`, `trace_view.lookup_limit`, `trace_view.max_events_per_trace`, `trace_view.sanitize_pii`.

- Отложено (после ТЗ‑12):
  - UI вкладка "Traces" в `ArchitectPanel` (lookup/detail/export) — причина: приоритет бэкенда, отсутствие готового макета.
  - `GET /api/admin/soul/trace/search` (фильтры/пагинация) — причина: минимально достаточный MVP.
  - Аудит `trace_view_opened/trace_exported` — причина: нет UI и сценариев экспорта.
  - Экспорт трассы в JSON/MD — причина: зависит от UI и аудита событий.
  - Совместимость схемы аудита: идемпотентное обеспечение `soul_audit_log.meta` + индексов — причина: на PROD унаследована схема без `meta`, что вызывало 500/502 при агрегации.
  - Стабилизация обратного прокси (nginx): локально (127.0.0.1:8000) lookup=200; через nginx ранее 502 при SQL‑ошибках — причина: ошибка агрегации приводила к 5xx, устранено фоллбеком, но нужно довести поведение и таймауты.

- Задачи на устранение (пост‑ТЗ):

  1) Добавить вкладку "Traces" в `frontend/src/pages/ArchitectPanel.tsx` (lookup/detail/export, авто‑refresh 10с).
  2) Реализовать `/api/admin/soul/trace/search` (фильтры: `trace_id/event_type/ts`, пагинация).
  3) Включить аудит `trace_view_opened/trace_exported` в `soul_audit_log` (best‑effort, PII‑safe).
  4) Сделать экспорт трассы (JSON) на сервере и в UI (кнопка Export).
  5) Идемпотентно обеспечить `meta jsonb` в `soul_audit_log` + индексы (DDL с `IF NOT EXISTS`), админ‑скрипт/эндпоинт совместимости.
  6) Nginx: проверить `proxy_read_timeout/proxy_send_timeout`, при необходимости уменьшить размеры ответов/временные окна для lookup.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
