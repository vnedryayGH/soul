---

## Индекс взаимных ссылок (P01–P37)

- P20/P33 — Mini App/Mini Chat операции (создание/отмена напоминаний/задач).
- P21 — мониторинг нарушений.
- P30 — исполнение с проверкой прав.

# P32 — ТЗ: RBAC & Subscriptions для Mini‑App/Web и LLM-лимитов

Версия: v1.0 (draft)
Источник: консолидация `docs/TZ_RBAC_v1.md` с привязкой к P20/P22/P23

## 0) Цели

- Единая ролевая модель (roles/permissions) и лимиты LLM по ролям/планам подписок.
- Панель Архитектора: CRUD ролей/прав, лимиты LLM, журналы.

## 1) Данные

- Таблицы: `roles`, `permissions`, `role_permissions`, `user_roles`, `subscription_plans`, `user_subscriptions`, `llm_limits`.
- Поведение: комбинирование ролей; эффективные лимиты — max по ролям.

## 2) API (админ)

- Роли: GET/POST/PUT/DELETE `/api/admin/rbac/roles`
- Права: GET/POST/PUT/DELETE `/api/admin/rbac/permissions`
- Связи: role‑permissions, user‑roles (GET/POST/DELETE)
- Лимиты LLM: GET/POST/PUT/DELETE `/api/admin/rbac/llm-role-limits`

## 3) Исполнение

- Middleware: загрузка ролей/прав/лимитов по `tg_id`/JWT; проверка разрешений на каждый запрос; проверка квот для LLM.
- При исчерпании квоты: 402 Payment Required + ссылка на апгрейд.

## 4) Интеграции

- P20 (бот‑платформа): маршруты Mini‑App; P22 (контракты OpenAPI); P23 (UI формы/грид «Роли×Формы»).

## 5) Метрики/Аудит/Безопасность

- Аудит изменений и отказов по лимитам; Zero‑Trust; rate‑limits.

## 6) Acceptance

- RBAC управляет видимостью UI и доступом к API;
- Лимиты LLM применяются корректно; панели/журналы отображают факты.

## 7) Регистрация: промокоды и подтверждение (консолидация из TZ_NP/TZ_TELEGRAM_AUTH)

- Роль `start`: доступ к экрану регистрации, отправка запроса админу.
- Роли назначаются: базовая по умолчанию; повышенные через промокод или подтверждение админом.
- Промокоды:
  - Таблица `promo_codes(id, code, plan_key, role_key, max_registrations, expires_at, is_active)`;
  - Таблица `promo_usages(id, promo_code_id, user_id, used_at)`; индексы по `code`, `expires_at`.
  - Валидация: активен, не истёк, не исчерпаны регистрации; атомарная фиксация использования.
- Запрос регистрации:
  - Таблица `registration_requests(id, user_id, comment, status[pending|approved|rejected], assigned_admin_id, created_at, processed_at)`.
  - Уведомление дежурному админу (configurable) + список заявок в UI.
- Политики согласия:
  - Флаги подтверждений на экране регистрации: согласие на ПДн, политика безопасности; ссылки управляются из настроек (P23 Settings UI).

## 8) UI/Процессы (P23 связка)

- Экран регистрации (Mini‑App): описание, чекбоксы согласий, поле комментария, поле промокода, кнопка «Зарегистрироваться».
- Админ‑UI: раздел «Регистрация»: список заявок, карточка пользователя (данные Telegram), approve/reject, журнал действий.
- Потоки:
  - Промокод → присвоение роли/плана, запись usage, уведомление пользователю.
  - Заявка → approve → присвоение роли/плана; reject → уведомление с шаблоном причин.
- Безопасность: все операции — через RBAC (`registration.manage`, `promo.manage`), аудит в `soul_audit_log`.

## Администрирование регистрации, промокоды и duty‑admin

Роли: Admin/Architect. Эндпоинты:

- `GET/POST /api/admin/settings` — служебные настройки (`registration.duty_admin_tg_id`, ссылки документов).
- `GET/POST/PUT/DELETE /api/admin/promo/*` — промокоды/активации.
- `GET/POST /api/admin/registration/*` — заявки (approve/reject).

Поток регистрации:

- Новый пользователь → роль `start` → экран регистрации (промокод, согласия, комментарий, desired_role/plan).
- Approve: снять `start`, назначить роль (по политике), синхронизировать `subscription_status`.
- Уведомления duty‑admin (опционально) по `registration.duty_admin_tg_id`.

Флаги CI/тестов: `DISABLE_BACKGROUND_TASKS`, `DISABLE_RBAC_SEED`, `DISABLE_EXTERNAL_NOTIFICATIONS`, `DISABLE_REQUEST_METRICS`.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
