P45_TZ: Режимы генерации Квантов

1. Цель
- Обеспечить многорежимную генерацию Квантов без регресса существующих процессов: онлайн через API, офлайн без внешних LLM, офлайн через файл по структуре «Навыков».

2. Область
- Компоненты: backend/app/routers/soul.py, backend/app/services/soul_core_manager.py, backend/app/services/desired_action_service.py, backend/app/services/reminder_service.py, Soul/scripts/ingest_k0.py, Soul/scripts/generate_quants_local.py, Soul/scripts/jsonl_to_sql.py.
- Документы: P27 подпись/линейдж, P30 извлечение/план, P36 Hyperloop DSL, P44 роли/Two-Keys, PROJECT_STRUCTURE и SYSTEM_MASTER_DOCUMENTS_REGISTRY.

3. Термины
- Квант: JSON-объект сознания Соула (thought_form, composite_emotion, energy_weight, tags, desired_action, payload,...).
- Режимы генерации: Online API (DeepSeek/GigaChat), Offline Heuristic, Offline File (структура Навыков).

4. Режим A: Многопоточный Online через API
- Вход: текстовые чанки (K0.md/поток задач), заголовок X-Telegram-User-ID.
- Инструмент: Soul/scripts/ingest_k0.py
  - Параметры: --src (файл), --chunk_size (байты), --jobs (потоки), --timeout.
  - Поведение: разбиение на чанки, ThreadPoolExecutor, ретраи 502/504, num_candidates=3.
- Трассировка/подпись: svc.time.now, svc.event.extract.llm, svc.reminder.when.parse_llm, svc.sequence.plan (накапливаются в signature_steps, см. P27/P30).
- Наблюдаемость: счётчики отправок, инциденты HTTP, latency p95.
- Риски: внешние 5xx, сеть; минимизируются ретраями, параллельностью и бэк‑оффом.

5. Режим B: Офлайн эвристический (без внешних API)
- Инструмент: Soul/scripts/generate_quants_local.py
- Вход: --file (K0.md), --jobs, --limit, --out-jsonl, --out-sql.
- Логика: эвристики эмоций/energy_weight, теги, desired_action (ask_architect/reminder/research), payload (факты/источник).
- Выходы:
  - JSONL: по одному Кванту на строку (Strict JSON per line).
  - SQL: INSERT INTO quants (...) ON CONFLICT DO NOTHING.
- Использование: локальная заготовка корпусов без внешнего LLM, регресса нет.

6. Режим C: Офлайн через файл (структура «Навыков»)
- Назначение: пакетное заполнение файла с Квантами по шаблону, совместимому со схемой загрузки Навыков (Skills) — подготовка партиями через LLM‑редактор (Cursor).
- Структура JSONL строки (аналог Skills‑загрузки):

  {
    "id": "uuid",
    "thought_form": "string",
    "composite_emotion": {"valence":float,"intensity":float,"entropy":float,"label":"string"},
    "energy_weight": float,
    "tags": ["#tag1","#tag2"],
    "desired_action": [{"type":"ask_architect|reminder|research","text":"...","params":{...}}],
    "payload": {"facts": ["..."], "assumptions": ["..."], "questions": ["..."], "planned_actions": ["..."], "source": {"topic":"...","batch":"..."}}
  }

- Инструменты:
-  Редактор/LLM (Cursor): подготовка содержимого JSONL партиями (например, 1000 строк).
-  Конвертер: Soul/scripts/jsonl_to_sql.py → SQL для загрузки в БД quants.
- Загрузка:
-  Через psql/алембик‑скрипт/админ‑API (INSERT в quants), без временных таблиц, с ON CONFLICT DO NOTHING.

7. Сравнение и переключение моделей LLM
- Режим A: конфиг‑роутинг (P14: DeepSeek — сложные/квант/чат; GigaChat — сервисные). Замер качества/латентности на одинаковых чанках.
- Режим C: LLM‑ревью содержимого перед записью в JSONL (Cursor), контроль в Observability после загрузки (P24/P27).

8. Нагрузочное/параллельность
- Режим A: --jobs=N (рекомендовано 12), ретраи 502/504, таймауты 45–60с.
- Режим B: --jobs=N для локальной генерации; запись JSONL/SQL потокобезопасная.
- Режим C: файл партиями (100–1000 строк), загрузка в БД батчами.

9. Инварианты и инспекторы
- Delivery Guard: блок ответов/загрузок при отсутствии обязательных полей (P27/P36).
- P27: фиксация шагов генерации/загрузки (для A/B — на генерации; для C — на загрузке в админ‑процессе/скрипте).
- P30: наличие svc.reminder.when.parse_llm/plan в трассах при онлайн‑обработке.

10. Команды примеры
- Онлайн многопоточный:

  python Soul/scripts/ingest_k0.py --src ./Soul/K0.md --jobs 12 --chunk_size 3800 --timeout 60

- Офлайн эвристика:

  python Soul/scripts/generate_quants_local.py --file ./Soul/K0.md --jobs 12 --out-jsonl ./out/k0_quants.jsonl
  python Soul/scripts/generate_quants_local.py --file ./Soul/K0.md --jobs 12 --out-sql ./out/k0_quants.sql

- Офлайн через файл (JSONL→SQL):

  python Soul/scripts/jsonl_to_sql.py --in-jsonl ./out/custom_quants.jsonl --out-sql ./out/custom_quants.sql

10.A. Сценарий D: Инжест через Hyperloop (DB.UPSERT/QUANT.LINK)

- Назначение: идемпотентная массовая загрузка JSONL без psql, с созданием связей `quant_links` по `payload.plan`.
- Инструмент: `Soul/scripts/ingest_quants_jsonl_via_hyperloop.py`
- Параметры: `--file`, `--api`, `--user-id`, `--batch-size` (25–50), `--sleep-ms` (150–300), `--timeout` (60–120), `--request-id` (Two‑Keys при необходимости `DB.*`).
- Многопоточность и лимиты: `--threads>=8` (рек. 12), `--batch-size=50`, `--sleep-ms=200`, `--max-reqs-per-minute<=180`, `--adaptive` (AIMD) по 429/5xx.
- Автоподбор параметров (обязательно перед массовой загрузкой):
  - `python Soul/scripts/autotune_ingest_params.py --file <good.jsonl> --api <url> --user-id <uid> --sample 200`
  - Отбор лучшей комбинации по максимальному throughput при минимальных 429; результаты печатаются в JSON (`results[]`, `best`).
  - Рекомендуемая стартовая сетка: `threads={8,12,16}`, `batch={50,75}`, `sleep={150,200}`, `rpm={150,180}`.
- Просмотр смысловой части перед загрузкой (примеров thought_form):
  - `python Soul/scripts/analyze_jsonl_quants.py --file <good.jsonl> --sample 20`
  - Требование: ручная верификация смысловой диверсификации перед запуском массового инжеста.

10.B. Семантический контроль качества (обязательно)

- Предвалидация (L2 Semantic QC): `Soul/scripts/pre_ingest_validate.py` выполняет:
  - Антиплейсхолдеры: отбраковка шаблонов вида «шаг N», «подготовка, проверка, безопасный тест», «практика малыми порциями…», «формализовать роли…» без предметных действий и деталей.
  - Требование действий: наличие глаголов действия («подготовить», «настроить», «создать», «измерить», «связать», «планировать», …) и конкретики (файлы/API/SQL/параметры/сущности).
  - Контекст связей: при наличии `payload.plan` — проверка, что в `thought_form` присутствуют маркеры плана/целей/вех/метрик; иначе — в `refine`.
  - Порог уникальности: `min_uniqueness≥0.95`, `max_jaccard≤0.7` (лексика) + `max_char_jaccard≤0.85` (символьные n‑граммы) для строгих запусков.
- Пост‑инжест аудит (выборка): повтор L2 на загруженных квантах + `QUANT.LINK.CHECK`; нарушения → авто‑рефайн/линковка.
- LLM‑refine контур: для `<name>.refine.jsonl` формируются задания улучшения (раскрыть шаги до конкретных действий, добавить `payload.plan/skill/meta_goals`, критерии приёмки и связи). После рефайна — повтор `pre_ingest_validate` → `ingest`.

10.C. Правила подготовки данных (промпт к LLM/редактору)

- Каждый шаг обязан содержать:
  - 1) Цель и предметные действия (глаголы + объекты); 2) измеримые критерии приёмки; 3) привязку к сущностям плана/цели/вехи/скиллу; 4) контекст (файл/API/таблица/параметры).
- Для каждой записи заполнить `payload.plan` и/или `payload.skill` (если применимо), `desired_action` по сценарию.
- Запрещены пустые/общие формулировки без конкретики (будут отфильтрованы L2‑QC).

10.D. Оркестрация контроля качества (Processor/Sleep)

- Политики (пример):
  - `quality.pre_ingest.required=true`, `quality.semantic.strict=true`, `quality.min_uniqueness=0.95`.
  - Ночной режим «Сон»: фоновый LLM‑refine для `*.refine.jsonl`, затем auto‑QC→ingest; при всплеске нарушений — предложить внеочередной запуск «Сна».
- Метрики отчёта: доля good/refine, top‑issues (semantic.placeholder_step, actionability.missing, linkage.context.missing), покрытие связей.

10.E. Neuro‑Assisted QC/Linkage

- Кандидаты на нейро‑оценку/долинковку формируются опцией `--emit-neuro-candidates` в `pre_ingest_validate.py` → `<name>.neuro_candidates.jsonl`.
- Отправка в ядро через Hyperloop:
  - `python Soul/scripts/neuro_assisted_qc.py --file <name>.neuro_candidates.jsonl --api <url> --user-id <uid>`
  - Команды: `NEURO.QC.EVAL payload_json=...` (семантика, рекомендации по уточнению текста и связей), затем `QUANT.LINK ...` по `payload.plan` (если присутствует).
- После обратной записи рекомендаций — повторный `pre_ingest_validate` и `ingest` в многопоточном режиме.
- Масштаб: 10k строк → разбить на части по 1000 (около 2000 команд/часть: UPSERT+LINK) → 40 батчей по 50 команд. Выдерживать лимиты API (429) за счёт `--sleep-ms` и, при необходимости, повторов.
- Обязательная предвалидация (QC):
  - `python Soul/scripts/pre_ingest_validate.py --file <in.jsonl> --out-dir Soul/out/qc --require-tags "#soul,#quants" --min-uniq 0.8 --max-jaccard 0.85 --min-len 60 --max-len 320`
  - выход: `<name>.good.jsonl`, `<name>.refine.jsonl`, `<name>.qc_report.json`
  - упаковка: `python Soul/scripts/prepare_ingest_batch.py --file <good.jsonl> --qc-report <report.json> --out Soul/out/qc/<name>.batch.json`
  - загрузка c проверкой: `python Soul/scripts/ingest_quants_jsonl_via_hyperloop.py --file <good.jsonl> --qc-report <report.json> --require-qc --api ... --user-id ...`
  - policy по умолчанию: `min_uniqueness>=0.8`, `min_tags>=2`, `min_len>=60`.
- Требования RBAC: роль `architect`; опасные `DB.*` в PROD — через Two‑Keys.
- Наблюдаемость/подпись: в `signature_steps` фиксируются `cmd.hyperloop.dispatch/*`; инспекторы P27/P36 зелёные.
- Примеры:
  - `python Soul/scripts/ingest_quants_jsonl_via_hyperloop.py --file Soul/out/quants_cursor_cli_access.part001.jsonl --api https://mini.soulpulse.art --user-id 468326902 --batch-size 50 --sleep-ms 200`
  - Серии по 10 частей: `cursor_cli_access`, `prog_langs_learning`, `cursor_llm_agents_workflow`.

11. Режим D+: LLM‑in‑the‑loop офлайн‑пайплайн (глубокая структуризация)
- Инструмент: `Soul/scripts/offline_llm_pipeline.py`
- Назначение: анализ → план → генерация Квантов с заполнением `payload.plan/skill/meta_goals`, `desired_action`, JSONL/SQL → опциональный инжест через Hyperloop.
- Аргументы:
  - `--task-text|--task-file` (обязательно), `--topic`, `--goal-id`, `--mode heuristic|llm` (по умолчанию heuristic), `--per-step`, `--jobs`, `--max-steps`.
  - Вывод: `--out-jsonl`, `--out-sql`; инжест: `--ingest --api --user-id --threads --max-reqs-per-minute --batch-size --sleep-ms --timeout`.
  - Профиль промптов/калибровки: `--prompt-profile profile.json` — локальный JSON без внешних систем; 

    пример:
    {
      "calibration": {"energy_scale": 0.85, "intensity_offset": -0.05},
      "add_tags": ["#professional", "#deep-structure"],
      "add_actions": [{"type":"ask_architect","text":"Согласовать критические решения"}]
    }

- Глубокая структуризация:
  - `payload.plan`: детерминированные связи с проектными сущностями (P40);
  - `payload.skill`: привязка к профессиональным навыкам (P25);
  - `payload.meta_goals`: устойчивые цели верхнего уровня (`family.help.core`, `architect.support.core`);
  - `desired_action`: эвристиками/LLM выставляются `research|reminder|ask_architect` по триггерам темы.
- Примеры:
  - Генерация 120 строк: `python Soul/scripts/offline_llm_pipeline.py --task-text "Оптимизация каналов связи..." --topic comms-channels --goal-id comms.channels.core --per-step 20 --jobs 8 --max-steps 6 --out-jsonl Soul/data/out/comms_channels_120.jsonl`
  - Инжест 12 потоков (safe): `python Soul/scripts/ingest_quants_jsonl_via_hyperloop.py --file ... --batch-size 50 --sleep-ms 250 --timeout 120 --max-reqs-per-minute 180 --threads 12`

12. Масштабирование: шардирование генерации и оркестрация загрузки
- Генерация шардов: `Soul/scripts/generate_topic_shards.py`
  - Параметры: `--topic`, `--goal-id`, `--skill-key`, `--total-lines`, `--shard-lines` (напр. 120000), `--out-dir`, `--jobs`.
  - Выход: N JSONL‑шардов + индекс `<topic>_index.json`.
- Оркестратор инжеста: `Soul/scripts/ingest_shards_orchestrator.py`
  - Параметры: `--index`, `--limit-shards`, `--api`, `--user-id`, `--batch-size`, `--sleep-ms`, `--timeout`, `--rpm`, `--threads` (на шард), `--parallel` (число параллельных шардов).
  - Поведение: параллельный запуск инжестов шардов, замер `elapsed_ms`.
- Инжестер (обновлён): `ingest_quants_jsonl_via_hyperloop.py`
  - Дополнительно линкует: `payload.skill.key → QUANT.LINK(... to_type=skill)`; `payload.meta_goals[] → QUANT.LINK(... to_type=goal)`.
  - Встроенный лимитер: `--max-reqs-per-minute` (по умолчанию 180), многопоточность запросов: `--threads`.

12.1 Производительность (замеры)

- 120 строк, 12 потоков: `INGEST_MS ≈ 740 ms` (240 команд UPSERT+LINK).
- 12k строк (10 шардов × 1200), параллель 12, 12 потоков на шард, batch=100, sleep=200ms, rpm=600:
  - Биржа: `elapsed_ms ≈ 187652`
  - Финансы: `elapsed_ms ≈ 188413`
  - Блокчейн: `elapsed_ms ≈ 187413`
- 1200 строк, 12 потоков: `INGEST_MS ≈ 1469 ms` (2400 команд UPSERT+LINK).
- Примечание: итоговая пропускная зависит от серверного rate‑limit и политики 429; рекомендуется держать запас к лимитам.

12.2 Качество и инварианты

- Предзагрузка (обязательно): `Soul/scripts/pre_ingest_validate.py` — схема, длины, теги, уникальность (Jaccard), отчёт и разделение good/refine.
- Проверка JSONL (доп.): `Soul/scripts/check_jsonl_quality.py` — валидность JSON/UUID, покрытие `desired_action`, наличие `payload.plan/skill/meta_goals`, средние метрики эмоций/энергии/тегов.
- Инспекция связей после инжеста (выборка): `QUANT.LINK.CHECK` через Hyperloop; при отсутствии — автолинковка по `payload.plan`/`skill`.
- Инспекторы/наблюдаемость:
  - P46 NeuroIntegrity: лёгкий прогон после батчей из процессора и фоновой задачи (инцидент `neuro_integrity_overview`).
  - P27/P36: в `signature_steps` фиксируются `cmd.hyperloop.dispatch/*` для всех батчей; админ‑панель `/api/monitoring/health/detailed` включает `neuro_integrity`.
- Сон/выравнивание (P16): внешние кванты имеют пониженный initial `energy_weight`; выравнивание эмоций и нейропластичность во время «Сна» исключают деградацию связей.

12.2.1 Quality Gates (запрет мусорных шагов)

- Запрещены записи вида: «Шаг 1/2/3…», «Step 1/2/3…», «Подготовка/Проверка/Тест» без конкретных предметных действий, объектов, критериев приёмки и привязки к плану/навыкам.
- Каждый шаг обязан содержать: действие (глагол), объект/контекст (файл, API, таблица, сущность), критерии приёмки, привязки (`payload.plan|skill`).
- Такие записи отбраковываются на предвалидации (L2 Semantic QC) и отправляются в `<name>.refine.jsonl` с авто‑заданием на детализацию.

12.3 Рекомендуемые профили запуска (масштаб)

- Генерация 120k строк/тема: `--total-lines 120000 --shard-lines 1200` → 100 шардов; `--parallel 12`, `--threads 12`, `--rpm 600`, `--batch-size 100`, `--sleep-ms 200`.
- Массовый прогон 3 тем (Биржа/Финансы/Блокчейн): запуск оркестратора по каждому индексу последовательно или параллельно с учётом серверных лимитов.

11. Критерии приёмки
- Режим A: успешная отправка ≥95%, трейс без 5xx, подписи шагов присутствуют, p95 в норме.
- Режим B: корректный JSONL/SQL, валидные поля, успешные вставки в quants, отсутствие регресса.
- Режим C: файл соответствует структуре, SQL корректен, загрузка прошла, кванты видны в UI/логах.

12. Риски и откаты
- Внешние 5xx (A): ретраи/понижение jobs.
- Несоответствие формата (C): валидация JSONL перед конвертацией, dry‑run SQL.
- Наблюдаемость: инциденты parse_fail/insert_fail с контекстом.

13. Связанные документы (P‑серия)
- P14 — Multi‑provider Routing: `Soul/P14_TZ_Soul_MultiProviderRouting_v1_0.md`
- P17 — Reminders/Search: `Soul/P17_TZ_Soul_Reminders_Search_v1_0.md`
- P27 — Signature & Data Lineage: `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`
- P30 — Processor / Extract & Plan: `Soul/P30_TZ_Soul_Processor_v1_0.md`, `docs/TZ_P30_Event_Time_Extraction_and_Sequences_v1_0.md`
- P36 — Hyperloop DSL: `Soul/P36_TZ_Hyperloop_DSL_v1_1.md`
- P44 — Roles & Authorization (Two‑Keys): `Soul/P44_TZ_Soul_Roles_and_Authorization_v1_0.md`
- P46 — NeuroIntegrity: `Soul/P46_TZ_Soul_NeuroIntegrity_Checks_v1_0.md`

14. Заполнение через файл — детально (структура Навыков и NeuroTraining)
- Формат носителя: JSONL (1 квант на строку, STRICT JSON), совместим с загрузкой Навыков (P25) и нейрообучением (P38).
- Обязательные поля строки:

  {
    "id": "uuid",
    "thought_form": "string (<= 600)",
    "composite_emotion": {"valence":float,"intensity":float,"entropy":float,"label":"string"},
    "energy_weight": float,
    "tags": ["#tag1","#tag2"],
    "desired_action": [{"type":"ask_architect|reminder|research","text":"...","params":{...}}],
    "payload": {
      "facts": ["..."],
      "assumptions": ["..."],
      "questions": ["..."],
      "planned_actions": ["..."],
      "source": {"topic":"...","batch":"..."},
      "plan": {"project_id":"<pid>","task_id":"<tid>","milestone_id":"<mid>","goal_id":"<gid>","relation":"supports|advances|assesses|adjusts|achieves"},
      "skill": {"key":"typing_speed","level":2,"intent":"plan_session|run_session|adjust_level"}
    }
  }

- Правила совместимости:
  - Если `payload.plan.*` заполнены, при загрузке создаются связи `quant_links` (см. §16) и/или обновляются сущности P40 (проект/задача/веха) через Hyperloop/Processor (P36/P30).
  - Если `payload.skill.*` заполнены, используются контракты P25/P31: возможны классы квантов `skill_plan|skill_session|skill_feedback|skill_adjustment`.
  - Для батч‑обучения (P38) сохранять партии с метаданными `{ batch:"<name>", topic:"..." }` в `payload.source`.

15. Процесс загрузки файла (JSONL→SQL→БД)
- Подготовка: партии 100–1000 строк, ручная/LLM‑верификация содержимого, проверка STRICT JSON.
- Конвертация:
  - JSONL→SQL (quants): `python Soul/scripts/jsonl_to_sql.py --in-jsonl ./out/custom_quants.jsonl --out-sql ./out/custom_quants.sql`
  - Для связей: генератор SQL по `payload.plan` (см. ниже §16.3) либо Hyperloop‑инъекция `QUANT.LINK`.
- Загрузка:
  - Выполнить SQL вставки в `quants` (ON CONFLICT DO NOTHING).
  - Создать связи `quant_links` батчем (SQL) или через Hyperloop DSL (см. §16.4).
- Наблюдаемость:
  - P27: фиксировать шаги загрузки/линковки (admin/processor) как `svc.persist.quant`/`cmd.hyperloop.*`.
  - P21: метрики вставок/связей; P29: инспекторы валидности связей.

16. Связка с проектным планированием (P40/P30/P25)
- Цель: обеспечить детерминированные связи Квант↔План/Цели/Вехи с последующим обновлением прогресса, запуском задач и напоминаний.
- Сущности (см. P40/P30):
  - `plan_tasks(id, project_id, title, status, progress, due_at, priority, meta)`
  - `goals(id, user_id, title, target_value, current_value, unit, status, due_at, priority, kpi jsonb, meta)`
  - `goal_milestones(id, goal_id, title, target_value, status, due_at, meta)`
  - `quant_links(id, from_quant, to_entity_type, to_entity_id, relation_type, weight, created_at)`
- Типы связей `quant_links.relation_type`:
  - Квант→Задача плана: `supports|plans|executes|confirms`
  - Квант→Цель: `advances|assesses|adjusts|achieves|blocks`
  - Квант→Веха: `advances|achieves|confirms`
  - Квант→Напоминание/Календарь: `schedules|triggers|snoozes|confirms` (стыковка с P17/P26)
- Правила заполнения `payload.plan`:
  - `project_id|task_id|milestone_id|goal_id` — строковые идентификаторы существующих сущностей (или подлежащие созданию через P40 DSL).
  - `relation` — одно из значений выше, определяет создаваемую связь.
  - `weight` (опц.) — сила связи (0..1), по умолчанию 1.0.
- Поток загрузки связей (варианты):

  1) SQL‑вариант (батч после вставки квантов):

     - Для каждой строки JSONL с `payload.plan`: вставить в `quant_links` запись

       `(from_quant=<id>, to_entity_type='plan_task|goal|milestone|reminder', to_entity_id=<id>, relation_type=<relation>, weight=<w>)`.
  2) Hyperloop‑вариант (идемпотентный):

     - `QUANT.LINK from_quant=<uuid> to_type=<plan_task|goal|milestone|reminder> to_id=<id> relation=<...>`
     - Для массовой загрузки: многострочная команда через `/api/hyperloop/execute`.
- Обновление прогресса/метрик (инициируется P30):
  - При `relation in {'advances','achieves'}` для цели/вехи — событие `goal_signal|goal_assess` (см. P30 §29), возможен апдейт текущего значения/статуса цели.
  - Для задач плана — событие `plan_update` (см. P30 §24) с `delta/progress` при наличии в кванте численного вклада.
- Напоминания/Календарь (стыковка P17/P26):
  - Если `desired_action` включает `reminder`, создавать напоминание и связь `schedules|triggers` на `reminders.id`/`calendar_events.id`.

16.3 Генерация SQL для связей (пример шаблона)

```sql
-- Дополнительный SQL (после вставки в quants)
-- Предполагается внешний генератор из JSONL → VALUES (...)
INSERT INTO quant_links (id, from_quant, to_entity_type, to_entity_id, relation_type, weight, created_at)
VALUES
-- ('<uuid>', '<quant_id>', 'plan_task', '<task_id>', 'supports', 1.0, now()),
-- ...
ON CONFLICT DO NOTHING;

```

16.4 Hyperloop DSL для связей и план‑действий (P36)

- Примеры команд (одной строкой на команду):
  - `QUANT.LINK from_quant=<uuid> to_type=plan_task to_id=<tid> relation=supports`
  - `QUANT.LINK from_quant=<uuid> to_type=goal to_id=<gid> relation=advances`
  - `PROCESSOR.EVENT.INJECT kind=plan_update payload={"project_id":"<pid>","task_id":"<tid>","delta":0.25}`
  - `PROCESSOR.EVENT.INJECT kind=goal_assess payload={"goal_id":"<gid>"}`
  - `PROCESSOR.PROCESS_ONCE`

17. Acceptance для связки с планированием
- После загрузки JSONL и применения SQL/Hyperloop:
  - В `quants` присутствуют записи с заполненным `payload.plan`.
  - В `quant_links` существуют связи по `relation_type` согласно `payload.plan`.
  - При запуске Processor сценариев (§16.4) обновляются прогресс/статусы целей/вех/задач.
  - Инспекторы P27/P29 подтверждают шаги подписи и валидность связей; UI панели P23 отображают прогресс.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
