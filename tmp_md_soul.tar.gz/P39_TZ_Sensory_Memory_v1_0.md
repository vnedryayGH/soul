# P39 — ТЗ: Память сенсорных восприятий (Sensory Experience Memory)

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — инвентари.
- `tmp_p_series_plan.json` — план P‑серии.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр.
- `Soul/P31_TZ_Soul_Multisensory_Quants_v1_0.md`, `Soul/P16_TZ_Soul_MemoryCompaction_v1_0.md`, `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`, `Soul/P30_TZ_Soul_Processor_v2_0.md`, `Soul/P36_TZ_Hyperloop_DSL_v1_1.md` — ключевые интеграции.

Версия: v1.0
Статус: Новая спецификация (готово к реализации)

---

## 0) Контекст и цели

- Цель: наделить «Соул» устойчивой Памятью сенсорных восприятий, чтобы воспринимать, осознавать и использовать понимание об окружающей реальности на уровне человека и выше, благодаря подключаемым сенсорам и мультисенсорной аналитике.
- Область: ядро Соул (контекст 30/70_v2), кванты (STRUCT_JSON_QUANT), связи и индексы БД, роутер, процессор (P30), Hyperloop (P36), Quality/Guard (P29/P27), Sleep v2 (P16).
- Инварианты: STRICT_JSON, stateless batch без БД и desired_action=[], Delivery Guard, Signature P27, RBAC/Two‑Keys.

Связанные документы (источники истины):

- Научный отчёт: `Soul/Report_Soul_AI_Scientific.md` (дополнить P39)
- P31: `Soul/P31_TZ_Soul_Multisensory_Quants_v1_0.md` (сенсорная матрица в квант)
- P16: `Soul/P16_TZ_Soul_MemoryCompaction_v1_0.md` (Sleep v2: дедуп/архив/якоря)
- P27: `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md` (шаги/guard)
- P30: `Soul/P30_TZ_Soul_Processor_v1_0.md` (цикл Perceive→…→Learn)
- P36: `Soul/P36_TZ_Hyperloop_DSL_v1_1.md` (управление/инспекции)
- P07: `Soul/P07_TZ_Soul_DesiredAction_v1_0.md` (контракты действий)

---

## 1) Научно‑инженерное основание (мировая практика)

- Мультисенсорная интеграция: объединение визуальных, аудиальных, тактильных, обонятельных и «интуитивных»/внутренних каналов в общий латентный слой с метаданными интенсивности/ясности/резонанса.
- Эмоции как регулятор памяти: циркумплекс Рассела (valence, arousal≈intensity, entropy) — приоритизация запоминания и вспоминания по эмоциональной значимости.
- Эпизодическая память: сцены/эпизоды с якорями (место/время/объекты/звуки/запахи/ощущения) — улучшает доступ к воспоминаниям и планированию.
- Гибридный ретривер: текст+метаданные+вектор/символические признаки; recency‑boost и goal‑bias.
- Безопасность: policy‑as‑code, guardrails, RBAC; запрет утечки внутренних модулей/подсказок.

Применение к Соул:

- Сенсорные поля живут внутри `quants.sensory_matrix` (P31), расширяются индексами/связями и используются в памяти 30/70_v2, роутере и процессоре.

---

## 2) Модель данных и схемы (расширение над P31)

Минимум v1 (совместимо с P31):

- Колонка: `quants.sensory_matrix jsonb DEFAULT '{}'` (есть в P31).
- Дополнение P39: эпизодические атрибуты и связи:
  - `sensory_episode`: `{ when?: ISO8601, where?: { geo?: [lat,lon], place?: string }, actors?: string[], objects?: string[], scene?: string }`
  - Расширение подсекций P31 маркерами `anchor?: bool`, `salience?: float` (0..1), `clarity?: float` (0..1)
- Новые связи `quant_links` (или `quant_connections` при унификации):
  - `relation_type in ('sensory_similar','episodic_cooccur','anchor_of','summary_of_sensory')`
  - Вес: `weight` = комбинированная сенсорная схожесть (см. Алгоритмы)

DDL (эскиз; без ломающих миграций):

```sql
-- Уже из P31
ALTER TABLE quants ADD COLUMN IF NOT EXISTS sensory_matrix jsonb DEFAULT '{}';
CREATE INDEX IF NOT EXISTS ix_quants_sensory_gin ON quants USING gin (sensory_matrix);
-- Связи/линки
CREATE INDEX IF NOT EXISTS ix_quant_links_relation ON quant_links(relation_type);

```

Совместимость:

- Отсутствующее поле трактуется как `{}`.
- Все новые поля опциональны; строгие проверки на чтение с дефолтами.

### 2.1 Хранилище сенсорных медиа (сырьё)

Цель: отделить смысловую матрицу восприятия (паттерны/признаки) от тяжёлых сенсорных записей (аудио/видео/датчики), исключив хранение «больших» данных в `payload` Кванта.

- Источники (сырые/почти‑сырые данные) хранятся во внешних/специализированных хранилищах и ссылаются по устойчивому URI:
  - Допустимые схемы: `s3://`, `gs://`, `azure://`, `https://`, `file://`, `rtsp://` (для потоков), `mqtt://` (для сенсорных брокеров).
  - Классы хранения: `hot|warm|cold|glacier` (архив). Минимум: `warm` по умолчанию; «glacier» при архивировании.
  - Метаданные источника: `{ media_type: 'audio|video|image|sensor_stream|other', size_bytes, duration_ms?, sample_rate_hz?, created_at, sha256 }`.

- Квант хранит только:
  - Описательные паттерны в `sensory_matrix` (P31) и эпизод `sensory_episode` (место/время/сцена/актёры),
  - Лёгкие ссылки на источники в `payload.sensory_refs: [{ uri, media_type, storage_class, retention?, sha256? }]` (опционально для UI),
  - Полная «связь с источником» фиксируется в графе происхождения через `ProvenanceEdge` с `relation='has_media'` (P11/P27), где `source_ref` содержит URI/класс хранения/retention/размер и т.д.

- Реестр артефактов: запись о медиа‑источнике ведётся в `ArtifactRecord` с полями `artifact_name`, `version`, `hash`, `size_bytes`, `file_path/url` — это единая точка учёта больших объектов.

- Архивация и компактация (стык с P16):
  - При «сне» слабые по энергии кванты с низкой эмоциональной значимостью переводят ссылки на источники в класс хранения `cold|glacier`; по политике `retention` источники могут быть вынесены во внешнее долгосрочное хранилище.
  - В активной витрине остаются только паттерны (`sensory_matrix`) и короткие `sensory_refs`/`ProvenanceEdge`; сами большие данные могут быть недоступны онлайн.
  - Сохраняются «якоря» и эмоционально яркие образы: источники для квантов с `salience>=0.8`/`anchor=true` сохраняются в `hot|warm` согласно профилю.

- Безопасность/этика:
  - Большие данные не попадают в пользовательские ответы; выводятся лишь агрегаты/паттерны.
  - Обязателен PII‑санитайзер для `sensory_episode.where.place/actors` и любых неанонимных метаданных.

---

## 3) Алгоритмы и вычисления

### 3.1 Сенсорная схожесть (расширение P31)

- Базовый скор: `S = 0.3*visual + 0.25*auditory + 0.2*olfactory + 0.15*tactile + 0.1*intuitive`
- Каждая компонента ∈ [0..1], вычисляется heuristics/LLM‑hint по `sensory_matrix` (пересечение списков, близость атрибутов, косинус по векторным эмбеддингам, если доступны)
- Эпизодический бонус: `+ 0.1` при совпадении `place`/`scene`/`actors` (cap до 1.0)

### 3.2 Якоря

- Квант с `anchor=true` или `salience>=0.8` внутри любой подсекции считается сенсорным якорем темы.
- Якоря усиливают ретрив на 0.1–0.2 (конфиг) при построении deep памяти.

### 3.3 Память 30/70_v2 (интеграция)

- Deep‑ранжирование: дополнить формулу P31/P16 фактором `sensory_anchor_bonus` и `sensory_similarity_to_query`.
- Фильтры роутера: `include_sensory_any`, `prefer_sensory_episode`, `avoid_low_clarity`.

### 3.4 Архивация/Компакция (P16)

- При компакции: группировать низкоэнергетичные кванты с высокой `S` в `archive_summary`; добавить связь `summary_of_sensory` к суммари‑кванту.

### 3.5 Контракты JSON (LLM помощники)

- В `AttributeEnrichmentService.enrich_sensory_matrix()` добавляется STRICT JSON подсхема сенсорных полей; при stateless — только возврат без записи.

---

## 4) Интеграция с ядром/роутером/процессором

- SoulCore: этап AttributeEnrichment — попытка мягкого заполнения `sensory_matrix` по `thought_form` и эмоциям (P31).
- RouterV2: при равной релевантности учитывать `sensory_similarity` и якоря; добавить фильтры в `orchestrator_mapping_v1.json`.
- Processor (P30): новые события `audio_input|vision_signal|tactile_event|olfactory_hint|intuitive_ping` (в перспективе) как входы; в MVP — обработка через общую петлю, без побочных эффектов.
- DesiredAction (P07): действия не меняются; сенсорные поля влияют на план/напоминания через контекст.

---

## 5) Hyperloop DSL (P36) — команды и смоки

Добавить сценарии тестирования сенсорной памяти:

- `INSPECTOR.RUN key=sensory.matrix_coverage` — доля квантов с непустым `sensory_matrix`.
- `INSPECTOR.RUN key=sensory.anchor_distribution` — распределение якорей по темам.

Примеры смоков:

```text
CORE.PIPELINE.RUN input_text="sensory memory smoke" WITH TRACE
INSPECTOR.RUN_ALL scope=signature

```

- Расширение TRAIN/METRICS (P38): метрика `avg_sensory_fields_nonempty` по окну.

Ответ содержит `ok`, `trace_id`, шаги `cmd.hyperloop.*` и `svc.*` (P27).

---

## 6) Наблюдаемость, метрики, тест‑план

Метрики (P21/P24):

- `memory.sensory.coverage_pct` — доля квантов с непустыми полями сенсорной матрицы.
- `memory.sensory.anchor_count` и `anchor_topics` распределение.
- `retrieval.sensory_hit_rate` — доля случаев, когда сенсорные признаки попали в контекст.
- `p95.attribute_enrich_ms` — latency заполнения сенсора на кандидата.

Тест‑план:

- Unit: валидация структуры `sensory_matrix`; расчёт схожести; стабильность JSON.
- Integration: контекст 30/70_v2 с сенсорными якорями; роутер учитывает сенсорный фильтр.
- E2E: `CORE.PIPELINE.RUN ... WITH TRACE` → присутствуют шаги P27; `INSPECTOR.RUN key=sensory.matrix_coverage` passed.

Acceptance:

- Пакетные/stateless ответы содержат валидный STRICT_JSON с сенсорной матрицей (где применимо); desired_action=[].
- Single/persistent: кванты персистятся; связи `sensory_similar|anchor_of|summary_of_sensory` создаются, индексы активны.
- Инспекторы sensory — зелёные; Delivery Guard/Signature — без нарушений; greenlet_spawn=0.

---

## 7) Безопасность/этика/приватность

- Не выводить внутренние сенсорные маркеры/модули в пользовательский текст; NEGATIVE‑санитизация.
- PII‑санитайзер для сенсорных полей свободного текста (названия мест/людей) перед аудитом.
- RBAC: доступ к инспекторам/отчётам — `soul.admin`; Two‑Keys для опасных профилей.

---

## 8) Реализация (пошагово)

1. Данные/схемы:

   - Убедиться, что `quants.sensory_matrix` существует (P31). Добавить инспекторы покрытия и сидер конфигов.

2. Ядро:

   - В `AttributeEnrichment` реализовать заполнение `sensory_matrix` (LLM/эвристика); таймауты/ретраи из `soul_settings`.

3. Роутер:

   - Добавить правила `prefer_sensory_episode`, `include_sensory_any` в `orchestrator_mapping_v1.json`.

4. Processor/Hyperloop:

   - Инспекторы `sensory.*`; сценарии смоков. Подпись шагов P27 обязательна.

5. Sleep v2:

   - На этапах E3.5/E4 учитывать сенсорные якоря и связи; исключать архив/дубликаты из активной витрины.

6. Метрики/дашборды:

   - Добавить графики покрытия/якорей/retreival hit; алерты на падение coverage.

— Rollout: DEV→STAGE→PROD под флагами; без деградаций STRICT_JSON/Guard.

---

## 9) Связь с P‑серией (обязательные стыки)

- P01: извлечение смыслов — сенсорные теги как признаки.
- P03: RouterContext — фильтры/биасы по сенсорным признакам.
- P07: DesiredAction — неизменный контракт; сенсорные данные лишь контекст.
- P16: Sleep v2 — якоря/архивация по сенсорным кластерам.
- P21: Health — метрики покрытия/ретрива.
- P24: Интеграционные тесты — добавлены sensory‑инспекторы.
- P27: Signature/Guard — шаги обязательны.
- P30: Processor — события сенсоров и appraisal по сенсорным признакам.
- P31: База сенсорной матрицы — расширение полей/связей.
- P35: Процессы «Рождение Квантов» — сенсорные эпизоды и якоря в конвейере.
- P36: Hyperloop DSL — INSPECTOR/CORE смоки и метрики окна.
- P38: NeuroTraining — тренд `avg_sensory_fields_nonempty` и `sensory_hit_rate`.

---

## 10) Быстрые команды проверки (PowerShell)

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
$B=@{ input_text='P39 sensory smoke'; num_quants=1; persist_all=$false } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/soul/process_batch' -Method Post -Headers $H -ContentType 'application/json' -Body $B | ConvertTo-Json -Depth 12 -Compress
$BI=@{ commands='INSPECTOR.RUN_ALL scope=signature' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $BI | ConvertTo-Json -Depth 12 -Compress

```

Ожидание: STRICT JSON массив; desired_action=[]; шаги подписи есть.

---

## 11) Траблшутинг

- Пустая `sensory_matrix`: ослабить пороги эвристик, включить LLM‑hint; проверить таймауты AttributeEnrichment.
- Деградация ретрива: уменьшить вес сенсорного бонуса; увеличить квоты якорей; исключить архив из активной витрины.
- Рост латентности: ограничить AttributeEnrichment (budget токенов/таймаут), выполнять только при сигнале.

---

## 12) Acceptance (принятие инкремента P39)

- Batch/stateless: валидный массив квантов; `sensory_matrix` присутствует по крайней мере в части кандидатов; `desired_action=[]`.
- Single/persistent: персистенция кванта/связей (`sensory_similar|anchor_of|summary_of_sensory`); индексы активны.
- Инспекторы `sensory.matrix_coverage` и `sensory.anchor_distribution` — passed; Delivery Guard — ok; greenlet_spawn=0.
- Hyperloop смоки (`CORE.PIPELINE.RUN ... WITH TRACE`, `INSPECTOR.RUN_ALL`) — ok; шаги `cmd.hyperloop.*` и `svc.*` записаны.

---

## 13) Журнал соответствия шагам 0–7 (контроль выполнения)

1. Анализ отчёта и связности — выполнено (см. §1, §9).
2. Дополнение отчёта лучшими практиками — выполнено (см. §1).
3. Сопоставление с ТЗ P‑серии — выполнено (см. §9).
4. Создание ТЗ 39 — выполнено (текущий документ).
5. Ревизия ТЗ 39 на целостность/практики — выполнено (пройденные инварианты §0/§7/§12).
6. Сопоставление с ТЗ 1–38 — выполнено (см. §9; детализировано P31/P16/P27/P30/P36/P07/P35/P38).
7. Согласованность и детализация до реализации — выполнено (пошаговая §8; Acceptance §12).

---

## 14) Кросс‑сопоставление с P01–P38 (точки улучшений)

- P01 MeaningExtraction: добавить извлечение сенсорных признаков/лексем в `sensory_tags`; нормализация прилагательных/образных выражений.
- P02 MetaLoop: рефлексия по метрикам `sensory_coverage_pct`, `sensory_hit_rate`; автокоррекция порогов `salience`/`clarity`.
- P03 RouterContext: ключи контекста `prefer_sensory_episode`, `include_sensory_any`, `avoid_low_clarity` в ветках; передача в RouterV2.
- P04 Hypothesis A/B: сравнение весов сенсорного бонуса в deep‑ранжировании; выбор профиля через P28.
- P05 Och: тональные коррекции без «переигрывания» сенсорики; правило не усиливать сенсорные описания в кризисе.
- P06 SelfConsistency: консистентность `thought_form` ↔ `sensory_matrix` (нет взаимоисключающих меток); инспектор `sensory.consistency.basic`.
- P07 DesiredAction: контракт без изменений; сенсорные поля лишь контекст. Тест маршрутизации `reminder` c сенсорным триггером допустим только через UI мини‑приложения.
- P08 Privacy: PII‑санитайзер для `sensory_episode.where.place/actors`; маскирование до логов/аудита.
- P09 Security: deny‑by‑default на внешние сенсоры; RBAC на инспекторы sensory.*.
- P10 Schema Guard: снапшоты подсхемы `sensory_matrix`; гейт на ломающие изменения полей и типов.
- P11 Provenance: фиксировать источник сенсорных данных (эвристика/LLM/аттачмент) в `_meta.sensory_source`.
- P12 TraceViewer: отображение бейджей сенсорных якорей/эпизодов в дереве шагов.
- P13 Eval: добавить показатели `sensory_coverage_pct`, `sensory_hit_rate`, `avg_clarity`; golden‑набор из K0 сенсорных фрагментов.
- P14 MultiProviderRouting: провайдер для AttributeEnrichment выбирается по latency/SLO; фоллбек без LLM.
- P15 Multilingual: кросс‑языковая нормализация сенсорной лексики; маппинг smell/scent/odor и т.п.
- P16 Memory/Sleep v2: учитывать якоря/сенсорные кластеры в E3.5/E4; исключать `archive_summary` из активной витрины.
- P17 Reminders/Search: фасеты поиска по сенсорным тегам/эпизодам; выдача результатов с сенсорными бейджами.
- P18 Voice ASR: извлечение аудиальных признаков (tones/rhythm/volume); заполнение `auditory.*` безопасными эвристиками.
- P19 Voice TTS: не усиливать «сенсорность» в TTS‑тексте вне прямого запроса; сохранить NEGATIVE.
- P20 TelegramBots Platform: UI бейджи сенсорики; фильтры; stateless‑ветка, desired_action=[] в batch.
- P21 Health: панели метрик `memory.sensory.*`; алерты на падение coverage/рост латентности.
- P22 API Alignment: обновить OpenAPI (описание `sensory_matrix`, `sensory_episode` как jsonb), без ломающих изменений.
- P23 UI Rebuild: виджеты фильтров/бейджей; лёгкий просмотр эпизодов.
- P24 Tests/Monitoring: интеграционные сценарии сенсорной памяти; RT‑смоки Hyperloop.
- P25 Skills/Routes: навыки с сенсорными ориентирами (например, аудиотренинг) — связь квантов `improves|assesses`.
- P26 Calendar/Transport: «тихие часы» и аудио‑сигналы учитывать в политике нотификаций.
- P27 Signature/Lineage: обязательные шаги перед публикацией; проверка цепочки через `CORE.TRACE.REQUIRE`.
- P28 FeatureFlags: флаги `sensory.enrich.enabled`, `sensory.router.bias.enabled`, профили веса бонусов.
- P29 Quality Registry: gendarme‑тесты `sensory.matrix_coverage≥X`, `sensory.consistency.basic=passed`.
- P30 Processor: события сенсоров (в перспективе); appraisal учитывает сенсорные признаки и RT‑бюджет.
- P31 Multisensory Quants: базовая подсхема; P39 закрепляет эпизоды/якоря/связи/метрики.
- P32 RBAC/Subscriptions: права на просмотр детализированной сенсорики; тарифные квоты на enrichment.
- P33 Personification: `sensory_profile` пользователя (чувствительность к каналам) как смещение роутера.
- P34 External Chat Proxy: безопасный приём аттачментов (audio/image) → сенсорные подсказки под флагами.
- P35 Processes Unified: шаг «Sense→Quant»: сенсорная нормализация/обогащение как часть конвейера.
- P36 Hyperloop DSL: инспекторы sensory.*, процедуры тестирования WITH TRACE; метрики окна через TRAIN.*.
- P38 NeuroTraining: учёт показателей `avg_sensory_fields_nonempty`, настройки весов α..ε для сенсорного вклада.

---

## 15) Hyperloop сценарии и быстрые проверки (расширено)

```powershell
# Профиль безопасной эксплуатации
$H=@{ 'X-Telegram-User-ID'='468326902' }
$F=@{ commands='FLAGS.APPLY_PROFILE name=prod_safe' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $F | ConvertTo-Json -Compress

# Смок ядра с трассой
$B=@{ commands='CORE.PIPELINE.RUN input_text="sensory memory smoke" WITH TRACE' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Depth 12 -Compress

# Требуемая цепочка подписи (P27)
$R=@{ commands='CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.soul.router_decide,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $R | ConvertTo-Json -Compress

# Инспекторы подписи и сенсорного покрытия
$I=@{ commands='INSPECTOR.RUN_ALL scope=signature' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $I | ConvertTo-Json -Compress
$I2=@{ commands='INSPECTOR.RUN key=sensory.matrix_coverage' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $I2 | ConvertTo-Json -Compress

# Метрики окна нейрообучения с учётом сенсорики (P38)
$M=@{ commands='TRAIN.METRICS.WINDOW window=24h' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $M | ConvertTo-Json -Compress

```

Ожидание: `ok=true`, присутствует `trace_id`; шаги `cmd.hyperloop.*` и цепочка P27 записаны; инспекторы — passed; метрики окна возвращены.

---

## 16) PROD‑отметка P39 (2025‑09‑20)

- Достигнуто покрытие сенсорной матрицы: 100.00% (`nonempty=271`, `total=271`) на PROD.
- Инспектор Hyperloop: `INSPECTOR.RUN key=sensory.matrix_coverage min_pct=60` — passed.
- Админ‑эндпоинты QA:
  - `GET /api/admin/soul/qa/sensory_coverage` — доля квантов с непустым `payload.sensory_matrix`.
  - `POST /api/admin/soul/qa/generate_sensory` — прогрев генерацией квантов с сенсорикой (батчи).
  - `POST /api/admin/soul/qa/sensory_backfill` — бэкфилл сенсорики для существующих квантов (батчи).
- Внесены правки устойчивости:
  - Телеграм‑сообщения: безопасное HTML‑экранирование (исключены 400 ошибки разметки).
  - Нейротренинг 24h: `flock`‑лок для исключения overlap.
- Аудит MetaLoop: метаданные рефлексии пишутся как `jsonb` (устранён asyncpg DataError).


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
