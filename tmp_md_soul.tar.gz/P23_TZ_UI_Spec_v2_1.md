# P23 — UI Спецификация v2.1 (консолидация 26 ТЗ + практика)

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — инвентари.
- `tmp_p_series_plan.json` — план P‑серии.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр.
- `Soul/P20_TZ_Telegram_Bot_Orchestrator_and_E2E_Dataflow_v1_1.md`, `Soul/P21_TZ_P95_Observability_and_Regulation_v1_0.md`, `Soul/P24_TZ_Soul_Integrated_Tests_and_Monitoring_v1_0.md`, `Soul/P30_TZ_Soul_Processor_v2_0.md`, `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`, `Soul/P36_TZ_Hyperloop_DSL_v1_1.md` — ключевые интеграции.

## Ссылки (интеграции и реестры)

- `docs/PROJECT_STRUCTURE_v8_2_0.md` — интеграции UI с P20/P21/P24/P30/P36
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр
- `Soul/Report_Soul_AI_Scientific.md` — разделы P23/P20/P30/P27/P28/P36
- `Soul/P20_TZ_Telegram_Bot_Orchestrator_and_E2E_Dataflow_v1_1.md` — каналы/вебхуки
- `Soul/P30_TZ_Soul_Processor_v2_0.md` — UI связи с Processor Dashboard/API
- `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md` — подпись UI событий/трассы
- `Soul/P28_TZ_FeatureFlags_Registry_and_Policies_v1_0.md` — фичефлаги UI/форм

## Индекс взаимных ссылок (P01–P37)

- P20 TelegramBots Platform — Mini App UI каналы.
- P21 Health/Monitoring — UI статусы/алерты.
- P33 Personification — экраны «Чат», «Выбор личности», напоминания.

## Описание

Дата: 2025-09-16

Ответственность: Мини‑апп/Веб каркас, формы, RBAC, деплой, диагностика

Статус: draft (для review и доработки итерациями)

## 0) Принципы (жёсткие)

- Никакого хардкода. Интерфейсные параметры — только через переменные (CSS tokens), ENV и runtime‑флаги. Любые не‑UI параметры — из БД.
- Безопасный старт: нулевой редирект на первом рендере, Mini‑App всегда рендерится; Web без React #300.
- Модульность и изоляция: страницы/виджеты по слоям; стили через токены; общая утилита логирования.
- Диагностика по умолчанию: понятные экраны ошибок, управляемые логи, smoke/CI, метка сборки.

## 1) Конфигурация и хранилище

- ENV (build/runtime):
  - `VITE_DEBUG_LOGS=0|1` — отключает info/log/debug (warn/error остаются).
  - `VITE_API_URL` — локальная разработка; на доменах *.soulpulse.art всегда относительный `/api`.
- Runtime‑флаги (URL/глобал) `window.__SP_FLAGS__`:
  - `ENABLE_LAYOUT_HEADER:boolean`
  - `ROUTES_STAGE: 1|2|3|4` (фазовое включение экранов)
  - `ENABLE_PERMS:boolean`, `PERMS_NO_REDIRECT:boolean`
  - `SAFE_BOOT:boolean`, `NOREACT:boolean`, `DIAG:boolean`
- База данных (не‑UI параметры): таблица `app_settings(key text primary key, value jsonb, updated_at timestamptz)`; серверной точкой `/api/ui/config` отдаём ключевые настройки UI/ролей/фич.

## 2) Дизайн‑система

- CSS‑tokens (unified): цвета/радиусы/тени/отступы/типографика; без хардкода.
- Визуальный стиль: спокойная палитра, мягкие скругления, edge‑highlight, цветные теги (color‑mix), единые карточки.
- AntD‑оверрайды — только через токены/префикс контейнера, без глобальных конфликтов.
- Доступность: контраст, видимый фокус, aria‑атрибуты, клавиатурная навигация. Темы: light/dark/auto.

## 3) Каркас, маршруты, платформы

- Роутер: `MemoryRouter` (Mini‑App/Web) — исключает историю/перенаправления WebView.
- Старт: Header‑only (ROUTES_STAGE=1); затем включение 2→3→4.
- Детект Mini‑App: по Telegram SDK/UA/referrer (без зависимости от tg_id). Никаких жёстких редиректов на старте.
- Guard’ы: без принудительных навигаций; состояние и видимость контролируются флагами/ролями.

## 4) Логи и диагностика

- `src/utils/logger.ts`: уровни debug|info|warn|error; в prod (VITE_DEBUG_LOGS=0) глушим debug/info/log; warn/error остаются.
- ErrorBoundary (root): выводит stack + componentStack + diag (wa, tg_id, href, UA, build‑id).
- DIAG панель `?diag=1`: build/flags/router/API_BASE/активный bundle.
- Метка сборки: `window.__SP_BUILD__ = <timestamp>` в index.html и отображение в DIAG/футере.

## 5) Реестр форм (объединение 26 ТЗ)

Категории: U — пользовательские; A — аналитика; F — функциональные; S — настройки; H — вспомогательные.

- U: `TelegramHome`, `MiniAppChat`, `DatesRemindersV2`, `Settings`
- A: `SoulLogs`, `Trace`
- F: `SoulDashboard`, `SoulGoals`, `SoulOptimization`, `SoulVisualization`
- S: `LLMParams`, `Prompts`, `Payments`, `RBACAdmin`
- H: `WebAuth`, `Register`

Модель элемента реестра:

```text
{id, key, name, category(U/A/F/S/H), route, roles[string[]], enabled(bool), owner, status(draft|ready), desc(<=120)}

```

API (UI‑реестр): `GET /api/ui/forms` (список), `PUT /api/ui/forms/{key}/visibility { role, visible }` (ETag/If‑Match, аудит).

## 6) RBAC «Роли×Формы» (грид)

- Таблица: строки — формы; столбцы — роли; ячейки — чекбоксы; по клику — PUT на API.
- Серверный RBAC обязателен (клиент — только UI). Изменения — аудируются.

## 7) Сборка/деплой/кэш

- Vite: sourcemap (debug), drop `debugger` (prod), console по флагу.
- Главный бандл: строгий cache‑bust `?v=<ts>` каждый деплой; pre‑commit audit dist (нет `localhost`, есть `assets/index-*.js` и `.map`).
- Nginx SPA (PROD):
  - `/assets/` — `types { application/javascript js; text/css css; }`, `try_files $uri =404`, `Cache-Control: immutable`.
  - `index.html` — `no-store`; fallback `/` → `/index.html`.

## 8) Этапы раскатки

0) Минимальная форма (wa/tg_id) — базовый `frontend`.

1) Header‑only + Stage=1: `TelegramHome`, `MiniAppChat`.

2) `F`‑модули (Soul*) под `RoleGuard(architect)`.

3) Admin/RBAC/`ArchitectPanel`.

4) Остальные (Prompts/Settings/Payments/Trace/LLMParams/Analytics).

После каждого шага — smoke + DIAG + метка сборки.

## 9) Ошибки/UX

- На первом кадре нет throw/redirect; сетевые ошибки — banners + retry/backoff; пустые состояния/скелетоны единые.
- SoulDashboard: вычисление статуса системы переведено на расчёт по свежим метрикам (без гонки состояния); секции экранированы локальными LocalSection для изоляции падений.

## 10) CI/Smoke

- pre‑commit (husky): audit dist + vite build; запрет `localhost` в `dist`.
- precommit:ui_audit — `node scripts/ui_audit.mjs` (структурная стат‑проверка форм/каркаса/меню/роутера, отсутствие хардкода layout/Router в страницах).
- CI: `VITE_DEBUG_LOGS=0`, `npm ci`, `npm run build`, `scripts/gate_dist.ps1`.
- Smoke (preview): `/, /webauth, /chat, /dates-reminders` + HEAD первого `assets/index-*.js`.

## 11) Структура каталогов (PROD)

- Рабочий фронт: `/var/www/soulpulse/frontend` (допустим symlink).
- Аварийный фронт: `/var/www/soulpulse/minimal`.
- Временные билды: `/var/www/soulpulse/v/<build>/` (опционально).

## 12) Обратные петли анализа

- Для каждого из 26 ТЗ: дополняем реестр форм/ролей/роутов; уточняем UX/перф/безопасность; фиксируем в этом документе, затем реализуем.

## 13) Критерии приёма

- Mini‑App/Web стартуют без React #300 и редирект‑циклов.
- Формы включены по ролям; RBAC‑грид работает.
- DIAG/логи/ошибки — понятны; деплой воспроизводим; кэши корректны.

(Документ живой, обновляется по мере консолидации 26 ТЗ и практик.)

## 14) Интеграционные цепочки и уведомления (связь с P24/P21)

- Обязательные цепочки (E2E) для UI и Admin (см. P24):
  - A) Диалог→Кванты: ввод → MeaningExtraction → RouterContext → SoulCore → Strict JSON → Persist → Trace/Provenance.
  - E) Напоминания/Календарь: создание→планирование→уведомление→ingestion в календарь (P26) → A/B поиска перед ответом.
  - G) Multi‑provider routing: профили/фолбэки/circuit‑breaker; UI‑метрики реакции на деградацию.
  - H) Health/Incidents: автосмок после деплоя; SLO/алерты (P21) поверх UI действий.
- Требуется дореализация (до приёмки инкремента):
  - UI‑видимость статусов цепочек и последних прогонов (Admin → Monitoring): индикаторы/время/commit/ошибки.
  - Точки вызова автотестов цепочек post‑deploy (кнопка в Admin + cron/CI триггер).
  - Уведомления об инцидентах (панель/тосты) и ссылки на трассы/логи.
- Acceptance дополнительно: после запуска бота автозапуск санити‑цепочек и отсутствие 5xx; публикация snapshot.

## 15) Telegram Mini Apps — правила разметки, инициализации и навигации

- Детекция платформы:
  - Mini‑App считается ТОЛЬКО если есть `window.Telegram.WebApp` и валидные данные инициализации: непустой `WebApp.initData` ИЛИ `initDataUnsafe.user.id`. Одного факта наличия `WebApp` недостаточно. Веб‑браузер без этих данных не считается Mini‑App.
- Инициализация:
  - На первом тике вызвать `Telegram.WebApp.ready()` и затем `Telegram.WebApp.expand()` (без ожидания сетевых ответов).
  - Подписки: `themeChanged`, `viewportChanged` — применять тему/классы и перерасчёт размеров без редиректов.
- Viewport и safe‑area:
  - Контейнеры: `min-height: var(--tg-viewport-stable-height, 100dvh)`; прокрутка — только в области контента.
  - Отступы: использовать `env(safe-area-inset-top)`/`env(safe-area-inset-bottom)` с фоллбэком 0; не перекрывать хедер системными вырезами.
- Каркас/разметка (без дублей):
  - Ровно один sticky‑хедер на странице. Запрещены вложенные/дублирующие topbar‑контейнеры.
  - Иерархия z-index: header ≥ 2000; drawer/overlays ≥ 2100; sidebar ≈ 1200; контент 1.
  - Горизонтальное верхнее меню — опционально; основной способ навигации в Mini‑App — кнопка‑гамбургер в хедере с Drawer.
- Роутинг:
  - Всегда `MemoryRouter`. Навигация через router‑контекст; вне контекста — только прямой `window.location.assign` как фоллбэк.
  - Никаких жёстких редиректов на старте; гейт рендера вместо редиректа.
- Тема и цвета Telegram:
  - Применять `--tg-theme-*` CSS‑переменные; опционально `setHeaderColor('bg_color')`/`setBackgroundColor`.
- Меню и доступ:
  - Иконка меню в хедере рендерится всегда (не зависит от ролей). Содержимое Drawer — по ролям/конфигу API.
- Производительность:
  - Исключить layout‑трешинг: один sticky‑контейнер, минимизировать fixed/overlays; скролл только у контента.

### 15.1) Аварийная ветка Mini‑App (HeaderOnly)

- При флаге обхода layout (`?simple=1` или авто для Mini‑App при сбое) рендерим упрощённый контейнер:
  - Сверху всегда `ModernHeader` (кнопка‑гамбургер → Drawer меню), z-index ≥ 1000.
  - Ниже — контент `TelegramHome` в прокручиваемой области (`overflow: auto`).
  - Не использовать `PlatformLayout` и сложные вложения, чтобы исключить React‑сбой (#300).
  - Меню остаётся доступным (Drawer) независимо от ролей; пункты — из API или безопасный фоллбэк.

---

## 16) Web — доступ по токену (гейт/редиректы)

- Базовые правила (frontend/src/App.tsx, frontend/src/api.ts):
  - Веб‑режим рендерит приложение только если `hasValidAuthToken()` И в `sessionStorage.tg_id` есть значение. Иначе — `WebLanding` (или `WebAuth` на `/webauth`).
  - `hasValidAuthToken()` валидирует JWT по `exp` и tg‑привязке: в WEB допускается отсутствующий `tg_id` в payload, если `sessionStorage.tg_id` уже установлен (обратная совместимость старых токенов).
  - `buildAuthHeaders()` всегда добавляет `Authorization: Bearer <jwt>` (если валиден) и `X-Telegram-User-ID` из `sessionStorage` или Telegram SDK; при отсутствии `tg_id` в сессии извлекает из JWT payload и синхронизирует.
  - Для ответов `401` в WEB действует мягкий редирект на `/webauth?return=<path>` с троттлингом не чаще 1 раза в 5 сек и без редиректа, если уже на `/webauth`.
- Роутинг:
  - Всегда `MemoryRouter` (Mini‑App/Web) для предсказуемости; `WebLanding`/`WebAuth` доступны без токена.
- UI/меню:
  - Если API `/api/ui/config` вернул пустое меню — отображать безопасный минимум: `Чат`, `Настройки`.
- Деплой/кэш:
  - `index.html` — `no-store`; все `assets/` — immutable; строгое обновление через полную замену каталога `frontend`.
- Пакетная загрузка данных после `ready()`; skeletons вместо блокировок UI.

---

## Consolidation (merge notes)

- Источники для слияния (архив):
  - `Archive/CLEANUP_20251009_005735/duplicates/P23_TZ_Soul_UI_Rebuild_v1_0.md`
  - `Archive/CLEANUP_20251009_005735/duplicates/P23_TZ_Frontman_Actor_v1_0.md`
- Принятые решения:
  - Актуальной базой является этот документ v2.1; материалы `UI Rebuild v1.0` и `Frontman Actor v1.0` интегрированы как уточнения архитектуры, реестра форм и CI/diagnostics.
  - Перенесены и унифицированы требования по:
    - каркасу/маршрутам/MemoryRouter (Mini‑App/Web), Header‑only старту и аварийной ветке;
    - реестру форм и RBAC‑гридy (Роли×Формы) с серверным контролем и ETag;
    - сборке/кэшу/SPA‑настройкам Nginx и pre‑commit audit dist;
    - DIAG/ошибкам/логированию, метке сборки и smoke‑цепочкам post‑deploy;
    - требованиям Mini‑App (SDK/viewport/theme/инициализация) и Web‑гейтам по токену.
  - Ссылки на P‑серии (P20/P21/P22/P24/P32) выровнены с текущей реализацией; все пути/URL управляются через БД/ENV, без хардкодов.
  - Навигация и реестр обновлены: см. `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` → раздел «Нормализация документации — Repo Cleanup (P54)».


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
