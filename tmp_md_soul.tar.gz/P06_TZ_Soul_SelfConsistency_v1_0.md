---

## Индекс взаимных ссылок (P01–P37)

- P01/P04 — объекты верификации (смыслы/гипотезы).
- P13 Eval — метрики самосогласованности.
- P14 — провайдерные профили для повторных запусков.
- P27 — подпись проверок; P24 — интеграционные тесты.
- P36 — команды запуска серий проверок.

### ТЗ Soul v1.0 — Контроль неопределённости и самосогласованности (Self‑Consistency/Contradiction)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: Реализовано (MVP без изменения схемы БД)

---

### 0. Executive summary

- Цель: снизить галлюцинации и дрейф смысла за счёт двух контуров: (A) Self‑Consistency — скрытая переоценка ответа с несколькими вариантами; (B) Contradiction — проверка противоречий с опорной памятью (якорями/цитатами).
- Интеграция: этап «4b. Uncertainty & Consistency» в существующем 4‑ступенчатом пайплайне (`generate_quant_enhanced`), без изменения STRICT_JSON_QUANT и без миграций БД в MVP.
- Выход: числовая `confidence` и флаги противоречий; калибровка `energy_weight` по формуле; политика действий при низкой уверенности (уточнение/мини‑исследование) — под фичефлагами.

---

### 1. Архитектура и точки интеграции

- Базовый пайплайн реализован в `backend/app/services/soul_core_manager.py: generate_quant_enhanced` (этапы: KeywordAnalysis → ContextEnrichment → SoulCore → AttributeEnrichment).
- Новый подпроцесс «4b. Uncertainty & Consistency» вызывается:
  - После получения чернового кванта(ов) и до финальной калибровки атрибутов/сохранения.
  - Для batch — поверх каждого кандидата или лучшего по текущим метрикам.
- Задействуем существующие сервисы:
  - Контекст 30/70: `backend/app/services/soul_context.py` (для выборки опорной памяти).
  - Настройки: `backend/app/services/soul_settings_service.py` (новые флаги `consistency.*`).
  - LLM‑провайдеры/выбор моделей: `LLMManager` (вызовы малой модели для self‑consistency/contradiction‑judge).
  - JSON‑утилиты: `backend/app/lib/json_strict.py` (валидация/нормализация промежуточных JSON).

---

### 2. ТЗ‑A. Self‑Consistency (скрытая переоценка ответа)

#### A.1 Цели

- Оценить уверенность ответа без утечки цепочек рассуждений в итоговый промпт.
- Повысить стабильность за счёт N перегенераций скрытой формулировки и согласованности между ними.

#### A.2 Файлы и изменения

- Новые:
  - `backend/app/services/consistency_service.py` — основной сервис self‑consistency.
  - `backend/app/services/consistency_contracts.py` — Pydantic‑контракты.
- Изменить:
  - `backend/app/services/soul_core_manager.py` — вставить вызов `ConsistencyService.self_consistency(...)` в этапе 4b.
  - `docs/SOUL_PIPELINE.md` — отразить шаг «4b. Uncertainty & Consistency».
  - `backend/app/services/soul_settings_service.py` — флаги `consistency.enabled`, `consistency.n_samples`, `consistency.temperature`, пороги.

#### A.3 Контракты (сервер)

```python
from typing import Any, Dict, List, Optional
from pydantic import BaseModel

class ConsistencyVariant(BaseModel):
    text_hidden: str  # скрытая короткая формулировка ответа (без PII)

class SelfConsistencyResult(BaseModel):
    confidence: float  # [0..1]
    variants: List[ConsistencyVariant]
    method: str  # e.g. "n_hidden_restatements"
    meta: Dict[str, Any] = {}

```

#### A.4 Алгоритм (MVP)

1) Сформировать короткое нейтральное описание ответа (server‑side шаблон, без вывода в промпт). Вход: `input_text`, `draft_quant.thought_form`, ключевые фрагменты контекста.
2) Запросить малую модель N раз (по умолчанию N=3) на скрытую переформулировку «смыслового ядра ответа» (не CoT). Температура малая (0.3–0.5).
3) Оценить согласованность: доля совпадающих/семантически близких формулировок (простой TF‑IDF/эмбеддинг‑косинус ≥ τ). Вернуть `confidence∈[0..1]`.
4) Записать событие аудита `soul_uncertainty_estimated` {confidence, n}.

Примечания:

- Без утечки CoT: варианты не попадают в итоговый промпт и в БД.
- Бюджет: лимит токенов и время на этот шаг ≤1.0–1.5 с.

#### A.5 Настройки и флаги

- `consistency.enabled=false` (по умолчанию)
- `consistency.n_samples=3`
- `consistency.temperature=0.4`
- `consistency.similarity_threshold=0.82` (для близости формулировок)
- `consistency.low_confidence_threshold=0.45` (ниже — политика «уточнить/исследовать»)

#### A.6 Наблюдаемость

- Аудит: `soul_uncertainty_estimated` {trace_id, confidence, n}.
- Метрики: `consistency.ms_total`, `consistency.confidence_hist`, ошибки малой модели.

#### A.7 Политика действий (опционально, за флагом)

- Если `confidence < low_confidence_threshold`:
  - В persistent‑режиме: добавить `desired_action` = `clarify` или инициировать `research` (через уже существующую политику действий ядра) — только при включённом флаге `consistency.auto_actions`.
  - В stateless: никаких действий; только сигнал в `PlannerFeedback.signals` (если этап 2.5 включён).

#### A.8 Acceptance

- На golden‑кейсах снижение доли уверенных, но фактически неверных утверждений.
- Время этапа ≤ 1.5 с p95; при ошибке/таймауте пайплайн не падает.

---

### 3. ТЗ‑B. Contradiction (проверка противоречий с памятью)

#### B.1 Цели

- Выявить явные противоречия с опорной памятью (якоря/цитаты) и сигнализировать в ядро.
- Не менять БД в MVP: использовать существующие выборки 30/70 и «якорные» кванты.

#### B.2 Файлы и изменения

- Новые:
  - `backend/app/services/contradiction_service.py` — быстрая проверка противоречий.
- Изменить:
  - `backend/app/services/soul_core_manager.py` — вызвать `ContradictionService.check(...)` в 4b.
  - `docs/SOUL_PIPELINE.md` — дополнить.

#### B.3 Контракты

```python
from typing import Any, Dict, List
from pydantic import BaseModel

class EvidenceItem(BaseModel):
    quant_id: str
    snippet: str
    score: float

class ContradictionResult(BaseModel):
    is_contradict: bool
    severity: float  # [0..1]
    evidence: List[EvidenceItem]
    method: str  # e.g. "keyword_negation+embedding"

```

#### B.4 Алгоритм (MVP)

1) Memory slice: запросить 30/70 контекст + усилить «якорями» (по тегам/индексам, top_k=5..8).
2) Эвристика противоречий:

   - Ключевые отрицания/антонимы в сравнении с якорями (keyword‑based quick pass).
   - Косинусная близость эмбеддингов «утверждение ↔ якорь» с признаком инвертируемых утверждений.

3) При срабатывании: `is_contradict=true`, `severity` по числу/весу совпадений; собрать краткие `evidence` (quant_id, snippet, score).
4) Аудит `soul_contradiction_found` {trace_id, severity, evidence_count}.

Примечания:

- Без хранения новых структур. Для эмбеддингов — использовать уже доступные в проекте средства; при отсутствии — fallback на keyword‑эвристику.

#### B.5 Политика действий (за флагом)

- При `is_contradict=true` и `severity≥0.6`:
  - persistent: добавить `desired_action=clarify` с подсказкой «найдено потенциальное противоречие», либо запустить `research` (по политике действий ядра), без автозаписи в память.
  - stateless: только сигнал в `[PLANNER_FEEDBACK]`/метрики.

#### B.6 Acceptance

- На наборах с преднамеренными противоречиями — фиксируется событие, финальный ответ смягчается (через clarify) при включённой политике.
- p95 на шаг ≤ 700 мс (keyword+ограниченный top_k).

---

### 4. Калибровка energy_weight

Формула (до сохранения кванта):

\(energy\_weight = clip( \alpha·confidence + \beta·affect\_intensity + \gamma·goal\_alignment )\)

- `confidence` — из Self‑Consistency [0..1].
- `affect_intensity` — из `composite_emotion.intensity` [0..1].
- `goal_alignment` — эвристика совпадения с активной целью/роутером (0..1).
- Дефолтные коэффициенты: `α=0.5, β=0.3, γ=0.2` (вынести в `consistency.calibration_weights`).
- Где применять: в `soul_core_manager.py` сразу перед финальной сборкой объекта `QuantStrict`.
- Без миграций: сохраняем только скорректированное `energy_weight` (число). Сырые сигналы уходят в аудит.

---

### 5. Производительность и SLO

- Общий бюджет на 4b: ≤ 1.5–2.0 с p95.
- Отключаемо флагами; при ошибках/таймаутах — тихий пропуск шага (без падения пайплайна).
- Минимизируем токены: короткие шаблоны, малая модель, малое `n_samples`.

---

### 6. Быстрая реализация (≤ 1 день)

1) Создать `consistency_service.py`, `consistency_contracts.py` и `contradiction_service.py` с MVP‑логикой (N=3 скрытых формулировок + keyword/embedding‑эвристика для противоречий).
2) Вставить этап 4b в `generate_quant_enhanced`; добавить флаги и пороги в `SoulSettingsService`.
3) Добавить аудит/метрики: `soul_uncertainty_estimated`, `soul_contradiction_found`.
4) Калибровать `energy_weight` в `soul_core_manager.py` с дефолтными весами.
5) Обновить `docs/SOUL_PIPELINE.md`.
6) Прогнать golden‑набор: проверка снижения ложной уверенности и стабильности JSON.

---

### 7. Траблшутинг

- Рост латентности: уменьшить `consistency.n_samples`, отключить эмбеддинги, оставить keyword‑эвристику.
- Шум в противоречиях: поднять `similarity_threshold` и `severity` порог, уменьшить `top_k` якорей.
- Нежелательные действия: держать `consistency.auto_actions=false` на старте; только сигналы и калибровка веса.

---

### 8. Флаги/конфиг

- `consistency.enabled=false`
- `consistency.n_samples=3`
- `consistency.temperature=0.4`
- `consistency.similarity_threshold=0.82`
- `consistency.low_confidence_threshold=0.45`
- `consistency.auto_actions=false`
- `consistency.calibration_weights={"alpha":0.5,"beta":0.3,"gamma":0.2}`

ENV (опционально): `SOUL_CONSISTENCY_ENABLED`, `SOUL_CONSISTENCY_SAMPLES`, `SOUL_CONSISTENCY_THRESHOLDS`.

---

### 9. Мировая практика (ориентиры)

- Self‑Consistency (несколько выборок и агрегирование согласия) — улучшение точности и устойчивости вывода.
- Committee/DeBate/Reflexion — короткий внутренний комитет/рефлексия перед фиксацией ответа.
- SelfCheckGPT/FactCheck — сверка с опорной базой знаний и указание на противоречия.
- Constitutional/Guardrails — применение правил безопасности до/после шага проверки.

В проекте используем лёгкий вариант без утечки CoT и без миграций: скрытые restatements + усечённая проверка якорей.

---

### 10. Ссылки на проектные файлы/документы

- Пайплайн: `backend/app/services/soul_core_manager.py: generate_quant_enhanced`
- Контекст 30/70: `backend/app/services/soul_context.py`
- Настройки: `backend/app/services/soul_settings_service.py`
- JSON‑утилиты: `backend/app/lib/json_strict.py`
- Пайплайн‑док: `docs/SOUL_PIPELINE.md` (дополнить шаг 4b)
- Строгий вывод кванта: `backend/app/services/soul_quant_schema.py`

---

### 11. Дашборды и алерты (Observability)

- Графики:
  - `consistency.confidence_hist` (распределение уверенности)
  - `consistency.ms_total.p95` (латентность шага 4b)
  - `contradiction.rate` (доля срабатываний/severity)
  - `energy_weight.delta_after_calibration` (средняя дельта калибровки)
- Таблицы/трейсы:
  - Топ кейсов с низкой `confidence` и их причины (из аудита)
  - Список `soul_contradiction_found` с evidence_count/примером
- Алерты:
  - `consistency.ms_total.p95 > 1500ms` (10 мин) — warn
  - `consistency.low_confidence_share > 20%` (за час) — warn
  - `contradiction.severity_mean > 0.6` (за сутки) — warn

---

### 12. Rollout/флаги и контроль регрессов

- Флаги включения: `consistency.enabled=false`, `consistency.auto_actions=false` (на PROD)
- Этапность:

  1) DEV: включить self‑consistency без auto‑actions, собрать baseline
  2) STAGE: включить contradiction‑эвристику, мониторинг алертов
  3) PROD: включить только self‑consistency; contradiction — сигналы без действий

- Контроль регрессов (через Eval, P13):
  - JSON validity не ниже baseline
  - p95 пайплайна не выше +10% baseline
  - clarity/actionability без падения > 2%

---

### 13. Server‑side шаблоны промптов (контуры)

- Self‑Consistency (скрытые рестейтменты):
  - Инструкции: «Сформулируй краткое нейтральное содержание ответа одной фразой. Не рассуждай. Не упоминай внутренние шаги. Без данных пользователя. Язык запроса.»
  - Вход: `{input_excerpt, draft_thought_form_excerpt, key_context_points[]}` (усечённые фрагменты без PII)
  - Выход: строго одна строка, ≤ 160 символов
- Contradiction‑judge (быстрая проверка):
  - Инструкции: «Есть утверждение и опорные выдержки. Ответь: есть ли явное противоречие? Верни JSON: {is_contradict:bool, severity:0..1, reasons:[str<=80]}»
  - Вход: `{statement, anchors[snippet<=200]}`
  - Модель: быстрая/дешевая; лимит токенов минимальный

Примечание: шаблоны держать как server‑constants, не включать в системный промпт ядра.

---

### 14. Runtime‑настройки и Admin API

- Настройки (живые, через `SoulSettingsService`):
  - `consistency.enabled`, `consistency.n_samples`, `consistency.similarity_threshold`, `consistency.low_confidence_threshold`, `consistency.auto_actions`, `consistency.calibration_weights`
- Admin API (новый роутер `consistency_admin.py`):
  - `GET /api/admin/consistency/settings` → текущее состояние
  - `PUT /api/admin/consistency/settings` → обновление подмножеств полей (RBAC `soul.admin`)
  - `POST /api/admin/consistency/test` → сухой прогон над текстом (без записи), возвращает `confidence`/`contradiction`

---

### 15. Golden‑set категории и пороги (связь с P13)

- Категории кейсов:
  - Фактические вопросы (fact)
  - Инструкции/советы (how‑to)
  - Творческие/мнения (creative)
  - Конфликтующие утверждения (contradict)
- Пороговые ожидания:
  - `confidence` медиана: fact ≥ 0.7; how‑to ≥ 0.6; creative ≥ 0.5
  - `contradiction.severity_mean` по «contradict» наборам ≤ 0.2 (после смягчения ответа)
- Отчёт Eval дополняется гистограммами confidence и долей уточнений при low‑confidence.

---

### 16. UI (ArchitectPanel)

- Переключатели: enable Self‑Consistency, enable Contradiction, auto‑actions
- Ползунки: n_samples, similarity_threshold, low_confidence_threshold
- Карточка «Последние низкие confidence»: список с `trace_id` и ссылкой в TraceViewer

---

### 17. План отката/риски

- Риски: рост латентности; ложные `contradict`; избыточные уточнения
- Откат: единый флаг `consistency.enabled=false`; раздельное отключение contradiction
- Деградация: уменьшить `n_samples`, поднять `similarity_threshold`, отключить эмбеддинги, оставить keyword‑эвристику

---

### 18. Примеры трасс (сверка)

- Трасса A (OK): `confidence=0.78`, `contradiction=false`, калибровка `Δenergy=+0.06`
- Трасса B (низкая уверенность): `confidence=0.38` → сигнал clarify (без авто‑действий), ответ смягчён
- Трасса C (противоречие): `severity=0.72` → сигнал/предупреждение, без записи в память

---

### 19. Отметка принятия (2025-09-20)

- Реализация на сервере:
  - `backend/app/services/self_consistency_service.py` (SelfConsistencyService) — активен по флагу `sc.enabled`.
  - `backend/app/services/contradiction_service.py` — добавлен (MVP эвристика отрицаний/антонимов).
  - Калибровка `energy_weight` по формуле α·confidence + β·intensity + γ·goal_alignment (мягкая смесь с исходным значением).
- Флаги/настройки: `sc.*`, `consistency.calibration_weights` — читаются через `SoulSettingsService`.
- Наблюдаемость: события `soul_self_consistency`, `soul_contradiction_found` пишутся; latency в бюджете.
- PROD‑смоки: Health/DB/LLM/Dispatcher/Sleep/Sanity — 200; регрессов не выявлено.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
