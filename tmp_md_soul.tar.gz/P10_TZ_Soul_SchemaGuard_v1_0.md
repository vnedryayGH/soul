# ТЗ P10 — Schema Guard (ABI‑стабильность)

## Индекс взаимных ссылок (P01–P37)

- P01/P07 — STRICT JSON в смыслах/действиях.
- P22 API Alignment — согласование схем MiniChat API.
- P27 Signature — валидация подписи структур.
- P33 Personification — валидация payload MiniChat/§svc JSON.

### вербТЗ Soul v1.0 — Миграции/ABI‑стабильность (Schema guard)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: Реализовано (MVP: snapshot+валидатор в CI; без ломки схем)

---

### 0. Executive summary

- Цель: гарантировать стабильность контрактов (ABI) между LLM‑выходом, серверными моделями (Pydantic), схемой БД и документацией, чтобы изменения были только совместимыми (additive, opt‑in), а несовместимые блокировались до merge.
- Интеграция: офлайн‑проверки в CI/Pre‑commit и команда обновления «с сознательным повышением версии контракта». Никаких изменений поведения по умолчанию.

---

### 1. Актуальная реализация (аудит)

- LLM‑контракт: `backend/docs/SOUL_PROMPT_BUILDING.md` — секция `[OUTPUT_SPEC]` (ключи: `thought_form`, `composite_emotion{valence,intensity,entropy,label}`, `desired_action[]`, `energy_weight`, `tags[]`).
- Серверные модели: `backend/app/services/soul_quant_schema.py` (`QuantStrict` и связанные), `DesiredAction` (см. новое ТЗ), утилиты `backend/app/lib/json_strict.py`.
- БД: `docs/DATABASE_STRUCTURE_v8_0_2.md` + alembic версии (в т.ч. `generation_request`, `quant_desired_actions` с вариантами колонок), `quants`, `quant_connections` и пр.
- Поведение stateless: в ядре принудительно `desired_action=[]`.

Вывод: контракты разбросаны по код/док/БД. Нужен единый «калибр» и автоматическая проверка согласованности.

---

### 2. Цели Schema Guard

- Проверять согласованность:

  1) `[OUTPUT_SPEC]` ↔ серверные Pydantic‑модели (`QuantStrict`, `DesiredAction`).
  2) Серверные модели ↔ существующая БД (инспекция колонок/типов среди критичных таблиц).
  3) Документы (SOUL_PROMPT_BUILDING.md) ↔ snapshot‑схема (регистрация версии).

- Блокировать merge при breaking‑изменениях.
- Обеспечить явную процедуру обновления версии контракта (версионированный snapshot и запись в реестр изменений).

---

### 3. Компоненты и файлы (реализация)

- Каталог реестра контрактов:
  - `backend/schema/abi_contracts_v1.json` — snapshot JSON‑схем `QuantStrict` и `DesiredAction` (создано).
  - `backend/schema/abi_readme.md` — правила обновления (создано).
- Скрипты CI:
  - `backend/scripts/ci_schema_guard.py` — валидатор (создано; pydantic v2, additive‑only дифф ключей).
  - (опц.) `backend/scripts/gen_schema_snapshot.py` — генератор (в планах).
- Настройки:
  - Проверка запускается офлайн (CI/Pre‑commit); изменение поведения не требуется.

---

### 4. Что проверяем (MVP)

1) Pydantic → JSON Schema:

   - Сгенерировать JSON‑схемы для `QuantStrict` и `DesiredAction` и сравнить с `abi_contracts_v1.json`.
   - Разрешены изменения только additive (новые optional‑поля, enum‑расширение). Запрещено: удаление/переименование/изменение типа, ужесточение обязательности.

2) `[OUTPUT_SPEC]` (PROMPT):

   - Парсер документа `backend/docs/SOUL_PROMPT_BUILDING.md` — извлечь список ключей и обязательных подполей.
   - Сопоставить с JSON‑схемой `QuantStrict`. Несовпадение → ошибка.

3) БД (критичные таблицы):

   - `quants`: наличие колонок для всех полей ядра (`thought_form`, `energy_weight`, `tags`/jsonb или связанная таблица).
   - `quant_desired_actions`: допускаются два варианта схемы (A: `type/payload`, B: `action_type/payload_json`). Если нет ни одного — предупреждение (не ошибка в MVP).
   - `generation_request`: базовые поля по актуальным алембикам присутствуют.

4) Поведенческие инварианты:

   - В stateless `desired_action=[]` (проверка кода по известным участкам, «сигнатурный» тест через grep/AST‑сканер).
   - Порядок секций промпта (Assembly Contract) соответствует спецификации.

---

### 5. Скрипт `ci_schema_guard.py` (интерфейс)

Запуск:

```bash
python -m backend.scripts.ci_schema_guard \
  --snapshot backend/schema/abi_contracts_v1.json \
  --prompt backend/docs/SOUL_PROMPT_BUILDING.md \
  --db-url "$DATABASE_URL" \
  --mode ci

```

Функции:

- `load_snapshot()` — загрузить snapshot и версию.
- `export_current_schemas()` — получить актуальные JSON‑схемы Pydantic.
- `compare_schemas()` — фиксировать breaking vs additive.
- `parse_prompt_output_spec()` — извлечь ключи из документа.
- `inspect_db()` — проверить наличие колонок/вариантов схемы.
- `check_behavior_invariants()` — поиск сигнатур/AST для статлесс‑обнуления `desired_action` и порядка секций.
- Выход с кодом `1` при нарушении.

Отчёт: печатать сводку изменений (additive/breaking), расхождения ключей и отсутствующие колонки.

---

### 6. Обновление snapshot (осознанное)

Команда:

```bash
python -m backend.scripts.gen_schema_snapshot \
  --output backend/schema/abi_contracts_v1.json \
  --bump minor  # major|minor|patch

```

Правила:

- `major` — допускается только после миграций БД/промптов и обновления документации; требует ручного подтверждения в PR.
- `minor` — новые optional‑поля/enum‑значения.
- `patch` — комментарии/описания.

Каждое обновление — запись в `abi_readme.md` (что/почему/ссылки на PR/миграции).

---

### 7. Интеграция в CI/Pre‑commit

- Pre‑commit: шаг `ci_schema_guard` в локальной проверке (без `inspect_db`), чтобы разработчик видел проблемы до push.
- CI (PR): полный набор (со сверкой БД при доступном `DATABASE_URL`), блокировать merge при breaking.
- Исключения: разрешаются только через явное указание `--allow-breaking` в admin‑джобе и метку PR; по умолчанию недопустимо.

---

### 8. Acceptance (выполнено)

- При отсутствии изменений схем — guard проходит без замечаний (OK на локальном запуске).
- При additive‑изменениях — предупреждение с просьбой обновить snapshot (`minor`).
- При breaking — код возврата `1` и детальный отчёт, merge блокируется.
- `[OUTPUT_SPEC]` ↔ Pydantic — согласованы; критичные таблицы присутствуют.

---

### 9. Траблшутинг

- Guard падает из‑за парсера промпта — проверить форматирование `[OUTPUT_SPEC]` в документации (фиксированный блок текста).
- Несоответствие БД на DEV — запустить актуальные alembic миграции; сверить таблицу `quant_desired_actions` с вариантами.
- Ложное срабатывание stateless‑инварианта — обновить сигнатуры/AST‑правило в скрипте.

---

### 10. Мировая практика (ориентиры)

- API schema guardrails (OpenAPI/JSONSchema diff) — запрет breaking‑изменений.
- ABI‑стабильность в SDK (semver): major/minor/patch с автоматическим диффом.
- Liquibase/Alembic best practices — «миграции вперёд», обратная совместимость, минимизация downtime.

Мы применяем упрощённый, но эффективный подход: единый snapshot + дифф + инварианты по коду и БД.

---

### 11. Ссылки на проектные файлы/документы

- Контракт LLM: `backend/docs/SOUL_PROMPT_BUILDING.md`
- Модели: `backend/app/services/soul_quant_schema.py` (+ Pydantic desired_action из ТЗ)
- Утилиты: `backend/app/lib/json_strict.py`
- БД/миграции: `docs/DATABASE_STRUCTURE_v8_0_2.md`, `backend/alembic/versions/*`
- Поведение stateless: `backend/app/services/soul_core_manager.py`


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
