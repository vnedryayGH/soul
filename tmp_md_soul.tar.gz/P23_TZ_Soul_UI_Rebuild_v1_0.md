---

## Индекс взаимных ссылок (P01–P37)
- P20 TelegramBots Platform — Mini App интеграция.
- P21 Health/Monitoring — индикаторы состояний.
- P33 Personification — экраны персон/настроек/напоминаний.
# P23 — Пересборка пользовательского интерфейса (Mini‑App + Web)

Версия: v1.0
Статус: Консолидировано по v2.1 (без регресса)

## 0) Принципы
- Никакого хардкода. Все UI‑параметры — через CSS tokens/ENV/runtime‑флаги; бизнес‑параметры — из БД.
- Безопасный старт: первый кадр без redirect/throw. Mini‑App всегда рендерится; Web без React #300.
- Модульность и изоляция слоёв; стили через токены; управляемые логи и понятные экраны ошибок.

## 1) Цели
- Стабильный Mini‑App в Telegram WebView (устранение React #300), быстрый старт ≤ 1.5s.
- Полное сохранение реализованных функций и страниц (отсутствие регресса).
- Единые UX‑паттерны, i18n и a11y; различия Mini‑App/Web — конфигами.
- Безопасность (CSP/XFO/CORS/Headers), строгий RBAC, совместимость с P20/P22.
- Авторизация: Mini‑App — auto из Telegram WebApp, Web — токен из Telegram (link‑flow).

## 2) Область работ
- Frontend: каркас, layout, навигация, меню, страницы, формы, темы/токены, guards, телеметрия.
- Config‑схемы (источник истины для UI): design‑tokens, themes, layout, nav/menu, features, forms.
- Read‑only API для конфигов UI (связка с P22): `/api/ui/config`, `/api/ui/themes`, `/api/ui/features`.
- Тестирование: unit/integ/E2E, визуальные и регрессионные, canary rollout.
- Admin: кнопка «Управление ботом» (start/stop/status) с RBAC и понятным UX.

## 3) Архитектура UI
- Слои:
  - Core: инициализация платформы (Mini‑App/Web), метрики старта, контекст пользователя.
  - Layout: контейнеры (Header/Sider/Content/Footer), брейкпоинты, адаптивность.
  - Navigation: маршруты, RBAC‑guards, ленивые страницы, кэш роутов.
  - Pages: функциональные разделы (см. реестр страниц).
  - Widgets: таблицы, формы, модальные окна, панели.
  - Styles: design‑tokens (CSS vars), темы, platform‑classes.
  - Guards: role/permission checks, scope‑видимость.
- Платформенные классы: `telegram-mini-app`, `sp-platform-telegram`, `sp-platform-web`.
- Сессия: Mini‑App — `tg_id` в `sessionStorage` (pre‑init); Web — токен в cookie/LS по политике безопасности.

## 4) Безопасность
- CSP минимум:
  - `script-src 'self' 'unsafe-inline' 'unsafe-eval' https://telegram.org`
  - `frame-src 'self' https://t.me https://*.telegram.org`
  - `frame-ancestors 'self' https://t.me https://*.telegram.org https://web.telegram.org`
- X‑Frame‑Options: SAMEORIGIN; Referrer‑Policy: strict-origin-when-cross-origin.
- Permissions‑Policy: запрет микрофона/камеры/гео по умолчанию.
- CORS: только доверенные origin; без `*`.
- `X-Telegram-User-ID` обязателен из Mini‑App.
- RBAC/Scopes: видимость меню/страниц/кнопок на основе ролей/разрешений; синхронизация с P22.

## 5) Авторизация и контексты
- Mini‑App: `Telegram.WebApp.initDataUnsafe.user.id` → `sessionStorage.tg_id`; все вызовы с `X-Telegram-User-ID`.
- Web: link‑flow токен, хранение по политике безопасности.
- UserContext: профиль, роли, разрешения, выбранный бот/команда.

## 6) Конфигурационные схемы
- `design‑tokens.json` → экспорт в CSS `--sp-*`.
- `themes.json` (light/dark/telegram).
- `layout.json` (слоты/брейки/видимость по платформе).
- `nav.menu.json` (дерево меню: id/title/icon/route/requiredPermissions[]/featureFlag?/platform?).
- `features.json` (фичефлаги и канареечные переключатели).
- `forms/*.json` (поля/маски/валидация/подсказки/зависимости).

## 7) Реестр страниц (без регресса)
- Core: TelegramHome, WebAuth, Home, Help, Settings, LLMSettings, LLMParams, Keywords, Payments.
- Chat: MiniAppChat, TelegramChat, ChatManagement.
- Soul: SoulDashboard, SoulGoals, SoulOptimization, SoulVisualization, SoulLogs.
- Admin: AdminPanel, SecurityDashboard, SecurityEvents, RBACAdmin, ArchitectPanel, Trace, ActivityGoalsIntegration, DatesReminders, DatesRemindersV2, SoulQuants, Register, Prompts, BotControl, SystemSettings.
- Для каждой страницы: контракт данных, зависимости, RBAC, навигация, loading/empty/error‑состояния, accessibility.

### BotControl (админ)
- Кнопки: «Запустить бота», «Остановить бота», «Статус».
- API: `POST /api/admin/bot/start`, `POST /api/admin/bot/stop`, `GET /api/admin/bot/status`.
- RBAC: доступ только для ролей с `soul.admin`.
- UX: явная индикация active/inactive, disable во время операций, тосты результата.

## 8) Производительность и метрики
- Бюджеты: TTI ≤ 1.5s (Mini‑App), ≤ 2.0s (Web); split/lazy/code‑splitting.
- Метрики: LCP/CLS/INP + собственные (время навигации, ошибки отрисовки, p95 API страницы).
- Отправка: `/api/monitoring` (batch), sampling, отказоустойчивость.

## 9) Платформенные различия
- Mini‑App: компактные шрифты/отступы, без тяжёлых анимаций, ограниченная навигация, скролл‑контейнеры.
- Web: расширенные таблицы, горячие клавиши, multi‑pane layout.
- Синхронизация темы c Telegram (если доступно SDK).

## 10) Формы и валидация
- Генерация UI из схем; валидаторы/маски; i18n/a11y.
- Унифицированный набор виджетов input/select/date/time/phone/tags/attachments/markdown.

## 11) Интеграция с P22/P20
- Фасады P20 для задач/событий/напоминаний/чата.
- Конфигурация `/api/ui/*` — read‑only.
- Учитываем `row_version`/ETag (конфликты/мягкие слияния).
- Admin API: bot start|stop|status (RBAC: `soul.admin`).

## 12) Тест‑план
- Unit: компоненты/guards/utils/валидаторы.
- Integration: маршруты/guards/меню, загрузка конфигов, i18n.
- E2E (Mini‑App/Web): авторизация, ключевые сценарии.
- Визуальные: скриншоты; регресс на фичефлагах.
- Контрактные: OpenAPI↔UI; Schema Guard.
- Производительность: TTI/перф в CI; Lighthouse/PSI (Web); замеры Mini‑App.

## 13) Внедрение (инкременты)
1) Каркас + Header; platform classes; pre‑init Mini‑App; метрики старта.
2) PermissionsProvider (без редиректов); загрузка ролей; безопасная отрисовка.
3) Маршруты партиями (Dashboard/Chat → Soul → Admin → Остальное), ленивые страницы.
4) Меню/Sider; responsive; темы/токены; удаление временной диагностики.
5) Отладка UI‑конфигов; i18n/a11y; UX‑полишинг.

## 14) Acceptance
- Mini‑App стабилен, TTI ≤ бюджета, без React #300; Web сопоставим.
- Все функции доступны; тесты зелёные; визуальные проверки ок.
- Все настройки из схем; RBAC/меню соответствуют ролям/скоупам.
- Метрики/health/алерты в норме; документация и реестры обновлены.
- Admin: кнопка start/stop/status работает и ограничена RBAC.

## 15) Риски/откат
- Перебор бюджета TTI → агрессивный split/кэш; отключение тяжёлых виджетов флагами.
- Несоответствие P20/P22 → Schema Guard/контракт‑тесты; PR‑гейт.
- Откат: пофайловые фичефлаги ENABLE_*; возврат к предыдущей стабильной партии.

## 16) Интеграционные цепочки (после запуска бота)
- Пост‑деплой (автосмок + ручной из Admin):
  - Диалог→Кванты (A): ввод → Persist/Trace/Strict JSON; UI без падений.
  - Напоминания/Календарь (E): CRUD → планирование → mock‑уведомление → календарь (P26).
  - Multi‑provider (G): DeepSeek дефолт; fallback GigaChat; тосты/индикаторы.
  - Health/Incidents (H): провокация нефатальных ошибок → алерты/дашборд (P21) → ссылки на логи/трейсы.
- До приёмки требуется:
  - Кнопка запуска цепочек + прогресс/лог.
  - Отчёт о прогоне (commit/branch/time/status/SLO) в Admin Monitoring.
  - Расширение набора цепочек (зафиксировать в P24 §2.1).
- Acceptance: все цепочки 200/ok; UI отражает статусы; нет регресса (React #300, маршруты, RBAC).

## 17) Единые требования к формам и таблицам (UX/UI)
- Таблицы:
  - Поиск/фильтры (дебаунс 250–400ms); сортировка; пагинация 10/20/50/100.
  - Sticky header; перенос длинных; управление колонками; массовые действия; тосты и подтверждения.
  - Экспорт CSV/JSON с respect фильтрам; виртуализация >500 строк.
  - Доступность: ARIA; фокус‑кольца; контраст ≥ WCAG AA.
- Формы:
  - Генерация из схем; валидаторы/маски; подсказки; запрет двойной отправки; `loading` у кнопок.
  - Конкурентность: `row_version`/ETag; мягкий мердж/предложение перезагрузки.
  - i18n: ru-RU даты/время; timezone сервера явно при расхождении.
- Кнопки/переключатели: типы, состояния, подписанные переключатели.
- Карточки/контейнеры: заголовок+подзаголовок, действия справа; унифицированные отступы; адаптивность AntD.

## 18) Чек‑листы страниц
### 18.1 LLMSettings
- GET `/api/llm/overview` — рендер без падений.
- Таб «Модели»: столбцы Модель/Описание/Контекст/Стоимость/Статус; бейдж количества.
- Таб «Функции»: `is_enabled`; выбор модели; `PUT /api/llm/functions/{name}`.
- Таб «Пайплайн чата»: JSON‑редактор; `PUT /api/llm/functions/chat` с `settings_json`.
- Таб «Мои настройки»: `PUT /api/llm/dev/user/preferences`.
- RBAC: `architect|admin`; неверный JSON подсвечивается; тосты ошибок/успеха.

### 18.2 SoulGoals
- Эндпоинты: `GET /api/soul/goals/`, `/summary`, `/{id}/milestones`, `/{id}/quants`, `POST /api/soul/goals/progress/update`.
- Таблица: поиск/фильтр/сортировка/пагинация; тултипы; кликабельные строки.
- Детали: вкладки этапов/квантов; статусы/теги; модал обновления.
- Регресс: поле `title`; сводка соответствует API; RBAC `architect`.

### 18.3 Reminders/Calendar
- API V2 и алиас старого `/miniapp/reminders` до удаления.
- Календарь: CRUD, повторы, палитры, тултипы/часы, клик по дню.
- Права: `api.reminders.*` управляют кнопками/действиями.
- Списки: группы, статистика, локаль dayjs `ru`; корректный `X-Telegram-User-ID`.

### 18.4 SystemSettings (админ)
- Маршрут `/admin/settings` (RBAC admin|architect), вкладки LLM/Reminders/Sleep/Router/Security.
- Источник: `GET /api/admin/soul/settings/all`; редактирование `PUT /api/admin/soul/settings`.
- Проверка LLM: `GET /api/admin/soul/llm/test?prompt=ping`.
- Мини‑апп адаптация: компактные компоненты; пагинация >10 записей.

## 19) Сборка/деплой/кэш
- Vite: sourcemap (debug), drop `debugger` (prod), console по флагу.
- Cache‑bust главного бандла `?v=<ts>`; audit dist в pre‑commit.
- Nginx SPA: `/assets` immutable; `index.html` no‑store; fallback `/` → `/index.html`.

## 20) CI/Smoke
- pre‑commit (husky): audit dist + vite build; запрет `localhost` в `dist`.
- CI: `VITE_DEBUG_LOGS=0`, `npm ci`, `npm run build`, `scripts/gate_dist.ps1`.
- Smoke (preview): `/, /webauth, /chat, /dates-reminders` + HEAD первого `assets/index-*.js`.

## 21) Структура каталогов (PROD)
- Рабочий фронт: `/var/www/soulpulse/frontend`.
- Аварийный фронт: `/var/www/soulpulse/minimal`.
- Временные билды: `/var/www/soulpulse/v/<build>/` (опционально).

## 22) Обратные петли анализа
- Для 26 ТЗ: дополняем реестр форм/ролей/роутов; уточняем UX/перф/безопасность; фиксируем в этом документе и реализуем.

## 23) Критерии приёма
- Mini‑App/Web стартуют без React #300 и редирект‑циклов.
- Формы включены по ролям; RBAC‑грид работает.
- DIAG/логи/ошибки — понятны; деплой воспроизводим; кэши корректны.

## 24) Интеграция с P24/P21 (уведомления и цепочки)
- Обязательные E2E цепочки (см. P24): A/E/G/H; UI‑метрики реакции на деградацию; алерты (P21).

---

## 25) Mini‑App: нюансы, проблемы и практики
Этот раздел фиксирует специфику Telegram Mini‑App в WebView, настройки, известные проблемы и проверенные решения.

### 25.1 Настройки окружения и платформы
- Router: `MemoryRouter` (Mini‑App и Web) — исключает историю/перенаправления WebView.
- Платформенные классы на `<body>`: `telegram-mini-app` и `sp-platform-telegram` для условных стилей.
- Высота: использовать `100dvh` вместо `100vh` (мобильные браузеры скрывают UI‑хром); контент‑области — `overflow-y:auto; -webkit-overflow-scrolling:touch;`.
- Telegram SDK: вызывать `Telegram.WebApp.ready()` после первичного рендера, `expand()` — опционально (может дергать высоту).
- Инициализация: `initDataUnsafe.user` может быть недоступен в первый тик — не полагаться на него для первого кадра.

### 25.2 Производительность старта
- Исключить тяжелые компоненты из первого кадра; отрисовывать Header‑only.
- Отключить ранние сетевые запросы до появления `tg_id`; показывать skeleton.
- Использовать флаги SAFE_BOOT/DIAG только временно; в проде — выключены.

### 25.3 Навигация, меню и guards
- RBAC/permissions не должны проводить redirect на первом кадре; управлять только видимостью.
- Меню/хедер должны быть устойчивыми к отсутствию данных; ошибки — баннеры с retry, не throw.

### 25.4 Скролл и верстка
- Запрещено ставить `overflow:hidden` на корневые контейнеры Mini‑App.
- Контент: `height:100dvh; overflow-y:auto; overscroll-behavior:contain; touch-action:pan-y`.
- Нижнее меню: фиксированная высота (≈26px) и тонкая граница сверху (`border-top:1px solid var(--sp-border-primary)`).
- Избегать nested‑scroll без необходимости; если используется — тестировать колесо/тач.

### 25.5 Диагностика и Error Boundaries
- RootErrorBoundary: выводит stack + componentStack + diag (wa, tg_id, href, UA, build‑id) с возможностью копирования.
- Локальные SectionBoundary вокруг рискованных узлов (Layout/меню/страницы) для быстрой локализации.
- Флаг `SHOW_ERROR_DETAILS` в проде выключен; включать точечно.

### 25.6 Безопасность (CSP/Headers)
- CSP согласована под Telegram SDK; запрещены внешние скрипты, кроме `https://telegram.org`.
- HSTS/XFO/XCTO/Referrer‑Policy/Permissions‑Policy — включены; CORS только доверенным origin.
- Заголовок `X-Telegram-User-ID` обязателен для Mini‑App API.

### 25.7 Нерешённые/открытые вопросы
- Единая синхронизация темы с Telegram (следует уточнить доступность API и реакцию на смену темы).
- Унификация высоты на Android WebView со старыми UA (проверить поведение `100dvh`).
- Поведение nested‑scroll внутри некоторых AntD‑компонентов (таблицы, модальные окна) — провести доп. тесты.

### 25.8 История проблем и их решения (кратко)
- React #300 на старте: устранено изоляцией Layout (SectionBoundary), упрощением мини‑лейаута до div, временным BYPASS_LAYOUT для локализации.
- «Широкая рамка» и отсутствие скролла: исправлено переходом на `100dvh`, снятием `overflow:hidden` с корня, добавлением `overflow-y:auto` на контент.
- Кнопка «Скопировать» в экране ошибок: добавлен fallback через скрытый `<textarea>` при недоступности `navigator.clipboard` + `user-select:text` и прокрутка.
- «Открыть веб‑доступ»: скрыто в Mini‑App, оставлено в Web; устранены визуальные конфликты старых CSS.

## Полный поток обработки в Mini‑App (консолидация)

Входные точки: ChatService (UI/WS), HTTP `/api/soul/process`, `/api/soul/process_batch`.
- Подготовка: PII‑маскирование (privacy.*), квоты/лимиты, контекст «architect_chat».
- Ветка ChatService: выбор модели, получение `full_ai_response`, разделение на `user_visible_response` и `analysis_data`, сохранение полного ответа в `messages`, фоновые задачи (keywords/reminders/§svc), санитайз видимого ответа (удаление «Accepted meanings…», «Generate up to…», `§sense/§qtags/§qew`, анти‑эхо), в режиме Архитектора маркеры не попадают в видимый ответ.
- `/api/soul/process`: единая сборка сообщений, batch‑fallback, выбор победителя по energy_weight, фоллбек `desired_action`, транзакционная персистенция `Message`→`quants`→`quant_desired_actions`, AGE/связи, «горячие» кванты, автопубликация инициатив.
- `/api/soul/process_batch`: stateless по умолчанию (без персистенции, очистка `desired_action=[]`), или persistent при `persist_all=true`.
- SoulCoreManager: язык, контекст, пред‑pipeline (keywords→meanings→quant_candidates), решение роутера, сборка `[CORE][ROUTER_CONTEXT][MODULES][OUTPUT_SPEC][NEGATIVE]+история+вопрос`, вызов LLM, post‑output guard, provenance (если включён), STRICT JSON парсинг и нормализация, self‑consistency, desired actions, метрики.
- Флаги: privacy.*, single.use_db_for_models, da.keep_in_stateless, persist_energy_threshold, batch_max_quants, planner.*, security.guard.*, provenance.*, TEST_NO_DB.
- Наблюдаемость: события/метрики/audit `soul_*`, распределение energy_weight, trace_id везде.
- Известная проблема «эхо техразбора» устранена: см. санитайз в ChatService и ядре.

## Сервисные ответы и режим Архитектора (диагностика)

Типы сервисных ответов:
- «Соул Спит» — мгновенный ответ без вызова LLM при включённом сне/оптимизации или запрете рождения квантов.
- «Ошибка с получением ответа от Соул» — при сбоях LLM/парсинга/внутренних исключениях; для роли Architect дополнен `§error{...}`.

Маркеризация (Architect mode):
- `§sense` — извлечённый смысл; `§qtags` — теги кванта; `§qew` — energy_weight; при ошибке — `§error{...}`.

Backend:
- `chat_service.py` — ветвление «сон/ошибка LLM»; добавление маркеров в режиме Architect.
- `telegram.py` — расширенный лог Telegram API (код/ответ/ошибка).

Frontend:
- ArchitectPanel/Trace — ссылки и вывод событий ошибок LLM (`soul_llm_error`).

Актуализация: при изменении поведения текстов/маркеров обновлять этот раздел и индексы.

## Mini‑App UI Reference (консолидация)

Каркас и навигация:
- `frontend/src/App.tsx` — маршруты (lazy), `PermissionsProvider`, гварды.
- `PlatformLayout.tsx` — различает Mini‑App/Web; `ModernHeader`, меню `PermissionBasedMenu`.
- Темы/стили: `useTheme.ts`, `styles/master.css`, `styles/miniapp-theme.css`.
- API/авторизация: `frontend/src/api.ts` (`API_BASE`, `buildAuthHeaders`, `tg_id`, JWT).

Ключевые страницы:
- Главная/Домашняя, WebAuth, Регистрация, Чат(ы), Промпты/Settings, LLMSettings/LLMParams, Платежи, Help.
- Архитектор: `ArchitectPanel`, `SoulDashboard`, `SoulGoals`, `ActivityGoalsIntegration`, `SoulOptimization`, `SoulVisualization`, `SoulLogs`, `Trace`, `SoulQuants`, Security Dashboard/Events.

Меню и права:
- `PermissionBasedMenu.tsx` и `usePermissions.tsx` — меню и гварды на основе `/api/user/ui-config`.
- Роли/доступ: скрытие недоступных разделов, фолбэки для Архитектора.

Обновления UI v3.0: lazy‑routes в `App.tsx`, событие `themeChange`, безопасный unlink целей.

Требование актуальности: любые UI‑изменения отражаются в этом разделе синхронно с кодом.

## Интеграция UI с RBAC

API UI‑конфига:
- `GET /api/user/permissions`, `/role-check/{role}`, `/permission-check/{perm}`, `/limits/{function}`, `/ui-config`.

Frontend хуки/компоненты:
- `usePermissions.tsx`, `usePlatform.tsx`.
- `PermissionGate`, `PlatformGate`, `PermissionButton`.
- `PermissionBasedMenu` — формирует пункты меню и скрывает недоступные.

Матрица доступа и производительность: см. P32 (роли/права/лимиты); UI — lazy‑load/мемоизация, кэш полномочий на сессию.

## Soul Dashboard & Trace (консолидация)

- Панель `SoulDashboard.tsx`: активность, KPI, «Этапы и ошибки», тестовая генерация.
- Источники: `/api/admin/soul/metrics/dashboard`, `/api/admin/soul/metrics/activity/recent`, `/api/admin/soul/audit/recent`.
- Trace View (план): `trace_id` сквозной; API `/api/admin/soul/trace/by-trace|by-quant|by-thread`; индексы по `event_type/quant_id/(meta.trace_id)`.
- UX: кнопка «Открыть цепочку» → модалка Trace Viewer; фильтры, экспорт.
- НФТ: P95 рендера ≤ 1.5с; live‑update через WebSocket; даунсемплинг историй.

## Mini‑App Styling Guide

- Класс контейнера: `telegram-mini-app` — включает профиль стилей Mini‑App.
- Учитывать CSS переменные Telegram (`--tg-theme-*`), применять собственные через `!important` для Mini‑App с изоляцией по классу.
- Базовые правила: принудительный цвет/фон для ключевых компонентов (карточки, кнопки, input), контрастность, адаптация меню.
- Тестирование: проверка в web (localhost:5173) и в Telegram Mini‑App; в консоли — наличие класса и применённых стилей.