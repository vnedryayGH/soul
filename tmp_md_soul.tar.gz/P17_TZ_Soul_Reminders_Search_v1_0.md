---

## Индекс взаимных ссылок (P01–P37)

- P20 TelegramBots Platform — интерфейсы календаря/напоминаний.
- P26 Calendar Transport — транспорт и каналы.
- P30 Processor — планирование/доставка.
- P33 Personification — Mini Chat: извлечение дат/§svc, уведомления.
- P45 Quant Generation Modes — пакетная генерация квантов и офлайн загрузка (JSONL→SQL), связи с напоминаниями/календарём.

### ТЗ Soul v1.0 — Поиск при напоминании (Reminder Search & Enrichment)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: MVP реализовано и задеплоено на PROD (prefetch); Stage‑2 — LLM‑планер и расширение схемы

---

### 0. Executive summary

- Цель: расширить систему напоминаний поддержкой «напоминание с поиском» — перед отправкой ответа в назначенное время система автоматически ищет свежую информацию (по URL или в поисковиках), обогащает контекст и формирует ответ с учётом найденного.
- Интеграция: без ломки ядра — используем существующий `desired_action: reminder`, добавляем признак поиска и конфиг в payload, фоновый планировщик "T‑offset" (по умолчанию 3 минуты до отправки), LLM‑планер задачи поиска и безопасный веб‑фетчер.
- По умолчанию планер LLM — Гигачат (бесплатный), поиски — Яндекс/Google (переключаемо). Все новые функции — за фичефлагами.
- По умолчанию планер LLM — Гигачат (бесплатный), поиски — Яндекс/Google (переключаемо). Все новые функции — за фичефлагами; LLM опционален и включается в панели.

---

### 1. Архитектура и точки интеграции

- Реализация (MVP):
  - `backend/app/services/web_fetcher.py` — безопасный асинхронный фетчер (таймауты, ретраи, ограничение объёма, политика доменов).
  - `backend/app/background_tasks.py` → `ReminderBackgroundTask._run_prefetch_if_needed` — планирование и выполнение prefetch за T‑offset до отправки.
  - `backend/app/services/reminder_service.py` — создание напоминаний; совместимость с различиями схемы на PROD.
  - `backend/app/services/reminder_actor.py` — ReminderActor: обогащение (LLM‑план + web‑поиск), персонализированная генерация и доставка (в т.ч. голосом).
  - `backend/app/models.py` — поля prefetch/search (prefetch_done, prefetch_time, prefetch_payload, search_query, search_url).
  - `backend/app/services/soul_settings_service.py` — секция `reminders.prefetch.*`.
  - Admin API/Frontend: использование существующих страниц напоминаний (доп. вкладка не обязательна на MVP).

Обновление 2025‑09‑21:

- ReminderActor использует реальные промпты персоны/ветки, сохранённые при создании/обнаружении запроса (`persona_prompt`, `llm_context_snapshot`) для LLM‑планирования, суммаризации фактов и финальной генерации текста.
- Доставка поддерживает голос (sendVoice) с алиасами Piper/Yandex; для «файны» применяется голос `faina` (алиас Piper → `ru_RU-kseniya-medium` с мягким FX).

---

### 2. Контракты и данные (payload JSON)

```json
{
  "enabled": true,
  "llm_provider": "gigachat",
  "target_url": "https://example.com/article",
  "search_engine": "yandex",
  "alt_engines": ["google"],
  "query": "курс доллара Мосбиржа",
  "offset_sec": 180,
  "plan": { "what": "курс USD/RUB", "where": "mos.ru; moex.com", "format": "краткая сводка с цифрами" }
}

```

Правила: без миграций в MVP (JSON поля в payload), Stage‑2 — отдельная таблица jobs.

---

### 3. Workflow

1) Создание напоминания (desired_action: reminder) → при наличии `search_query`/`search_url` сохраняются поля поиска (Stage‑2 Planner — опционален).
2) За `minutes_before` до due_at → `WebFetcher`: GET target_url либо SERP по движку (`engine=yandex|google`), сохраняем `prefetch_payload`.
3) В due_at → генерация текста напоминания с учётом `prefetch_payload` (выдержки/ссылки), отправка.

Фоллбек: при сетевых ошибках — отправить пояснение без блокировки.

---

### 4. Настройки/флаги

- Prefetch (MVP, секция `reminders.prefetch.*`):
  - `reminders.prefetch.enabled=true`
  - `reminders.prefetch.minutes_before=3`
  - `reminders.prefetch.engine=yandex|google|url`
  - `reminders.prefetch.timeout_ms=8000`
  - `reminders.prefetch.max_per_tick=10`
- Дополнительно:
  - `keyword_analysis.use_llm=true|false` — опциональный сервисный LLM; провайдер/тайминги настраиваются отдельно
  - allow/block списки доменов — на уровне конфигурации `WebFetcher`

---

### 5. Безопасность/приватность

- PII‑санитизация до логов/LLM.
- Запрет исполняемого контента; только текстовые выдержки + ссылки.

---

### 6. Наблюдаемость

- Аудит: `reminder_prefetch_ok|fail` (payload с url/engine/status), `reminder_send_done`; UX: `reminder_ack|reminder_snooze|reminder_cancelled` через Telegram‑callback.
- Подпись (P27): фиксируется шаг `svc.reminder.prefetch.fetch`; дополнительно в цепочке P30 присутствуют `svc.sequence.plan`, `svc.event.extract.llm`, `svc.time.now`, `svc.reminder.when.parse_llm`.
- Метрики: `reminder.fetch.p95_ms`, `reminder.fetch.error_rate`, coverage, usage_by_engine; для Acceptance контролируется `offset_hit_rate`.

Инспекторы (P27/P24):

- `reminder.actor.coverage` — проверяет наличие за окно времени шагов: `svc.reminder.context.restore|enrich.plan|enrich.fetch|enrich.summarize|generate|deliver`.

---

### 7. Acceptance

- Напоминания с «поиском» — сохраняют `prefetch_payload` и корректно обогащают уведомление; при сетевых ошибках — мягкий фоллбек без блокировки.
- Smoke (PROD): создание напоминания с `search_query` за 3 мин до due_at завершается 200; запись видна в `/api/miniapp/reminders`; инцидент `reminder_sent` зафиксирован.
- ReminderActor использует актуальный promt персоны (system) и `llm_context_snapshot` в запросах к LLM; в `signature_steps` присутствуют шаги Actor‑цепочки и обязательные шаги P27/P30 (см. выше).

---

### 8. Метрики, SLO, алерты

- Метрики: `reminder.fetch.p95_ms`, `reminder.fetch.error_rate`, `reminder.search.coverage`, `usage_by_engine`, `reminder.offset_hit_rate`
- SLO: `fetch.p95_ms ≤ 4000ms`, `error_rate ≤ 5%`, `offset_hit_rate ≥ 95%`
- Алерты: `error_rate > 8%` (10 мин), `offset_hit_rate < 90%` (60 мин)

---

### 9. Роль «Звонарь» (расширение спецификации)

Назначение: системная роль, ответственная перед Процессором (P30) за полный цикл напоминаний: извлечение из сообщений (DesiredAction→reminder), корректную постановку событий, доставку, целостность контекста и взаимодействие с другими сущностями.

Зона ответственности:

- Контроль источников напоминаний: MiniChat (§svc.tasks), прямые команды пользователя, интеграции календаря (P26).
- Верификация времени: нормализация «через X минут/часов/дней», TZ/DST, дедупликация окон ±2 мин.
- Постановка событий: инъекция `processor_events(kind="reminder")` с приоритетом по `priority` и `due_at`.
- Доставка: генерация персонализированного текста (учёт `active_persona`, `prefetch_payload`) и отправка в TG; фоллбек‑текст при ошибках LLM/сети.
- Наблюдаемость/подпись: шаги `svc.reminder.prefetch.fetch`, `svc.processor.*`, `svc.chat.reply_render` фиксируются; инциденты `reminder_*` регистрируются.
- Взаимодействие: Calendar/Goals (P26/P25), Router/DesiredAction (P03/P07), Guard/Signature (P27), RBAC/лимиты (P32), Hyperloop (P36) для управления и тестов.

Инварианты:

- Никаких служебных маркеров в видимом тексте; приватные данные маскируются до логов/LLM.
- Идемпотентность событий: `dedup_key = reminder:<id>:<due_at>` на уровне очереди.
- Stateless LLM‑вызовы для генерации текста уведомления (`db=None`), таймауты/ретраи по политике LLM.
- При включённом `delivery_guard.enforce` публикация блокируется при неполной подписи.

Метрики/SLO:

- `processor.events_processed{kind=reminder}`
- `processor.time_send_to_recv_ms{kind=reminder}` (p95)
- `reminder.offset_hit_rate` (попадание в окно ≤30 сек от due)
- `reminder.delivery_success_rate` и `telegram_send_error_rate`

Hyperloop (P36):

- `PROCESSOR.EVENT.INJECT kind=reminder payload={"reminder_id":"<id>","user":{"id":<uid>}}`
- `PROCESSOR.PROCESS_ONCE`
- Смоки: `CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"`

Acceptance для «Звонаря»:

- Due‑напоминания переводятся в события процессора и доставляются; при сбое — ретраи/инциденты; покрытие подписи видно в `signature_steps`.

---

### 9. Тест‑план

- Unit: выбор провайдера, таймауты, доменные политики, усечение текста
- Integration: URL доступен/падает; fallback на поисковик; RU/EN запросы; сохранение `prefetch_payload`
- Perf: 50 напоминаний в час — удержание SLO

---

### 10. Rollout

- DEV: включить `reminders.prefetch.enabled=true`, engine/тайминги по умолчанию
- STAGE: ограничить домены allow‑list, наблюдать метрики
- PROD: включено; деградации → временно выключить prefetch и отправлять обычные напоминания


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
