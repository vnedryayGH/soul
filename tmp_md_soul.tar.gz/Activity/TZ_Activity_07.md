### ТЗ (План реализации): Активности — Дирижер — Ощущения — Диспетчер Потоков (версия 07)

## 7.9. Админ‑метрики Диспетчера и UI‑виджеты (реализация v7)

Цель: обеспечить наблюдаемость работы Диспетчера Потоков (очередь, агрегаты, аналитика) напрямую в панели Архитектора без включения фоновых задач и без зависимости от ML‑модулей.

### Backend: Admin API

- Эндпоинт очереди (уже в ТЗ v7):
  - GET `/api/admin/dispatcher/queue`
    - Параметры: `status` (опц.), `limit` (int, по умолчанию 50)
    - Возвращает: `id, created_at, planned_for, activity_id, goal_id, policy, expected_energy, expected_entropy, priority, status, reason, human_summary`

- Новое (в рамках v7): агрегированные метрики:
  - GET `/api/admin/dispatcher/metrics`
    - Возвращает JSON:
      - `queue`: `{ in_queue, dispatched, skipped }` — счётчики по `flow_dispatch_queue`
      - `analytics`: массив последних часовых точек из `flow_dispatch_analytics_mv` (если MV присутствует):
        - `ts_hour, cnt_goal, cnt_explore, avg_ml_confidence, avg_value_per_cost`
    - Требования доступа: `soul.admin` (RBAC)

Примечания реализации:

- Совместимость с драйверами: синхронные агрегации через SQLAlchemy + `psycopg`.
- Наличие MV не обязательно — в этом случае `analytics: []`.

### Frontend: Панель Архитектора (UI)

- Вкладка «Диспетчер» добавлена в `ArchitectPanel`:
  - Кнопки:
    - «Загрузить метрики» — вызывает `GET /api/admin/dispatcher/metrics`, показывает модальное окно с агрегатами и таблицей `analytics`.
    - «Показать очередь» — вызывает `GET /api/admin/dispatcher/queue`, модальная таблица с текущими элементами (ключевые поля и `human_summary`).
    - «Запустить планирование» — `POST /api/admin/dispatcher/plan_once` (ручной цикл планирования, без фонового воркера).
    - «Материализовать» — `POST /api/admin/dispatcher/materialize_once` (однократный проход материализации).
  - Авторизация: через уже действующий механизм заголовка `X-Telegram-User-ID`/JWT.

- Новое (в рамках v7): настройки диспетчера:
  - GET `/api/admin/dispatcher/settings` — вернуть первую строку `conductor_settings` c ключевыми полями:
    - `dispatcher_enabled, dispatcher_mode, dispatcher_energy_budget, dispatcher_queue_max, dispatcher_exploration_temperature, schedule_budgets, ab_test_policies, dispatcher_state, fallback_policy, fallback_energy_budget, fallback_temperature`
  - PUT `/api/admin/dispatcher/settings` — частичное обновление разрешённых полей из списка выше (JSON/JSONB принимаются как строки);
  - Доступ — `soul.admin`.
  - Контролы настроек:
    - Пауза/возобновление (`dispatcher_state = paused|normal`)
    - Переключение режима (`dispatcher_mode = goal_driven|exploration`)
    - Быстрая установка энергобюджета (пример: `dispatcher_energy_budget = 5.0`)

### Data Pack для миграций (идемпотентные данные)

- SQL‑пакет `backend/scripts/migrations_data_pack.sql` (применяется в любой среде без дублей):
  - Гарантирует базовую строку в `conductor_settings`.
  - Обеспечивает наличие роли `Architect` в `llm_role_limits` (с `priority_boost=1.0`).
  - Добавляет пример активной цели `TEST DISPATCHER GOAL` (если отсутствует) — строго для тестовых стендов.

### Сид/Очистка тестовых данных (локальные сценарии)

- `backend/scripts/seed_dispatcher_dev.py`: создаёт базовые настройки и тестовую цель (`TEST DISPATCHER GOAL`).
- `backend/scripts/cleanup_dispatcher_dev.py`: удаляет тестовые элементы очереди/`generation_request` с безопасными фильтрами и тестовые цели, не затрагивая продуктивные данные.

### Acceptance (дополнение к v7)

- API `/api/admin/dispatcher/metrics` возвращает корректные агрегаты в пустой/наполненной очереди.
- Вкладка «Диспетчер» в панели отображает список очереди и аналитические строки без ошибок (даже если MV отсутствует).
- Запуск `plan_once`/`materialize_once` доступен c правами `soul.admin` и отрабатывает без фатальных ошибок при пустых данных.
- GET/PUT `/api/admin/dispatcher/settings` корректно читают/изменяют значения, UI‑кнопки применяют изменения без перезагрузки страницы.

Дата: 2025-09-10
Статус: План внедрения (этапы, DDL, UI, критерии)

ВАЖНО: Все алгоритмы/функции/настройки — в БД и доступны в панели Архитектора (RBAC, аудит). Ни одна функция не остается без UI‑отражения: формы, дашборды, включатели/пороговые значения, истории изменений.

### 0. Новые требования версии 07 (консолидация замечаний)

- Приоритизация запроса = f(RBAC роли пользователя, DGW факторов). Учет `llm_role_limits`.
- Масштабирование наблюдаемости: агрегированные MV/таблицы для UI‑графиков.
- Надежность: retries/compensation в диспетчеризации и материализации.
- Валидация входных данных кандидатов.
- Динамические бюджеты по расписанию.
- Cost‑aware приоритизация (priority / estimated_cost).
- A/B тестирование политик и аналитика.
- Safety режимы и интеграция с «красными кнопками».

### 1. DDL — расширения БД

#### 1.1. RBAC × DGW и лимиты ролей

```sql
-- Для упрощения: таблица лимитов ролей LLM (если отсутствует)
create table if not exists llm_role_limits (
  role text primary key,
  max_tokens_per_day int,
  max_rps numeric,
  priority_boost numeric default 0
);

-- Расширение generation_request для учета инициатора
alter table generation_request
  add column if not exists initiated_by_user_id int,
  add column if not exists initiated_by_role text;
create index if not exists idx_req_initiator on generation_request(initiated_by_role, initiated_by_user_id);

```

Правило: итоговый приоритет запроса `ReqPriority = RoleBoost(initiated_by_role) + DGW`.

#### 1.2. Очередь/Материализация — надежность

```sql
alter table flow_dispatch_queue
  add column if not exists retry_count int default 0,
  add column if not exists last_error text,
  add column if not exists human_summary text; -- человеко-читаемое объяснение

alter table generation_request
  add column if not exists retry_count int default 0;

```

Статусы дополнительны: `retrying`, `failed`.

#### 1.3. Валидация кандидатов

```sql
alter table flow_dispatch_queue
  add column if not exists validation_ok boolean,
  add column if not exists validation_issues jsonb;

```

#### 1.4. Динамические бюджеты

```sql
alter table conductor_settings
  add column if not exists schedule_budgets jsonb; -- {"msk_night": {"from":"01:00","to":"06:00","fallback_energy_budget":2.0}}

```

#### 1.5. Cost‑aware

```sql
alter table flow_dispatch_queue
  add column if not exists estimated_cost numeric,
  add column if not exists value_per_cost numeric; -- priority / cost
create index if not exists idx_flow_q_valuecost on flow_dispatch_queue(value_per_cost desc nulls last);

```

#### 1.6. A/B тестирование политик

```sql
alter table conductor_settings
  add column if not exists ab_test_policies jsonb; -- {"goal_driven":0.9, "exploration_aggressive":0.1}

create table if not exists flow_policy_assignment (
  id uuid primary key,
  created_at timestamptz not null default now(),
  cohort text not null, -- A|B|...
  policy text not null,
  user_id int null,
  thread_id uuid null,
  request_id uuid null
);

```

#### 1.7. Safety режимы

```sql
alter table conductor_settings
  add column if not exists dispatcher_state text default 'normal'; -- normal|goal_only|maintenance|paused

create table if not exists safety_protocol_events (
  id uuid primary key,
  created_at timestamptz not null default now(),
  level int not null, -- 1..3
  source text not null, -- 'ethics','admin','monitor'
  action text not null, -- 'soft_stop','pause','hard_kill'
  meta jsonb
);

```

#### 1.8. Аналитика (MV/агрегаты)

```sql
create materialized view if not exists flow_dispatch_analytics_mv as
select date_trunc('hour', created_at) as ts_hour,
       count(*) filter (where policy='goal_driven') as cnt_goal,
       count(*) filter (where policy like 'exploration%') as cnt_explore,
       avg((reason->>'ml_confidence')::numeric) as avg_ml_confidence,
       avg(value_per_cost) as avg_value_per_cost
from flow_dispatch_queue
group by 1;

create unique index if not exists uq_flow_dispatch_analytics_mv on flow_dispatch_analytics_mv(ts_hour);

```

### 2. Алгоритмы и поведение

#### 2.1. Итоговый приоритет (RBAC × DGW)

`ReqPriority = RoleBoost(initiated_by_role) + DGW`.

- RoleBoost берется из `llm_role_limits.priority_boost`.
- Для `Architect` — максимальный boost и обход некоторых лимитов с аудитом.

#### 2.2. Retries и компенсации

- Materializer и Дирижер при ошибках увеличивают `retry_count` и переводят статус в `retrying`; при превышении лимита — `failed`.
- Событие `dispatching_failed` в аудит с snapshot входных данных и `last_error`.
- Энергобюджет, зарезервированный под элемент, возвращается в пул (баланс в памяти процесса + запись в метриках цикла).

#### 2.3. Валидация данных кандидатов

- Перед расчетом приоритета выполняется валидация: диапазоны `energy_weight ∈ [0,1]`, наличие `goal_id/activity_id`, корректность `tags` и т.п.
- При ошибках — `validation_ok=false`, `validation_issues` заполняется, элемент помечается `skipped` с объяснением и аудитом `validation_failed`.

#### 2.4. Динамические бюджеты

- Планировщик применяет `schedule_budgets` (по часовому поясу MSK): ночью увеличивает `fallback_energy_budget`, днём — наоборот.
- Все переключения бюджетов логируются `budget_schedule_applied`.

#### 2.5. Cost‑aware диспетчеризация

- При равных приоритетах выигрывает меньшая `estimated_cost`.
- В режиме balanced цель: максимизировать Σ(value_per_cost) при ограничении энергобюджета.

#### 2.6. A/B тестирование

- Распределение по политикам согласно `ab_test_policies` (по пользователю/ветке/случайно, но детерминированно).
- Сохранение назначения в `flow_policy_assignment` и агрегирование результатов в MV.

#### 2.7. Safety и «красные кнопки»

- `dispatcher_state` влияет на выбор кандидатов: `goal_only` — исключает exploration; `maintenance` — минимальная активность; `paused` — полная пауза.
- При событиях `safety_protocol_events` уровня 1 — мягкая остановка; 3 — отмена всех `scheduled` и приостановка `dispatched` где возможно.
- Уведомления Архитектору через канал `alerts` и бота.

### 3. UI/Панель Архитектора

- Настройки: все поля `conductor_settings`/`llm_role_limits`/`schedule_budgets`/`ab_test_policies` с валидацией и подсказками.
- Очередь: список `flow_dispatch_queue`, карточка с `reason` и `human_summary`, действия promote/demote/skip/cancel.
- Графики: `flow_dispatch_analytics_mv`, `flow_dispatch_metrics`, A/B‑разрез.
- Safety: переключатель `dispatcher_state`, журнал `safety_protocol_events`, кнопки Soft Stop/Pause/Hard Kill (с подтверждением и RBAC).

### 4. План релиза (этапы)

Этап 1 (1–2 дня):

- DDL миграции для новых полей/таблиц/MV; UI формы для `conductor_settings`, очередь‑лист (read‑only).
- Базовый Materializer, статусы и аудит.

Этап 2 (2–4 дня):

- RBAC×DGW приоритизация; валидация кандидатов; retries/compensation.
- UI действий над очередью, `human_summary` и базовые графики.

Этап 3 (3–5 дней):

- Динамические бюджеты; cost‑aware; A/B тестирование с аналитикой MV.
- Safety режимы, «красные кнопки», интеграция с `alerts`.

Этап 4 (2 дня):

- Полировка UI/аудита, нагрузочное тестирование, документация.

### 5. Приемочные критерии (v7)

- В панели доступны настройки и действия для всех новых возможностей; все изменения пишутся в аудит.
- Итоговый приоритет учитывает роли; приоритеты Архитектора видимо доминируют.
- Очередь устойчива к ошибкам: есть retries, компенсации, валидатор.
- Динамические бюджеты и cost‑aware работают и отражаются в UI.
- A/B тестирование сохраняет назначения и показывает отчёты.
- Safety режимы меняют поведение системы и генерируют уведомления.
