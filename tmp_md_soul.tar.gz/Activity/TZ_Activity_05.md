### ТЗ: Активности — Дирижер — Ощущения — Диспетчер Потоков (версия 05)

Дата: 2025-09-10
Статус: Готово к быстрой реализации (v5 — планирование очереди)

### 0. Цель версии 05

Ввести компонент «Диспетчер Потоков» (Flow Dispatcher), который трансформирует цели и энергетические метрики в тактический план генерации Квантов: формирует очередь, балансирует ресурсы и интегрируется с Дирижером.

### 1. БД-расширения

#### 1.1. Настройки (расширение `conductor_settings`)

```sql
alter table conductor_settings
  add column if not exists dispatcher_enabled boolean default true,
  add column if not exists dispatcher_mode text default 'balanced', -- 'goal_driven'|'exploration'|'balanced'
  add column if not exists dispatcher_energy_budget numeric default 5.0, -- суммарный energy_weight на цикл
  add column if not exists dispatcher_queue_max int default 1000,
  add column if not exists dispatcher_exploration_temperature numeric default 0.9;

```

#### 1.2. Очередь диспетчера

```sql
create table if not exists flow_dispatch_queue (
  id uuid primary key,
  created_at timestamptz not null default now(),
  planned_for timestamptz, -- желаемое время запуска
  activity_id uuid not null references activity(id) on delete cascade,
  goal_id uuid null,       -- цели из goals_view/quantum_goals
  request_id uuid null references generation_request(id) on delete set null,
  policy text not null,    -- goal_driven|exploration|balanced
  expected_energy numeric, -- из прогноза/эвристики
  expected_entropy numeric,
  priority numeric not null, -- финальный вычисленный приоритет
  status text not null default 'queued', -- queued|scheduled|dispatched|skipped|cancelled
  reason jsonb
);
create index if not exists idx_flow_q_status_priority on flow_dispatch_queue(status, priority desc, created_at);

```

#### 1.3. Метрики диспетчера

```sql
create table if not exists flow_dispatch_metrics (
  ts_hour timestamptz primary key,
  queued int,
  scheduled int,
  dispatched int,
  skipped int,
  energy_budget_used numeric,
  cache_hit_rate numeric,
  ml_gating_rejects int
);

```

### 2. Политики планирования очереди

#### 2.1. Goal-Driven

- Приоритет цели: G_priority = goal.priority × (1 + avg_energy_weight_of_related_quants).
- В очередь добавляются запросы, семантически близкие целям с наибольшим G_priority.
- Используются кэш/векторный поиск/граф‑близость (через `graph_cluster_cache`).

#### 2.2. Exploration

- Активируется при низкой средней энергии (avg_energy_weight < threshold) или по расписанию.
- Для запросов повышается `temperature` (используется поле ветки/батча), приоритизируются темы с высокой ожидаемой энтропией.

#### 2.3. Balanced

- Чередование высокоэнергетических и низкоэнергетических задач; управление «энергетическим бюджетом» на цикл через `dispatcher_energy_budget`.
- Нельзя последовательно планировать более N высокоэнергетических заданий (N — настройка, по умолчанию 1–2).

### 3. Интеграция с Дирижером (v4)

- Соблюдать лимиты `compute_time_budget_ms`, `max_batches_per_cycle`.
- Использовать `graph_cluster_cache` для быстрой оценки группировки; попадания/промахи фиксировать `graph_cache_hit/miss` в аудите.
- Применять ML‑гейтинг: при `predicted_confidence < ml_min_confidence_threshold` отбрасывать/снижать приоритет элементов очереди.
- После планирования очередь «материализуется» в `generation_request`/батчи Дирижера.

### 4. Мониторинг и управление

#### 4.1. Дашборд очереди

- Лента элементов очереди: цель/активность/ожидаемая энергия/политика/приоритет/статус.
- Графики: загрузка ресурсов, hit‑rate кэша, % полезных Квантов, расход бюджета энергии.
- Действия: promote/demote/skip/cancel.

#### 4.2. Admin API (черновик)

- POST `/api/admin/soul/dispatcher/promote/{queue_id}`
- POST `/api/admin/soul/dispatcher/demote/{queue_id}`
- POST `/api/admin/soul/dispatcher/skip/{queue_id}`
- POST `/api/admin/soul/dispatcher/pause`
- POST `/api/admin/soul/dispatcher/resume`

Все действия пишутся в `soul_audit_log` (actor=dispatcher).

### 5. Алгоритм работы Диспетчера

1) На вход: активные цели, состояние очереди, бюджет времени/энергии, кэш графа, предсказания ML.
2) Выбор политики (`dispatcher_mode`) и сбор кандидатов.
3) Расчёт приоритета кандидатов (на базе DGW факторов и G_priority/энтропии/бюджета).
4) Гейтинг по ML‑уверенности, отбраковка или снижение приоритета.
5) Наполнение `flow_dispatch_queue` и планирование `planned_for`.
6) Передача запланированных элементов в Дирижер: создание/обновление `generation_request` и батчей.
7) Логирование решений с snapshot (входные метрики/выбранная политика/расчёт приоритетов).

### 6. DDL дополнительно (фрагменты)

```sql
-- Индикатор паузы диспетчера
alter table conductor_settings add column if not exists dispatcher_paused boolean default false;

-- Материализация в generation_request
alter table generation_request
  add column if not exists dispatcher_queue_id uuid;
create index if not exists idx_req_dispatcher on generation_request(dispatcher_queue_id);

```

### 7. Приемочные критерии (v5)

- Диспетчер формирует очередь по выбранной политике и укладывается в бюджет вычислений и энергии.
- Очередь видна в панели, доступна ручная приоритизация и пауза/возобновление.
- Интеграция с Дирижером корректная: элементы очереди превращаются в запросы/батчи.
- Аудит фиксирует ключевые решения и снапшоты.

### 8. Дорожная карта

1) MVP: FIFO + бюджет времени, события аудита, базовый дашборд.
2) Goal‑Driven + кэширование + простая визуализация очереди.
3) Balanced/Exploration, ML‑гейтинг, полный дашборд и admin API.
