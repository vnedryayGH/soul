### ТЗ: Активности — Дирижер — Ощущения (версия 04)

Дата: 2025-09-10
Статус: Готово к быстрой реализации (v4 — усиление управляемости и производительности)

### 0. Цели версии 04

- Снизить вычислительную нагрузку за счет кэширования графовых вычислений и бюджетирования.
- Повысить качество и контролируемость ML‑прогнозов (валидация, пороги доверия, переобучение).
- Улучшить интерпретируемость решений (вклад факторов DGW, объяснения ML).
- Обезопасить автокалибровку коэффициентов (диапазоны, sandbox, staged rollout/approval).

Базой является v3. Все параметры/переменные — из БД. Цепочка: Данные БД → Алгоритмы → Транспорты → Интерфейсы.

### 1. Расширения БД

#### 1.1. Настройки Дирижера (расширение `conductor_settings`)

- compute_time_budget_ms int default 150
- max_requests_per_cycle int default 200
- max_batches_per_cycle int default 20
- graph_cache_ttl_minutes int default 30
- graph_cache_max_entries int default 10000
- ml_min_confidence_threshold numeric default 0.5
- ml_retrain_cron text default '0 3 * * *'  -- ежедневно 03:00
- dgw_coeff_a_min..dgw_coeff_f_min numeric default 0
- dgw_coeff_a_max..dgw_coeff_f_max numeric default 10
- sandbox_enabled boolean default false
- sandbox_params jsonb default '{}'::jsonb
- rollout_strategy text default 'approve'  -- 'immediate'|'approve'|'staged'
- rollout_staged_percentage int default 10
- rollout_staged_users uuid[] default '{}'

DDL (фрагменты):

```sql
alter table conductor_settings
  add column if not exists compute_time_budget_ms int default 150,
  add column if not exists max_requests_per_cycle int default 200,
  add column if not exists max_batches_per_cycle int default 20,
  add column if not exists graph_cache_ttl_minutes int default 30,
  add column if not exists graph_cache_max_entries int default 10000,
  add column if not exists ml_min_confidence_threshold numeric default 0.5,
  add column if not exists ml_retrain_cron text default '0 3 * * *',
  add column if not exists dgw_coeff_a_min numeric default 0,
  add column if not exists dgw_coeff_a_max numeric default 10,
  add column if not exists dgw_coeff_b_min numeric default 0,
  add column if not exists dgw_coeff_b_max numeric default 10,
  add column if not exists dgw_coeff_c_min numeric default 0,
  add column if not exists dgw_coeff_c_max numeric default 10,
  add column if not exists dgw_coeff_d_min numeric default 0,
  add column if not exists dgw_coeff_d_max numeric default 10,
  add column if not exists dgw_coeff_e_min numeric default 0,
  add column if not exists dgw_coeff_e_max numeric default 10,
  add column if not exists dgw_coeff_f_min numeric default 0,
  add column if not exists dgw_coeff_f_max numeric default 10,
  add column if not exists sandbox_enabled boolean default false,
  add column if not exists sandbox_params jsonb default '{}'::jsonb,
  add column if not exists rollout_strategy text default 'approve',
  add column if not exists rollout_staged_percentage int default 10,
  add column if not exists rollout_staged_users uuid[] default '{}';

```

#### 1.2. Кэш графовых вычислений

- `graph_cluster_cache`:
  - id uuid pk
  - cache_key text not null unique  -- hash(activity_id + goal_id + semantic_key)
  - cluster_ref jsonb not null      -- метаданные кластера/топ‑узлы/метрики
  - score numeric not null          -- агрегированный показатель близости
  - expires_at timestamptz not null
  - created_at timestamptz default now()
  - last_hit_at timestamptz
  - hit_count int default 0

```sql
create table if not exists graph_cluster_cache (
  id uuid primary key,
  cache_key text not null unique,
  cluster_ref jsonb not null,
  score numeric not null,
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  last_hit_at timestamptz,
  hit_count int not null default 0
);
create index if not exists idx_graph_cache_exp on graph_cluster_cache(expires_at);

```

#### 1.3. Качество данных и ML‑регистрация

- `ml_training_examples`:
  - id uuid pk
  - created_at timestamptz default now()
  - features jsonb not null
  - label_energy numeric not null
  - weight numeric default 1
  - source_request_id uuid null references generation_request(id) on delete set null
  - activity_id uuid null references activity(id) on delete set null
  - thread_id uuid null
  - is_valid boolean default true
  - validation_issues jsonb

- `ml_models_registry`:
  - id uuid pk
  - model_name text not null
  - version text not null
  - created_at timestamptz not null default now()
  - params jsonb not null
  - metrics jsonb not null  -- {rmse, mae, r2, auc, ...}
  - is_current boolean not null default false

- `ml_retraining_runs`:
  - id uuid pk
  - started_at/finished_at timestamptz
  - dataset_stats jsonb
  - model_version_old text
  - model_version_new text
  - status text not null default 'running'
  - error text

```sql
create table if not exists ml_training_examples (
  id uuid primary key,
  created_at timestamptz not null default now(),
  features jsonb not null,
  label_energy numeric not null,
  weight numeric default 1,
  source_request_id uuid,
  activity_id uuid,
  thread_id uuid,
  is_valid boolean not null default true,
  validation_issues jsonb
);

create table if not exists ml_models_registry (
  id uuid primary key,
  model_name text not null,
  version text not null,
  created_at timestamptz not null default now(),
  params jsonb not null,
  metrics jsonb not null,
  is_current boolean not null default false
);

create table if not exists ml_retraining_runs (
  id uuid primary key,
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  dataset_stats jsonb,
  model_version_old text,
  model_version_new text,
  status text not null default 'running',
  error text
);

```

#### 1.4. Объяснения ML‑предсказаний

- `ml_prediction_explanations`:
  - id uuid pk
  - request_id uuid not null references generation_request(id) on delete cascade
  - model_version text not null
  - top_features jsonb not null   -- {feature: contribution}
  - shap_approx jsonb null
  - created_at timestamptz default now()

```sql
create table if not exists ml_prediction_explanations (
  id uuid primary key,
  request_id uuid not null references generation_request(id) on delete cascade,
  model_version text not null,
  top_features jsonb not null,
  shap_approx jsonb,
  created_at timestamptz not null default now()
);
create index if not exists idx_ml_expl_req on ml_prediction_explanations(request_id);

```

### 2. Алгоритмы и производительность

#### 2.1. Бюджетирование вычислений

- Каждый цикл Дирижера ограничен `compute_time_budget_ms`, `max_requests_per_cycle`, `max_batches_per_cycle`.
- Внутри цикла все дорогостоящие операции (графовый анализ, ML‑прогноз, векторный поиск) выполняются с time‑budget и кратной деградацией: пропуск шага → fallback.

#### 2.2. Кэш графовых кластеров

- Перед графовой кластеризацией вычисляется `cache_key`; при попадании — используем `cluster_ref`; обновляем `hit_count`/`last_hit_at`.
- При промахе — считаем кластер, сохраняем в `graph_cluster_cache` с TTL `graph_cache_ttl_minutes`.
- Регулярная очистка просроченных записей и LRU‑ограничение по `graph_cache_max_entries`.

#### 2.3. Гейтинг по доверию ML

- Если `predicted_confidence < ml_min_confidence_threshold`, вклад `E_pred` в DGW зануляется (или масштабируется), и запрос маршрутизируется по базовой эвристике.
- Все решения гейтинга фиксируются в аудите `ml_gating_decision` с причинами.

#### 2.4. Валидация и очистка данных

- При формировании `ml_training_examples` выполняются проверки: диапазоны, пропуски, аномалии; проблемы пишутся в `validation_issues` и помечаются `is_valid=false`.
- В тренировочный набор попадают только валидные записи; summary валидности сохраняется в `ml_retraining_runs.dataset_stats`.

#### 2.5. Переобучение модели

- По `ml_retrain_cron` воркер запускает обучение на свежих данных с holdout‑подвыборкой, считает метрики, записывает в `ml_models_registry`.
- Включение новой версии — согласно `rollout_strategy` (см. 3.3).

### 3. Безопасность автокалибровки и развёртываний

#### 3.1. Диапазоны коэффициентов

- При любом обновлении A..F значения ограничиваются [coeff_min, coeff_max] из `conductor_settings`.
- При выходе за границы — отказ и запись в аудит `coefficients_reject_out_of_range`.

#### 3.2. Sandbox‑режим

- При `sandbox_enabled=true` новые коэффициенты/модель применяются только для процентов/группы пользователей из `rollout_staged_*` и не влияют на глобальные метрики.
- Результаты эксперимента записываются в `conductor_optimization_runs` и `soul_audit_log`.

#### 3.3. Стратегии выката

- rollout_strategy:
  - 'immediate' — мгновенное применение (только при явном подтверждении Архитектором).
  - 'approve' — изменение ждёт ручного подтверждения в панели.
  - 'staged' — поэтапный выкат: `rollout_staged_percentage` и/или список `rollout_staged_users`.

### 4. Интерпретируемость и интерфейсы

#### 4.1. Вклад факторов DGW

- В дашборде отображать стек‑диаграмму вклада факторов (P_static, E_quant, G_goal, S_sensation, E_eff, E_pred) в итоговый DGW для выбранных запросов/батчей.
- Фактические значения берутся из `generation_request.dgw_factors`.

#### 4.2. Объяснение ML‑прогнозов

- Для запросов с предсказанием показывать топ‑фичи из `ml_prediction_explanations.top_features`; при наличии SHAP‑оценок — мини‑визуализацию.
- В карточке запроса: модель/версия, уверенность, объяснение, решение гейтинга.

#### 4.3. Панель безопасных развёртываний

- Управление sandbox, просмотр сравнения before/after, одобрение/откат, настройка staged rollout.

### 5. Аудит

- Для событий: `graph_cache_hit/miss`, `ml_gating_decision`, `coefficients_autotune`, `coefficients_reject_out_of_range`, `rollout_approved/rolled_back/applied` добавлять подробный `meta` со снимками входных данных и результатами.

### 6. DDL дополнительно (фрагменты)

```sql
-- Ограничение коэффициентов при обновлении (пример функции‑валидации)
create or replace function validate_coeff_ranges() returns trigger as $$
begin
  if new.dgw_coeff_a < new.dgw_coeff_a_min or new.dgw_coeff_a > new.dgw_coeff_a_max then
    raise exception 'dgw_coeff_a out of range';
  end if;
  -- Аналогично для b..f
  return new;
end; $$ language plpgsql;

drop trigger if exists trg_validate_coeffs on conductor_settings;
create trigger trg_validate_coeffs before update on conductor_settings
for each row execute function validate_coeff_ranges();

```

### 7. Приемочные критерии (v4)

- Дирижер ограничивает вычисления бюджетами; при превышении — корректно деградирует без ошибок.
- Графовая кластеризация использует кэш; видны события cache hit/miss в аудите.
- ML‑гейтинг по доверию работает; при низкой уверенности вклад E_pred не учитывается, решение логируется.
- Валидация данных формирует `ml_training_examples` только из валидных записей; есть отчёт о качестве.
- Переобучение модели выполняется по расписанию; замена модели — согласно стратегии выката.
- Диапазоны коэффициентов enforced; sandbox и staged rollout доступны и управляются из панели.
- В дашборде доступны вклад факторов DGW и объяснения ML.

### 8. Порядок внедрения (этапность)

1) Включить E_eff и бюджетирование вычислений.
2) Severity Ощущений (из v3) и визуализация вкладов DGW.
3) Графовый кэш и кластеризация.
4) ML‑гейтинг по порогу доверия.
5) Валидация данных и расписание переобучения; модель‑реестр.
6) Sandbox и безопасные выкаты; автокалибровка в ограничениях.
