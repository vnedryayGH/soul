### ТЗ: Активности — Дирижер — Ощущения (версия 02)

Дата: 2025-09-10
Ответственный: Архитектор проекта
Статус: Готово к быстрой реализации (MVP → расширение)

### 0. Цели и рамки

- **Цель**: превратить «Дирижер» в самооптимизирующуюся систему управления потоком генерации Квантов, интегрированную с Активностями, Ощущениями и Целями, с прозрачным управлением через панель Архитектора.
- **Принцип внедрения**: строгое следование цепочке изменений: **Данные БД → Алгоритмы → Транспорты → Интерфейсы**.
- **Требование**: все параметры/переменные — только из БД, настраиваются в панели Архитектора; заглушек не создавать. Используем уже существующие Кванты/связи из БД.
- **Выходной результат**: рабочий модуль с управляемыми очередями, батчингом и обратной связью, с аудитом и визуализациями в панели.

### 1. Термины

- **Активность**: настраиваемая деятельность Соул, создающая запросы на генерацию Квантов.
- **Дирижер**: компонент, формирующий и упорядочивающий очередь запросов, объединяющий их в батчи, управляющий ресурсами.
- **Ощущения**: контур непрерывной обратной связи, вычисляющий сигналы на основе метрик качества/энергии/энтропии Квантов и состояния очереди.
- **DGW** (Dynamic Generation Weight): динамический вес запроса на генерацию, используемый для приоритезации.
- **Квантовое тяготение**: батчинг семантически близких запросов вокруг активных Целей/Квантов.

### 2. Нефункциональные требования

- **Надежность**: гарантированная доставка, повторные попытки, идемпотентность обработки батчей.
- **Наблюдаемость**: аудит каждого решения Дирижера, метрики очереди и потребления токенов.
- **Производительность**: устойчивость при росте очереди; батчинг снижает число LLM-вызовов.
- **Безопасность**: доступ к панели только Архитектору/админам (RBAC), действия логируются.

### 3. Данные БД (истина в последней инстанции)

Важно: ниже описаны только новые/расширяемые сущности. Существующие таблицы Квантов и их связей используются как есть; деградацию не допускаем.

#### 3.1. Справочники и конфигурации

- `activity` — реестр Активностей:
  - id (uuid, pk)
  - name (text, uniq within owner)
  - code (text, uniq global)
  - is_enabled (bool, default true)
  - priority_static (int, default 0)
  - time_min_minutes_per_day (int, default 0)
  - time_max_minutes_per_day (int, nullable)
  - persona_prompt_id (uuid, fk → persona_prompt)
  - official_identity_id (uuid, fk → official_identity)
  - created_by / updated_by (uuid, fk → users)
  - created_at / updated_at (timestamptz)
  - indexes: (is_enabled, priority_static), (code), (persona_prompt_id)

- `activity_goal` — связи Активности с Целями:
  - id (uuid, pk)
  - activity_id (uuid, fk → activity)
  - goal_id (uuid, fk → goals)
  - goal_type (enum: regular|absolute|episodic|trigger|situational)
  - target_metric (jsonb) — показатели/пороговые значения
  - weight (numeric, default 1)
  - is_active (bool, default true)
  - created_at / updated_at (timestamptz)
  - unique(activity_id, goal_id)

- `activity_permission` — полномочия Активности (возможности модулей):
  - id (uuid, pk)
  - activity_id (uuid, fk → activity)
  - capability (enum: notify_architect|read_messenger|send_messenger|read_email|send_email|custom)
  - config (jsonb)
  - is_allowed (bool, default false)
  - unique(activity_id, capability)

- `conductor_settings` — глобальные настройки Дирижера:
  - id (uuid, pk, singleton=TRUE)
  - dgw_coeff_a, dgw_coeff_b, dgw_coeff_c, dgw_coeff_d (numeric, default 1)
  - batch_size_max (int, default 10) — предпочтение: батчи по 10
  - batch_tokens_max (int, default 4000)
  - daily_limit_free_tokens (int, nullable)
  - daily_limit_paid_tokens (int, nullable)
  - rate_limit_rps (numeric, default 1)
  - retry_max_attempts (int, default 3)
  - retry_backoff_initial_ms (int, default 1000)
  - retry_backoff_multiplier (numeric, default 2)
  - forecast_horizon_hours (int, default 6)
  - starvation_avoidance_window (int, default 30) — минута
  - created_at / updated_at (timestamptz)

- `sensation_rule` — правила вычисления сигналов Ощущений:
  - id (uuid, pk)
  - name (text)
  - metric (enum: avg_energy|avg_valence|entropy|queue_growth|error_rate)
  - window_minutes (int)
  - function (enum: zscore|ema|percentile)
  - polarity (enum: positive|negative|bidirectional)
  - weight (numeric, default 1)
  - threshold (numeric, nullable) — порог для триггеров
  - is_enabled (bool, default true)
  - created_at / updated_at (timestamptz)

#### 3.2. Очередь и батчинг

- `generation_request` — единичный запрос на генерацию:
  - id (uuid, pk)
  - activity_id (uuid, fk → activity)
  - goal_id (uuid, fk → goals, nullable)
  - quantum_seed_id (uuid, fk → quanta, nullable) — семя/контекст
  - prompt_hint (text) — подсказка/задача от Робота Активности
  - dgw_value (numeric) — вычисленный вес
  - dgw_factors (jsonb) — разложение по факторам P_static/E_quant/G_goal/S_sensation
  - status (enum: queued|batched|processing|succeeded|failed|cancelled)
  - priority_bucket (int) — для быстрой выборки
  - error (jsonb, nullable)
  - attempts (int, default 0)
  - created_at / updated_at / processed_at (timestamptz)
  - indexes: (status, priority_bucket, dgw_value desc), (activity_id), (created_at)

- `generation_batch` — батч связанных запросов:
  - id (uuid, pk)
  - semantic_cluster_id (uuid, nullable)
  - requests (uuid[]) — состав батча (или отдельная табл. many-to-many `generation_batch_item`)
  - provider_account_id (uuid, fk → llm_account)
  - model (text)
  - tokens_input (int, default 0)
  - tokens_output (int, default 0)
  - status (enum: ready|processing|succeeded|failed)
  - response (jsonb, nullable)
  - error (jsonb, nullable)
  - created_at / updated_at / completed_at (timestamptz)
  - indexes: (status, created_at)

#### 3.3. Поставщики LLM и бюджеты

- `llm_provider`:
  - id (uuid, pk)
  - name (text) — например: openai, anthropic, google, local
  - base_url (text)
  - is_enabled (bool, default true)

- `llm_account`:
  - id (uuid, pk)
  - provider_id (uuid, fk → llm_provider)
  - label (text)
  - api_key_secret_ref (text) — ссылка на секрет (vault)
  - model_default (text)
  - ctx_window (int)
  - price_token_input (numeric)
  - price_token_output (numeric)
  - daily_token_budget (int, nullable)
  - is_enabled (bool, default true)

#### 3.4. Аудит и метрики

- `soul_audit_log`:
  - id (uuid, pk)
  - ts (timestamptz)
  - actor (enum: conductor|sensation|robot|user)
  - action (text)
  - entity_type (text)
  - entity_id (uuid, nullable)
  - reason (jsonb)
  - user_id (uuid, fk → users, nullable)

- `queue_metrics_hourly`:
  - ts_hour (timestamptz, pk)
  - queued_count (int)
  - processing_count (int)
  - succeeded_count (int)
  - failed_count (int)
  - avg_dgw (numeric)
  - tokens_input (int)
  - tokens_output (int)

#### 3.5. Семантическая близость и граф

- Если используется pgvector: добавить `embedding` (vector) для нужных сущностей (например, активных Целей) и HNSW-индексы для ближайших соседей.
- Если используется Apache AGE для графа связей Квантов, в скриптах синхронизации для `relation_type` применять: `COALESCE(connection_type::text, 'semantic')`.

#### 3.6. Начальные значения

- В `conductor_settings`: batch_size_max=10, dgw_coeff_a=b=c=d=1, retry_max_attempts=3.
- Базовые `sensation_rule`: avg_energy/ema/pos; entropy/ema/neg; queue_growth/zscore/neg.

#### 3.7. Согласование с существующими таблицами Квантов (точные имена/поля)

Источник истины: действующие миграции и схемы проекта (`quants`, `quant_desired_actions`, `quant_connections`, `quantum_goals`, `messages`, `chat_threads`, `soul_audit_log`).

- `quants` (минимально необходимый подмножество полей для интеграции):
  - id UUID pk
  - thought_form TEXT
  - payload JSONB
  - energy_weight FLOAT/NUMERIC
  - composite_emotion JSONB ИЛИ набор полей `emotion_*` (поддерживаются обе формы; автодетект по наличию столбцов)
  - created_at TIMESTAMPTZ
  - tags JSONB/TEXT[] (поддержка обеих реализаций)
  - Примечание: при наличии таблицы `messages` поддерживается связка 1:1 `quants.id = messages.id` (в `Soul/quants_schema_v1.sql` добавлен FK NOT VALID). Дирижер должен работать корректно при наличии/отсутствии этого ограничения.

- `quant_connections`:
  - from_quant_id, to_quant_id UUID fk → quants(id)
  - connection_type ENUM ('semantic','causal','episodic','goal_link')
  - connection_strength NUMERIC(0..1)
  - keyword_overlap NUMERIC(0..1)
  - Индекс уникальности по (from_quant_id, to_quant_id, connection_type) обязателен.
  - При синхронизации графа/AGE для `relation_type` использовать `COALESCE(connection_type::text,'semantic')`.

- `quantum_goals` ИЛИ `goals`:
  - В проекте присутствует `quantum_goals` (id, quant_id, priority, is_active, completed_at).
  - В этом ТЗ `activity_goal.goal_id` допускает ссылку на активную цель как на запись в `quantum_goals` (либо совместимый представительный слой «Цели»). Для совместимости добавить слой представления `goals_view` (см. миграции) поверх `quantum_goals`.

- `messages`:
  - id UUID pk
  - thread_id UUID fk → chat_threads(id)
  - sender_type TEXT ('user'|'bot')
  - text TEXT
  - created_at TIMESTAMPTZ
  - При наличии связки 1:1 с `quants.id` новые Кванты создаются с тем же `id`, что и сообщение-ответ.

- `chat_threads`:
  - id UUID pk
  - user_id INT fk → users(id)
  - created_at TIMESTAMPTZ
  - Расширения для ветвления/типов добавлены в разделе 11 (миграции ниже).

- `soul_audit_log` (существующая):
  - Поля: created_at/timestamp, event_type/action, quant_id, meta/description (+ back-compat колонки). Данный ТЗ использует её как универсальный аудит; новые поля не требуются.

Требование: не создавать дубликатов упомянутых таблиц; только расширять через миграции, соблюдая обратную совместимость.

### 4. Алгоритмы

#### 4.1. Вычисление DGW

Формула: DGW = (A × P_static) + (B × E_quant) + (C × G_goal) + (D × S_sensation)

- `P_static` — priority_static Активности.
- `E_quant` — средний энергетический вес последних N Квантов Активности (N и окно — из настроек; по умолчанию N=20, окно 7 дней).
- `G_goal` — близость к активным Целям: косинусное сходство embedding запроса к embedding активных Целей (максимальное значение по целям активности).
- `S_sensation` — агрегированный сигнал от правил Ощущений (взвешенная сумма rule.value × rule.weight с учетом polarity).
- Коэффициенты A, B, C, D — из `conductor_settings`.

`dgw_factors` сохраняет детали: {P_static, E_quant, G_goal, S_sensation, A, B, C, D}.

#### 4.2. Основной цикл Дирижера

1) Забрать новые `generation_request` со статусом `queued`, пересчитать `DGW`, задать `priority_bucket` (например, по квантилям DGW).
2) Применить «Квантовое тяготение»: кластеризовать по семантической близости к активным Целям/текущему фокусу; сформировать батчи до `batch_size_max` и `batch_tokens_max`.
3) Назначить `llm_account` с учетом бюджетов/лимитов; учитывать `rate_limit_rps` и прогноз потребления.
4) Отправить батчи в обработку; обновить статусы запросов в batched/processing.
5) По завершении — распаковать ответы, записать созданные Кванты, связать их с Целями/Активностями, обновить метрики энергии/энтропии.
6) Логировать каждое решение в `soul_audit_log` с полем `reason`.
7) Защита от голодания: если запрос долго в `queued` (старше `starvation_avoidance_window`), поднять его bucket/добавить boost к DGW.

Статусы запросов/батчей должны обеспечивать идемпотентность: повторная обработка батча не создает дубликаты Квантов.

#### 4.3. Ощущения (реальное время)

- Периодически (каждые 1–5 мин) вычислять значения правил `sensation_rule` по окнам времени; нормализовать в диапазон [-1, 1] с учетом polarity.
- Агрегировать в `S_sensation`. Если S_sensation < 0 — подавление малопродуктивных Активностей (снижение DGW), > 0 — поощрение.
- Влиять как на `DGW`, так и на пороги батчинга (можно ужесточать при отрицательном сигнале).
- Все срабатывания логируются в `soul_audit_log` (actor=sensation).

#### 4.4. Прогноз ресурсов и backpressure

- Прогнозировать суточное потребление токенов по EMA последних K часов. При превышении `daily_limit_*`:
  - ужесточить порог DGW (отсечь хвост очереди);
  - при необходимости запросить у Архитектора повышение лимита (инициативное сообщение);
  - инициировать «Сон» для дефрагментации/архивации низкоприоритетных Квантов.

#### 4.5. Повторы и отказоустойчивость

- Категории ошибок: транзиентные (429/5xx), постоянные (4xx), токенные лимиты, таймауты.
- Повторные попытки: экспоненциальная задержка `retry_backoff_initial_ms × multiplier^attempt` с джиттером; предел `retry_max_attempts`.
- Circuit breaker на уровне `llm_account`; при деградации — failover на другой аккаунт/провайдера.

### 5. Транспорты

#### 5.1. Интерфейс к LLM

- Запрос (json): {persona, official_identity, goals_context, activity_context, requests[], rules, system_policies}.
- Ответ (json): {items: [{request_id, quantum_payload, energy, valence, entropy, tags}], usage: {tokens_in, tokens_out}, model}.
- Подсчет токенов и стоимость — на уровне `generation_batch` + агрегация по `llm_account`.

#### 5.2. Очередь

- DB-ориентированная очередь (polling/notification) на основе таблиц `generation_request`/`generation_batch`.
- Гарантии: обрабатываем только записи с версией/lock (SELECT FOR UPDATE SKIP LOCKED), статусы — через state machine.

### 6. Интерфейсы панели Архитектора

- Управление Активностями: создание/редактирование, выбор личности (persona_prompt), официальной идентичности, лимитов времени, статического приоритета, полномочий.
- Настройки Дирижера: коэффициенты DGW, размеры батчей, лимиты токенов, полисы повтора, rate limits, окно защиты от голодания.
- Ощущения: список правил, веса, окна, пороги; график текущего S_sensation и вкладов правил.
- Очередь и батчи: лента запросов, текущие DGW и факторы; состав батчей; статусы; повторные попытки.
- Визуализации: граф приоритетов очереди в реальном времени; диаграмма влияния факторов DGW; история срабатываний Ощущений; прогноз потребления токенов.
- Аудит: таблица событий `soul_audit_log` с фильтрами и reason JSON.

RBAC: доступ только ролям Architect/Admin; все изменения пишутся в аудит.

#### 6.1. Виджет состояния материализованных представлений

- Отображает список MV (минимум `goals_view_mv`) с полями: `last_refreshed_at`, `last_refresh_ok`, `refresh_count`, `refreshed_by`, `refresh_duration_ms`.
- Цветовая индикация:
  - Зеленый: `last_refresh_ok=true` и `now()-last_refreshed_at <= threshold_ok_minutes`.
  - Желтый: `last_refresh_ok=true`, но давно не обновлялось (`>` threshold_warn_minutes).
  - Красный: `last_refresh_ok=false` или не обновлялось сверх `threshold_critical_minutes`.
- Действия: ручной REFRESH (кнопка), просмотр истории статусов, скачивание логов.

Настройки порогов и уведомлений берутся из БД (см. 7.3).

### 7. Миграции и развертывание

- Миграции: добавить новые таблицы, enum-тип(ы), индексы. Связи с существующими таблицами Квантов/Целей — через внешние ключи.
- Пример DDL (PostgreSQL, фрагменты):

```sql
create table if not exists activity (
  id uuid primary key,
  name text not null,
  code text not null unique,
  is_enabled boolean not null default true,
  priority_static int not null default 0,
  time_min_minutes_per_day int not null default 0,
  time_max_minutes_per_day int,
  persona_prompt_id uuid,
  official_identity_id uuid,
  created_by uuid,
  updated_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_activity_enabled_priority on activity(is_enabled, priority_static);

create type goal_type as enum ('regular','absolute','episodic','trigger','situational');

create table if not exists activity_goal (
  id uuid primary key,
  activity_id uuid not null references activity(id) on delete cascade,
  goal_id uuid not null,
  goal_type goal_type not null,
  target_metric jsonb,
  weight numeric not null default 1,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(activity_id, goal_id)
);

create type request_status as enum ('queued','batched','processing','succeeded','failed','cancelled');

create table if not exists generation_request (
  id uuid primary key,
  activity_id uuid not null references activity(id) on delete cascade,
  goal_id uuid,
  quantum_seed_id uuid,
  prompt_hint text,
  dgw_value numeric,
  dgw_factors jsonb,
  status request_status not null default 'queued',
  priority_bucket int,
  error jsonb,
  attempts int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  processed_at timestamptz
);

create index if not exists idx_request_status_priority on generation_request(status, priority_bucket, dgw_value desc);

```

— Представление целей для совместимости (поверх `quantum_goals`):

```sql
-- goals_view нормализует интерфейс "Целей" для activity_goal.goal_id
create or replace view goals_view as
select
  qg.id as id,
  qg.quant_id as owner_quant_id,
  qg.priority as priority,
  qg.is_active as is_active,
  qg.completed_at as completed_at
from quantum_goals qg;

-- При необходимости добавить материализованное представление/индексы

```

— Материализованное представление активных целей с индексами:

```sql
-- Материализованное представление только активных целей для быстрых выборок
create materialized view if not exists goals_view_mv as
select
  qg.id as id,
  qg.quant_id as owner_quant_id,
  qg.priority as priority,
  qg.is_active as is_active,
  qg.completed_at as completed_at
from quantum_goals qg
where qg.is_active = true;

-- Индексы для ускорения выборок/сортировок
create unique index if not exists uq_goals_view_mv_id on goals_view_mv(id);
create index if not exists idx_goals_view_mv_priority on goals_view_mv(priority desc);

-- Обновление без блокировок чтения (после наличия уникального индекса)
-- REFRESH MATERIALIZED VIEW CONCURRENTLY goals_view_mv;

```

— Ссылки на потоки/сообщения в запросах генерации:

#### 7.1. Обновление goals_view_mv (расписание и триггеры)

- Периодическое обновление scheduler/cron:

```bash
# Каждые 5 минут с конкурентным обновлением (после создания уникального индекса)
*/5 * * * * psql "$DATABASE_URL" -c "REFRESH MATERIALIZED VIEW CONCURRENTLY goals_view_mv;"

```

- Триггерное уведомление при изменениях в `quantum_goals`:

```sql
-- Канал уведомлений
-- LISTEN goals_changed; -- выполняется в воркере

create or replace function notify_goals_changed() returns trigger as $$
begin
  perform pg_notify('goals_changed', coalesce(new.id::text, old.id::text));
  return null;
end;
$$ language plpgsql;

drop trigger if exists trg_quantum_goals_notify on quantum_goals;
create trigger trg_quantum_goals_notify
after insert or update or delete on quantum_goals
for each row execute function notify_goals_changed();

```

- Воркер-обновления (псевдокод):

```text
loop:
  LISTEN goals_changed
  on notify:
    debounce 30–60s (накапливаем изменения)
    try acquire advisory lock  (e.g., pg_try_advisory_lock(hashtext('goals_view_mv_refresh')))
    if locked:
      REFRESH MATERIALIZED VIEW CONCURRENTLY goals_view_mv
      release lock

```

Замечания:

- При высокой нагрузке достаточно периодического cron; триггерный подход улучшает свежесть данных.
- Для транзакционной консистентности чтений в Дирижере использовать «чтение из MV» с доп. фильтром по дате обновления при необходимости.

#### 7.2. Таблица статусов материализованных представлений

Для отображения в панели времени последнего успешного обновления и диагностики добавляется таблица `mv_status`.

```sql
create table if not exists mv_status (
  view_name text primary key,
  last_refreshed_at timestamptz,
  last_refresh_ok boolean default null,
  last_refresh_error text,
  refresh_count int not null default 0,
  refreshed_by text, -- 'cron' | 'trigger' | 'manual'
  refresh_duration_ms int,
  updated_at timestamptz not null default now()
);

create index if not exists idx_mv_status_updated_at on mv_status(updated_at desc);

```

Рекомендованная операция UPSERT при успешном обновлении `goals_view_mv`:

```sql
insert into mv_status as s (view_name, last_refreshed_at, last_refresh_ok, last_refresh_error, refresh_count, refreshed_by, refresh_duration_ms, updated_at)
values ('goals_view_mv', now(), true, null, 1, :refreshed_by, :duration_ms, now())
on conflict (view_name) do update
set last_refreshed_at = excluded.last_refreshed_at,
    last_refresh_ok = excluded.last_refresh_ok,
    last_refresh_error = excluded.last_refresh_error,
    refresh_count = s.refresh_count + 1,
    refreshed_by = excluded.refreshed_by,
    refresh_duration_ms = excluded.refresh_duration_ms,
    updated_at = now();

```

#### 7.3. Алерты по состоянию MV

Настройки порогов и каналов уведомлений:

```sql
create table if not exists observability_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

-- Начальные значения (пример)
insert into observability_settings(key, value) values
  ('mv_thresholds', '{"ok_minutes": 10, "warn_minutes": 30, "critical_minutes": 60}')
on conflict (key) do nothing;

```

Проверка статуса и отправка уведомления (cron каждые 5 минут):

```bash
*/5 * * * * psql "$DATABASE_URL" -c "select app_check_mv_and_alert();"

```

Функция проверки (упрощённо):

```sql
create or replace function app_check_mv_and_alert() returns void as $$
declare
  cfg jsonb;
  ok_m int;
  warn_m int;
  crit_m int;
  rec record;
  age_min int;
begin
  select value into cfg from observability_settings where key = 'mv_thresholds';
  ok_m := coalesce((cfg->>'ok_minutes')::int, 10);
  warn_m := coalesce((cfg->>'warn_minutes')::int, 30);
  crit_m := coalesce((cfg->>'critical_minutes')::int, 60);

  for rec in select * from mv_status loop
    age_min := extract(epoch from (now() - coalesce(rec.last_refreshed_at, now() - interval '365 days'))) / 60;
    if (rec.last_refresh_ok is false) and (age_min > warn_m) then
      perform pg_notify('alerts', json_build_object(
        'type','mv_failure',
        'view', rec.view_name,
        'age_minutes', age_min,
        'last_error', rec.last_refresh_error
      )::text);
    elsif (rec.last_refresh_ok is true) and (age_min > crit_m) then
      perform pg_notify('alerts', json_build_object(
        'type','mv_stale',
        'view', rec.view_name,
        'age_minutes', age_min
      )::text);
    end if;
  end loop;
end;
$$ language plpgsql;

```

Доставку `alerts` привязать к каналу уведомлений панели/бота Архитектора.

#### 7.4. Ретрансляция `alerts` в Telegram-бот Архитектора

- Получатели: все записи в `telegram_accounts` с `is_architect=true`.
- Транспорт: backend-воркер выполняет `LISTEN alerts`; каждое уведомление — JSON payload, пересылается личным сообщением от бота.
- Формат уведомления (JSON в `pg_notify`):

```json
{"type":"mv_failure","view":"goals_view_mv","age_minutes":12,"last_error":"timeout"}

```

- Формат текстового сообщения в Telegram:

```text
⚠️ MV Alert: mv_failure
• View: goals_view_mv
• Age: 12 мин
• Status: failure
• Error: timeout
• Last refresh: {{last_refreshed_at or 'n/a'}}
Действия: /mv_status goals_view_mv  |  /refresh_mv goals_view_mv

```

- Антиспам/агрегация: дебаунс по `view` 2 минуты; если приходят повторные события, отправлять сводку: «N событий за X мин» с последней ошибкой.
- Команды бота:
  - `/mv_status [view]` — показать статус из `mv_status`.
  - `/refresh_mv <view>` — инициировать `REFRESH MATERIALIZED VIEW CONCURRENTLY <view>` (доступно только Архитекторам), с записью результата в `mv_status` и ответом в чат.

При ошибке обновления фиксировать статус и текст ошибки:

```sql
insert into mv_status as s (view_name, last_refreshed_at, last_refresh_ok, last_refresh_error, refresh_count, refreshed_by, refresh_duration_ms, updated_at)
values ('goals_view_mv', coalesce(s.last_refreshed_at, now()), false, :error_text, 1, :refreshed_by, null, now())
on conflict (view_name) do update
set last_refresh_ok = false,
    last_refresh_error = excluded.last_refresh_error,
    refresh_count = s.refresh_count + 1,
    refreshed_by = excluded.refreshed_by,
    updated_at = now();

```

Дополнение к воркеру (псевдокод):

```text
on refresh start:
  t0 = now()
  REFRESH MATERIALIZED VIEW CONCURRENTLY goals_view_mv
  duration_ms = now() - t0
  UPSERT mv_status(view_name='goals_view_mv', last_refresh_ok=true, refreshed_by='trigger'|'cron', refresh_duration_ms=duration_ms)

on refresh error:
  UPSERT mv_status(view_name='goals_view_mv', last_refresh_ok=false, refreshed_by='trigger'|'cron', last_refresh_error=err)

```

```sql
-- Расширение generation_request
alter table if exists generation_request
  add column if not exists thread_id uuid null,
  add column if not exists message_id uuid null;

-- Индексы для быстрой выборки
create index if not exists idx_request_thread on generation_request(thread_id);
create index if not exists idx_request_message on generation_request(message_id);

-- Внешние ключи (мягкие, если таблицы существуют)
do $$ begin
  if exists (select 1 from information_schema.tables where table_name = 'chat_threads') then
    alter table generation_request
      add constraint fk_req_thread foreign key (thread_id)
      references chat_threads(id) on delete set null;
  end if;
  if exists (select 1 from information_schema.tables where table_name = 'messages') then
    alter table generation_request
      add constraint fk_req_message foreign key (message_id)
      references messages(id) on delete set null;
  end if;
end $$;

```

- Развертывание: только локально → тестовый сервер → прод. Никаких прямых правок на проде.
- Тестирование: использовать реальные Telegram ID согласно политике проекта; тесты не поднимают серверы/каналы; удаление сообщений — только через мини-приложение, проверки бота на удаление удалить из тестов/доков.

### 8. Приемочные критерии (MVP)

- В панели можно создать Активность, назначить цели, задать коэффициенты DGW и лимиты.
- Роботы генерируют `generation_request`; Дирижер формирует батчи (по 10 штук по умолчанию) и отправляет к выбранному провайдеру.
- Новые Кванты создаются, связаны с Целями/Активностью; записаны энергия/валентность/энтропия.
- Ощущения динамически влияют на приоритет (видно по графику DGW и по логу аудита).
- Лимиты токенов учитываются; при дефиците применяется backpressure; аудит фиксирует решения.

### 9. Чек-лист быстрой реализации

- Создать миграции для таблиц и enum-типов; применить на dev.
- Заполнить `conductor_settings` и базовые `sensation_rule`.
- Добавить UI-формы в панели: Активности, Настройки Дирижера, Ощущения, Очередь/Батчи, Аудит.
- Реализовать воркер Дирижера: DGW, батчинг, вызов LLM, разбор ответа, запись Квантов и связей.
- Реализовать воркер Ощущений: расчет правил, запись сигналов, влияние на DGW.
- Настроить метрики и графики в панели (очередь, DGW факторы, прогноз токенов).
- Прогнать целевой сценарий end-to-end на тестовом сервере; затем — выпуск на прод.

### 10. Расширения (после MVP)

- Автоподстройка A/B/C/D ночью («Сон») по целевой функции полезности.
- Расширение capability-модулей (почта, мессенджеры) и их транспортов.
- Кластеризация батчей по графу AGE с учетом весов ребер (semantic/causal/temporal).

### 11. Коммуникации: Telegram-бот, аутентификация кодом, БД диалогов и ветки

#### 11.1. Потоки и роли

- Архитектор и пользователи взаимодействуют с Соул через Telegram-бота.
- Аутентификация Архитектора — через одноразовый код-пароль, выдаваемый в панели; пользователи — через привязку Telegram ID.
- Каждый диалог хранится в собственной ветке `chat_threads`; ветки могут разветвляться (branching) и обрабатываются как независимые «банки памяти» для подстановки контекста в LLM.

#### 11.2. Схема БД (расширения)

- `telegram_accounts` (новая):
  - id UUID pk
  - user_id INT fk → users(id)
  - tg_user_id BIGINT not null unique
  - username TEXT
  - is_architect BOOLEAN default false
  - created_at/updated_at TIMESTAMPTZ

- `telegram_auth_codes` (новая) — одноразовые коды доступа Архитектора:
  - id UUID pk
  - user_id INT fk → users(id)
  - code TEXT not null unique
  - expires_at TIMESTAMPTZ not null
  - used_at TIMESTAMPTZ null
  - created_at TIMESTAMPTZ default now()

- Расширение `chat_threads` (существующая):
  - type ENUM: 'architect_direct'|'user_dialog'|'service' (default 'user_dialog')
  - parent_thread_id UUID null → chat_threads(id) — для веток
  - branch_label TEXT null — человекочитаемая метка ветки
  - persona_prompt_id UUID null → prompts(id)
  - model TEXT null, temperature NUMERIC(3,2) null, max_tokens INT null (для фиксации параметров инференса на ветке)
  - Индексы: (user_id, created_at desc), (parent_thread_id), (type)

- Расширение `messages` (существующая, без ломки):
  - Добавить `meta` JSONB null — для хранения tokens_in/out, role при необходимости, ошибок провайдера, link на batch
  - Индекс GIN по `meta`

- Дополнительные структуры памяти (новые):
  - `thread_summaries`: id, thread_id, summary_text, tokens_in, created_at — хранение многоуровневых саммарей для веток
  - `message_embeddings`: id, message_id, embedding vector — pgvector/HNSW для поиска релевантной истории внутри ветки

DDL (фрагменты):

```sql
create table if not exists telegram_accounts (
  id uuid primary key,
  user_id int not null references users(id) on delete cascade,
  tg_user_id bigint not null unique,
  username text,
  is_architect boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists telegram_auth_codes (
  id uuid primary key,
  user_id int not null references users(id) on delete cascade,
  code text not null unique,
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

alter table chat_threads
  add column if not exists type text not null default 'user_dialog',
  add column if not exists parent_thread_id uuid null references chat_threads(id) on delete set null,
  add column if not exists branch_label text null,
  add column if not exists persona_prompt_id uuid null,
  add column if not exists model text null,
  add column if not exists temperature numeric(3,2) null,
  add column if not exists max_tokens int null;

alter table messages
  add column if not exists meta jsonb;

```

#### 11.3. Аутентификация в Telegram-боте

- Архитектор в панели генерирует одноразовый код (запись в `telegram_auth_codes`).
- В боте команда `/login <code>`:
  - Проверка валидности и срока годности кода; разовая пометка `used_at`.
  - Связка текущего `tg_user_id` с `user_id` Архитектора в `telegram_accounts` с `is_architect=true`.
- Для обычных пользователей — авто-создание/связка `telegram_accounts` по `tg_user_id`; права определяются ролями пользователя.

#### 11.4. Ветвление диалогов и типы общений

- При старте новой ветки создается `chat_threads` с `parent_thread_id` и `branch_label`.
- В панели доступны действия: создать ветку от текущей, переименовать, заморозить/архивировать ветку.
- Тип ветки (`type`) определяет политику конфиденциальности и доступности в выборке контекста.

#### 11.5. Интеграция с Дирижером

- `generation_request` может ссылаться на `thread_id` и/или `message_id` (seed) для контекстной генерации.
- При успешной генерации ответы сохраняются как `messages` (sender_type='bot') и, при наличии, как `quants` с тем же `id` (если включена связка 1:1).
- Батчи Дирижера могут группировать запросы по одной ветке (`thread_id`) для экономии контекста.

### 12. Алгоритмы памяти и сбор истории для LLM (с учетом веток)

#### 12.1. Отбор контекста внутри ветки

- Бюджет токенов распределяется на: системные инструкции, краткую саммарю ветки (`thread_summaries`), релевантные сообщения по векторному поиску (`message_embeddings`), последние k сообщений по времени.
- Ветки изолированы: контекст собирается только из текущей ветки, за исключением настроек, явно разрешающих «перелив» контекста от родительской ветки (с пониженным весом).

#### 12.2. Политики суммаризации

- При переполнении истории: свернуть «старый хвост» ветки в `thread_summaries`; хранить уровни саммарей (L1/L2) с datestamp.
- При ответе LLM записывать обновленные саммари с учетом новых сообщений.

#### 12.3. Управление персоной и параметрами инференса на ветке

- `persona_prompt_id`, `model`, `temperature`, `max_tokens` закрепляются за веткой (`chat_threads`) и наследуются сообщениями; изменение фиксируется в аудите.
