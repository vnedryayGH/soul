# ТЗ (План реализации): Активности — Дирижёр — Ощущения — Диспетчер Потоков (версия 09)

Дата: 2025-09-15
Статус: ТЗ к внедрению (v9) — расширение и конкретизация v8; выравнивание с P20/P21/P22/P23/P24 и текущей реализацией ядра.

Важное: вся конфигурация хранится в БД; все функции — в Панели Архитектора (UI) с валидациями, подсказками, мониторингом и аудитом изменений. Никаких заглушек и деградаций.

---

## 0. Executive Summary

- Цели: довести «Активности» и «Ощущения» до промышленной эксплуатации, встроить в Диспетчер и конвейер Соул (DGW×RBAC), добавить строгий гейтинг веток `architect_*` и полную наблюдаемость.
- Результат: CRUD‑управление Активностями и Ощущениями, фоновые роботы Активностей, формула приоритезации с учётом роли/энергии/расписаний, валидатор очереди, UI‑визарды, метрики/дашборды, план безопасного запуска и отката.

---

## 1. Область работ (scope)

- Включено:
  - Схемы БД, индексы, миграции (Alembic) для Активностей/Ощущений/Аналитики.
  - API (REST/WebSocket where applicable), Pydantic‑контракты, JSON‑примеры, OpenAPI расширение.
  - Алгоритмы: роботы Активностей → очередь, RBAC×DGW приоритет, валидатор, гейтинг `architect_*`.
  - Наблюдаемость, метрики, алерты, аудит.
  - UI‑визарды и виджеты (описание контрактов, без реализации UI‑кода здесь).
  - Тест‑план (интеграционные цепочки), критерии приёмки, rollout/rollback.
- Не включено:
  - Глубокая ML‑модель DGW — используется текущая формула и настройки.
  - Мультисервисный шедулер за пределами текущего процесса (может быть добавлен позднее).

---

## 2. Архитектура компонентов

- ActivityService: CRUD Активностей, полномочий, целей, расписаний; публикация событий аудита.
- ActivityRobots: фоновые исполнители, читают активные Активности/расписания и создают заявки в `flow_dispatch_queue`.
- Dispatcher v9: приоритезация заявок по формуле RBAC×DGW×Activity×TimeWindow; валидация кандидатов; гейтинг веток `architect_*`.
- SensationEngine: хранение настроек/событий «Ощущений», вклад в DGW, агрегации для «Энергобаланса».
- RBAC/Scopes: проверка прав; роль‑буст в приоритете; админ‑операции только для Architect.
- Observability: события `_audit_direct`, метрики (приоритет, очередь, роботы), MVs, HealthScore (P21 интеграция).

---

## 3. Схемы БД (DDL, индексы)

SQL приведён как целевое DDL; реализация через Alembic.

```sql
-- Активности
CREATE TABLE IF NOT EXISTS activities (
  id uuid PRIMARY KEY,
  name text NOT NULL,
  persona_prompt_id int NULL,
  priority int NOT NULL DEFAULT 0,
  time_min_min int NOT NULL DEFAULT 0,
  time_max_min int NOT NULL DEFAULT 60,
  satisfaction_policy jsonb NOT NULL DEFAULT '{}'::jsonb,
  actions_prompt text NULL,
  official_identity jsonb NULL,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  row_version int NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_activities_enabled ON activities(enabled);
CREATE INDEX IF NOT EXISTS idx_activities_priority ON activities(priority DESC);

-- Полномочия Активности
CREATE TABLE IF NOT EXISTS activity_permissions (
  activity_id uuid NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
  permission text NOT NULL,
  PRIMARY KEY(activity_id, permission)
);

-- Связь с целями
CREATE TABLE IF NOT EXISTS activity_goals (
  activity_id uuid NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
  goal_id uuid NOT NULL,
  goal_type text NOT NULL,
  metrics jsonb NOT NULL DEFAULT '{}'::jsonb,
  PRIMARY KEY(activity_id, goal_id)
);

-- Расписания Активности
CREATE TABLE IF NOT EXISTS activity_schedules (
  id uuid PRIMARY KEY,
  activity_id uuid NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
  cron text NULL,
  window jsonb NULL,
  timezone text NULL,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_activity_schedules_enabled ON activity_schedules(enabled);

-- Частный кейс «Семья»
CREATE TABLE IF NOT EXISTS family_contacts (
  user_id int NOT NULL,
  contact_tg_id bigint NOT NULL,
  relation text NULL,
  allow_read boolean NOT NULL DEFAULT false,
  allow_send boolean NOT NULL DEFAULT false,
  PRIMARY KEY(user_id, contact_tg_id)
);

-- Ощущения (настройки/события)
CREATE TABLE IF NOT EXISTS sensation_settings (
  id uuid PRIMARY KEY,
  name text NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  severity_range numrange NULL,
  weight numeric NOT NULL DEFAULT 1.0,
  params jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS sensation_events (
  id uuid PRIMARY KEY,
  type text NOT NULL,
  severity numeric NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_sensation_events_type ON sensation_events(type);
CREATE INDEX IF NOT EXISTS idx_sensation_events_created ON sensation_events(created_at);

-- Очередь Диспетчера (существует, расширение полей при необходимости)
-- flow_dispatch_queue(id, user_id, activity_id?, goal_id?, type, payload, priority, created_at, state, reason, human_summary)
-- Требуемые индексы:
-- CREATE INDEX IF NOT EXISTS idx_fdq_state ON flow_dispatch_queue(state);
-- CREATE INDEX IF NOT EXISTS idx_fdq_priority ON flow_dispatch_queue(priority DESC, created_at DESC);

-- Материализованные представления аналитики
-- Энергобаланс
CREATE MATERIALIZED VIEW IF NOT EXISTS energy_balance_mv AS
SELECT date_trunc('hour', created_at) AS ts_hour,
       SUM((payload->>'energy_in')::numeric) AS energy_in,
       SUM((payload->>'energy_out')::numeric) AS energy_out,
       SUM((payload->>'sensations_delta')::numeric) AS sensations_delta,
       AVG((payload->>'value_per_cost')::numeric) AS value_per_cost_avg
FROM sensation_events
GROUP BY 1;
CREATE INDEX IF NOT EXISTS idx_energy_balance_mv_ts ON energy_balance_mv(ts_hour);

-- Эффективность Активностей
CREATE MATERIALIZED VIEW IF NOT EXISTS activity_effectiveness_mv AS
SELECT activity_id,
       date_trunc('day', created_at) AS ts_day,
       AVG((payload->>'energy')::numeric) AS avg_energy,
       SUM((payload->>'completed_goals')::int) AS completed_goals,
       AVG((payload->>'value_per_cost')::numeric) AS value_per_cost_avg,
       COUNT(*) FILTER (WHERE state='queued')::int * 1.0 / NULLIF(COUNT(*),0) AS queue_share
FROM flow_dispatch_queue
GROUP BY 1,2;
CREATE INDEX IF NOT EXISTS idx_activity_effectiveness_mv ON activity_effectiveness_mv(activity_id, ts_day);

```

Примечание: добавить `row_version int NOT NULL DEFAULT 1` в новые таблицы, если требуется оптимистическая блокировка.

---

## 4. API и контракты (REST)

Пространство имён (admin‑требует роль Architect):

- `/api/admin/activities/*`, `/api/admin/sensations/*`

Служебные: аудит/метрики остаются в существующих админ‑роутах; WebSocket не обязателен.

Pydantic‑модели (сводка):

```python
class ActivityBase(BaseModel):
    name: constr(min_length=1)
    persona_prompt_id: Optional[int] = None
    priority: conint(ge=0, le=100) = 0
    time_min_min: conint(ge=0) = 0
    time_max_min: conint(ge=1) = 60
    satisfaction_policy: Dict[str, Any] = Field(default_factory=dict)
    actions_prompt: Optional[str] = None
    official_identity: Optional[Dict[str, Any]] = None
    enabled: bool = True

class ActivityCreate(ActivityBase):
    pass

class ActivityUpdate(BaseModel):
    name: Optional[str] = None
    persona_prompt_id: Optional[int] = None
    priority: Optional[conint(ge=0, le=100)] = None
    time_min_min: Optional[conint(ge=0)] = None
    time_max_min: Optional[conint(ge=1)] = None
    satisfaction_policy: Optional[Dict[str, Any]] = None
    actions_prompt: Optional[str] = None
    official_identity: Optional[Dict[str, Any]] = None
    enabled: Optional[bool] = None
    row_version: conint(ge=1)

class ActivityOut(ActivityBase):
    id: UUID
    created_at: datetime
    updated_at: datetime
    row_version: int

class ActivityPermission(BaseModel):
    permission: constr(min_length=3)

class ActivityGoalLink(BaseModel):
    goal_id: UUID
    goal_type: str
    metrics: Dict[str, Any] = Field(default_factory=dict)

class ActivitySchedule(BaseModel):
    id: Optional[UUID]
    cron: Optional[str]
    window: Optional[Dict[str, Any]]
    timezone: Optional[str]
    enabled: bool = True

class SensationSetting(BaseModel):
    id: Optional[UUID]
    name: constr(min_length=1)
    enabled: bool = True
    severity_range: Optional[str]
    weight: condecimal(gt=0)
    params: Dict[str, Any] = Field(default_factory=dict)

class SensationEvent(BaseModel):
    id: Optional[UUID]
    type: constr(min_length=1)
    severity: condecimal(ge=0)
    payload: Dict[str, Any] = Field(default_factory=dict)
    created_at: Optional[datetime]

```

Основные эндпоинты (примеры):

```http
GET /api/admin/activities
POST /api/admin/activities {ActivityCreate}
GET /api/admin/activities/{id}
PATCH /api/admin/activities/{id} {ActivityUpdate} (If-Match: ETag=row_version)
DELETE /api/admin/activities/{id}

GET /api/admin/activities/{id}/permissions
PUT /api/admin/activities/{id}/permissions { permissions: [ActivityPermission] }

GET /api/admin/activities/{id}/goals
PUT /api/admin/activities/{id}/goals { links: [ActivityGoalLink] }

GET /api/admin/activities/{id}/schedules
PUT /api/admin/activities/{id}/schedules { items: [ActivitySchedule] }

GET /api/admin/sensations/settings
POST /api/admin/sensations/settings {SensationSetting}
PATCH /api/admin/sensations/settings/{id} {SensationSetting}

POST /api/admin/sensations/events {SensationEvent}
GET /api/admin/sensations/events?type=...&from=...&to=...

```

Примеры JSON (создание Активности):

```json
{
  "name": "Коммуникации в семье",
  "priority": 60,
  "time_min_min": 5,
  "time_max_min": 20,
  "satisfaction_policy": {"target_valence": 0.6, "min_actionability": 0.5},
  "official_identity": {"display_name": "Семейный помощник", "avatar": "family"},
  "enabled": true
}

```

OpenAPI: добавить схемы и пути в `docs/openapi-p20-telegram-bots.yaml` под тегом `Activities`/`Sensations`. Все ресурсы — с `row_version` и заголовками `ETag/If-Match` для PATCH.

---

## 5. Алгоритмы и формулы

- Роботы Активностей:
  - Каждые N минут (по расписанию) выбирают активные Активности с подходящими окнами `activity_schedules`.
  - Формируют заявки в `flow_dispatch_queue` с базовой полезной нагрузкой (цель/контекст/источник).
  - Ведут аудит `activity_robot_enqueued` с `activity_id`, `schedule_id`, причинами.
- Валидатор очереди:
  - Проверяет: обязательность `user_id`, корректность `activity_id|goal_id`, допустимость `tags`, верхние/нижние пороги времени/приоритетов.
  - При отказе — `state=invalid`, `reason`, `human_summary`, событие аудита `dispatch_validation_failed`.
- Приоритет (RBAC×DGW×Activity×TimeWindow):
  - Базовая формула:  `P = clamp(0, 100, Wrole + Wdgw + Wact + Wtime)`
    - `Wrole = role_boost(initiated_by_role)`; примеры: Architect=+30, Admin=+15, Premium=+5, Basic=0.
    - `Wdgw = round(energy_weight*50 + composite_valence*10 - entropy*5)` из текущего контура.
    - `Wact = priority (0..100) из activities` с нормализацией до диапазона [0..30] → `Wact = priority*0.3`.
    - `Wtime = +10` внутри активного окна, `-10` вне окна.
  - Порог публикации в работу: `P>=25`.
- Гейтинг `architect_*`:
  - Для веток/типов, помеченных как `architect_*`, допускается материализация заявки только при наличии подтверждённого кода `/login <CODE>` для текущего `tg_id` в окне действия.
  - События аудита: `architect_login_confirmed`, `architect_queue_rejected`, `architect_queue_allowed`.
- «Семья» (частный кейс):
  - Маршрутизация сообщений/ответов возможна только при `allow_read/allow_send` в `family_contacts`.
  - DGW‑смещение: вечер/выходные → `Wtime += 5`.
- Ощущения → DGW:
  - Сигналы `sensation_events` агрегируются, вклад в `Wdgw` через `sensations_delta = severity*weight` по настроенным `sensation_settings`.

---

## 6. Наблюдаемость, метрики, аудит

- Аудит: `activity_robot_enqueued`, `dispatch_validation_failed`, `architect_*`, `sensation_event_ingested`.
- Метрики (timeseries):
  - Очередь: размер/минуту, доля invalid, p95 времени в очереди, доля обработанных.
  - Приоритет: распределение `P`, доля заявок с `P>=25`.
  - Ощущения: частота типов, средняя `severity`, вклад `sensations_delta`.
  - Энергобаланс и эффективность Активностей: из MVs.
- Дашборды: вкладки «Очередь», «Энергобаланс», «Активности», «Ощущения». Алерты: рост invalid>5%, падение `value_per_cost_avg`, отсутствие событий роботов>10 мин.

---

## 7. Безопасность и приватность

- RBAC строго: админ‑роуты только Architect/Admin; пользовательские данные — по текущему пользователю.
- Архитектор‑код: одноразовые, TTL, журналирование использования; многократные неверные попытки → алёрт.
- PII/Privacy: данные контактов и событий ощущений — приватны; логи не содержат открытых PII.
- Two‑keys: чувствительные изменения (массовые операции, изменение ролей/приоритетов > определённого порога) — через `/api/admin/two-keys/*`.

---

## 8. Интеграции и совместимость

- P20 API: добавить теги/пути под `Activities`/`Sensations`.
- P21 Health: включить метрики и health‑срезы (сводка/временные ряды).
- P22 API Alignment: контракты Strict, `row_version`, `ETag/If-Match`, Schema Guard.
- P23 UI: визарды/виджеты; RBAC‑меню; безопасный рендер в мини‑апп и веб.

---

## 9. Миграции (Alembic)

- Ревизии:

  1) `20250915_090001_activities_core.py` — `activities`, `activity_permissions`, `activity_goals`, `activity_schedules`, индексы.
  2) `20250915_090002_sensations_core.py` — `sensation_settings`, `sensation_events`, индексы.
  3) `20250915_090003_activity_family.py` — `family_contacts`.
  4) `20250915_090004_activity_mv.py` — MVs `energy_balance_mv`, `activity_effectiveness_mv`.

- Все таблицы с `row_version` при необходимости; добавить индексы на поля состояния/времени/приоритета.
- Idempotent‑DDL, откаты `downgrade` присутствуют.

---

## 10. Тест‑план (интеграционные цепочки)

- Юнит: валидация моделей, формула `P`, валидатор очереди, гейтинг `architect_*`.
- Интеграция: CRUD Активностей/Ощущений; роботы → очередь; MVs рефреш; дашборды читают метрики.

- Сценарии:

  - A) Создание Активности + расписание → по таймеру заявка в очередь.
  - B) Понижение/повышение приоритета Активности влияет на `P`.
  - C) Архитектор без кода → запрет; с кодом → допуск.
  - D) «Семья»: разрешённые контакты → маршрутизация проходит; без прав → отказ.
  - E) Ощущения: события меняют `sensations_delta` и сдвигают DGW.

- Нагрузочные: роботы при N активностях, p95 задержка; очередь не копится при целевом SLO.
- Наблюдаемость: наличие событий аудита и метрик, алёрты не стреляют ложноположительно.

---

## 11. Критерии приёмки (go/no‑go)

- CRUD Активностей/Ощущений работает, все поля сохраняются, `row_version` и `ETag/If-Match` соблюдаются.
- Роботы создают заявки по расписанию, валидатор пропускает валидные и отклоняет некорректные с причинами.
- Приоритет `P` рассчитывается и влияет на порядок обработки; пороги применяются.
- Гейтинг `architect_*` обеспечивает доступ только при подтверждённом коде.
- Дашборды отображают очереди/энергобаланс/эффективность/ощущения; MVs актуализируются.
- Логи/аудит чистые от ошибок; алёртов на деградацию нет.

---

## 12. Роллаут и откат

- Фичефлаги: `ENABLE_ACTIVITIES`, `ENABLE_SENSATIONS`, `ENABLE_ARCHITECT_GATING`.
- Этапы: миграции → API (disabled by default) → роботы (dry‑run) → включение окон, затем приоритезации → дашборды.
- Откат: выключить флаги, очистить очередь от activity‑источников, откатить ревизии MV при необходимости (данные исходных таблиц не затрагиваются).

---

## 13. Риски и меры

- Перегрузка очереди роботами — лимитер частоты и batch‑пакеты.
- Некорректные окна расписаний — валидация cron/window и dry‑run превью в UI.
- Ошибки приоритета — фоллбек на базовый приоритет и лог аудита конфликтов.
- Утечки PII — маскирование логов, политики доступа, тесты приватности.

---

## 14. Ссылки и соответствия

- `docs/PROJECT_STRUCTURE_v8_0_4.md` — структура и конвейер.
- `docs/openapi-p20-telegram-bots.yaml` — расширить тегами `Activities`/`Sensations`.
- `Soul/PROJECT_AI_AUTOPILOT_v2_26.md` — RBAC, UI‑навигация.
- `Soul/Report_Soul_AI_Scientific.md` — DGW/эмоции/политики.
- P21/P22/P23/P24 — здоровье, выравнивание API, UI, тесты/мониторинг.
