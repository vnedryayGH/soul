### ТЗ: Активности — Дирижер — Ощущения (версия 03)

Дата: 2025-09-10
Статус: Готово к быстрой реализации (v3 поверх v2)

### 0. Дополнения к v2

- Расширена формула DGW (добавлены эффективность и прогноз ценности).
- Автокалибровка коэффициентов в процессе «Сна».
- Графовое кластеризование для батчинга.
- ML‑прогноз потенциальной ценности запроса.
- Расширенный аудит со снапшотами решений.
- Критичность сигналов Ощущений и preempt‑обработка.
- Дашборд «Энергетический баланс» и KPI для Активностей.

### 1. База данных: новые/расширенные сущности

Расширение `conductor_settings`:

- dgw_coeff_a..d (numeric)
- dgw_coeff_e (numeric) — коэффициент эффективности E_eff
- dgw_coeff_f (numeric) — резерв под будущие факторы
- use_graph_clustering (bool, default false)
- prediction_enabled (bool, default false)

Новые метрики эффективности по Активностям:

- `activity_efficiency_daily`:
  - id uuid pk
  - activity_id uuid fk → activity
  - window_date date
  - avg_energy numeric
  - tokens_spent int
  - e_eff numeric generated always as (nullif(tokens_spent,0) is null ? null : avg_energy / nullif(tokens_spent,0)) stored
  - created_at timestamptz default now()
  - unique(activity_id, window_date)

Прогноз ценности запросов:

- расширение `generation_request`:
  - predicted_energy numeric null
  - predicted_confidence numeric null
  - dgw_factors jsonb — дополнить полями {E_eff, E_pred}
  - indexes: (predicted_energy desc)

Автокалибровка коэффициентов:

- `conductor_optimization_runs`:
  - id uuid pk
  - started_at/finished_at timestamptz
  - objective jsonb — целевая функция
  - params_before jsonb — сохраненные коэффициенты
  - params_after jsonb — найденные коэффициенты
  - score_before numeric, score_after numeric
  - status enum('running','succeeded','failed')
  - error text null

Sensation severity:

- расширение `sensation_rule`:
  - severity enum('low','medium','high','critical') default 'low'

Аудит снапшотов:

- расширение `soul_audit_log` (использовать поле meta/jsonb):
  - для событий conductor_batch_formed, sensation_rule_triggered, priority_recompute — сохранять snapshot входных данных.

### 2. DGW: расширенная формула

DGW = (A × P_static) + (B × E_quant) + (C × G_goal) + (D × S_sensation) + (E × E_eff) + (F × E_pred)

- E_eff — эффективность Активности за окно (например, 7 дней): avg(energy_weight) / tokens_spent.
- E_pred — прогнозируемая энергия создаваемого Кванта (см. раздел 4).
- Коэффициенты A..F — из `conductor_settings`.

### 3. Графовое кластеризование для батчинга

- При `use_graph_clustering=true` Дирижер, кроме семантики, учитывает граф `quant_connections`:
  - вычисляет близость запроса к существующим кластерам по максимуму связности (connection_strength, число инцидентных ребер);
  - объединяет запросы, направленные на усиление тех же кластеров, в один батч.
- В аудит добавляется причина `graph_cluster_boost`.

### 4. ML‑прогноз потенциальной ценности

- Модель (MVP): линейная регрессия/градиентный бустинг по признакам: activity_id, исторические метрики `avg_energy`, `tokens_spent`, эмбеддинг `prompt_hint` (сжато до PCA), текущий `S_sensation`.
- Предсказания сохраняются в `generation_request.predicted_energy` и `predicted_confidence`.
- Влияние на DGW регулируется коэффициентом F (`dgw_coeff_f`).

### 5. Автокалибровка коэффициентов (Сон)

- Раз в сутки запускается оптимизация коэффициентов A..F:
  - Целевая функция: max Σ energy_weight / Σ tokens_spent за период.
  - Метод: grid/random search → локальный градиентный шаг; хранение лучших параметров в `conductor_optimization_runs` и обновление `conductor_settings` при улучшении score.
- Аудитирует событие `coefficients_autotune` с before/after и score.

### 6. Preempt‑обработка критических сигналов Ощущений

- Для правил с `severity='critical'`:
  - сигнал помещается в приоритетный канал;
  - Дирижер прерывает текущий цикл, делает немедленный пересчет DGW для очереди;
  - при необходимости формирует emergency‑батч (ограниченный по size/tokens) для локализации проблемы;
  - событие `sensation_preempt` фиксируется в аудите с snapshot текущих правил.

### 7. Дашборд «Энергетический баланс»

- Приток: число и доля запросов по Активностям (за окно, real‑time поток).
- Расход: токены/время на Активность и на модель/провайдера.
- КПД: Σ energy_weight / Σ tokens_spent по Активности; топ‑эффективные/низкоэффективные направления.
- Дрилл‑даун до веток/батчей/запросов; ссылки на аудит решений.

### 8. Изменения в алгоритмах

- Пересчет DGW включает E_eff и E_pred; при недоступности метрик — graceful fallback (нормализация по имеющимся факторам).
- Батчинг: добавлены графовые признаки; параметризуемый вес графа vs семантики.
- Прогноз ценности вызывается асинхронно; при недоступности модели использует EMA‑эвристику.

### 9. DDL (фрагменты)

```sql
alter table conductor_settings
  add column if not exists dgw_coeff_e numeric default 1,
  add column if not exists dgw_coeff_f numeric default 0,
  add column if not exists use_graph_clustering boolean not null default false,
  add column if not exists prediction_enabled boolean not null default false;

create table if not exists activity_efficiency_daily (
  id uuid primary key,
  activity_id uuid not null references activity(id) on delete cascade,
  window_date date not null,
  avg_energy numeric,
  tokens_spent int,
  e_eff numeric,
  created_at timestamptz not null default now(),
  unique(activity_id, window_date)
);

alter table generation_request
  add column if not exists predicted_energy numeric,
  add column if not exists predicted_confidence numeric;

create index if not exists idx_req_predicted_energy on generation_request(predicted_energy desc nulls last);

create table if not exists conductor_optimization_runs (
  id uuid primary key,
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  objective jsonb not null,
  params_before jsonb not null,
  params_after jsonb,
  score_before numeric,
  score_after numeric,
  status text not null default 'running',
  error text
);

alter table sensation_rule
  add column if not exists severity text not null default 'low';

```

### 10. Приемочные критерии (v3)

- DGW учитывает E_eff и E_pred; коэффициенты настраиваются в панели и сохраняются.
- Опция `use_graph_clustering` влияет на батчинг; аудит содержит `graph_cluster_boost` при применении.
- Предсказания ценности сохраняются и учитываются; при недоступности модели — система работает в деградированном режиме без ошибок.
- Автокалибровка коэффициентов выполняется раз в сутки; результат фиксируется и откатывается при ухудшении score.
- Критические сигналы Ощущений вызывают preempt‑пересчет и формирование emergency‑батча.
- Дашборд «Энергетический баланс» отображает приток/расход/КПД по Активностям, поддерживает дрилл‑даун и ссылки на аудит.
