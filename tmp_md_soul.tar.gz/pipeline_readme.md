# Soul Orchestrator Pipeline (кратко)

1) Вход: запрос пользователя → собрать `active_goal`, `current_quant`, `flow_context_summary`.
2) Роутер: прогнать через `soul_quant_router_v1_1.json` → получить `modules_order`, `context_load_policy`, `context_filters`, `goal_bias`, `boost_quants`.
3) Контекст: применить 30/70_v2 согласно политике + фильтры; принудительно включить `boost_quants`.
4) Промпт: загрузить модули из `modules_registry_v1.json` в порядке `modules_order` (core обязательно).
5) Генерация: вызвать LLM → STRICT_JSON_QUANT.
6) Пост‑обработка: сохранить Квант, выполнить `desired_action`, применить `architect_feedback_processing` по событию, логировать решение роутера.


