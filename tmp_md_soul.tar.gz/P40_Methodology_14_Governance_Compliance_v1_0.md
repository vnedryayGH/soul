# M14 — Governance/Compliance (v1.0)

Цель: соблюдение регуляторных и внутренних требований с аудитом.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Policies → Controls → Evidence → Audit → Remediation.

Алгоритмы/метрики: Control Coverage, Audit Findings MTTR, p95.

Роли: Compliance Officer, PM, Security Lead.

DSL: CONTROL.ADD, EVIDENCE.ADD, METHODOLOGY.SET, INSPECTOR.RUN_ALL.

Acceptance: контрольный реестр/доказательная база в БД; панели compliance.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
