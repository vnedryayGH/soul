# P29R — ТЗ: Инспекторы Жандарма (Rust) v1.0

Версия: v1.0
Статус: к внедрению (этап 2)

## 1) Назначение

Быстрые инспекторы качества горячего пути: parity/performance/security_limits.

## 2) Контракты

Запуск: `run(key, payload_json)` →

```json
{ "status":"passed|failed", "detail":"...", "metrics": {"latency_ms": 1.23} }

```
Ключи:

- `rs.parity` — сравнение Python↔Rust по результатам/подписи.
- `rs.performance_sla` — контроль p95/p99.
- `rs.security_limits` — лимиты глубины/длины/таймаутов.

## 3) SLA

Единичный инспектор ≤ 2 ms p95. Потоковый режим для батчей (стрим).

## 4) Интеграция

UDS/HTTP JSON; вызовы из Hyperloop `INSPECTOR.RUN(_ALL)` через Python мост.

## 5) Наблюдаемость

Метрики: `p29_rs_inspector_latency_ms{key}` (hist), `p29_rs_inspector_failed_total{key}` (counter).

## 6) Тесты

Golden‑кейс ≥100 суммарно; property/fuzz входа; отсутствие `panic`.

## 7) Безопасность

Без `unsafe`; лимиты входа; общий таймаут.

## 8) Acceptance

Интеграция с Hyperloop инспекторами, зелёные статусы за 24h окно.

## Dual-language гейты переключений

- rs.parity: дифф Python↔Rust по ответам/подписям; пороги mismatch.

- rs.performance_sla: p95/p99 на parse/exec/total; флаг backpressure_on.

- rs.security_limits: лимиты длины/глубины/таймаутов; отказ категорий.

### Сценарии переключений (Жандарм)

1) shadow smoke: `INSPECTOR.RUN_ALL`; `CORE.PIPELINE.RUN ... WITH TRACE` — ok, `trace_id` есть.

2) canary 5–10%: `rs.parity` mismatches ≤ 0.5%; отчёт/инциденты при превышении.

3) primary_fallback: soak 24h; фоллбеки < порога; алерты не срабатывают.

4) primary: soak 48h; `incidents A=0`.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
