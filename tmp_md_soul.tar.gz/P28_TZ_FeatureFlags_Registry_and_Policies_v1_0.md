<!-- markdownlint-disable MD041 MD022 MD032 MD012 MD047 -->
---

## Индекс взаимных ссылок (P01–P37)

- P21 Monitoring — флаги наблюдаемости; P27 — включение подписи.
- P30 Processor — поведение очереди/обработки.
- P33 Personification — флаги Mini Chat (санитария, диагностика, провайдеры).
- P36 Hyperloop DSL — флаги для инспекторов/команд.

## P28 — ТЗ: Единый реестр фичефлагов (Feature Flags Registry)

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — инвентари.
- `tmp_p_series_plan.json` — план P‑серии.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр.
- `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`, `Soul/P21_TZ_P95_Observability_and_Regulation_v1_0.md`, `Soul/P30_TZ_Soul_Processor_v2_0.md`, `Soul/P36_TZ_Hyperloop_DSL_v1_1.md` — ключевые интеграции.

Версия: v1.2  
Статус: Реализация совместно с P27; добавлена плагинная архитектура и инспекторы

### 1. Цели

- Централизовать управление фичефлагами ядра Соул, хранить в БД и админ‑панели.
- Давать гибкие политики включения/выключения фич, с описанием и типами.
- Снизить риск дрейфа конфигураций между окружениями.
- Обеспечить плагинную расширяемость флагов и инспекторов качества/безопасности.

### 2. Модель данных

- Таблица: `soul_settings(key text primary key, value text, description text, category text, data_type text, is_configurable bool, created_at, updated_at)`
- Типы: `boolean|integer|float|string|json`
- Категории: `signature|diagnostic|sanitizer|llm|privacy|router|planner|dispatcher|sleep|security|ab|self_consistency|desired_action|ui|limits|feature_flags`.
- Таблица реестра инспекторов (новая): `feature_inspectors(id uuid pk, key text unique, module text, callable text, scope text, enabled bool, config jsonb, updated_at)`

### 3. Реестр санитайзеров и P27 связка

- Ключи санитайзера (см. P27):
  - `sanitizer.visible_text.enabled` (bool)
  - `sanitizer.visible_text.patterns` (json)
  - `sanitizer.thought_form.enabled` (bool)
  - `sanitizer.thought_form.patterns` (json)
  - `sanitizer.architect.append_markers_to_visible` (bool)
- Инспекторы санитайзера: регистрируются как плагины в `feature_inspectors` со `scope='sanitizer'`.

### 4. Матерь флагов (FeatureFlagsSupervisor)

- Профили: `prod_safe`, `diagnostics_on`, `dev_fast`.
- Критические инварианты P27: поддерживаются автоматически (если `mother_flags.auto_enforce=true`).
- Настройки:
  - `mother_flags.auto_enforce` (bool)
  - `mother_flags.health_check_interval_sec` (int)
  - `mother_flags.profile.current` (string)
- Админ‑API: `/api/admin/feature-flags/*`
  - `GET /get?key=` — чтение флага
  - `POST /set` — установка флага `{key,value}`
  - `POST /apply-profile` — применить профиль `{profile}`
  - `POST /reconcile-p27` — применить инварианты P27
  - `GET /state` — краткое состояние флагов

### 5. Плагинная архитектура и инспекторы

- Плагины размещаются в `backend/app/feature_plugins/*` или указываются модуль/функция в реестре `feature_inspectors`.
- Требования к плагину:
  - Экспорт `run(db: AsyncSession, context: dict|None) -> dict{status, detail, metrics?}`
  - Контракт: запрещены побочные эффекты вне задекларированного `scope` и конфигурации
- Загрузчик инспекторов:
  - При старте/по расписанию читает включённые записи `feature_inspectors.enabled=true`
  - Динамически импортирует модуль и вызывает `run` (async/sync), аггрегирует отчёт
  - Аудит и `test_results` пополняются элементами отчёта

### 6. Hyperloop интеграция (P36)

- Команды:
  - `FLAGS.SET key=.. value=..`
  - `FLAGS.UNSET key=..`
  - `FLAGS.APPLY_PROFILE name=..`
  - `INSPECTOR.RUN key=..` (новая): выполнить инспектора по ключу
  - `INSPECTOR.RUN_ALL scope=sanitizer|security|*` (новая)

### 7. Матрица соответствия (P30/P36)

- P30 (Processor): флаги профиля процессора (`processor.*`), инспекторы в `scope='processor'`
- P36 (Hyperloop): команды управления флагами/инспекторами (см. раздел 6)
- P27 (Signature): инварианты и Guard — проверяются инспекторами `scope='signature'`

### 8. Acceptance

- Флаги P27 и Санитайзера присутствуют; изменения применяются в рантайме.
- Реестр `feature_inspectors` создан, инспекторы загружаются как плагины и исполняются.
- Hyperloop команды для флагов/инспекторов доступны и проходят smoke.
- Отчёты инспекторов отображаются в админ‑панели и пишутся в `test_results`.

### 9. Runbook

- Проверка ключей: `GET /api/admin/soul/settings/all`.
- Применить профиль: `POST /api/admin/feature-flags/apply-profile {"profile":"prod_safe"}`.
- Запуск инспектора: `POST /api/admin/feature-flags/inspect {"key":"sanitizer.patterns_consistency"}`.

Ссылки (интеграции и реестры):

- docs/PROJECT_STRUCTURE_v8_2_0.md — карта модулей/интеграций (P27/P28/P30/P36)
- docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md — мастер‑реестр документов
- Soul/Report_Soul_AI_Scientific.md — сводка нормализации и «Нереализованные требования — сводка»
- Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md — подпись/линейность
- Soul/P30_TZ_Soul_Processor_v2_0.md — интеграция лимитов/флагов процессора
- Soul/P36_TZ_Hyperloop_DSL_v1_1.md — команды управления флагами/инспекторами


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
