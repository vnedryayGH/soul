# PROJECT AI AUTOPILOT v2.27

Версия: v2.27  
Дата: 2025‑09‑25  
Статус: актуально; добавлен быстрый контур Hyperloop для работы с проектным репозитарием, требование активной ветки и автозагрузки промпта.

## Обновления

- Добавлен раздел «Быстрый контур Hyperloop (P40 §2.3)» — команды `SESSION.CLAIM|PING|RELEASE`, `DEV.CONNECT`, `LLM.MIRROR`, `PROJECT.LIST|CREATE`, `PLAN.TASK.ADD|DEPEND`, `PLAN.CPM.CALC WITH TRACE` (Windows PowerShell).  
- Уточнено требование: любая разработка только через `plan_task.id` (P40), действия зеркалируются `LLM.MIRROR(.BATCH)` с `payload.plan.task_id`.  
- Зафиксировано освобождение ветки по завершении: `SESSION.RELEASE branch="<key>"`.

## Быстрый контур Hyperloop (Windows PowerShell)

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
$B=@{ commands='SESSION.CLAIM owner="468326902" branch="p40-dev" topic="planning" session="dev-001"' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

$B=@{ commands='DEV.CONNECT owner="468326902" branch="p40-dev"' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

$B=@{ commands='PROJECT.LIST' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

$C='PROJECT.CREATE name="P40 MVP" methodology=hybrid priority=0.8 owner=468326902'
$B=@{ commands=$C } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

$C='PLAN.TASK.ADD project_id="<PID>" title="CPM расчёт" cpm_duration_days=2.5'
$B=@{ commands=$C } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

$C='PLAN.CPM.CALC project_id="<PID>" WITH TRACE'
$B=@{ commands=$C } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

$C='LLM.MIRROR owner="468326902" branch="p40-dev" topic="dev" user_command="..." agent_reply="ok"'
$B=@{ commands=$C } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

$B=@{ commands='SESSION.RELEASE branch="p40-dev"' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress
```

Примечания: STRICT JSON, P27 Guard, без локальных JSON как источника истины.


