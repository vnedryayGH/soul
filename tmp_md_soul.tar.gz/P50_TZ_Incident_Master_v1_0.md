# P50 — ТЗ: Персонаж «Incident Master» v1.0

Назначение: ввести в Ядро Соул самостоятельного агента‑персону «Incident Master» (далее — IM), который непрерывно и автоматически управляет полным жизненным циклом инцидентов: обнаружение, тряж, маршрутизация/эскалация, расследование (RCA), митигирующие действия, верификация, закрытие и постмортем, с соблюдением методологий P40/P50 и политик безопасности P44. IM интегрирован с Ядром Соул, инспекторами P29, Delivery Guard P27, Процессором P30, наблюдаемостью P21, Hyperloop DSL (P36), планированием P40 и доступом к сервисной/внешней LLM.

---

## 1. Роль и зона ответственности

- Управление инцидентами end‑to‑end по процессу: Detect → Triage → Assign/Escalate → Mitigate → RCA → Fix → Verify → Close → Postmortem.
- Постоянный мониторинг сигналов (инспекторы P29, метрики/алерты P21, Delivery Guard, ошибки API/RS, Processor P30, фронтенд) и авто‑создание инцидентов по правилам.
- Автотриаж: присвоение `severity/priority/status`, привязка `trace_id` (P27), заполнение `meta.inspector_key/source`, постановка ответственного или авто‑эскалация к Архитектору.
- Управление рисками: контроль SLA MTTA/MTTR и p95 стадий; эскалации при нарушениях; группировка/дедуп по сигнатурам и связям.
- RCA и непрерывные улучшения: инициирование RCA, ведение KB/Runbook, генерация/финализация постмортемов, обратные связи в P40 задачи.
- Соблюдение RBAC/Two‑Keys (P44): закрытие и правки RCA на sev1/2 только с подтверждением.

## 2. RBAC и права доступа

- Роль: `incident_master` (суперсет над операционными правами инцидентов, под управлением роли `architect`).
- Доступ: админ‑роуты `/api/admin/incidents/*`, чтение/запись `soul_settings` и `soul_secrets` через сервисы (`SoulSettingsService`/`SecretsService`), инспекторы P29, Delivery Guard P27, Prometheus/Grafana (read‑only через прокси API).
- LLM: доступ и к сервисной LLM (внутренний провайдер) и к внешней большой LLM через серверный прокси (см. P42/P21). Ключи — только из БД (SecretsService/Settings), без хардкодов.

## 3. Интеграции (ядро/сервисы)

- P27: запись шагов `svc.incident.*`, сохранение `trace_id` источника.
- P29: инспекторы `incident.required_steps`, `guard.delivery.enforceable`, RS/processor инспекторы; их нарушения → авто‑INCIDENT.CREATE (источник `inspector`).
- P21: алерты Prometheus → `/api/alerts/alertmanager` → авто‑инциденты/эскалации; дашборд `ops/grafana/incidents_dashboard.json`, правила `ops/prometheus/rules_incidents.yml`.
- P30: события процесса (analyze/search/answer/deliver/persist) → инциденты и таймлайн.
- P36: Hyperloop DSL `INCIDENT.*` (create/update/link/close/postmortem/list/assign/route.to_architect).
- P40: связь c проектными задачами `plan_task_id`, эскалации и закрытия синхронят статусы задач.

## 4. Поведение и автоматика IM

- Автотриаж: при создании из инспектора/алерта IM заполняет: `severity/priority` по матрице SLA (`incident.sla.*`), `status=open`, `meta.inspector_key|source`, привязки к задачам/квантам/act trace (если доступны).
- Авто‑эскалация: для `severity∈{1,2}` при нарушении SLA MTTA/этапа triage — немедленная `INCIDENT.ROUTE.TO_ARCHITECT` + Telegram‑уведомление через алерт‑бот.
- RCA‑цикл: при `status in ('mitigated','verifying')` IM инициирует генерацию постмортема (через LLM с фактами из БД), валидацию P27/P29 и предлагает Runbook. Для sev1/2 правки RCA/закрытие только с Two‑Keys.
- Группировка/дедуп: объединение инцидентов по сигнатурам/связям (KB signature, `reason_hash`, `trace_id`, `to_kind+to_id`) и закрытие дублей как `duplicate_of`.

## 5. Настройки/ключи (через БД)

- `incident.master.enabled` (bool, default=false) — включает IM автоматику.
- `incident.master.autotriage.enabled` (bool) — автоприсвоение статусов/приоритетов.
- `incident.master.escalate.architect_on_breach` (bool) — авто‑эскалация на нарушения SLA triage/rca/verify.
- `incident.master.postmortem.auto_generate` (bool) — автогенерация драфта при закрытии.
- `incident.sla.*` (матрица MTTA/MTTR/стадии) — источники истин из БД, UI редактирование через админку.
- `delivery_guard.enforce` (bool) — обязательный для enforce‑проверок (инспектор `guard.delivery.enforceable`).

## 6. API/DSL

- Admin API: `backend/app/routers/incidents_admin.py` — список, детали, создание, обновление, события, связи, закрытие, эскалация, постмортем (экспорт/финализация), KB/Runbook.
- DSL: `INCIDENT.CREATE|UPDATE|LINK|CLOSE|POSTMORTEM.GENERATE|LIST|ASSIGN|ROUTE.TO_ARCHITECT` (см. `Soul/P50_TZ_Incident_Management_v1_0.md`).

## 7. Наблюдаемость и приёмка

- Метрики: `incidents_created_total{severity,source}`, `incidents_open_total`, `incident_mtta_ms`, `incident_mttr_ms`, `incident_stage_latency_ms{stage}`.
- Алерты: правила из `ops/prometheus/rules_incidents.yml` (MTTA/MTTR/stage p95) с человекочитаемыми аннотациями (severity/risk/steps). Маршрутизация Alertmanager → Telegram.
- Acceptance (минимум):
  - Авто‑создание инцидента инспектором `guard.delivery.enforceable` с `severity=2`, заполненными полями и событием в таймлайне.
  - Авто‑эскалация sev1/2 при нарушении SLA triage; уведомление Telegram; запись события `escalation`.
  - Закрытие sev1/2 только с Two‑Keys; постмортем‑драфт создан и доступен через API/экспорт.
  - Дашборд показывает открытые, распределение по severity и MTTA/MTTR; алерты срабатывают и приходят в Telegram.

## 8. Безопасность и соответствие

- Все URL/порты/токены читаются через `SoulSettingsService`/`SecretsService` из БД; хардкод запрещён.
- Логи без PII; записи P27 обязательны; инспекторы P29 включены в RUN_ALL.
- Two‑Keys на закрытие/правки RCA для sev1/2; трассировка решений/шагов IM в `incident_events`.

## 9. План внедрения

1) Включить флаги `incident.master.*`, `delivery_guard.enforce` через DSL.
2) Обновить реестр документов и `docs/PROJECT_STRUCTURE.md` (ссылки/потоки/дашборды).
3) Создать проект P40 «Incident Master Enablement», добавить задачи: ТЗ, флаги/интеграции, смоки, отчёты, UI‑min.
4) Смоки: `INCIDENT.CREATE` → `ROUTE.TO_ARCHITECT` → close_with_postmortem; проверить метрики/алерты/Telegram.

## 10. Связанные документы

- `Soul/P50_TZ_Incident_Management_v1_0.md`
- `docs/PROJECT_STRUCTURE.md` (раздел Observability/Incidents)
- `ops/prometheus/rules_incidents.yml`, `ops/grafana/incidents_dashboard.json`
- `backend/app/routers/incidents_admin.py`, `backend/app/services/incident_service.py`
- `backend/app/routers/alertmanager_webhook.py`
- `backend/app/feature_plugins/incident_required_steps.py`, `backend/app/feature_plugins/guard_delivery_enforceable.py`
