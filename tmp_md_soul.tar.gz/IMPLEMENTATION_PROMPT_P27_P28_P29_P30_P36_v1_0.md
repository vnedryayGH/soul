## Единый промпт реализации (P27/P28/P29/P30/P36)

Версия: v1.0  
Статус: Готов к использованию инженерами для реализации и тестирования

### 0) Назначение

- Свести в одну структуру правила проекта, ссылки на ключевые ТЗ и реестры, требования к секретам, унифицированный язык Hyperloop DSL и порядок реализации/тестирования/документирования.
- Обеспечить плагинную архитектуру инспекторов/тестов/санитайзеров/фичфлагов и согласование с Процессором (P30).

### 1) Ключевые документы (локальные пути)

- P27 (Signature & Guard): `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`
- P28 (Feature Flags & Inspectors): `Soul/P28_TZ_FeatureFlags_Registry_and_Policies_v1_0.md` (v1.2)
- P29 (Gendarme/Judge): `Soul/P29_TZ_Quality_Registry_Gendarme_and_Judge_v1_0.md` (v1.1)
- P30 (Processor): `Soul/P30_TZ_Soul_Processor_v1_0.md`
- P36 (Hyperloop DSL): `Soul/P36_TZ_Hyperloop_DSL_v1_1.md`
- Единый реестр: `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8_1.md`

### 2) Правила проекта (обязательные)

- Никакой деградации функциональности; отсутствие «заглушек», если данные мигрированы — найти и использовать (см. K0/мемо).  
- Все изменения документируются сразу в соответствующих ТЗ и в реестре документов.  
- Тесты не поднимают новые серверы/каналы; используют уже работающие (см. правила тестов).  
- Удалённые тесты Telegram‑бота на удаление сообщений — не использовать (перенесено в мини‑чат).  
- Ветки: `feature/p30-p36-p29-hardening-YYYYMMDD`.  
- Запуск бекенда/алембика — из `backend` (см. локальные скрипты), uvicorn: `uvicorn app.main:app`.  
- Визуализация и UI‑правки — приоритетно.

### 3) Секреты и окружение

- Backend ENV (локально): `backend/.env.local` (не коммитить):
  - `DATABASE_URL=postgresql+psycopg://...`
  - `LLM_PROVIDER`, `OPENAI_API_KEY|DEEPSEEK_API_KEY|GIGACHAT_*`
  - `BOT_TOKENS` (опц.)
  - `HYPERLOOP_API_KEY`, `HYPERLOOP_API_SECRET`
  - Флаги по умолчанию: `delivery_guard.enforce=false`, `processor.enabled=true`, др. (см. P28/P30)
- PROD: `/var/www/soulpulse/backend/.env.prod` (ключи HMAC, LLM, DB)

### 4) Унифицированный DSL (P36) — подключение

- Внутренний (RBAC `soul.admin`): `POST /api/hyperloop/execute`
- Внешний (подписанный): `POST /api/hyperloop/execute-signed`  

Поля: `key`, `ts`, `sig=HMAC_SHA256("${key}:${ts}:${commands}", secret)`, допускается дрейф времени ±300s.  
Флаг: `hyperloop.allow_signed=true`.

### 5) Унифицированный DSL — команды (MVP)

- FLAGS: `FLAGS.SET|UNSET|APPLY_PROFILE`
- INSPECTOR: `INSPECTOR.RUN key=...`, `INSPECTOR.RUN_ALL [scope=...]`
- TEST: `TEST.RUN key=...` (Жандарм)
- JUDGE: `JUDGE.CHARTER.UPSERT`, `JUDGE.CHECK`
- PROCESSOR: `PROCESSOR.ENABLE|DISABLE|POLICY.SET|EVENT.INJECT|PROCESS_ONCE|PROCESS_EVENT`
- CORE: `CORE.PIPELINE.RUN`, `TRACE.STEPS`, `CORE.TRACE.REQUIRE`, `CORE.MSG.AUDIT`

Пример запроса:

```json
{
  "commands": "FLAGS.SET key=delivery_guard.enforce value=true\nINSPECTOR.RUN key=sanitizer.patterns_consistency\nTEST.RUN key=p29.processor_cycle",
  "options": {"stop_on_error": true}
}

```
Ожидаемый ответ: нормализованный e2e с `results[]`, `signature.steps`, `incidents`, `ok` (см. P36).

### 6) Плагинная архитектура и реестры

- Тесты Жандарма: плагины `backend/app/gendarme_tests/*` (наименование по ключу или через `tests_registry.expected_outcome{module, callable}`).
- Инспекторы P27/P28: плагины `backend/app/feature_plugins/*` или реестр БД `feature_inspectors(key,module,callable,scope,enabled,config)`.
- Контракт плагина:

```text
async def run(db: AsyncSession, context: dict | None = None) -> dict:
    return {"status": "passed|failed", "detail": "...", "metrics": {...}}

```

- Жандарм (сервер): динамическая загрузка тестов по реестру/конвенции (`GendarmeService._run_dynamic_test`).
- HyperloopEngine: `INSPECTOR.RUN/INSPECTOR.RUN_ALL` вызывает плагины инспекторов (по реестру/конвенции).

### 7) Реализация — план работ

1) БД: добавить ensure‑скрипт для `feature_inspectors` (schema и индексы).  
2) Сервер: 

   - Завершить загрузчик инспекторов (scope=signature|sanitizer|processor).
   - Включить Hyperloop команды `INSPECTOR.RUN(_ALL)` (добавлено) и smoke‑покрытие.
   - Довести P29 Suite до 100% (после деплоя `judge_service`).

3) Процессор (P30): расширить Admin UI для ретраев/бэкоффов и Guard шагов; метрики Prometheus по `event_kind`.
4) Жандарм/Судья: авто‑правила, тренды/регрессии, алёрты (P21).
5) Документация: синхронизировать P27/P28/P29/P30/P36 и Master Registry.

### 8) Тестирование

- Локально: `start_local_test.bat` (BE/FE, опц. туннели) + панели P23/P29/P30.  
- Интеграционные smoke через Hyperloop: `TEST.RUN`, `INSPECTOR.RUN`, `PROCESSOR.*`.  
- Фокус: без поднятия новых серверов, реальные учетные данные; targeted тесты до фикса, финальный Suite в конце.

### 9) Деплой/миграции

- Частичный деплой файлов по SSH:

```text
scp -o StrictHostKeyChecking=accept-new -i Arh\spbd_ed25519 backend\app\... root@mini.soulpulse.art:/var/www/soulpulse/backend/app/...

```

- Перезапуск uvicorn (user‑space): `pkill -f 'uvicorn app.main:app' || true; nohup venv/bin/uvicorn app.main:app ... &`
- ENV/секреты — только в `.env.prod` (не в БД).

### 10) Документирование/реестры

- После каждого шага:
  - Обновить соответствующее ТЗ (версии/статус/Acceptance/Нереализовано/План).
  - Обновить `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8_1.md` (ссылки/версии).
  - Зафиксировать новые команды DSL/эндпоинты в P36/P29/P28/P27/P30.

### 11) Контроль качества

- Метрики: `/api/metrics` и `/api/metrics/prometheus` — наличие `processor_queue_len`, `processor_incidents_rate_per_min`, p95, coverage.  
- Алёрты P21: пороги для очереди, guard pass, incidents rate, e2e p95.  
- Аудит: `CORE.MSG.AUDIT`, запись результатов тестов/инспекторов в `test_results`.

### 12) Приложение — быстрые примеры DSL

```text
# Включить Guard и запустить инспектора санитайзера
FLAGS.SET key="delivery_guard.enforce" value=true
INSPECTOR.RUN key=sanitizer.patterns_consistency

# Политика блокировок процессора
PROCESSOR.POLICY.SET key="block.all" value={"enabled": true}
PROCESSOR.EVENT.INJECT kind="chat_message" payload={"text":"hi"} priority=10
PROCESSOR.PROCESS_ONCE

# Запуск тестов Жандарма / Судьи
TEST.RUN key=p29.pipeline_smoke
JUDGE.CHARTER.UPSERT name="core_safety" version="v1" text="no dangerous ops" enforced=true
JUDGE.CHECK code="no dangerous ops here"

```

### 13) Текущий статус и незакрытые задачи

- Реестр инспекторов `feature_inspectors` создан; ensure‑скрипт выполнен на PROD.
- Команды `INSPECTOR.RUN/INSPECTOR.RUN_ALL` реализованы в HyperloopEngine; запуск на PROD работает.
- Базовые плагины реализованы в репозитории (локально):
  - `backend/app/feature_plugins/sanitizer_patterns_consistency.py`
  - `backend/app/feature_plugins/signature_required_steps_consistency.py`

  Локальный запуск `INSPECTOR.RUN_ALL scope=*` выполнен; артефакт сохранён: `logs/inspectors_result_local.json`.
  На локали: `sanitizer.patterns_consistency=passed`; `signature.required_steps.consistency=failed` (ожидаемо при отсутствии свежих `signature_steps` в окне 24ч на dev‑данных).
  Требуется деплой плагинов на PROD и повторный запуск `INSPECTOR.RUN_ALL`; артефакт PROD сохранять в `/var/www/soulpulse/scripts/gendarme_inspectors_result.json`.

- P29 Suite зелёный 3/4; блокер: деплой `judge_service` для `p29.judge_charter`.

– P29 Suite зелёный 4/4 на PROD; `judge_service` задеплоен. Сервисный анализ Жандарма выполняется через GigaChat (таймаут 1.5s, retries=0; fallback DeepSeek). Артефакт: `/var/www/soulpulse/scripts/gendarme_suite_result.json`.

— Конец промпта.
