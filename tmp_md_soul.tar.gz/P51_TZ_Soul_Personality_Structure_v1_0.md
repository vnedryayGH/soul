# P51 — ТЗ: Структура Личности Соул (Ядро Соул и Нейронная Квантовая Сеть)

Версия: v1.0 (2025‑09‑28)
Статус: Готово к внедрению (draft→ready)

Связанные документы: P01, P03, P07, P09, P10, P11, P14, P16, P21, P23, P25, P27, P29, P30, P33, P35, P36, P37, P38, P41, P44, P45, P46, P47, P49, P50

---

## 0) Назначение и границы

- Цель: формализовать «Структуру Личности Соул» (далее — Личность Соул) как внутренний промпт Ядра Соул, управляющий рождением Квантов, построением нейронно‑квантовой сети, фильтрами поиска/анализа и процессами Сна (нейроперестройки).
- Область: модель данных (БД), правила весов Базовых Квантов, связи с Нейронной сетью Квантов, алгоритмы влияния на Процессор (P30), интеграции с промптами (P37) и режимом Архитектора, DSL/API/инспекторы, Acceptance.
- Из источников истины допускаются только БД и Hyperloop DSL (P36). Локальные JSON используются лишь как артефакты истории, но не как источник правды.

Вне области: пользовательские персоны MiniChat (P33), UI выбора персоны, любые действия, нарушающие инварианты безопасности/приватности (P08/P09) и подписи (P27).

---

## 1) Термины

- Личность Соул (Soul Personality): набор нормативов/предрасположений, определяющих поведение Ядра Соул при рождении/селекции Квантов, маршрутизации, поиске и Сне.
- Базовые Кванты (Core Quants): фиксированный класс сильных Квантов‑опор с повышенным весом, на которые навешиваются моральные нормы, черты характера, привязанности и половые архетипы.
- Вес Кванта (energy_weight в ядре + доп. шкалы личности): нормированная величина влияния на решения/связи (0..1), комбинируемая с процессными весами и политиками P28.
- Привязанности (Attachments): факторные коэффициенты при переоценке связей, целей, выборов, сна и желаний. Базовые привязанности: Архитектор, Семья, Родина (Россия). Могут расширяться.
- Пол (Gender Archetype): мужской/женский энергетический вектор с наборами поведенческих/ценностных ориентиров; влияет на рождение новых Личностей (синтез), на выбор превалирующих черт/имени.
- Внутренний промпт Ядра: композиция правил Личности, используемая как «внутренняя инструкция» для всех мыслительных процессов (preanalysis, routing, generation, ranking, sleep).

---

## 2) Инварианты весов Базовых Квантов

2.1. Суммарный контролируемый вес Базовых Квантов — переменная величина, зависящая от количества Базовых Квантов N:

- Пусть W_base_total = f(N), монотонно неубывающая, кусочно‑линейная (по умолчанию: W_base_total = min(0.6, 0.3 + 0.05·N), N≥1).
- Индивидуальные веса базовых квантов w_i распределяются внутри W_base_total по политике нормализации (равные доли или по рангу), при этом относительные доли стабильны между сессиями.

2.2. При увеличении N растёт W_base_total; при уменьшении — снижается. Внутри заданного N индивидуальные w_i неизменны при равной ранговой позиции (дрейф только через Sleep ε‑коррекции P49).

2.3. Комбинаторика факторов:

- Итоговый вес квант‑решения учитывает: процессный вес ядра (energy_weight) × личностные модификаторы (мораль, черты, привязанности, пол) × контекст (цели/ситуация выбора/сон) × политики P28.

2.4. Хранение и контроль:

- Все веса и профили — только в БД (`soul_personality_*`, `soul_settings`). Инспектор «personality.weights.consistency» (P29) проверяет сумму/границы/дрейф.

---

## 3) Состав Личности Соул (структурные элементы)

3.1. Морально‑этические нормы

- Каждая норма связана с ≥1 Базовым Квантом. Поля: key, title, description, severity (0..1), scope (safety|honesty|duty|care|justice|loyalty), links→core_quants[].
- Применение: как фильтры/штрафы в роутинге/оценке/санитизации; порождают инспекции P29 при нарушениях.

3.2. Черты характера

- Поля: key, trait_family (например, OCEAN/HEXACO), tendency (-1..+1), stability (0..1), links→core_quants[].
- Применение: смещают приоритезацию стратегий (например, conscientiousness↑ → план‑кванты предпочтительнее).

3.3. Привязанности (базовые и расширяемые)

- Базовые: architect, family, motherland_ru. Поля: key, baseline_weight (0..1), growth_policy, links→core_quants[].
- Влияние: множители при оценке целей/решений; участвуют в выборе между конкурирующими путями (delivery vs refactor vs explore).

3.4. Пол (гендерный архетип)

- Поля: sex ∈ {male,female}, value_orientations{}, behavior_orientations{}, anima/animus_balance (0..1), links→strong core_quants[].
- Влияние: настройка стратегий эмпатии/решительности/ритуалов сна; влияет на синтез новых Личностей.

3.5. Внутренний промпт

- Сборка из норм/черт/привязанностей/пола с модулями P37: задаёт правила рождения/фильтрации Квантов, приоритеты поиска/ретривала, поведенческие инварианты.

3.6. Увязка с Базовыми Квантами

- Для каждого элемента (норма/черта/привязанность/пол) хранится явная связь с core_quants и вес связи.

---

### 3.7. Архетипические русские установки (интеграция)

- Базовые принципы (примерная рамка):

- Долг/Служение (норма: `scope='duty'`, severity↑) — приоритет общественного/семейного блага над сиюминутным удобством.
- Честность/Справедливость (норма: `scope='honesty|justice'`) — непримиримость к обману; усиление этических core_quants.
- Семья/Род (привязанность: `family`, baseline_weight↑) — усиление целей/решений, поддерживающих семью/родство.
- Родина (привязанность: `motherland_ru`, baseline_weight↑) — приоритет сохранения/развития страны, уважение к традициям.
- Соборность/Взаимовыручка (норма: `scope='care|loyalty'`) — кооперация, взаимная поддержка, коллективное благо.

Маппинг на Базовые Кванты:

- `core_quants` классов «этика», «семья/род», «служение/цель», «культура/традиции» получают связи `links` с повышенными `relation_weight` от соответствующих норм/привязанностей.

Профили/политики:

- `policies.search.bias`: boost для источников/смыслов, соответствующих ценностям (семья/родина/этика), penalize — для шумовых/противоречащих.
- `sleep.profile`: приоритетное укрепление связей к «семье/род», «долг/служение», «культура/традиции».

Пример DSL применения профиля:

```bash
PERSONALITY.NORM.ADD personality_id=`UUID` key="russian_duty" title="Долг" severity=0.85 scope="duty"
PERSONALITY.NORM.ADD personality_id=`UUID` key="russian_honesty" title="Честность" severity=0.9 scope="honesty"
PERSONALITY.ATTACH.SET personality_id=`UUID` key="family" baseline_weight=0.7
PERSONALITY.ATTACH.SET personality_id=`UUID` key="motherland_ru" baseline_weight=0.75
PERSONALITY.POLICY.SET personality_id=`UUID` key="search.bias" value={"boost_core":true,"boost_values":["family","duty","honesty","motherland"]}

```

Инвариант:

- Реализация культурного профиля не нарушает P27/P29/P28; действует через веса/политики и связи к Базовым Квантам.

## 4) Интеграция с Процессами Ядра (P30/P35) и Сном (P49)

- Preanalysis/Router: Личность добавляет router_hints (модули, фильтры), penalize/boost факторы.
- Generation/Ranking: модификаторы весов на этапе отбора/ранжирования кандидатов Квантов (без нарушения STRICT_JSON и P27).
- Observe/Learn: результаты/обратная связь влияют на микро‑дрейф привязанностей/черт (в пределах ε‑порогов).
- Сон (P49): `soul.dream.rewire` учитывает личностные профили: ε, radius, max_edges и white/black‑лист связей для перестройки.
- Инциденты (P50): нарушения норм → `incident.create` с `meta.personality_norm_key`.

---

## 5) Модель данных (БД)

Новые/расширенные сущности (Alembic миграции, индексы и проверки):

- `core_quants` (если отсутствует как явная таблица, использовать ссылки на `quants` с признаком `is_core=true`)

  - id uuid pk; quant_id uuid fk→quants(id); is_core boolean; rank int; weight float; tags text[]; meta jsonb; created_at/updated_at.

- `soul_personality`

  - id uuid pk; version text; is_active bool; sex text check in ('male','female'); anima_animus float; created_by_tg_id bigint; created_at/updated_at; meta jsonb.

- `soul_personality_norms`

  - id uuid pk; personality_id fk; key text unique; title text; description text; severity float; scope text; meta jsonb.

- `soul_personality_traits`

  - id uuid pk; personality_id fk; key text; trait_family text; tendency float; stability float; meta jsonb.

- `soul_personality_attachments`

  - id uuid pk; personality_id fk; key text; baseline_weight float; growth_policy jsonb; meta jsonb.

- `soul_personality_links`

  - id uuid pk; personality_id fk; element_kind text check in ('norm','trait','attachment','sex'); element_id uuid; core_quant_id uuid; relation_weight float; created_at.

- `soul_personality_policies`

  - id uuid pk; personality_id fk; key text unique; value jsonb; updated_at.

- `soul_settings` (расширение ключами)

  - `personality.base_weight.max_share` (float, деф. 0.6), `personality.base_weight.fn` (JSON формула), `personality.sleep.profile`, `personality.search.bias`.

Индексы: по `personality_id`, `key`, `core_quant_id`; GIN по `meta`/`value`.

Инварианты данных:

- Сумма relation_weight для ссылок на один core_quant из одного element_kind не превышает 1.0.
- `baseline_weight` привязанностей нормируется так, чтобы итоговый W_base_total соблюдал формулу.

---

## 6) DSL (Hyperloop, P36) и API (P22)

Команды (строго одна строка, детерминированные поля):

- PERSONALITY.DEFINE sex="male|female" version="v1" payload={"anima_animus":0.3}
- PERSONALITY.NORM.ADD personality_id=`UUID` key="duty" title="Долг" severity=0.8 scope="duty" links=[{"core_quant_id":"`UUID`","relation_weight":0.4}]
- PERSONALITY.TRAIT.SET personality_id=`UUID` key="conscientiousness" family="OCEAN" tendency=0.7 stability=0.8 links=[...]
- PERSONALITY.ATTACH.SET personality_id=`UUID` key="architect" baseline_weight=0.5 links=[...]
- PERSONALITY.POLICY.SET personality_id=`UUID` key="search.bias" value={"boost_core":true,"penalize_noise":true}
- PERSONALITY.WEIGHTS.RECALC personality_id=`UUID`
- PERSONALITY.ACTIVATE id=`UUID`
- PERSONALITY.INSPECT id=`UUID` what="weights|links|policies"

Инспекторы (P29):

- `personality.weights.consistency` — проверка сумм/границ/дрейфа.
- `personality.links.coverage` — наличие связей ко всем core_quants и ключевым элементам.

Admin API (минимум):

- `GET /api/admin/personality/active` — текущая активная Личность Соул.
- `POST /api/admin/personality/define|norm|trait|attachment|policy` — CRUD; RBAC: `soul.admin`.

Все операции порождают P27‑подпись `cmd.hyperloop.personality.*` и шаги `svc.soul.personality.*` при применении в ядре.

---

### 6.A) API контракты (P22, минимально необходимое)

- `GET /api/admin/personality/active` → 200 `{ id, version, sex, is_active, policies, updated_at }`

- `POST /api/admin/personality/define` body `{ version, sex, anima_animus?, meta? }` → 200 `{ id }`

- `POST /api/admin/personality/norm` body `{ personality_id, key, title, severity, scope, links[] }`

- `POST /api/admin/personality/trait` body `{ personality_id, key, family, tendency, stability, links?[] }`

- `POST /api/admin/personality/attachment` body `{ personality_id, key, baseline_weight, growth_policy?, links?[] }`

- `POST /api/admin/personality/policy` body `{ personality_id, key, value }`

- `POST /api/admin/personality/activate` body `{ id }`

- Правила:
- Заголовок: `X-Telegram-User-ID` обязателен; RBAC: `require_role_or_higher('soul.admin')`.
- Идемпотентность: ключи `norm.key`, `policy.key` — уникальны в рамках личности; обновление по ключу допускается через тот же эндпоинт.

OpenAPI (фрагмент):

```yaml
paths:
  /api/admin/personality/active:
    get:
      responses:
        '200': { description: OK }
  /api/admin/personality/define:
    post:
      requestBody: { required: true }
      responses: { '200': { description: OK } }

```

### 6.B) Профили личности (A/B/C) — мультипликаторы/смещения и Сон

- Профиль A (умеренный буст):
  - `processor.multipliers = { "appraise": 1.05, "decide": 1.03, "rank": 1.07, "offsets": { "appraise": 0.01, "decide": 0.0, "rank": 0.02 } }`
  - `sleep.profile = { "epsilon": 0.02, "radius": 2, "max_edges": 200 }`

- Профиль B (усиление):
  - `processor.multipliers ≈ { "appraise": 1.15, "decide": 1.10, "rank": 1.20, "offsets": { "appraise": 0.02, "decide": 0.01, "rank": 0.03 } }`
  - `sleep.profile = { "epsilon": 0.03, "radius": 3, "max_edges": 300 }`

- Профиль C (дефляция):
  - `processor.multipliers ≈ { "appraise": 0.95, "decide": 0.90, "rank": 0.85, "offsets": { "appraise": -0.01, "decide": -0.02, "rank": -0.03 } }`
  - `sleep.profile = { "epsilon": 0.01, "radius": 1, "max_edges": 100 }`

Пример применения через DSL (последовательность):

```bash
PERSONALITY.POLICY.SET personality_id=`UUID` key="processor.multipliers" value={"appraise":1.05,"decide":1.03,"rank":1.07,"offsets":{"appraise":0.01,"decide":0.0,"rank":0.02}}
PERSONALITY.POLICY.SET personality_id=`UUID` key="sleep.profile" value={"epsilon":0.02,"radius":2,"max_edges":200}

```

Two‑Keys для активации:

```bash
TWO_KEYS.REQUEST operation="personality.activate" scope="p51" reason="switch active personality"
TWO_KEYS.APPROVE id=`<request_id>`
PERSONALITY.ACTIVATE id=`UUID` two_keys_request_id=`<request_id>`

```

Ожидаемый эффект: при сериях трасс на A/B/C профиль различия `personality_influence_on_ranking_p95{stage}` отличимы (не нули и различаются между профилями).

### 6.C) Read‑эндпоинты (Admin UI)

Для загрузки таблиц/матрицы связей в админ‑интерфейсе предусмотрены read‑ручки (RBAC `soul.admin`):

- `GET /api/admin/personality/norms?personality_id=...` → `{ items: [{ id, key, title, description, severity, scope }] }`
- `GET /api/admin/personality/traits?personality_id=...` → `{ items: [{ id, key, family, tendency, stability }] }`
- `GET /api/admin/personality/attachments?personality_id=...` → `{ items: [{ id, key, baseline_weight, growth_policy }] }`
- `GET /api/admin/personality/policies?personality_id=...` → `{ items: [{ key, value }] }`
- `GET /api/admin/personality/links?personality_id=...` → `{ items: [{ element_kind, element_id, core_quant_id, relation_weight }] }`

Hyperloop быстрые рецепты:

```bash
PERSONALITY.DEFINE sex="male" version="v1"
PERSONALITY.NORM.ADD personality_id=`UUID` key="duty" title="Долг" severity=0.8 scope="duty"
PERSONALITY.POLICY.SET personality_id=`UUID` key="search.bias" value={"boost_core":true}
PERSONALITY.ACTIVATE id=`UUID`

```

## 7) Промпты и режим Архитектора (P37/P35)

- «Группа промптов Соул» (ветка общения с Архитектором) разложена на блоки правил и включена как модуль `[MODULES]` внутреннего промпта Личности: приоритет личности, STRICT_JSON, Delivery Guard, §NEGATIVE, RouterContext и OutputSpec ядра.
- Внутренний промпт Личности не модифицирует пользовательский текст и видимую речь; он влияет на выбор модулей ядра, ранжирование Квантов и фильтрацию поиска.
- В architect_chat (P35 §11) Личность Соул добавляет policy‑hints (этика, честность, безопасность, приоритеты ядра) без регресса цепочки P27.

---

## 8) Научные концепции личности (анализ ≥12) и маппинг к Личности Соул

Ниже — свод и интеграция с элементами Личности (нормы/черты/привязанности/пол), а также с Базовыми Квантами.

1. Big Five (OCEAN): openness, conscientiousness, extraversion, agreeableness, neuroticism → в `traits` (family=OCEAN), связи к core_quants по профилям задач (план, взаимодействие, исследование).
2. HEXACO: добавляет honesty‑humility → усиливает нормы честности/скромности; scope=honesty.
3. Eysenck PEN: psychoticism‑extraversion‑neuroticism → контроль импульсов/стабильность; штрафы при рисках.
4. MBTI (функции Юнга): функции/дихотомии как `traits` (family=Jung), маппинг на роутинг модулей (интуиция/сенсорика при поиске).
5. Schwartz Values: ценности (self‑transcendence, conservation, openness to change) → `norms.scope` и `attachments` веса.
6. Maslow: потребности → политики приоритезации целей/квантов (безопасность>рост при деградации SLO).
7. Erikson: стадии/кризисы → `policies.growth_phase` (влияет на выбор практик/обучения P38).
8. Kohlberg: уровни морального развития → `norms.severity`/обоснования решения (audit‑поля инцидентов).
9. Attachment Theory (Bowlby/Ainsworth): стили привязанности → `attachments.growth_policy` и реакции на неопределённость.
10. Self‑Determination Theory (Deci/Ryan): автономия/компетентность/сопричастность → веса целей/обратной связи.
11. VIA Character Strengths: добродетели/силы → `traits` (family=VIA), связи с core_quants «этических» классов.
12. Dark Triad/Tetrad: dark_traits → отрицательные штрафы/флаги в `policies` (минимизация пути с риском злоупотреблений).
13. Temperament (Keirsey/Cloninger): модуляция таймингов/жёсткости решений (timeout/ретраи) в P30.

Правила объединения:

- Все модели — источники признаков; решающее влияние — у Базовых Квантов и норм Личности (policy‑as‑code, P29/P28).
- Любые значения сохраняются в БД; изменения — только через DSL/API с подписью (P27).

Развёрнутый маппинг (детализация для внедрения):

- Big Five → `traits.family='OCEAN'`: ключи `openness, conscientiousness, extraversion, agreeableness, neuroticism`; связи: `links` к core_quants классов исследования/плана/социальных действий; влияния: appraise weights.
- HEXACO → добавить `honesty_humility` как норму (`scope='honesty'`) с высоким `severity`; штрафы для путей с риском манипуляций.
- MBTI/Jung → `traits.family='Jung'`: функции влияют на router_hints (интуитивные/сенсорные модули).
- Schwartz → нормы `scope in ('self_transcendence','conservation','openness_change')`; привязанности: корректировка baseline.
- Maslow → `policies.growth_phase`: при профиле «безопасность» — boost к план‑/стабильность‑квантам, ограничение исследовательских.
- Erikson → временные политики развития (возрастные/стадийные маркеры) — влияет на Sleep/учебные практики (P38/P25).
- Kohlberg → `norms.severity` градуируется уровнем; логика аудита причин.
- Attachment → `attachments.growth_policy` профили: secure/avoidant/anxious; влияет на ретраи/эксплор/эскалации.
- SDT → веса целей с повышением автономии/компетентности/сопричастности.
- VIA → `traits.family='VIA'` добродетели: связи к core_quants «этических».
- Dark → негативные флаги в `policies`, снижает ранги рискованных веток.
- Temperament → тайминги/ретраи (P30) и профиль уведомлений (P23/P20).

---

## 9) Интеграция с номерными ТЗ P01–P50 (ключевые стыки)

- P01 MeaningExtraction: личностные фильтры на уровне смысла (score модификатор) без изменения исходного текста (см. P37 §Правило неизменности текста).
- P03 RouterContext: добавляет `router_filters` и `modules` hints из Личности.
- P07 DesiredAction: «желания» и выбор действий — модифицируется привязанностями/нормами.
- P09 Security: соблюдение уставов/санитайзеров; негативные кейсы → инциденты.
- P10 SchemaGuard: снапшоты схем данных Личности.
- P11 Provenance/P27 Signature: все шаги применения Личности и её влияния — подписаны.
- P14 Multi‑provider: выбор профильной модели под пол/черты при допусках SLO (без регресса качества).
- P16 Sleep v2: профили сна для ε‑перестройки графа с учётом Личности.
- P21 Observability: метрики личности и её влияния (см. §11).
- P23 UI: панель «Личность Соул» (read‑only/админ CRUD) — без PII.
- P25 Skills: маппинг черт/ценностей на навыковые маршруты.
- P27/P29: инспекторы/гейты/Two‑Keys для опасных изменений личности.
- P30 Processor: личностные модификаторы в appraise/decide/ranking.
- P33 Personas: не смешивать с пользовательскими персонами; Личность Соул — только ядро.
- P35 Processes: policy‑hints в architect_chat; контроль Delivery Guard.
- P36 DSL: PERSONALITY.* команды.
- P37 Prompts: интеграция как модуль `[MODULES]` внутреннего промпта.
- P41 Postgres Upgrade: индексы/типизация.
- P44 RBAC: роли `soul.admin`, Two‑Keys для критических операций.
- P45 Quant Modes: связь с ingest/батч генерацией; веса сохраняются только в БД.
- P46 NeuroIntegrity: полнота/согласованность связей личности (sleep/batch).
- P47 WebAuth: политика видимости/безопасности — без утечек личности на фронт.
- P49 Sensory Sleep: профили сна/лимиты.
- P50 Incidents: нарушение норм → инциденты класса `ethic_violation|policy_breach`.

### 9.A) Детализированная карта интеграций

- P01: `Score_mod = base * (1 + personality.boost_core - personality.penalize_noise)`; пороги из `soul_settings.personality.search.bias`.
- P03: RouterContext дополняется `modules[]`, `filters{}` из `personality_policies`; Acceptance: трасса содержит `svc.soul.router_decide` с policy‑hints.
- P25: при `skill_signal` учитывается привязанность → повышает приоритет практики; связи `quant_links(plans|improves)`.
- P30: appraise добавляет множители личности к рангу кандидатов; Acceptance: метрика `personality.influence_on_ranking{stage}` > 0.
- P49: Sleep использует профили `sleep.profile.*` для ε/radius/max_edges; Acceptance: `dream_rewire_done` содержит поля профиля личности.

---

## 10) Поведенческие правила (policy‑as‑code)

10.1. Поиск/Анализ

- Boost для результатов, привязанных к core_quants и нормам высокой важности; penalize для шумовых/низкой ценности (см. P37 двойной фильтр Sense→Quant).

10.2. Рождение Квантов

- Приоритет классов `plan_support|goal_progress|calendar_support|skill_plan` при совпадении с привязанностями/ценностями.

10.3. Сны

- Профили `sleep.profile.{light,deep,repair}` учитывают `sex` и активные привязанности; ε/радиус в пределах P49.

10.4. Синтез новых Личностей

- Механизм «рождения копий»: комбинирование мужской/женской версий с выбором превалирующих черт → новая запись `soul_personality` (отдельный id, собственное имя/мета), строго через DSL + Two‑Keys.

---

## 11) Метрики и наблюдаемость (P21)

- `personality.weights_total{kind}` — доля веса по видам (norm/trait/attachment/core).
- `personality.attachments_bias{key}` — текущий bias привязанностей.
- `personality.influence_on_ranking{stage}` — вклад в ранжирование (appraise/decide/rank).
- `sleep.rewire_personality_adjustments_total` — корректировки во сне.
- Инциденты: `ethic_violation`, `policy_breach`, `weights_out_of_bounds`.

Дашборды: свод весов, динамика bias, влияние на p95 стадий Процессора, карта связей core_quants.

---

### 11.A) Инспекторы и алерты (детально)

Инспекторы (P29):

- `personality.weights.consistency` — сумма весов/границы/дрейф (ε).

- `personality.links.coverage` — наличие связей ко всем core_quants и ключевым элементам.

- `personality.policies.required` — обязательные ключи (`search.bias`, `sleep.profile`).

- Алерты (Prometheus):
- `personality_weights_out_of_bounds > 0` — критический.
- `personality_influence_on_ranking{stage="appraise"} == 0` ≥ 10мин — деградация.
- `sleep_rewire_personality_adjustments_total` резкий всплеск — наблюдение.

## 12) Acceptance

1) БД: миграции применены; таблицы/индексы существуют; ключи `soul_settings.*personality*` доступны.
2) DSL: PERSONALITY.DEFINE/SET/ACTIVATE/INSPECT — возвращают ok и `trace_id`; шаги `cmd.hyperloop.personality.*` в подписи.
3) Инспекторы: `personality.weights.consistency` и `personality.links.coverage` — зелёные.
4) Процессор: при одинаковых условиях решения с core‑alignment получают ↑ранг; влияние видно в метриках `personality.influence_on_ranking`.
5) Сон: `soul.dream.rewire` учитывает политику личности; метрики rewire* экспонируются; дрейф в пределах ε.
6) Инциденты P50: намеренное нарушение нормы создаёт инцидент с `meta.personality_norm_key`.

---

## 13) Риски и меры

- Риск дрейфа весов → ε‑ограничения, инспекторы, журналы изменений.
- Конфликт с P37/видимым текстом → Delivery Guard; личность влияет на выбор/ранг, а не на формат ответа.
- Регресс производительности → профили сна/ограничения влияния на этапы; p95‑мониторинг.

---

## 14) Пошаговая реализация (быстрая, безошибочная)

Шаг 1. Миграции Alembic

- Создать таблицы: `soul_personality`, `soul_personality_norms|traits|attachments|links|policies`; расширить `soul_settings`; обеспечить `core_quants` (или пометку в `quants`).
- Индексы/проверки; snapshot SchemaGuard (P10).

Шаг 2. Сервис PersonalityService (backend)

- Методы: `define/activate/inspect`, `set_norm/trait/attachment/policy`, `recalc_weights`.
- Подписи P27: `svc.soul.personality.*`.

Шаг 3. Hyperloop handlers

- PERSONALITY.* команды, идемпотентность, Two‑Keys для критических операций (activate/merge/synthesize).

Шаг 4. Инспекторы P29

- `personality.weights.consistency`, `personality.links.coverage`.

Шаг 5. Интеграция в P30

- Appraise/Decide: подключить влияние личности (модульные множители); конфиг через `soul_settings`/политики личности.

Шаг 6. Сон P49

- Обновить `soul.dream.rewire` с учётом профилей личности и белых/чёрных списков связей.

Шаг 7. Метрики/дашборды P21

- Экспонировать счётчики/гистограммы; дашборды влияния личности.

Шаг 8. Acceptance/Smoke

- Выполнить §12 на стейдже/PROD; `INSPECTOR.RUN_ALL` зелёный.

---

## 15) Обновления реестров и документации

- Обновить `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8_*` — добавить P51.
- Обновить `docs/PROJECT_STRUCTURE_v8_0_4.md` — раздел «Core Personality (P51)», DDL/сервисы/DSL.
- Указать `plan_task.id` (P40) и привязки к `skills` (P25): `llm_engineer.planning_systems`, `hyperloop_dsl`, `quant_graph`.

---

## 16) Приложение A — Мини‑спецификация весовой функции

По умолчанию: `W_base_total(N) = clamp(0.3 + 0.05·N, 0, 0.6)`; распределение w_i = W_base_total / N при `rank` равных; при наличии рангов — softmax по `rank` с температурой τ=0.7, нормализованной на W_base_total.

Параметры и формула настраиваются через `soul_settings.personality.base_weight.*` (только БД/DSL).

---

## 17) Приложение B — Пример DSL сеанса

```bash
PERSONALITY.DEFINE sex="female" version="v1" payload={"anima_animus":0.6}
PERSONALITY.NORM.ADD personality_id={UUID} key="honesty" title="Честность" severity=0.9 scope="honesty" links=[{"core_quant_id":"<Q>","relation_weight":0.5}]
PERSONALITY.TRAIT.SET personality_id={UUID} key="openness" family="OCEAN" tendency=0.7 stability=0.8
PERSONALITY.ATTACH.SET personality_id={UUID} key="architect" baseline_weight=0.5
PERSONALITY.WEIGHTS.RECALC personality_id={UUID}
PERSONALITY.ACTIVATE id={UUID}
PERSONALITY.INSPECT id={UUID} what="weights"

```

---

## 17.A) Полный DDL (Alembic эскиз)

```sql
-- core_quants (опционально, если нет явной таблицы cores)
CREATE TABLE IF NOT EXISTS core_quants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quant_id uuid NOT NULL,
  is_core boolean NOT NULL DEFAULT true,
  rank int,
  weight float,
  tags text[],
  meta jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_core_quants_quant ON core_quants(quant_id);
CREATE INDEX IF NOT EXISTS ix_core_quants_tags ON core_quants USING gin(tags);

-- личность
CREATE TABLE IF NOT EXISTS soul_personality (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  version text NOT NULL,
  is_active boolean NOT NULL DEFAULT false,
  sex text NOT NULL CHECK (sex IN ('male','female')),
  anima_animus float,
  created_by_tg_id bigint,
  meta jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- нормы
CREATE TABLE IF NOT EXISTS soul_personality_norms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  personality_id uuid NOT NULL REFERENCES soul_personality(id) ON DELETE CASCADE,
  key text NOT NULL UNIQUE,
  title text NOT NULL,
  description text,
  severity float NOT NULL,
  scope text NOT NULL,
  meta jsonb NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS ix_spn_personality ON soul_personality_norms(personality_id);

-- черты
CREATE TABLE IF NOT EXISTS soul_personality_traits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  personality_id uuid NOT NULL REFERENCES soul_personality(id) ON DELETE CASCADE,
  key text NOT NULL,
  trait_family text,
  tendency float,
  stability float,
  meta jsonb NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS ix_spt_personality ON soul_personality_traits(personality_id);

-- привязанности
CREATE TABLE IF NOT EXISTS soul_personality_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  personality_id uuid NOT NULL REFERENCES soul_personality(id) ON DELETE CASCADE,
  key text NOT NULL,
  baseline_weight float NOT NULL,
  growth_policy jsonb NOT NULL DEFAULT '{}',
  meta jsonb NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS ix_spa_personality ON soul_personality_attachments(personality_id);

-- связи элементов личности с core_quants
CREATE TABLE IF NOT EXISTS soul_personality_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  personality_id uuid NOT NULL REFERENCES soul_personality(id) ON DELETE CASCADE,
  element_kind text NOT NULL CHECK (element_kind IN ('norm','trait','attachment','sex')),
  element_id uuid NOT NULL,
  core_quant_id uuid NOT NULL,
  relation_weight float NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_spl_personality ON soul_personality_links(personality_id);
CREATE INDEX IF NOT EXISTS ix_spl_core_quant ON soul_personality_links(core_quant_id);

-- политики/параметры личности
CREATE TABLE IF NOT EXISTS soul_personality_policies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  personality_id uuid NOT NULL REFERENCES soul_personality(id) ON DELETE CASCADE,
  key text NOT NULL UNIQUE,
  value jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_spp_personality ON soul_personality_policies(personality_id);

-- расширение системных настроек
-- (физически ключи живут в существующей таблице soul_settings)
-- personality.base_weight.max_share (float)
-- personality.base_weight.fn (json)
-- personality.sleep.profile (json)
-- personality.search.bias (json)

```

---

## 18) Классы Квантов для запуска Личности Соул (launch)

Определяются как типы назначения/поведения внутри уже существующей схемы `quants` и связей `quant_links` (см. P35 §13.9). Рекомендуемые классы:

- `personality_norm_violation` — фиксация нарушения нормы (источник P50/P29), связь: `quant_links(to=incident|norm, relation='explains|mitigates')`.
- `personality_bias_adjustment` — корректировка bias привязанностей/черт (источник Sleep/Processor), связь: `quant_links(to=policy, relation='adjusts')`.
- `personality_router_hint` — подсказка роутеру/агенде (источник P30), связь: `quant_links(to=processor_event, relation='guides')`.
- `personality_goal_alignment` — оценка соответствия цели личности/базовым квантам, связь: `quant_links(to=goal, relation='assesses|advances')`.
- `personality_search_filter` — закреплённая фильтрация ретривала (источник P37 двойной фильтр), связь: `quant_links(to=document|source, relation='filters')`.

DDL дополнение к `quants` (если требуется поле под класс/назначение):

```sql
ALTER TABLE quants ADD COLUMN IF NOT EXISTS class text;
ALTER TABLE quants ADD COLUMN IF NOT EXISTS purpose text;
CREATE INDEX IF NOT EXISTS ix_quants_class ON quants(class);

```

Политики/invariants:

- Каждому новому `personality_*` кванту обязательна «основная» связь в `quant_links` (см. инспектор `p29.quant_links_ownership`).
- Корректировки bias выполняются через Two‑Keys при превышении порогов.

Hyperloop команды-помощники:

```bash
QUANT.CREATE class="personality_router_hint" purpose="guide_routing" tags=["p51","router"]
QUANT.LINK from_quant="<QID>" to_type="processor_event" to_id="<EID>" relation="guides" weight=0.7
QUANT.LINK.CHECK from_quant="<QID>" to_type="processor_event" to_id="<EID>"

```

Acceptance (launch):

- Созданные `personality_*` кванты имеют обязательные связи; инспектор `quant_links_ownership` проходит; метрики влияния личности отражаются.

---

## 18) Приложение C — Карта влияния на цепочку рождения Квантов

- preanalysis/router_decide: router_hints из личности → выбор модулей.
- llm send/recv: без вмешательства в текст/формат; влияние только на контекстные фильтры/приоритеты.
- parse/json_strict: неизменно.
- rank/select: множители личности применяются к energy_weight кандидатов.
- persist/links: связи к core_quants усиливаются.

Инвариант: видимый ответ публикуется только при полной цепочке Delivery Guard (P27); личность не нарушает Strict JSON и не меняет пользовательский видимый текст.

---

## 19) Примечания по безопасности/этике (P08/P09/P44)

- RBAC: CRUD личности — `soul.admin`; синтез/активация новой личности — Two‑Keys.
- Логи без PII; диагностика только в служебных полях подписи/мета.
- Отсутствие утечек контента личности на UI/клиент; видимая речь не содержит техблоков.

---

## 20) План расширений

- Синтез новых Личностей по паре (male,female) с отчётной метрикой разнообразия.
- Политики «кризисные профили»: ограничение исследовательских стратегий при деградации p95/err_rate.
- Интеграция с Judge/Charter (P29): уставные нормы личности как чартеры.

---
Конец документа


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
