# SOUL: Инструкция по выкату (test → prod)

## Вводные

- Значения окружений: `deployment_config_v1.json`.
- Артефакты: промпты, маршрутизатор, реестр модулей, политики контекста, сиды RBAC, OpenAPI, тесты и скрипты — в каталоге `Soul/`.

## 0. Подготовка ветки

```powershell
git fetch --all
$cfg = Get-Content -Raw -Path Soul/deployment_config_v1.json | ConvertFrom-Json
$branch = $cfg.branch
git checkout $branch
git pull --ff-only

```

## 1. Тестовая среда

```powershell
scp -o StrictHostKeyChecking=accept-new -r Soul/* "$($cfg.test.ssh_user)@$($cfg.test.ssh_host):$($cfg.test.deploy_path)/"
ssh -o StrictHostKeyChecking=accept-new "$($cfg.test.ssh_user)@$($cfg.test.ssh_host)" << 'EOF'
set -e
DEPLOY="$HOME/opt/soul"; mkdir -p "$DEPLOY"; cd "$DEPLOY"
cat > .env <<ENV
API_BASE_URL=$($cfg.test.api_base_url)
SOUL_ROUTER_ENABLED=true
SOUL_ROUTER_PATH=$DEPLOY/Soul/soul_quant_router_v1_1.json
SOUL_MODULES_REGISTRY=$DEPLOY/Soul/modules_registry_v1.json
SOUL_CONTEXT_POLICY=$DEPLOY/Soul/context_policies_v1.json
LLM_PROVIDER=deepseek
LLM_MODEL=deepseek-chat
TG_BOT_TOKEN=$($cfg.test.tg_bot_token)
TG_WEBHOOK_URL=$($cfg.test.tg_webhook_url)
ENV
psql "$DATABASE_URL" -f $DEPLOY/Soul/seeds_soul_rbac_v1.sql || true
sudo systemctl restart soul-backend || true
sudo systemctl restart soul-workers || true
EOF
pwsh -File Soul/scripts/run_smoke.ps1 -ApiBase $cfg.test.api_base_url
k6 run Soul/tests_soul/load_smoke_k6.js

```

## 2. Прод (green)

```powershell
scp -o StrictHostKeyChecking=accept-new -r Soul/* "$($cfg.prod.ssh_user)@$($cfg.prod.ssh_green_host):$($cfg.prod.deploy_path)/"
ssh -o StrictHostKeyChecking=accept-new "$($cfg.prod.ssh_user)@$($cfg.prod.ssh_green_host)" << 'EOF'
set -e
DEPLOY="$HOME/opt/soul"; mkdir -p "$DEPLOY"; cd "$DEPLOY"
cat > .env <<ENV
API_BASE_URL=$($cfg.prod.api_base_url)
SOUL_ROUTER_ENABLED=true
SOUL_ROUTER_PATH=$DEPLOY/Soul/soul_quant_router_v1_1.json
SOUL_MODULES_REGISTRY=$DEPLOY/Soul/modules_registry_v1.json
SOUL_CONTEXT_POLICY=$DEPLOY/Soul/context_policies_v1.json
LLM_PROVIDER=deepseek
LLM_MODEL=deepseek-chat
TG_BOT_TOKEN=$($cfg.prod.tg_bot_token)
TG_WEBHOOK_URL=$($cfg.prod.tg_webhook_url)
ENV
psql "$DATABASE_URL" -f $DEPLOY/Soul/seeds_soul_rbac_v1.sql || true
sudo systemctl restart soul-backend || true
sudo systemctl restart soul-workers || true
EOF
pwsh -File Soul/scripts/run_smoke.ps1 -ApiBase $cfg.prod.api_base_url

```

## 3. Переключение трафика

- Обновить LB/DNS на `ssh_green_host`; мониторить 15–30 минут p95 и ошибки.

## 4. Откат

- Вернуть трафик на blue; сохранить аудит и логи; завести инцидент.

## Чек-лист

- [ ] 200 на health/quants; STRICT_JSON_QUANT на process
- [ ] Логируются `router_decision`, `quant_generated`
- [ ] Автопубликация desired_action при priority > 0.6
- [ ] prod бот/вебхук корректны

## 5. Проверка/выпуск сертификата для https://soulpulse.art

- Проверить актуальность:

```bash
echo | openssl s_client -servername soulpulse.art -connect soulpulse.art:443 2>/dev/null | openssl x509 -noout -dates -issuer -subject

```

- Если требуется выпуск/обновление (пример c Certbot + NGINX):

```bash
sudo certbot certonly --nginx -d soulpulse.art -d www.soulpulse.art --non-interactive --agree-tos -m admin@soulpulse.art
sudo systemctl reload nginx

```

- Настроить автообновление (если не настроено):

```bash
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer

```

## 6. Быстрая подстановка SSH/DB параметров из проекта

- Ключи и доступы ищем в проектных папках `D:\YandexDisk\AI\0-3D4Art-Soft-SoulP\Telegram_Bot`.
- После нахождения значений:

  1) Внести их в `Soul/deployment_config_v1.json` в секции `test` и `prod`:

     - `ssh_user`, `ssh_host` или `ssh_blue_host`/`ssh_green_host`
     - `api_base_url`, `tg_bot_token`, `tg_webhook_url`
     - (опционально) `db_url` если нужен явный `DATABASE_URL`

  2) Перезапустить шаги инструкции. Все команды читают параметры из `deployment_config_v1.json` — дополнительных правок не требуется.
