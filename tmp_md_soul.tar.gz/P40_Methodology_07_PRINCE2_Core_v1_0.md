# M07 — PRINCE2 Core (v1.0)

Цель: управляемая среда проекта с контролем стадий и бизнес‑обоснованием.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Starting up → Initiating → Controlling → Managing Stage Boundaries → Closing.

Алгоритмы/метрики: Stage Tolerances, Risk Register, Benefits Review, p95.

Роли: Executive, PM, Team Manager, QA.

DSL: PLAN.STAGE.ADD, RISK.ADD, BENEFITS.SET, METHODOLOGY.SET, INSPECTOR.RUN_ALL.

Acceptance: реестр рисков/стадий в БД; инспекторы зелёные.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
