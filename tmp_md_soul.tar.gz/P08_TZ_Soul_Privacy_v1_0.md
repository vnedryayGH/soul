---

## Индекс взаимных ссылок (P01–P37)

- P09 Security — технические меры защиты данных.
- P21 Health/Monitoring — контроль приватности и инцидентов.
- P23 UI Spec — согласия/тексты для пользователя.
- P24 Integrated Tests — тесты приватности/редакции логов.
- P27 Signature/Lineage — аудит без PII.
- P30 Processor — обработка событий с учётом приватности.
- P33 Personification — ретеншн/удаление профиля/ключевых слов/напоминаний.
- P34 External Chat Proxy — каналы и границы доверия.

### ТЗ Soul v1.0 — PII‑Sanitizer и Privacy‑политика

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: Частично реализовано (MVP включён: input/logs/trace санитайз; Stage‑2 — DLP/ретеншн)

---

### 0. Executive summary

- Цель: исключить утечки персональных данных и секретов в промпты, логи, аудит и отчёты, сохранив отладочную ценность трасс и метрик.
- Интеграция: server‑side PII‑Sanitizer на входе/выходе и при логировании; централизованная Privacy‑политика; маскирование/хеширование; аудит событий приватности. По умолчанию — бережный режим, без миграций.

---

### 1. Актуальная реализация (аудит)

- Сборка промпта: `backend/docs/SOUL_PROMPT_BUILDING.md` — NEGATIVE/санитизация модульных имён уже оговорены.
- Аудит и трассировка: `docs/SOUL_PIPELINE.md`, ТЗ трасс‑вьювера `Soul/TZ_Soul_TraceViewer_v1_0.md` — вывод событий/мета.
- Guard: `Soul/TZ_Soul_Security_v1_0.md` — post‑guard проверка выхода.
- Provenance: `Soul/TZ_Soul_Provenance_v1_0.md` — планируемые источники/хеши.

Вывод: базовый слой приватности реализован (privacy_sanitizer + интеграция в /api/soul/process, маскирование в логах/трассах); расширения переносятся в Stage‑2.

---

### 2. Архитектура и точки интеграции

- Новый сервис: `backend/app/services/privacy_sanitizer.py` — детект/маскирование/хеширование PII и секретов.
- Точки вызова (в этом порядке):

  1) На входе API (до аудита): sanitize input_text/attachments.
  2) Перед сборкой промпта: повторная быстрая очистка (markdown/URL/ключи).
  3) Перед логированием/аудитом/трассой: маскирование excerpts/мета.
  4) В TraceViewer/Provenance экспорте: финальный санитайз.

- Конфигурация: `soul_settings_service.py` и `backend/config/privacy_policy.yaml`.

---

### 3. Политика PII/секретов (что считаем приватным)

- Контактные данные: email, телефон, адрес, соц‑идентификаторы.
- Финансовые идентификаторы: PAN (кредитная карта — Luhn), IBAN, БИК/ИНН (гос‑идентификаторы — по флагу).
- Учётные данные: логины, ключи API, токены Bearer, cookie, URL с токенами.
- Имена/ФИО (через NER/словари) — мягкое маскирование (первая буква + маска).
- Telegram‑данные: usernames/@handle — маскирование частичное.
- Свободный текст: эвристики для дат рождения, паспортных серий (по флагу региональности).

---

### 4. Компоненты и контракты (Pydantic)

```python
from typing import Any, Dict, List, Optional, Literal
from pydantic import BaseModel

class DetectedEntity(BaseModel):
    type: Literal[
        "EMAIL","PHONE","ADDRESS","NAME","PAN","IBAN","TAX_ID",
        "API_KEY","BEARER","COOKIE","URL_TOKEN","TG_HANDLE","DOB","PASSPORT"
    ]
    value_excerpt: str
    start: int
    end: int

class SanitizationResult(BaseModel):
    masked_text: str
    entities: List[DetectedEntity]
    hash_map: Dict[str, str] = {}  # raw->hash(token)

```

Политика/конфиг:

```yaml
# backend/config/privacy_policy.yaml
privacy:
  enabled: true
  mask_char: "*"
  hash_salt_env: "PRIVACY_HASH_SALT"
  mask_rules:
    EMAIL: "full"    # full|partial|hash
    PHONE: "partial"
    NAME:  "partial"
    PAN:   "hash"
    API_KEY: "hash"
  allowlist_domains: ["example.com"]
  log_max_excerpt: 200

```

---

### 5. Алгоритмы детекта (MVP)

- Регулярные выражения:
  - EMAIL: `\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b`
  - PHONE (RU/INTL): `(?:(?:\+?\d{1,3}[\s-]?)?(?:\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{2}[\s-]?\d{2})`
  - PAN: `\b(?:\d[ -]*?){13,19}\b` + Luhn
  - BEARER: `Bearer\s+[A-Za-z0-9\-._~+/]+=*`
  - API_KEY: префиксы `sk-`, `AKIA`, `ghp_`, и т.п.
  - URL с токенами: параметры `token=`, `key=`, `sig=`.
- NER (опц., флаг):
  - Имена/адреса: spaCy ru_core_news_sm/en_core_web_sm (если доступно); иначе словарно‑правила.
- Нормализация и постпроцессинг: дедуп по диапазонам, приоритет секретов над PII, тримминг excerpts.

---

### 6. Маскирование/хеширование

- Маскирование: partial (оставить 2–3 символа/домены), full (всё заменитьmask_char), custom для имен (И*** П***).
- Хеширование: SHA‑256(salt + raw) → hex(12) для tokenization/линковки событий без хранения исходника.
- Правила применяются по `mask_rules`; allowlist доменов — email может не маскироваться для доверенных доменов (по флагу).

---

### 7. Точки применения

1) Вход API: sanitize `input_text` и вложения; в `meta` запросов/аудита хранить уже masked/hashed.
2) Prompt build: удалить URL‑токены/ключи; не включать PII в `[PLANNER_FEEDBACK]`/контекст.
3) Логи/Аудит/Trace: excerpts → усечь до `log_max_excerpt`, применить маскирование; в TraceViewer — включить финальный санитайз.
4) Provenance (если включён): хранить только hash и короткие описания; выключить excerpts флагом.

---

### 8. Настройки/флаги

- `privacy.enabled=true`
- `privacy.mask_inputs=true`
- `privacy.mask_logs=true`
- `privacy.mask_outputs=true`
- `privacy.excerpts=true`
- `privacy.hash_salt_env=PRIVACY_HASH_SALT`
- `privacy.log_max_excerpt=200`

ENV: `PRIVACY_HASH_SALT`, `SOUL_PRIVACY_ENABLED`.

---

### 9. Наблюдаемость и аудит

- События:
  - `privacy_input_sanitized` {entities_count, types}
  - `privacy_log_masked` {excerpt_len}
  - `privacy_violation_blocked` {type}
- Метрики: `privacy.entities_per_req`, `privacy.ms_sanitize`, `privacy.mask_rate`.

---

### 10. Acceptance

- При включённой приватности PII/секреты не попадают в логи, аудит и экспорт трасс.
- В промпт не включаются ключи/токены/URL‑секреты; `[PLANNER_FEEDBACK]` очищен от PII.
- Латентность санитайзера p95 ≤ 10 мс; overhead всего пайплайна незначителен.

---

### 11. Траблшутинг

- Ложные срабатывания по именам — отключить NER, оставить regex/словари; добавить allowlist слов.
- Прорывы токенов в логи — усилить правила URL/BEARER, проверять экспорт из TraceViewer.
- Снижение объяснимости — увеличить `log_max_excerpt`, включить частичное маскирование вместо full.

---

### 12. Stage‑2 (опционально)

- Data Retention: срок хранения логов/аудита/трасс (настройки в днях) с авто‑очисткой.
- Права субъектов (DSAR): выгрузка/удаление по user_id (сквозная маскировка, токенизация).
- DLP‑модуль: ML‑классификатор секретов/PII с обучение по инцидентам.
- Шифрование: KMS для секретов; поля с PII в БД — encryption‑at‑rest (миграции по плану).

---

### 13. Реализация (быстро, ≤ 1 день)

1) Создать `privacy_sanitizer.py` (regex+опц. NER), конфиг `privacy_policy.yaml`.
2) Вставить вызовы в: API вход, сборку промпта, аудит, TraceViewer/Provenance экспорт.
3) Добавить события/метрики; флаги в `soul_settings_service.py`.
4) Прогнать red‑team/конфиденциальные кейсы; зафиксировать отчёт.

---

### 14. Ссылки на проектные файлы/документы

- Промпт и NEGATIVE: `backend/docs/SOUL_PROMPT_BUILDING.md`
- Ядро: `backend/app/services/soul_core_manager.py`
- Guard: `Soul/TZ_Soul_Security_v1_0.md`
- Трасс‑вьювер: `Soul/TZ_Soul_TraceViewer_v1_0.md`
- Provenance: `Soul/TZ_Soul_Provenance_v1_0.md`


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
