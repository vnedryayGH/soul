# P40 — ТЗ: Repo Cleanup Manager (v1.0)

## Цель

Управляемая очистка репозитория от временных/лог‑файлов и кэшей с возможностью dry‑run согласования, интеграцией с Hyperloop/DB/LLM, GUI и headless режимами. Проектные папки не удаляются; регрессии запрещены.

## Требования

- Область: все каталоги репозитория, кроме `Arh` и служебных `venv`, `site-packages`, `Archive`, `backups`, `out`, `out_pr_bundle`, `tmp_artifacts`, `Server-TMP`, `tmp_rsbus`.
- Удаление: директории `__pycache__`, `.pytest_cache`, `.mypy_cache`, `.ruff_cache`; файлы `*.pyc|*.pyo|*.pyd|*.tmp|*.temp|.DS_Store|Thumbs.db|*.log|*.log.*|*.cache`.
- Перемещение в архив: `*.dump|*.tgz|*.tar|*.tar.gz|*.zip|*.7z|grafana.db|backend_deploy*.tgz|*.zip|dist.zip|tmp_*|*.old|*.bak` → `Archive/CLEANUP_<ts>/`.
- Dry‑run: формирует JSON‑манифест для согласования (без изменений в репозитории).
- Интеграция с DB/Hyperloop: чтение настроек `cleanup.*`, проверки preflight/planning.enforce/health/db/check, запуск LLM‑сервисов.
- Логи и трассировка: сохранение логов GUI/headless для дальнейшего анализа LLM‑агентом.

## Реализация

- PowerShell `scripts/cleanup_repo.ps1`:
  - Прогресс, лимиты (`ReportEveryN`, `MaxSeconds`, `StopAfter`), `-OutputPath` для сводки.
  - Исключение `Arh` по умолчанию в `ExcludeTopLevel`.
- Python GUI `scripts/cleanup_gui.py`:
  - Вкладка Очистка (Dry‑Run/Execute/Stop, Open/Copy Summary), вкладка Hyperloop/DB/LLM (Preflight, Claim, DB Check, Health, INSPECTOR, TRACE, DSL).
  - Headless: PowerShell обёртка (`--headless`) и чистый Python‑сканер (`--headless --python-scan`) без зависаний.
- BAT‑лаунчер: `start_cleanup_gui.bat` в корне.

## Управление (CLI/DB/Соул)

- Headless (чистый Python):
  - `python scripts/cleanup_gui.py --headless --python-scan --exclude Arh --output tmp_cleanup_summary.json`
- Headless (через PowerShell):
  - `python scripts/cleanup_gui.py --headless --dry-run --from-db --output tmp_cleanup_summary.json`
- Ключи настроек из DB (Hyperloop): `cleanup.include_top_level`, `cleanup.exclude_top_level`, `cleanup.preview_top`, `cleanup.report_every_n`, `cleanup.max_seconds`, `cleanup.stop_after`, `cleanup.no_archive`.

## Файл для согласования

- JSON‑сводка: `tmp_cleanup_summary.json` (корень проекта). Доступна также кнопкой «Open Summary JSON» в GUI.

## Логи и диагностика

- GUI: `logs/cleanup_gui_YYYYmmdd_HHMMSS.log`
- Headless PowerShell: `logs/cleanup_headless_YYYYmmdd_HHMMSS.log`
- Dry‑run JSON: `tmp_cleanup_summary.json`

## Принятие

- Smoke dry‑run по всем каталогам, кроме `Arh`, формирует валидный JSON‑манифест.
- Проверки через Hyperloop выполняются из GUI/CLI.
- При EXECUTE создаётся `Archive/CLEANUP_<ts>/` с `manifest.json`.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
