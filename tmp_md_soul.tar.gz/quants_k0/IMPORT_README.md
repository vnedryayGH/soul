# Импорт базовых квантов (K0) в SoulPulse

## Предпосылки

- Бекенд запущен: `http://127.0.0.1:8000`
- Роль: Architect (доступ к админ‑эндпоинтам)
- Переменные окружения при локальном тесте (опционально):
  - `TEST_NO_DB=0` (для реального импорта в БД)
  - `DISABLE_EXTERNAL_LLM=1` (чтобы не делать внешние LLM‑вызовы во время импорта)

## Очистка тестовых данных (при необходимости)

Перед импортом K0 рекомендуется удалить тестовые/мусорные данные:
1) Проверка текущих счётчиков:

   - GET `/api/admin/soul/cleanup/check`

2) Очистка квантов/целей/связей/аудита:

   - POST `/api/admin/soul/cleanup`

Примечание: эндпоинты безопасно работают даже если таблиц нет или AGE недоступен.

## Импорт K0

- Эндпоинт: POST `/api/admin/soul/import/k0`
- Тело запроса (JSON):
  - `base_path`: путь к каталогу с K0 JSON (по умолчанию `Soul/quants_k0`)
  - `persist_desired_actions`: `true|false` — сохранять ли desired_action в таблицу `quant_desired_actions`

Пример тела запроса:

```json
{
  "base_path": "Soul/quants_k0",
  "persist_desired_actions": true
}

```

Что делает импорт:

- Читает все `*.json` в `base_path`
- Для каждого файла:
  - создаёт `Message` (UUID используется как `quant.id`)
  - вставляет запись в `quants`
  - при `persist_desired_actions=true` добавляет записи в `quant_desired_actions`
  - создаёт связи в Apache AGE: `(:User {tg_id})-[:CREATED]->(q:Quant)` и первичные `RELATED`

## Проверка после импорта

- GET `/api/admin/soul/graph/recent_quants?limit=10`
- GET `/api/admin/soul/graph/hubs?min_strength=0.2&limit=5`
- GET `/api/admin/soul/graph/strong_edges?min_strength=0.3&limit=10`

## PowerShell‑скрипт для быстрой операции

См. `Soul/quants_k0/import_k0.ps1` (очистка → импорт → проверки).

## Замечания

- В режиме `TEST_NO_DB=1` импорт будет нерабочим (БД не используется). Для реальной загрузки выключите тест‑режим.
- Если отсутствуют таблицы `quants`, `quant_desired_actions` и/или расширение AGE, сначала примените миграции/DDL проекта.
