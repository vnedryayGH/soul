<!-- markdownlint-disable MD022 MD032 MD012 MD041 -->

# P34 — ТЗ: Внешний чат‑прокси и мобильная интеграция

## Индекс взаимных ссылок (P01–P37)

- P20 TelegramBots Platform — архитектура канала.
- P21 — health точек прокси.
- P33 — Mini Chat канал/мобильная интеграция.
- P36 — команды инспекции/трасс через DSL.

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — инвентари.
- `tmp_p_series_plan.json` — план P‑серии.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр.
- `Soul/P20_TZ_Telegram_Bot_Orchestrator_and_E2E_Dataflow_v1_1.md`, `Soul/P21_TZ_P95_Observability_and_Regulation_v1_0.md`, `Soul/P22_TZ_Soul_API_Alignment_v1_0.md`, `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`, `Soul/P36_TZ_Hyperloop_DSL_v1_1.md` — ключевые интеграции.

Версия: v1.0 (draft)
Статус: Миграция `docs/SOULPULSE_CHAT_TECH_SPEC_v1_0.md` без регресса объёма/смысла

## 0) Цели

- Безопасный серверный прокси для LLM провайдера (DeepSeek), закрытый аутентификацией и квотами.
- Мобильная интеграция (Android) с корректной конфигурацией сред, таймаутами и логированием.

## 1) Архитектура

- Клиент (Android): ChatFragment/VM/Repo → DeepSeekApiService; OkHttp/Retrofit; EncryptedSharedPreferences.
- Сервер (Ktor): `/api/ai/deepseek/chat/completions` → `https://api.deepseek.com/v1/chat/completions`.
- Инфраструктура: Nginx (TLS/HTTP2, SPA), домен/HTTPS, переменные окружения (DEEPSEEK_API_KEY).

## 2) Конфигурация

- BASE_URL: staging/prod; прокси путь: `api/ai/deepseek/`.
- Таймауты: клиент 30/120/30s; сервер 15/120/120s; ретраи: 1–2 (backoff).
- Ключ хранится на сервере; клиент не содержит секретов.

## 3) Контракты

- POST `/api/ai/deepseek/chat/completions` — тело/ответ в формате DeepSeek; коды 200/400/401/429/5xx.
- Рекомендации: добавить `stream=true` (SSE/WebSocket) как опцию.

## 4) Безопасность (обязательные исправления)

- JWT: RS256/ES256, r/o ключи; issuer — домен HTTPS; обязательные claims (`iat,nbf,jti`), verify() вместо decode().
- Прокси: требовать JWT, rate limit per user/IP, ограничение размера тела, маскирование ошибок.
- Клиент: отключить BODY/Authorization‑логи в release; хранить токены только в `EncryptedSharedPreferences`.
- Nginx: HSTS и security headers.

## 5) Тестирование

- Юнит (клиент): успешные/ошибки/таймауты; инструментальные: UI поведение; интеграционные: Postman/cURL; DAST: ZAP baseline.
- Примеры cURL приложить.

## 6) Производительность

- Таргеты: стабильные 200 на прокси; ограниченная доля 5xx; поддержка ретраев с backoff.

## 7) Миграция/совместимость

- Этап 1: безопасность JWT; Этап 2: прокси (JWT/квоты/лимиты); Этап 3: клиент (логи/хранилище токенов); Этап 4: расширения (addons/streaming).

## 8) Acceptance

- Прокси закрыт JWT; квоты включены; клиент без чувствительных логов; домен HTTPS; тесты пройдены.

## 9) Источники

- Консолидация: `docs/SOULPULSE_CHAT_TECH_SPEC_v1_0.md`.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
