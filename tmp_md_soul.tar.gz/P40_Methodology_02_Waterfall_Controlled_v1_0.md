M02 — Waterfall Controlled (v1.0)

Цель: строго контролируемая каскадная поставка с управлением артефактами, вехами и рисками.

Инварианты (P-серия): P27 Delivery Guard; P28 Routing; P29 Two-Keys; P30 Processor; P36 Hyperloop.

Процесс (фазы): Initiation → Requirements → Design → Implementation → Verification → Deployment.

Алгоритмы/метрики: CPM/EVM; Defect burn-down; Gate SLA (p95, err_rate).

Роли: Архитектор, PM, QA Lead, Release Manager.

Интеграции (DSL): PLAN.TASK.ADD/DEPEND; METHODOLOGY.SET; QUANT.LINK.AUTO; INSPECTOR.RUN_ALL.

Acceptance: все флаги/ключи в БД; зелёные инспекторы; панели Grafana обновлены.



## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
