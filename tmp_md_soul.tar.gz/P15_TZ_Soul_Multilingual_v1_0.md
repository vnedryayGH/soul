---

## Индекс взаимных ссылок (P01–P37)

- P03 RouterContext — языковые параметры в истории.
- P14 MultiProviderRouting — выбор моделей по языку.
- P23 UI Spec — i18n Mini App.
- P33 Personification — язык профиля/ответов; парсинг дат по локали.

### ТЗ Soul v1.0 — Многоязычие и выравнивание памяти (Language Detection, Normalization, Memory Alignment)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: ЧАСТИЧНО ВЫПОЛНЕНО (MVP‑1); отложено: нормализация промптов

---

### 0. Executive summary

- Цель: обеспечить единый семантический слой при вводе/памяти на RU/EN/… так, чтобы ретривал 30/70 и роутер работали стабильно вне зависимости от языка запроса и исторических квантов.
- Интеграция (сделано в MVP‑1): лёгкий сервис `language_service.py` с детектором языка; прокидка `locale` в `ROUTER_CONTEXT`; выбор маршрута модели с учётом языка (openai для EN); подготовлен `translation_service.py`.
- Отложено (MVP‑2): нормализатор токенов/лемм, кросс‑языковые теги, расширение ретрива по canonical/synonyms.
- Результат: язык кванта/ввода определяется на лету, ключевые токены/теги нормализуются к каноническим формам (EN‑леммы), ретривал использует гибрид BM25+синонимы с переводом запросов.

---

---

### 1. Архитектура и точки интеграции (кратко)

- `language_service.py`: detect (сделано) → normalize/lemmatize/canonicalize/expand_synonyms (отложено)
- `soul_context.py`: использовать canonical/expanded terms в запросах BM25/тегах
- `soul_core_manager.py`: держать `input_lang` и формировать `[LANG_POLICY]`

---

### 2. Метрики, SLO, алерты

- Метрики:
  - `lang.detect.rate_by_lang`
  - `lang.detect.switch_rate`
  - `lang.query_expanded_terms`
  - `retrieval.hit_rate_xlang`
- SLO: `lang.service.p95_ms ≤ 20ms`, `hit_rate_xlang ≥ baseline +10%`
- Алерты: падение `hit_rate_xlang > 5%/сутки`; `p95_ms > 40ms` (10мин)

---

### 3. Тест‑план

- Unit: детект/лемматизация/нормализация; граничные случаи `min_chars`
- Integration: рост hit‑rate на RU↔EN наборах; отсутствие регрессов JSON
- Perf: `p95_ms` ≤ 20ms при 100 RPS (DEV)

---

### 4. Rollout

- DEV: включить `lang.enabled=true`, собрать baseline
- STAGE: включить `expand_synonyms`, наблюдать метрики
- PROD: постепенный rollout (25%→100%), алерты по SLO

---

### 1.1 Полная архитектура и интеграции

- Новый сервис `backend/app/services/language_service.py` выполняет: detect → normalize → lemmatize → canonicalize → expand_synonyms.
- Встраивание в `soul_context.py`: расширение поискового запроса по каноническим терминам и синонимам; нормализация тегов при сравнении.
- Встраивание в `soul_core_manager.py`: вычисление `input_lang` и прокладка его в `[LANG_POLICY]`; временное обогащение тегов контекста (in‑memory).
- Данные синонимов/канонизации: `backend/config/lang_synonyms.json`.

---

### 1.2 Файлы и изменения (MVP без миграций)

- Новые:
  - `backend/app/services/language_service.py`
  - `backend/config/lang_synonyms.json`
- Изменить:
  - `backend/app/services/soul_context.py` — использовать canonical/expanded terms в BM25/тегах
  - `backend/app/services/soul_core_manager.py` — прокинуть `input_lang`, собрать временные теги
  - `backend/app/services/soul_settings_service.py` — флаги `lang.*`

---

### A. LanguageService (MVP)

Интерфейс:

```python
def detect_lang(text: str) -> str: ...              # "ru"|"en"|...
def normalize_tokens(text: str, lang: str) -> list[str]: ...
def lemmatize(tokens: list[str], lang: str) -> list[str]: ...
def to_canonical_terms(tokens: list[str], lang: str) -> list[str]: ...
def expand_synonyms(canonical_terms: list[str]) -> set[str]: ...

```

Поведение:

- Для ru — предпочтительно pymorphy2; для en — лёгкий стеммер. На коротких строках (< `lang.detect.min_chars`) fallback на `lang.default`.
- Канонизация в EN‑леммы/универсальные ключи, затем расширение через двунаправленный словарь.

---

### B. Выравнивание памяти при ретривале (30/70)

Алгоритм:
1) Определить `input_lang` → `canonical_terms` → `expanded_terms`.
2) Текстовый поиск (BM25): добавлять исходные слова + `expanded_terms`.
3) Матч тегов: сравнивать по `to_canonical_terms`.
4) Повышать вес совпадений по каноническим терминам в ранжировании 30/70.

Без записи в БД, все преобразования — в памяти.

---

### C. Обогащение тегов в рантайме

- Перед сборкой `[ROUTER_CONTEXT]` расширять временные теги контекста по `canonical_terms` (in‑memory), без изменения сохранённых квантов в MVP.

---

### Контракты (Pydantic)

```python
from typing import List, Set
from pydantic import BaseModel

class LangDetectResult(BaseModel):
    lang: str
    confidence: float

class CanonicalQuery(BaseModel):
    input_lang: str
    canonical_terms: List[str]
    expanded_terms: Set[str]

```

---

### Настройки/флаги

- `lang.enabled=true`
- `lang.default="ru"`
- `lang.supported=["ru","en"]`
- `lang.synonyms.max_expand=5`
- `lang.detect.min_chars=8`

ENV (опц.): `SOUL_LANG_ENABLED`, `SOUL_LANG_SUPPORTED`.

---

### Acceptance (добавление)

- На RU↔EN golden‑наборах рост `retrieval.hit_rate_xlang` ≥ +10% vs baseline без падения JSON‑валидности.
- Общий SLO пайплайна сохранён (≤13с суммарно).
- Overhead LanguageService ≤ 5% времени запроса.

---

### Stage‑2 (опционально)

- Материализованный слой «канонических тегов» и/или таблица `quant_canonical_tags`.
- Векторный кросс‑языковой индекс (LaBSE/laser) для ретривала.
- Фоновое авто‑обогащение часто используемых квантов каноническими тегами.

---

### Траблшутинг

### Отложенная задача: Нормализация промптов (Prompt Normalization)

- Что: выровнять системные/модульные промпты под мультиязычность (консистентные ключи, отсутствие англ. артефактов в RU, единая секция [LANG_POLICY], запрет роли‑свитчинга на всех языках, унификация инструкций JSON STRICT).
- Зачем: снизить вариативность вывода и ошибки JSON при смене языка; стабилизировать DesiredAction/теги; улучшить hit‑rate ретрива и self‑consistency на EN.
- Риски:
  - Регресс формата JSON при жёстких переписках системного текста (минимизируем итеративно, feature‑flagged).
  - Изменение тона/личности (смягчаем через NEGATIVE и smoke‑набор примеров).
  - Временный спад качества на RU при перекосе на EN‑конструкции (контроль через golden‑set и A/B).

- Ошибки детекта на коротких строках → поднимать `min_chars`, fallback на `lang.default`.
- Шум от синонимов → ограничить `lang.synonyms.max_expand`, уточнить словарь.
- Просадка производительности → кэшировать `canonical_terms` для последних запросов.

---

### Ссылки

- Контекст 30/70: `backend/app/services/soul_context.py`
- Ядро: `backend/app/services/soul_core_manager.py`
- Настройки: `backend/app/services/soul_settings_service.py`
- Prompt: `backend/docs/SOUL_PROMPT_BUILDING.md` ([LANG_POLICY])


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
