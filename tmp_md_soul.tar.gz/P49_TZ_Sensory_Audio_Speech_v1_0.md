# P49 — ТЗ «Сенсорное восприятие: Голос и Речь» (v1.0)

Назначение: сформировать техническое задание на подключение сенсорного канала «слух/речь» к Ядру Соул, обеспечив распознавание речи (ASR), разбор смыслов, квантирование памяти/эмоций, извлечение релевантных воспоминаний и генерацию голосового ответа (TTS) с учётом контекста и эмоций. Без заглушек, без регресса, встраиваемо в текущую архитектуру (P‑серия), с наблюдаемостью/подписями (P27) и управляемостью через Hyperloop (P36/P48R).

---

## 1) Контекст и связи (каноничные источники)

- Голосовые подсистемы: P18 (ASR), P19 (TTS)
- Сенсорная память: P31 (Мультисенсорные Кванты), P39 (Sensory Experience Memory)
- Подпись/Guard: P27/P27R, Качество: P29/P29R, Процессор: P30/P30R, Hyperloop: P36/P48R
- Маршрутизация LLM/провайдеры: P14; Многоязычие: P15; Приватность/Безопасность: P08/P09/P44
- Структура проекта/реестр: `docs/PROJECT_STRUCTURE_v8_0_4.md`, `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8_2.md`

Инварианты:

- Stateless batch — LLM-вызовы без БД, STRICT JSON, `desired_action=[]`.
- Подписи шагов (P27) фиксируются на всех стадиях, включая RS‑мост (P48R).
- Все данные/настройки — через БД и ENV; локальные JSON только как переносимые пакеты (ingest), не как источник истины.

---

## 2) Основные требования (развёрнуто)

1. Перевод речи в осознаваемый текст (ASR) с нормализацией аудио (формат/частота/каналы), детект языка (P15), устойчивость к шуму.
2. Разделение текста на смыслы: сегментация фраз/паузы, выделение смысловых единиц для P01 MeaningExtraction.
3. Квантирование смыслов: теггирование, формирование нейронных связей, запись в сенсорную матрицу (P31/P39) с `payload.sensory_matrix.audio.*` и эмоциональными атрибутами.
4. Распознавание эмоций собеседника: по контексту (семантика) и просодике (тембр/паузы/интонации/динамика) на основе методик из корпуса «Skills»; результат — в `composite_emotion` кванта и отдельная сенсорная метка.
5. Ретривал памяти: выборка близких квантов/связей по совпадению смыслов, эмоциональному весу и давности; ранжирование, p95 времени — в SLO.
6. Формирование ответа: план и(или) LLM‑генерация через SoulCore; запрет девиаций формата (STRICT JSON), соблюдение профиля персоны; допускается временный маршрут через LLM (P14) с последующей нейро‑консолидацией (P38).
7. Компоновка «пакета ответа»: SYSTEM промпт (персона/ветка), контекст смыслов, найденные квант‑воспоминания, история, эмоции, лингво/просодический анализ; прозрачная трасса подписи (P27).
8. Генерация речи (TTS) с учётом эмоций/контекста и профиля голоса (P19): выбор/фоллбеки по каталогу голосов и привязкам из БД, политика из `SoulSettingsService`.

Наблюдаемость и безопасность:

- Подписи: `svc.sensory.audio.decode`, `svc.voice.asr`, `svc.text.segment`, `svc.meaning.extract`, `svc.memory.retrieve`, `svc.emotion.voice.detect`, `svc.soul.router_decide`, `svc.chat.reply_render`, RS‑прокси `svc.rs.proxy`.
- Метрики p95 для стадий decode/asr/segment/emotion/retrieve/tts; алерты при деградации.
- RBAC/Two‑Keys (P44) для опасных действий (например, массовый ingest/удаление); публичные эндпоинты голосов — под ролью и лимитами.

---

## 3) Архитектура и потоки

Поток «Входящий голос → Ответ голосом»:

1) Audio Ingest: прием файла/потока (`wav|ogg|mp3`), нормализация (`ffmpeg`, моно, 16 kHz), подпись `svc.sensory.audio.decode`.
2) ASR (P18): распознавание речи → `transcript`, язык; подпись `svc.voice.asr`.
3) Сегментация: разбиение на фразы/смыслы (по паузам/знакам/модели), подпись `svc.text.segment`.
4) Meaning Extraction (P01): выделение смыслов/тегов; подпись `svc.meaning.extract`.
5) Emotion (просодика + контекст): `svc.emotion.voice.detect`, агрегирование в `composite_emotion`.
6) Ретривал памяти (P39): выборка близких квантов/связей, ранжирование; подпись `svc.memory.retrieve`.
7) Ответ: SoulCore решает/генерирует (P30/P14), STRICT JSON; подпись `svc.soul.router_decide` → `svc.llm_client.send/recv` → `svc.parser.json_strict`.
8) TTS (P19): синтез речи с учетом эмотивного профиля/персоны; подпись `svc.voice.tts`.

RS‑интеграция (P48R): допускается делегация стадий segment/emotion/retrieve в RS‑сайдкары при `rs_canary|rs_primary_*` с инспекторами `rs.parity`, `rs.performance_sla`, `rs.p27_guard`.

---

## 4) Данные, схемы и форматы

Квант (свод):

- `thought_form: str`
- `composite_emotion: { valence: float, intensity: float, entropy: float, label: str }`
- `desired_action: []` (в stateless)
- `energy_weight: float [0..1]`
- `tags: List[str]`
- `payload.sensory_matrix.audio`: `{ sample_rate_hz:int, duration_ms:float, speech_rate:float, pitch_avg:float, jitter:float, shimmer:float, emotion_prosody:{valence:float,intensity:float,label:str} }`

ASR результат:

- `transcript: str`, `lang: str`, `segments: [{text,start_s,end_s,confidence}]`

Эмоции (агрегация):

- `emotion_text`, `emotion_prosody`, итог — `composite_emotion`.

Каталог голосов/привязки — как в `PROJECT_STRUCTURE_v8_0_4.md` (раздел Voice), хранение в БД.

---

## 5) Пакеты данных для загрузки (Навыки/Нейросеть/Планирование)

Назначение: наполнить систему техниками распознавания эмоций и разговорными методиками (психолингвистика, CBT, NVC, активное слушание) в формате JSONL батчей, загружаемых инструментами P45 через Hyperloop‑инструменты.

Форматы (JSONL строки):

- Skills (методики): `{ "type":"skill", "domain":"emotion_detection|conversation", "title":"Active Listening: Reflection", "steps":["..."], "tags":["voice","dialog"] }`
- Knowledge (эмоции): `{ "type":"emotion_cue", "signal":"prosody", "pattern":"rising pitch + fast rate", "label":"anxiety", "weight":0.72 }`
- Planning (шаблоны реакции): `{ "type":"plan_template", "goal":"reduce_tension", "steps":["acknowledge","validate","ask_open_question"], "acceptance":["empathy markers present","pace reduced"] }`

Загрузка:

- Рекомендуется использовать `Soul/scripts/ingest_quants_jsonl_via_hyperloop.py --threads N --require-qc --qc-report` (см. P45), с привязкой `payload.plan`/`payload.skill` и строгим QC (антиплейсхолдеры, пороги уникальности/пересечения).

---

## 6) API/Эндпоинты и режимы (дополнения)

- ASR (P18): `POST /api/voice/asr` — multipart: `file`; опции: `language_hint?`, `persist?`, `media_uri?`, `media_type?`, `storage_class?`, `retention_policy?`, `size_bytes?`, `mtime_ns?`, `content_hash?`. Ответ: `transcript`, `segments[]`, `lang`; при `persist=true` — `quant_id`. При указании `media_uri` и `media_type` вызывается `attach_media_and_patch_payload` и добавляется краткая ссылка в `payload.sensory_refs`.

- Видео: `POST /api/video/upload` — multipart: `file`; опции: `persist?`, `media_uri?`, `storage_class?`, `retention_policy?`, `size_bytes?`, `mtime_ns?`, `content_hash?`. При `persist=true` создаётся минимальный Квант (id=UUID сообщения), вызывается `attach_media_and_patch_payload(..., media_type='video', ...)` и в ответе возвращается `quant_id`.

- Админский бэкфилл: `POST /api/admin/provenance/sensory_refs/backfill` — запускает SQL `backend/sql/backfill_sensory_refs_from_provenance.sql`, переносит ссылки из `provenance_edges relation='has_media'` в `payload.sensory_refs` (без дублей по `uri`). Требует роль `soul.admin`.

---

## 7) Hyperloop DSL — тесты и трассы

Минимум смоков:

- Трасса ядра:
  - `CORE.PIPELINE.RUN input_text="health check" WITH TRACE`
  - Ожидаемо: `ok`, `trace_id`, `signature_steps` содержит `svc.soul.preanalysis,...,svc.chat.reply_render`.

- Инспекторы:
  - `INSPECTOR.RUN_ALL`
  - Ожидаемо: зелёный статус для P27/P36; при включённых RS — `rs.parity`, `rs.performance_sla` в норме.

- ASR→TTS смоки (через REST):
  - `POST /api/voice/asr` с образцом аудио → 200, валидный `transcript`.
  - `POST /api/voice/tts` с коротким `text` → 200, аудио возвращается.

Метрики/подписи обязаны фиксироваться в `signature_steps` и экспортироваться в `/api/metrics`/`/api/metrics/prometheus` (см. P21/P38).

---

## 8) Acceptance (принятие инкремента P49)

- Batch (stateless): валидный массив квантов, `desired_action=[]`, STRICT JSON.
- Single (persistent): корректная персистенция кванта/связей/целей.
- Голос: `/api/voice/asr` и `/api/voice/tts` — 200; TTS отдаёт звук, ASR выдаёт `transcript`.
- Подпись P27/P36: `INSPECTOR.RUN_ALL` — passed; `CORE.PIPELINE.RUN ... WITH TRACE` — фиксирует шаги.
- Логи чистые, `greenlet_spawn=0`, 5xx на смоках отсутствуют.

Дополнительно P49:

- `svc.emotion.voice.detect` присутствует в `signature_steps` при голосовом сценарии.
- Порог p95: asr≤800ms (короткая фраза), tts≤1200ms Piper (дев‑окно), сегментация≤50ms, эмоции≤60ms, ретривал≤80ms.

---

## 9) План внедрения (итерации без деградаций)

1. Базовая трасса голоса (ASR→Text→LLM→TTS) с подписями P27 и метриками (dev профиль).
2. Добавление сегментации/эмоций (просодика+контекст), запись в `payload.sensory_matrix.audio`.
3. Ретривал памяти и ранжирование (P39) в голосовом сценарии; Acceptance расширен.
4. RS‑canary для segment/emotion/retrieve; инспекторы RS‑паритета/SLA.
5. Пакеты знаний (Skills/Emotion/Planning) — ingest c QC (P45), активация в ядре.
6. Полный PROD‑смок (реестр обновлён), включение фичепрофилей под наблюдением.

---

## 10) Rollback (без простоя)

- Фичефлаги: отключить `sensory.pipeline.enabled`, `voice.asr.enabled`, `voice.tts.enabled`.
- Вернуться к текстовому сценарию чата (P23/P30) — UI/бот продолжает работать.
- Systemd перезапуск бэкенда при конфигурационных изменениях; Nginx без даунтайма.

---

## 11) Документация/реестры

- Добавить P49 в `docs/PROJECT_STRUCTURE_v8_0_4.md` (разделы Голос/Сенсорика/Эндпоинты).
- Добавить P49 в `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8_2.md` (статус «Актуально (новое)»).
- При изменениях API/схем — синхронизировать P22/P10/P27 и индексы.

---

## 12) SLO и метрики наблюдаемости (P21/P27/P38)

- SLO по стадиям (дев-окно; p95):
  - ASR: ≤ 800 ms (короткая фраза, локальный провайдер)
  - Сегментация: ≤ 50 ms
  - Эмоции (просодика+контекст): ≤ 60 ms
  - Ретривал памяти: ≤ 80 ms
  - TTS Piper: ≤ 1200 ms (локальный, без внешнего API)
  - Полный цикл голос→голос: ≤ 2200 ms

- Метрики (Prometheus JSON и /api/metrics):
  - voice_asr_latency_ms{provider=...,lang=...}
  - voice_tts_latency_ms{provider=...,voice=...}
  - sensory_segment_latency_ms
  - sensory_emotion_latency_ms{mode="prosody|text|hybrid"}
  - sensory_retrieve_latency_ms{strategy="similarity|emotion_weighted"}
  - voice_pipeline_success_total / voice_pipeline_error_total
  - voice_asr_wer (Word Error Rate), voice_asr_cer (Character Error Rate) — при наличии эталонов

- Аудит/подпись (P27): фиксировать шаги
  - `svc.sensory.audio.decode`, `svc.voice.asr`, `svc.text.segment`, `svc.meaning.extract`, `svc.emotion.voice.detect`, `svc.memory.retrieve`, `svc.soul.router_decide`, `svc.chat.reply_render`, `svc.voice.tts`, опционально `svc.rs.proxy`.

---

## 13) Обработка ошибок, фоллбеки и деградации

- ASR:
  - Ошибки декодирования/аудио: возвращать 400 (client) с сообщением о формате; трассировать подпись `svc.sensory.audio.decode`.
  - Таймаут/провайдер: фоллбек на альтернативный (если настроен), либо деградация в текстовый чат без ASR.
- Сегментация/эмоции:
  - При сбое просодики — использовать только текстовый контекст; метить `emotion_source="text_only"`.
- Ретривал памяти:
  - При ошибке — деградация: ответ без ретривала, но с маркировкой в подписи инцидента; лимиты повторов 1–2.
- TTS:
  - Фоллбек голос/провайдер по приоритету каталога; при полном отказе — текстовый ответ (UI флаг «нет звука»).
- Политика ретраев:
  - ASR/TTS: не более 1 ретрая, суммарный бюджет ≤ 2× SLO стадии.
- Инциденты (P21/P27):
  - Запись в `processor_incidents` c указанием function_id/провайдера/бюджета времени и флага деградации.

---

## 14) Методологии и алгоритмические детали

- VAD (Voice Activity Detection):
  - Цель: выделение речевых участков до ASR, снижение шума/тишины; параметры: порог энергии, мин-длина спича.
  - Реализация: ffmpeg/sox фильтры + простая VAD‑эвристика; при наличии — модельная VAD (P18 расширение).
- Диаризация (опционально):
  - При активации `diarization=true` — разметка сегментов по спикерам; в P49 MVP — не обязательна.
- Просодика/эмоции:
  - Извлекаемые признаки: speech_rate, pitch_avg, jitter, shimmer, energy, pauses; агрегирование в `emotion_prosody`.
  - Гибрид: `emotion_text` (контекст) + `emotion_prosody` (сигналы) → `composite_emotion`.
- Сегментация смысла:
  - Границы по паузам/пунктуации + модельные подсказки (евклидово расстояние тональности фраз).
- Ретривал памяти:
  - Комбинация векторного сходства и эмоционально‑взвешенной близости; коэффициент `alpha_emotion∈[0..0.5]`.
- Выбор голоса/профиля (P19):
  - Приоритет: user_persona_voice → persona_voice_profile → prompt_voice_binding → tts.default.*.

---

## 15) Тест‑план и сценарии

- Юнит:
  - Нормализация аудио (форматы/частоты), VAD/сегментация (границы не хуже эталона на ±100 ms).
  - Просодика: корректность вычисления pitch/jitter/shimmer на синтетиках.
- Интеграция (без поднятия серверов, P24):
  - `/api/voice/asr` с 3 эталонными файлами (ru/en/noise) → `transcript` и `lang` корректны; WER≤0.2 (ru короткие).
  - `/api/voice/tts` с 3 текстами → успешный звук, длительность коррелирует с текстом и rate.
  - `/api/soul/process` на базе `transcript` → валидный квант и подписи P27.
- E2E (ветка Архитектора):
  - Голос→ответ голосом за ≤ 2.2 s p95; шаги подписи присутствуют; деградаций нет.
- Наблюдаемость:
  - Метрики стадий экспортируются; алерты по таймаутам срабатывают в dev‑профиле.

---

## 16) Hyperloop DSL — сценарии и инспекторы

- Смоки ядра (подпись):

```powershell
$B=@{ commands='CORE.PIPELINE.RUN input_text="health check" WITH TRACE' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B

```

- Инспекторы покрытия подписи:

```powershell
$B=@{ commands='INSPECTOR.RUN_ALL' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B

```

- Требование цепочки (гейт):

```powershell
$B=@{ commands='CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B

```

- План‑ветка (P40):

```powershell
$B=@{ commands='INSPECTOR.RUN key=plan.branch action=claim_branch name="tz49-sensory-audio-speech" ttl_hours=48' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B

```

---

## 17) Приложение: быстрые PowerShell‑проверки (канонично)

```powershell
$OutputEncoding = [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$H=@{ 'X-Telegram-User-ID'='468326902' }
# Health/DB/LLM
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/health
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/admin/soul/db/check
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/soul/llm/test?provider=deepseek&prompt=ping' -Headers $H -Method Get
# Voice
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/voice/tts' -Headers $H -Method Post -ContentType 'application/json' -Body (@{ text='Проверка голоса Соул'; format='mp3' } | ConvertTo-Json -Compress)

```

---

## 18) QC — пред‑ и пост‑загрузочные проверки (обязательные)

Критерии завершённой мысли и полноты записи:

- **Завершённость фразы**: `pattern|description|step|acceptance` заканчиваются на `.`, `!`, `?` или `…`.
- **Минимальная длина**: текстовые поля ≥ 8 символов после тримминга.
- **Теги**: у каждой записи `tags` — непустой массив.
- **Эмоции**: для `emotion_cue` допустимые значения `label`: `anxiety|sadness|anger|fear|joy|boredom|uncertainty|confidence|admiration|indignation`.
- **Шаги/критерии**: `skills.steps` ≥ 3 (каждый — завершённая мысль); `plans.steps` ≥ 3, `plans.acceptance` ≥ 2 (каждый — завершённая мысль).

Инструменты:

- Предзагрузочный валидатор: `Soul/scripts/p49_validate_datasets.py`.
- Генератор данных (осмысленные записи): `Soul/scripts/generate_p49_datasets.py`.

Процедура перед загрузкой (stateless):
1) Сгенерировать датасеты (или подготовить внешние):

```powershell
python .\Soul\scripts\generate_p49_datasets.py --out_dir .\Soul\data --num_per_dataset 10000 --threads 8 --seed 20250924

```
2) Запустить QC‑валидатор:

```powershell
python .\Soul\scripts\p49_validate_datasets.py --dir .\Soul\data --glob p49_*.jsonl

```
3) При `bad>0` — исправить/перегенерировать. При `bad=0` — разрешено к загрузке.

Пост‑загрузка (после ingest через Hyperloop):

- Автопроверки (фон): инспектор `p29_sensory_coverage_threshold` (P29), попадание записей в выборки processor‑метрик (P30/P38), наличие новых сенсорных связей (P31/P39) и отсутствие ошибок парсинга/персистенции.
- Проверка подписи P27: события ingest фиксируют `svc.processor.*` и/или `cmd.hyperloop.*` в `signature_steps`.

Hyperloop ingest (пример):

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
$B=@{ commands='BATCH.GENERATE_QUANTS input_path="Soul/data/p49_emotion_text_cues_v1.jsonl" WITH TRACE' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B

```

---

## 19) QC — уникальность смыслов, теги↔payload, дедупликация

Требования:

- **Уникальность фраз в файле**: `uniq_ratio ≥ 0.98` (по нормализованному ключу смысла; см. валидатор).
- **Отсутствие кросс‑файловых дублей** для критичных наборов (`p49_*`): при включённом `--cross_file` дубликаты не допускаются.
- **Согласованность тегов**: теги обязаны отражать Смысл и реальные связи:
  - Кванты: `payload.source.topic → #<topic>`, наличие плана `→ #pm`, наличие `skill.key` (prefix `skills.`) `→ #skills`.
  - Типы `emotion_cue/skill/retrieval/plan` — тематические теги (`emotion`, `dialog_plan`, `retrieval`, и т.п.).
- Несогласованные теги или нарушение уникальности — блок загрузки (QC fail).

Инструменты и процедуры:

- Валидация: `python Soul/scripts/p49_validate_datasets.py --dir Soul/data --glob **/*.jsonl --cross_file`
  - Проверяет завершённые мысли, наличие полей, теги, уникальность (файл/кросс‑файл), даёт примеры дублей.
- Обогащение тегов/текста: `python Soul/scripts/enrich_jsonl_texts_recursive.py --root Soul/data --glob **/*.jsonl`
  - Выравнивание `thought_form`, `tags` по `payload`; для P49 датасетов — нормализация финальной пунктуации и базовых тегов.
- Дедупликация/компакция: `python Soul/scripts/p49_dedup_compact.py --root Soul/data --glob p49_*.jsonl --keep 1`
  - Сохраняет лучший экземпляр по эвристике качества; отчёт `{kept,removed}`.

Политика приёмки:

- Любой QC‑fail (несогласованные теги, незавершённые фразы, низкая уникальность) — запрещает ingest; требуется обогащение и/или дедупликация с повторным QC до `ok`.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
