# P48 — ТЗ: Зеркалирование действий LLM‑агентов в проектные структуры Ядра Соул

Статус: v1.0 (к внедрению)

## 1) Цель

- Полная интеграция работы LLM‑агентов (Cursor) с внутренними структурами Ядра Соул: фиксация команд/ответов/трасс рассуждений, связка с планом/ветками/навыками/целями, оценка успеха, пользовательские лайки/дизлайки, рождение Квантов и пополнение целей.

## 2) Область

- Ядро: P27 подпись, P30 Процессор, P36 Hyperloop DSL, P40 план, P25 навыки, P45 квант‑ингест, P16/P38 сон/обучение.
- Реализуемый компонент: `backend/app/feature_plugins/llm_mirror.py` + правила в `.cursorrules` + раздел P40/P45.

## 3) Поток данных

1. Пользователь → команда (инициатор): фиксируется контекст задачи/ветки плана.
2. LLM агент → ответ: полностью сохраняется, парсится и раскладывается по полям кванта (`payload.mirror.*`).
3. Трасса рассуждений (reasoning_trace) сохраняется целиком.
4. Запись кванта и линковка: `plan_task|goal|skill` связи создаются идемпотентно.
5. Фидбек: `user_feedback=up|down` и `success=true|false` фиксируются.
6. Сон/обучение: формируются эталонные ветки навыков и рекомендации; новые смыслы → новые кванты и/или цели.

## 4) Контракты

- INSPECTOR: `llm.mirror` (см. модуль) — вход `context`:
  - `owner`, `project_id?`, `plan_task_id?`, `branch?`, `topic?`, `goal_ids?[]`, `skill_keys?[]`,
  - `user_command`, `agent_reply`, `reasoning_trace[]`, `success?`, `user_feedback?`.
- Выход: `{status, quant_id, links:{plan_task, goals[], skills[]}}`.

## 5) DSL (P36)

- Пример:

```text
INSPECTOR.RUN key=llm.mirror params_json={
  "owner": "468326902",
  "plan_task_id": "<UUID>",
  "branch": "P45/ingest/qc",
  "topic": "sec-ngfw",
  "user_command": "Расшири QC для JSONL",
  "agent_reply": "Добавил запрет 'Шаг 1/2/3…'...",
  "reasoning_trace": ["анализ требований","сопоставление","внесение правок"],
  "success": true,
  "user_feedback": "up",
  "skill_keys": ["llm_engineer.planning_systems"]
}

```

## 6) Хранение/связи

- `quants(id, thought_form, payload.jsonb{mirror{...}}, tags[], energy_weight)`
- `quant_links(from_quant → plan_task|goal|skill)` типы `implements|advances|improves`.

## 7) Наблюдаемость

- Шаги `cmd.hyperloop.inspector.run` и последующие `svc.persist.quant`/`QUANT.LINK` отражаются в `signature_steps` (P27).
- Инциденты: `llm_mirror_saved`, `llm_mirror_link_fail` — в `processor_incidents`.

## 8) Сон/Навыки (P16/P38/P25)

- Ночной контур обучает навыки на успешных ветках (success=true, fb=up) → формирует эталонные цепочки для рекомендаций.
- При обнаружении новых смыслов/целей — рождение новых квантов/целей и их линковка.

## 9) Acceptance

- Команда/ответ/трасса отражены в кванте; есть связи к задачам/целям/навыкам; инспекторы зелёные; UI отображает ветки и результат.

## 10) Риски

- Переполнение логов/записей: контролируем длины и поля; эмодзи/PII — санитайзер (P08/P09) при выводе.

## 11) Практика MIRROR: устойчивые вызовы в PowerShell

- Рекомендация: для сложных строк используйте HTTP POST с телом из файла (PowerShell безопасно обрабатывает кавычки/Юникод):

```text
# Сформировать файл тела (tmp_body.json)
'{ "commands": "LLM.MIRROR owner=\"468326902\" branch=\"p40-phase2-dsl-prod-250930\" topic=\"dev\" user_command=\"Itogovy status iteracii\" agent_reply=\"DSL i fasady zadepoleny na PROD; smoki OK; inspectory bez kritichnyh; plan_tasks: P51=5835e82e-b319-4697-bee6-a98f1f7e8c3a,P48=2bc3ab6e-a6ee-45e8-a02e-9593ff8bf1c5; git origin=/var/git/soulpulse.git main\" plan_task_id=\"1c89bf1d-4741-4e83-84f9-0882e1e5752c\"" }' |
  Set-Content -Path tmp_body.json -Encoding UTF8 -NoNewline

# Отправить в Hyperloop API
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -H "Content-Type: application/json" --data-binary "@tmp_body.json" https://mini.soulpulse.art/api/hyperloop/execute

```

- Эквивалент через Hyperloop CLI (предпочтительно):

```text
python .\Soul\scripts\hyperloop_cli.py --http-post https://mini.soulpulse.art/api/hyperloop/execute --post-json-file tmp_body.json

```

- ASCII‑fallback: при проблемах с локалью/Юникод в PowerShell используйте латиницу в `user_command/agent_reply`, затем продублируйте русскую версию отдельной записью MIRROR.

- Инварианты MIRROR:
  - Всегда указывать `owner`, `branch`, `topic`, `plan_task_id`.
  - Для длинных reasoning_trace — использовать `INSPECTOR.RUN key=llm.mirror params_json={...}` (см. раздел DSL) вместо строкового DSL.

## 12) Acceptance MIRROR

- Успешная команда возвращает `quant_id`; квант содержит:
  - `payload.mirror.user_command|agent_reply|reasoning_trace|plan_task_id|branch|topic|owner`.
  - Линки к плану/целям/скиллам (если указаны) с типами `implements|advances|improves`.
- В `INSPECTOR.RUN_ALL` присутствуют шаги `cmd.hyperloop.llm.mirror` и/или `cmd.hyperloop.inspector.run` (при params_json), цепочка подписи полная (P27).
- Для PROD — допускается ASCII‑сообщение MIRROR, если среда искажает Юникод.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
