---

## Индекс взаимных ссылок (P01–P37)

- P21 Health/Monitoring — отчётность по происхождению.
- P27 Signature/Lineage — связанная подпись шагов.
- P30 Processor — события/трассы.
- P33 Personification — Mini Chat: audit без PII.

### ТЗ Soul v1.0 — Причинность и происхождение знаний (Provenance Graph)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: Stage‑2 реализовано (таблица provenance_edges + API; MVP audit‑only включаем по флагу)

---

### 0. Executive summary

- Цель: обеспечить прослеживаемость «почему родился квант» — из каких сигналов/источников он возник, с какой долей вклада. Это критично для аудита, обучения на опыте и объяснимости.
- Интеграция: прозрачный сбор provenance на этапах пайплайна `generate_quant_enhanced` (input → context → router → planner/tools → llm → parse → enrich → save).
- MVP: без миграций — записываем связки в аудит (`soul_provenance_recorded`) и формируем in‑memory summary. Stage‑2: лёгкая таблица `provenance_edges` с дедупом по хешу и API для просмотра.

---

### 1. Архитектура и точки интеграции

- Пайплайн ядра: `backend/app/services/soul_core_manager.py: generate_quant_enhanced` (4 этапа + Planner 2.5 при включении).
- Контекст 30/70: `backend/app/services/soul_context.py` — источник «recent/ranked» сниппетов.
- Аудит: `soul_audit_log` (см. `docs/SOUL_PIPELINE.md`).
- Настройки: `backend/app/services/soul_settings_service.py` — новые `provenance.*`.
- Роутер/инструменты (если включены): источники «router_policy», «planner_tool».

Слои provenance:

- Вход: `input_text` (hash + нормализованный excerpt)
- Контекст: recent/ranked сниппеты (id/score/hash)
- Роутер/модули: активированные политики (ключи/эвристики)
- Planner/Tools: инструмент/аргументы/резюме (hash/excerpt)
- LLM вызов: request/response hash, модель/провайдер
- Парсер/нормализация: `json_strict.normalize_quant` hash
- Атрибуты/энерго‑калибровка: коэффициенты/сигналы
- Goal/связи: активная цель/связанные id

---

### 2. ТЗ‑A. MVP (audit‑only, без БД)

#### A.1 Файлы/изменения

- Новые:
  - `backend/app/services/provenance_service.py` — сбор и публикация событий.
  - `backend/app/services/provenance_contracts.py` — Pydantic модели.
- Изменить:
  - `backend/app/services/soul_core_manager.py` — вызывать `ProvenanceService` на ключевых шагах; включается флагом.
  - `docs/SOUL_PIPELINE.md` — добавить раздел «Provenance flow».
  - (опц.) `backend/app/routers/dispatcher_admin.py` — ручка просмотра краткого provenance по `quant_id` из аудита.

#### A.2 Контракты (сервер)

```python
from typing import Any, Dict, Optional
from pydantic import BaseModel

class ProvEdgeAudit(BaseModel):
    trace_id: str
    quant_id: Optional[str]
    stage: str             # input|context_recent|context_ranked|router|planner|tool|llm|parse|enrich|goal
    source_type: str       # text|quant|tool|goal|model|policy
    source_ref: Dict[str, Any]  # {id/hash/key/excerpt/score}
    weight: float = 1.0
    relation: str = "influenced_by"  # influenced_by|derived_from|uses

```

`ProvenanceService.audit_edge(edge: ProvEdgeAudit)` → пишет событие `soul_provenance_recorded` (meta=edge.dict()).

#### A.3 Алгоритм

- На каждом шаге собрать минимальный пакет меты и хеш:
  - Хеши: SHA‑256 от `normalize(text)`/`canonical_json`.
  - Excerpt: ≤ 200 символов, через санитайзер (удалить PII/модули/URL‑артефакты).
- Вызывать `audit_edge` c `trace_id` общего запроса и `quant_id` после появления id.
- Ограничения: `provenance.max_edges_per_quant=30` — не превышать.

#### A.4 Настройки/флаги

- `provenance.enabled=false`
- `provenance.max_edges_per_quant=30`
- `provenance.capture_levels="basic|extended"` (MVP=basic)

#### A.5 Наблюдаемость/Acceptance

- Метрики: `prov.edges_per_quant`, `prov.ms_overhead` (целевой overhead ≤ 5%).
- Acceptance: при включении флага в аудите возникают события с корректным `trace_id` и непустыми hash/excerpt, пайплайн не замедляется заметно.

---

### 3. ТЗ‑B. Stage‑2 (таблица provenance_edges + API)

#### B.1 Миграция (алембик)

Таблица `provenance_edges`:

```sql
create table if not exists provenance_edges (
  id uuid primary key,
  created_at timestamptz not null default now(),
  trace_id uuid not null,
  quant_id uuid null,
  stage text not null,
  source_type text not null,
  source_id uuid null,
  source_hash text not null,
  source_ref jsonb null,
  relation text not null default 'influenced_by',
  weight numeric null,
  confidence numeric null,
  notes text null
);
create index if not exists idx_prov_quant on provenance_edges(quant_id);
create index if not exists idx_prov_trace on provenance_edges(trace_id);
create unique index if not exists uq_prov_edge on provenance_edges(quant_id, stage, source_type, source_hash);

```

Без жёстких FK для гибкости; ссылки осуществляются через `quant_id`/`source_id` при наличии.

#### B.2 Сервис и API

- `ProvenanceService.record_edges_bulk(edges: List[ProvEdge])` — upsert (ON CONFLICT DO NOTHING) по `uq_prov_edge`.
- `get_edges_for_quant(quant_id)` — выборка упорядоченная по весу/дате.
- Роуты (admin RBAC):
  - `GET /api/admin/provenance/quant/{id}` → `{edges:[...]}`
  - `GET /api/admin/provenance/trace/{trace_id}` → смежные ребра запроса
- Экспорт: `GET /api/admin/provenance/export/openlineage/{trace_id}` — JSON совместимый с OpenLineage (упрощённо).

Примечания реализации (PROD):

- Hyperloop (stateless): минимальные рёбра фиксируются всегда (input/llm.response) с `trace_id`; 

  при наличии `quant_id` (single) он подставляется в рёбра.

- `/api/soul/process` (single): при успешной генерации фиксируются как минимум 2 рёбра (`input:text`, `llm:response`) с `quant_id`.

#### B.3 Интеграция в пайплайн

- В местах, где в MVP шёл аудит, дополнительно накапливать `ProvEdge` и по завершении записи кванта → bulk‑insert.
- Дедуп по хешу; ограничение `max_edges_per_quant` соблюдаем на сервере.

#### B.4 Acceptance

- Для любого нового кванта `GET /api/admin/provenance/quant/{id}` возвращает ≥1 ребро.
- Для свежего trace `GET /api/admin/provenance/trace/{trace_id}` возвращает ≥1 ребро.
- Экспорт OpenLineage валиден JSON и содержит события для `input:text` и `llm:response`.
- Дедуп работает; повторные вызовы не множат записи.
- Проверка проводится для обоих окружений: `https://mini.soulpulse.art` и `http://127.0.0.1:8000`.

---

### 4. Источники/edge‑типы (канонический перечень)

- `input:text` — исходный текст запроса (hash/excerpt).
- `context_recent:quant` — недавние кванты (id/score/snippet/hash).
- `context_ranked:quant` — ранжированные кванты 30/70.
- `router:policy` — активные модули/фильтры/goal_bias (ключи, без сырого текста).
- `planner:plan` — краткая сводка плана (hash).
- `tool:result` — итог инструмента (hash/excerpt, без PII, только `stateless_ok`).
- `llm:request` — хеш промпта/провайдера/модели/параметров.
- `llm:response` — хеш нормализованного JSON.
- `parse:normalize` — хеш результата `normalize_quant`.
- `enrich:calibration` — коэффициенты калибровки `energy_weight`.
- `goal:link` — id активной цели/связи.

---

### 5. Безопасность и приватность

- Санитизация: PII‑masker для excerpts; хранить hash вместо полного текста, где возможно.
- RBAC: доступ к API provenance — только `soul.admin`.
- Ограничение data exfiltration: не сохранять внешние URL/ключи; только хеши/краткие описания.

---

### 6. Производительность

- Цель: overhead ≤ 5% времени запроса.
- Техника: буферизация и batch insert; предрасчёт хешей; усечение/обрезка сериализуемых полей.

---

### 7. Быстрая реализация (≤ 1 день)

1) MVP: добавить `provenance_service.py` и вызовы `audit_edge(...)` на ключевых шагах пайплайна. Флаг `provenance.enabled=false` — по умолчанию.
2) Метрики/аудит: `soul_provenance_recorded` + счётчики.
3) Док: обновить `docs/SOUL_PIPELINE.md` — схема слоёв provenance.
4) (Опц.) Admin‑ручка просмотра audit‑summary по `quant_id`.
5) Stage‑2: алембик для `provenance_edges`, сервис bulk‑insert, admin API, экспорт.

---

### 8. Траблшутинг

- Много событий → поднять `max_edges_per_quant`? Наоборот: снизить до 15–20 и оставить только ключевые слои.
- PII в excerpts → усилить санитайзер, логировать только hash, excerpts выключить флагом `provenance.excerpts=false`.
- Просадка SLO → отключить `tool:result` на этапе планера (самый дорогой), оставить только hash без excerpts.

---

### 9. Флаги/настройки

- `provenance.enabled=true` (PROD)
- `provenance.capture_levels="basic"`
- `provenance.max_edges_per_quant=30`
- `provenance.excerpts=true`

ENV (опц.): `SOUL_PROVENANCE_ENABLED`, `SOUL_PROVENANCE_MAX_EDGES`, `SOUL_PROVENANCE_EXCERPTS`.

---

### 10. Мировая практика (ориентиры)

- OpenTelemetry spans/links — привязка "операций"; мы — лёгкие edge‑ссылки на источники.
- OpenLineage/Marquez — lineage для данных; мы — аналог для LLM‑потока (можно экспортировать в схожий формат).
- LangSmith/W&B Traces — трейсинг LLM; мы добавляем причинность на уровне семантических источников.
- MLflow lineage — связывание артефактов/моделей/параметров; мы фиксируем модель/параметры в `llm:request`.

Принцип: минимально‑достаточная прослеживаемость без утечки данных и без тяжёлой схемы.

---

### 11. Ссылки на проектные файлы/документы

- Пайплайн: `backend/app/services/soul_core_manager.py: generate_quant_enhanced`
- Контекст 30/70: `backend/app/services/soul_context.py`
- Настройки: `backend/app/services/soul_settings_service.py`
- Аудит: `docs/SOUL_PIPELINE.md` (таблица `soul_audit_log`)
- JSON‑нормализация: `backend/app/lib/json_strict.py`

### ТЗ Soul v1.0 — Причинность и происхождение знаний (Provenance Graph)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: К реализации (MVP с audit‑only + опционально БД‑edges)

---

### 0. Executive summary

- Цель: обеспечить прослеживаемость «почему родился квант» — из каких сигналов/источников он возник, с какой долей вклада. Это критично для аудита, обучения на опыте и объяснимости.
- Интеграция: прозрачный сбор provenance на этапах пайплайна `generate_quant_enhanced` (input → context → router → planner/tools → llm → parse → enrich → save).
- MVP: без миграций — записываем связки в аудит (`soul_provenance_recorded`) и формируем in‑memory summary. Stage‑2: лёгкая таблица `provenance_edges` с дедупом по хешу и API для просмотра.

---

[Содержимое соответствует исходному ТЗ `TZ_Soul_Provenance_v1_0.md`]

---

### 12. Метрики, SLO, алерты

- Метрики:
  - `prov.edges_per_quant` — среднее число ребер на квант
  - `prov.ms_overhead` — накладные затраты на сбор provenance
  - `prov.capture_rate` — доля квантов с ≥1 edge
- SLO: `prov.ms_overhead.p95 ≤ 5%` от общего времени запроса; `capture_rate ≥ 90%` (MVP)
- Алерты: `ms_overhead.p95 > 8%` (10 мин), `capture_rate < 80%` (60 мин)

---

### 13. Тест‑план

- Unit: детерминированность хешей; санитизация excerpts (без PII); лимит `max_edges_per_quant`
- Integration: end‑to‑end вызов пайплайна — наличие ключевых stage‑edges; связность `trace_id→quant_id`
- Perf: прогоны 100 запросов — измерение overhead, проверка SLO

---

### 15. Реализация/верификация (2025‑09‑21)

- Подтверждено на PROD:
  - Hyperloop WITH TRACE: рёбра по `trace_id` не пустые; экспорт OpenLineage валиден.
  - `/api/soul/process` (num_candidates=1): создаётся квант; рёбра по `quant_id` не пустые.
- Метрики `/api/metrics` дополнены ключами provenance (edges_count 1h/24h, edges_per_quant avg/p50/p95, ms_overhead p95) — наполняются по мере трафика.
- Ограничения/заметки: при внешних вызовах возможны 502 от Nginx (таймауты/буферизация); локально (127.0.0.1) всё стабильно.

---

### 14. Rollout

- DEV: `provenance.enabled=true`, `capture_levels=basic`, `max_edges_per_quant=15`
- STAGE: наблюдать `ms_overhead`/`capture_rate`; при отклонениях — урезать уровни/edge‑типы
- PROD: включить audit‑only; Stage‑2 таблицу — раскатывать поэтапно (25%→100%)


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
