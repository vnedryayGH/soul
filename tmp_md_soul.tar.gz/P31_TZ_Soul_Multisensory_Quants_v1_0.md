---

## Индекс взаимных ссылок (P01–P37)

- P01 MeaningExtraction — связь смыслов и квантов.
- P35 Processes — рождение/связывание квантов; конвейер Sense→Quant.
- P33 Personification — Mini Chat: N/A.

---

## Приложение A — Схема БД Квантов сознания (Quants) — v1

Цель: автономные таблицы для Квантов сознания, оптимизированные под:

- 30/70_v2 выбор контекста (энергия, связи, ключевые слова)
- связность графа Квантов (directed edges)
- “сон” (затухание, пересчет связей, архивирование)
- аудит инициатив и действий

### Сущности

- quants: основной объект (мыслеформа, эмоция, метрики, JSONB пейлоад, теги)
- quant_desired_actions: действия Кванта (тип, приоритет, статус, автопубликация)
- quant_connections: направленные связи между Квантами (тип, сила, keyword_overlap)
- quant_tags: нормализованные теги
- soul_audit_log: аудит системных событий

### Поля quants (ключевые)

- energy_weight (0..1) — значимость Кванта
- q_factor_snapshot, energy_bucket — снимок состояния для анализа
- thought_form — ядро смысла
- payload JSONB — полный структурированный ответ (строгая схема из промпта)
- tags TEXT[] и нормализованные теги в quant_tags
- decayed_energy, decay_updated_at — поддержка алгоритма “сна”
- priority_cached — кэш приоритета инициатив

### Индексы и производительность

- GIN по payload (jsonb_path_ops) и tags
- btree по energy_weight, created_at, priority_cached
- индексы на графовые таблицы и силу связи (connection_strength, keyword_overlap)
- материализованное представление quant_rank_mv с формулой R = 0.5*energy + 0.3*max_connection_strength + 0.2*keyword_overlap

### 30/70_v2 выборка (пример)

- 30% — последние по created_at
- 70% — топ по quant_rank_mv.rank_score

### Сон (обслуживание)

- пересчет decayed_energy
- усиление/ослабление quant_connections.connection_strength
- архив слабых Квантов (is_archived)

### RBAC и аудит

- роль `soul_app`: SELECT/INSERT на основные таблицы; ограниченный UPDATE; без DELETE
- все ключевые события в `soul_audit_log`

### Миграция

1) Применить `quants_schema_v1.sql`
2) Создать ORM-модели и миграции
3) Настроить сервис “сон” (Celery/Django-Q)
4) Включить индексы и MV refresh по расписанию

### Примеры

- Поиск по тегам: GIN по `tags`, TRGM по `quant_tags.tag`
- Топ контекст: `SELECT id FROM quant_rank_mv ORDER BY rank_score DESC LIMIT :N;`

---

## Приложение B — Методика разбора K0 и подготовки Квантов сознания (K-series)

Цель: получить воспроизводимый конвейер преобразования исходного документа `Soul/K0.md` в набор Квантов (STRICT JSON), индекс логических связей и готовность к пакетному переносу в БД.

### Входные артефакты

- `Soul/K0.md` — исходный документ (контент).
- `Soul/soul_core_prompt_human_fusion_v2_9.json` — операционная спецификация Кванта (STRICT_JSON_QUANT).
- `Soul/tests_soul/jsonschema_quant_v1.json` — валидационная схема результата.

### Выходные артефакты

- Директория `Soul/quants_k0/` с файлами `quant_####.json`.
- Индекс `Soul/quants_k0/index.json` со связями между Квантами.
- Финальный SQL‑пакет импорта (создаётся ОДИН РАЗ после завершения всего объёма).

### Конвенции

- Именование: `quant_0001.json` … монотонно по порядку разбора.
- Теги: каждый Квант содержит тег `#K0` + тематические теги раздела.
- Приоритет цели: goal‑кванты получают поле `priority` в `index.json` (если отсутствует — по умолчанию 0.7 при переносе).
- Детерминированные UUID при импорте: UUID = v5(namespace=url, name=file_name), чтобы один и тот же файл давал один и тот же `id`.

### Пошаговый цикл (для каждого смыслового фрагмента)

1) Выделение фрагмента

- Найти логически цельный блок (заголовок/абзац/маркированный раздел) длиной ≥5 слов.
- Зафиксировать диапазон строк `approx_line_start..approx_line_end`.

2) Анализ по `v2_9`

- Отрефлексировать фрагмент через призму схемы Кванта: `thought_form`, `composite_emotion`, `desired_action`, `energy_weight`, `tags`.
- Учитывать правила из `operational_framework` и `safety_override` (тон, табу на IT‑лексику в пользовательском слое, Law of Three).

3) Создание Кванта (STRICT JSON)

- Поля (минимум):
  - `thought_form`: сжатая выжимка смысла (1–2 предложения).
  - `composite_emotion`: `{valence,intensity,entropy,label}`; оценка эвристическая, согласованная между Квантами одного раздела.
  - `desired_action`: массив объектов поддерживаемых типов: `proposal|request|research|reminder` (+поля по типу). Избегать `note` для БД — переносить заметки в `proposal/body` или теги.
  - `energy_weight`: 0..1 (эвристика: идея/механика базового уровня 0.5–0.7, мета‑сводки 0.55–0.65).
  - `tags`: `#K0` + 3–6 ключевых тегов.
- Мета:
  - `_meta.source = "Soul/K0.md"`;
  - `_meta.source_range = {approx_line_start, approx_line_end}`;
  - `_meta.note` — краткая пометка происхождения.

4) Запись файла `quant_####.json`

- Сохранить в `Soul/quants_k0/`.
- Проверить JSON на валидность и соответствие `jsonschema_quant_v1.json` (в IDE или скриптом).

5) Обновление `index.json`

- Добавить объект:
  - `id`, `file`, `source_range`, `source_excerpt` (краткая строка‑якорь),
  - `connections`: список рёбер: `{type: semantic|causal|episodic|goal_link, to: quant_id, note}`.
  - (опционально) `priority` — для goal‑квантов.
- Связности:
  - semantic: объясняющее/уточняющее отношение,
  - causal: «из этого следует/вытекает»,
  - episodic: образ/пример ↔ обобщение,
  - goal_link: цель/нить/ритуал.
- Сила связи и keyword_overlap вычисляются на этапе импорта (см. ниже).

6) Повтор до конца документа

- Двигаться последовательно по разделам, чтобы исключить пропуски и дубли.
- SQL‑пакет НЕ генерировать до завершения всего объёма.

### Политики наполнения полей

- Эмоции: согласованность в пределах смыслового блока; избегать крайних значений без необходимости.
- Energy: механики/каркас 0.55–0.65; цели/ритуал/нить 0.6–0.7; образы/иллюстрации 0.45–0.55.
- Desired actions:
  - proposal: изменения правил/каркаса/процессов,
  - request: запрос подтверждения/включения ограничителей/настроек,
  - research: калибровка коэффициентов, связь архетипов с метриками,
  - reminder: рутинные практики/чек‑листы.

### Структура `index.json` (минимум)

```text
{
  "version": "1.0",
  "source": {"doc": "Soul/K0.md", "note": "..."},
  "quants": [
    {
      "id": "quant_0001",
      "file": "quant_0001.json",
      "source_range": {"approx_line_start": 26, "approx_line_end": 33},
      "source_excerpt": "Личность ... к трем годам ...",
      "connections": [
        {"type": "semantic", "to": "quant_0002", "note": "..."}
      ],
      "priority": 0.7
    }
  ]
}

```

### Правила переноса в БД (после завершения всего набора)

- Генерация пакета выполняется единоразово скриптом `Soul/scripts/generate_quants_k0_sql.py`:
  - `quants.id` = детерминированный UUID от имени файла (v5),
  - `payload` = полный JSON Кванта,
  - `quant_tags` нормализуются из `tags`,
  - `quant_desired_actions` формируются из массива `desired_action` (тип, priority, autopublish>0.6),
  - `quant_connections` — по `index.json` с авто‑оценкой `connection_strength = 0.5 + 0.5*keyword_overlap`.
- Автопубликация: `priority>0.6` → `autopublish=true`.
- SQL формируется ТОЛЬКО когда весь объём Квантов готов.

### Критерии готовности (DoD)

- Все смысловые разделы K0.md покрыты Квантами.
- Каждый Квант валиден по схеме и содержит `#K0`.
- `index.json` содержит корректные связи и приоритеты целей.
- Финальный SQL‑пакет формируется и проходит smoke‑вставку в dev.

### Реальный алгоритм рождения квантов (обновлено 2025-09-12)

#### Обнаруженные проблемы и исправления

В ходе диагностики системы были выявлены и исправлены критические ошибки в алгоритме генерации квантов:

1) Проблема с возвратом ID квантов

- Причина: `greenlet_spawn` ошибка в `SoulSettingsService` после commit транзакции
- Локация: `backend/app/routers/soul.py:551-556` — создание нового сервиса в async контексте
- Исправление: Замена на прямые SQL запросы для чтения настроек
- Результат: ID квантов теперь корректно возвращаются в API ответах

2) Архитектура сервисов в SoulCoreManager

- Компоненты: 6 основных сервисов для генерации квантов
  - `SoulContextService` — построение контекста из истории (12 сниппетов)
  - `SoulSettingsService` — динамические настройки (отключен для избежания greenlet_spawn)
  - `SoulPromptsService` — управление промптами (`soul_core_system`)
  - `LLMManager` — выбор модели для функции `soul_core` (DeepSeek/Gigachat)
  - `SoulQuantRouterService` — решение о модулях (Flow/Ved/Klee/Chekhov)
  - `SoulAuditService` — логирование событий (отключен в критических местах)

3) Структура промптов для LLM

```text
[CORE]
[ROUTER_CONTEXT] — JSON с активными модулями и фильтрами  
[MODULES] — инструкции подключенных модулей
[OUTPUT_SPEC] — требования к STRICT JSON формату
[NEGATIVE] — запреты и ограничения

```

4) Присваивание ID и транзакции

- ID кванта: создается через `Message` модель с `uuid.uuid4`
- Последовательность:
  1. `Message` → `db.add()` → `await db.flush()` → `created_quant_id = str(message.id)`
  2. Вставка в `quants` с тем же ID
  3. `await db.commit()` — критическая точка
  4. Пост-обработка (цели, связи, AGE граф)
- Ошибка: Исключения после commit приводили к rollback и потере ID

5) Качественные показатели реальных квантов

- Energy weight: 0.85-0.95 для высококачественных квантов
- Valence: 0.8-0.9 для позитивных состояний
- Пакетная генерация: до 20 кандидатов с выбором по максимальному весу
- Рефайн через Gigachat: обогащение неполных квантов при `use_quant_refiner=true`

### Интеграция с K0 методикой

Данная техническая информация дополняет методику разбора K0.md:

- Валидация: Кванты должны соответствовать реальной схеме `SoulCoreManager`
- Поля: Обязательные поля совпадают с API: `thought_form`, `composite_emotion`, `desired_action`, `energy_weight`, `tags`
- Качество: Целевые показатели energy_weight должны быть ≥0.85 для автопубликации
- Связи: Автоматическое создание `quant_connections` при пересечении ≥2 тегов

### Проблемы кодировки

- Диагноз: Проблема в PowerShell, данные в БД корректны (UTF-8)
- Решение: Создан скрипт `test_encoding.ps1` для корректного отображения кириллицы
- Подтверждение: Английский текст отображается правильно, кириллица искажается только в клиенте

### Примечания

- Для удобства навигации в `_meta.note` фиксируется краткая идентификация раздела.
- Для будущих целей возможна таблица `quantum_goals` (см. ТЗ) — goal‑кванты помечаются заранее.
- Критически важно: Избегать создания новых сервисов в async контексте после commit транзакции.

# P31 — ТЗ: Мультисенсорные Кванты (sensory_matrix) и сенсорные связи

Версия: v1.0 (draft)
Статус: Новая P‑спецификация (консолидация уникальных разделов из `docs/TZ_Soul_Core_v2_0.md`)

## 0) Цель

- Расширить модель Кванта сенсорной матрицей (`sensory_matrix`) и ввести сенсорные связи/якоря для более глубокого восприятия и навигации в памяти.

## 1) Модель данных (минимум v1)

- Поле `quants.sensory_matrix jsonb DEFAULT '{}'` (GIN индекс).
- Сенсорные подсекции: `visual{colors[],objects[],scenes[],lighting[],movement[],intensity,clarity,symbolic_weight}`, `auditory{sounds[],tones[],rhythms,harmonics,volume,clarity,emotional_resonance}`, `olfactory{primary_scents[],scent_families[],intensity,memory_trigger,emotional_valence}`, `tactile{textures[],temperature,pressure,movement[],comfort,grounding}`, `intuitive{energy_patterns[],synchronicity,resonance,presence,mystery,connection}`.

DDL (эскиз): см. Приложение А (совместимо с v1 — только `quants.sensory_matrix`).

## 2) Алгоритмы

- calculate_sensory_similarity(q1,q2) → [0..1] (веса типов: visual 0.3, auditory 0.25, olfactory 0.2, tactile 0.15, intuitive 0.1).
- Сенсорные якоря: выбор квантов с высоким `intensity/clarity/resonance` как опор для навигации.

## 3) Интеграция

- SoulCore: `AttributeEnrichmentService.enrich_sensory_matrix()` — лёгкий LLM/эвристика для заполнения `sensory_matrix` по `thought_form` и эмоции.
- Роутер/Контекст: при равной релевантности — учитывать `sensory_similarity` и якоря.
- UI: визуальные/аудиальные теги (цвета/звуки) как бейджи; фильтры.

## 4) Совместимость и этапность

- v1: только `quants.sensory_matrix` + расчёт сходства в приложении. Внешние таблицы активов опциональны (этап v2+).
- Обратная совместимость: отсутствие поля трактуется как `{}`.

## 5) Метрики и тесты

- Метрики: доля квантов с `sensory_matrix` заполненной частично/полностью; impact на coverage/latency.
- Тесты: валидация структуры; расчёт сходства; отсутствие деградаций п95.

## 6) Приложение А: DDL (минимум)

```sql
ALTER TABLE quants ADD COLUMN IF NOT EXISTS sensory_matrix jsonb DEFAULT '{}';
CREATE INDEX IF NOT EXISTS ix_quants_sensory_gin ON quants USING gin (sensory_matrix);

```


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
