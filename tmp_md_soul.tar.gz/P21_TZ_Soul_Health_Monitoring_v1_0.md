---

## Индекс взаимных ссылок (P01–P37)
- P20/P34 — каналы и точки health.
- P30 — метрики процессора/очередей.
- P33 — метрики Mini Chat (latency/tokens/errors), алерты webhook.
- P35/36 — трассы команд и процессов.
## P21 — ТЗ: Метрики здоровья Soul и мониторинг (детально)

### 1. Цель
Обеспечить непрерывный контроль «здоровья» ядра Soul и периферийных платформенных модулей (P01–P20), оперативное выявление деградаций и быстрый поиск первопричин (RCA) с минимальным MTTR, без ложной стабилизации и без деградации функциональности.

### 2. Область покрытия
- Ядро квантов: STRICT_JSON_QUANT, Router, модули-политики, Memory 30/70_v2, Sleep v2
- Безопасность: NEGATIVE/санитизация, PII‑Sanitizer, Jailbreak‑shield (P08, P09)
- Память и хранилища: БД квантов и связей, Schema‑Guard (P10)
- Оркестрация и инструменты: Conductor (P05), pc.* / cursor.* (двухключевая политика)
- Платформа Telegram‑ботов (P20): API, очереди, RBAC, Inbox, версии/ETag
- Провайдеры LLM/ASR/TTS, multi‑provider routing (P14)

#### 3.1 Aux LLM (Phi‑4) — метрики и алёрты
- Источники:
  - Счётчики `llm_aux_req_total`, `llm_aux_err_total`, `llm_aux_latency_ms_p95`, `llm_failover_used_total` (см. `backend/app/monitoring.py`, `backend/app/main.py`, `backend/app/services/llm_client.py`).
  - Событийные счётчики `phi_health_fail_total`, `phi_remediation_restart_total` — провалы health‑check и срабатывание автоматической ремедиации.
- Алёрты (пример):
  - `PhiHealthDown` — риск medium/high: подряд ≥ N провалов health в окне T → действия: проверить `llm.aux.url`/сеть/юнит systemd, при необходимости `systemctl status|restart <phi_service>`.
  - `PhiRemediationLoop` — риск high: ≥ K автоперезапусков в окне T → действия: временно выключить `phi.remediation.enabled`, исследовать логи/ресурсы модели.
  - Порогирование: p95 latency > budget, error_rate > max → yellow и рекомендация снизить нагрузку/увеличить таймаут.

#### 3.2 Управление (P30 Processor)
- Периодический health‑check выполняется в `ProcessorScheduler` по ключам `phi.monitor.*`; при повторных сбоях и включённой ремедиации — безопасный `systemctl restart` юнита (`phi.remediation.systemd_service`) с кулдауном.
- Ключи настроек хранятся в `soul_settings` и управляются через панель/DSL `FLAGS.SET`.

### 3. Набор метрик (минимально необходимый)
- Производительность пайплайна квантов:
  - json_validity_ratio (LLM → STRICT_JSON_QUANT), error_rate_pipeline, p50/p95/p99_latency_ms, throughput_qph
  - quant_birth_rate (на 100 сообщений), desired_action_presence_ratio, fallback_rate_router
- Память/ретривал:
  - retrieval_hit_rate@k, avg_connection_strength, memory_compaction_savings, duplicates_merged, ttl_pruned
- Качество рассуждений/стабильность:
  - self_consistency_pass_rate, contradiction_detect_rate, reeval_change_rate
- Безопасность:
  - pii_detect_rate, pii_mask_coverage, jailbreak_block_rate, negative_gate_block_rate
- Маршрутизация и политики:
  - module_distribution (Flow/Klee/Ved/Chekhov), policy_conflict_rate (журнал конфликтов роутера)
- Инструментальность и действия:
  - tool_success_rate, tool_error_rate, dry_run_ratio, two_keys_queue_wait_p95
- Платформа/инфраструктура:
  - api_5xx_rate, api_p95_ms, db_error_rate, migration_drift_detected (Schema‑Guard), provider_failover_rate
- Бот‑Оркестратор (P20):
  - bot.queue_len_outbound, bot.retry_rate, bot.api_4xx/5xx_rate, bot.webhook_5xx, bot.polling_detected
  - bot.voice_share, bot.tts_fail_rate, bot.asr_fail_rate, bot.caption_parse_errors
  - bot.prefix_ai_usage (должно быть 0), bot.persona_prefix_mismatch (должно быть 0)
- Пользовательские/UX:
  - clarification_question_ratio, actionability_ratio, retention_7d, mobile_view_usage

Итоговый health_score ∈ [0,1] агрегируется взвешенно по доменам с порогами: green ≥ 0.95, yellow 0.85–0.95, red < 0.85.

### 4. Источники данных
- Аудит и события: soul_audit_log (включая soul_meta_*), журнал конфликтов роутера
- Логика P‑модулей: P06 Self‑Consistency, P08/P09 безопасность, P16 компакция памяти
- HTTP‑метрики FastAPI, провайдеры LLM/ASR/TTS (успех/ошибка/латентность/стоимость)
- DB и Schema‑Guard: drifts, миграции, индексы, размеры
- CI/Pre‑commit: статические проверки (json_validity, маршруты), health‑снэпшот

### 5. Хранение и модели
- `soul_health_snapshots` (агрегаты):
  - id UUID, period_start timestamptz, period_end timestamptz
  - scope text (system|team|user|bot|service), components text[]
  - metrics jsonb (ключ→значение), health_score double, created_at timestamptz
  - индексы: (period_start), (scope, period_start desc)
- `soul_incidents` (инциденты):
  - id UUID, kind text, severity enum(low|medium|high|critical), status enum(open|mitigated|resolved|false_positive)
  - title, description, affected_components text[], detected_at, resolved_at, snapshot_id UUID nullable, tags text[]
  - owner bigint (Telegram ID), runbook_url text, created_at
  - индексы: (status), (severity, detected_at desc)

### 6. Расчёт и SLA
- Частота агрегации: каждые 1 мин (system), каждые 5 мин (team/bot), также on‑demand
- Пороговые политики:
  - red алерты: json_validity_ratio<0.98, api_5xx_rate>1%, jailbreak_block_rate<99%, self_consistency_pass_rate<90%
  - yellow: p95_latency увеличение >50% от 7‑дневного медианного бенчмарка
- SLO: MTTA ≤ 5 минут, MTTR ≤ 60 минут критических инцидентов

### 7. API и интерфейсы мониторинга
- GET `/api/health/snapshot?scope=system&components=core,security` → HealthSnapshot
- GET `/api/monitoring/metrics/{metric}/history` → таймсерии метрик (использовать существующий роутер, не дублировать)
- GET `/api/health/incidents?status=open&severity=high` → список инцидентов
- POST `/api/health/incidents` → регистрация ручного инцидента/привязка снапшота
- PATCH `/api/health/incidents/{id}` → изменение статуса/owner/labels
- GET `/api/health/dash` → агрегированный дэшборд (для UI)
- GET `/api/bot/orchestrator/health` → состояние очередей/ретраев, webhookInfo, ключи LLM/Telegram, флаги polling‑детектора
- Все ответы включают `trace_id` и `row_version` при необходимости

### 8. Дэшборды и быстрый RCA
- Виджеты:
  - HealthScore by domain, Top regressions (Δ от бенчмарка), Error budget burn, Router conflicts
  - Security guardrail status, Two‑keys queue p95, Provider failover trend
  - Кнопки перехода: «показать логи по trace_id», «сравнить с прошлой неделей», «показать последние деплои/миграции»
- Шаблоны RCA‑плейбуков (автоссылки в инцидентах):
  - «Падает json_validity» → проверить изменения prompts/P07/P10, запустить оффлайн‑golden‑set (P13)
  - «Рост 5xx» → посмотреть последние релизы, DB‑индексы, провайдеры
  - «Проблемы безопасности» → запустить Red‑Team harness (P09), проверить NEGATIVE‑гейт

### 9. Интеграции с CI
- Скрипт `scripts/ci_generate_metrics.py` расширить: формировать `Soul/CI/health_snapshot.json` и `ci_report.md` секцию «Health»
- Порогирование (опция): `--strict` завершать не‑нулём при red
- Пре‑коммит: сохранять быстрый снэпшот (без сетей/БД) на основе статических сигналов

### 10. Безопасность и доступ
- RBAC: просмотр/создание инцидентов — по ролям; экспорт — только админы
- PII‑минимизация: метрики обезличены; глубокие логи доступны только через two‑keys
- Политики scope‑ов для health‑провайдеров чтения из системы

### 11. Приёмка
- Доступность API `/api/health/*` и корректные схемы
- Запись снапшота и создание инцидента через API, отображение на дэшборде
- Триггеры red/yellow и создание инцидента автоматикой
- Бот‑Оркестратор: webhooks OK, polling не запущен, очереди в норме, ключи валидны, префиксы корректны
- CI формирует health‑снэпшот локально; README обновлён

### 12. Роллаут
- Этап 1: только чтение/агрегация system‑уровня, ручные инциденты
- Этап 2: автоматические алерты + интеграция с P13 golden‑set
- Этап 3: дэшборды и быстрый RCA с плейбуками, two‑keys для глубоких логов


### 13. Алерт «High error rate» (фильтрация тестовых 4xx и шумных маршрутов)

### 13.1. Алерты AGE‑синхронизации (lag/skipped)

- Метрики источника:
  - `age.sync.lag_sec` (ключ в `soul_settings`), экспорт в Prometheus `age_sync_lag_sec`.
  - `age.sync.{inserted,updated,skipped}_{last,total}`.
- Правила Prometheus (см. `ops/prometheus/rules_rs_actors.yml`, группа `rs_age_alerts`):
  - `AgeSyncLagHigh`: `age_sync_lag_sec > 300` for 2m.
  - `AgeSyncSkippedBurst`: `increase(age_sync_skipped_total[10m]) > 100` for 2m.
- Аннотации (в Telegram):
  - Русские расшифровки: причина/влияние/что делать (добавлены в `rules_rs_actors.yml`).
- Приёмка:
  - При догоне `lag_sec` падает ступенчато при смене `last_ts`; алерт гаснет при <300s устойчиво.
  - В логе/настройках фиксируются `age.sync.last_ts` и `age.sync.last_id` (tie‑breaker).

- Назначение: сигнализировать о росте доли ошибок без ложных срабатываний от инспекторов/админ‑маршрутов и тестовых 4xx.
- Источники метрик:
  - Глобальная метрика: `soulpulse_errors_total_by_kind{kind=...}` и `soulpulse_requests_total` (кастомный экспорт).
  - Опционально покомпонентно/по endpoint: клиентские счётчики `soulpulse_errors_total{error_type=...,endpoint=...}` и `soulpulse_requests_total{endpoint=...}` (если включены для скрейпа).
  - Инфраструктура: всплески 502 от Nginx/uvicorn учитывать как инфраструктурные деградации; контролировать `proxy_read_timeout/proxy_send_timeout`.

- Глобальное правило (окно 5m, исключаем test‑ошибки):
```
sum(rate(soulpulse_errors_total_by_kind{kind!="test"}[5m]))
/
sum(rate(soulpulse_requests_total[5m]))
  > 0.02
```
- Окно/сглаживание: использовать rate с 5m (а не irate), длительность удержания для алерта: 10m (`for: 10m`).
- Тяжесть: warn при >2%, critical при >5%:
  - warn: `> 0.02` for 10m
  - critical: `> 0.05` for 5m

- Вариант по маршрутам (если доступны клиентские метрики; исключаем инспекторы/админку):
```
# ошибки (исключаем test) по endpoint
errors_by_ep_5m = sum by (endpoint) (rate(soulpulse_errors_total{error_type!="test"}[5m]))
# запросы по endpoint
req_by_ep_5m    = sum by (endpoint) (rate(soulpulse_requests_total[5m]))

err_rate_by_ep  = (errors_by_ep_5m / req_by_ep_5m)
  and on(endpoint) endpoint !~ "^/api/(hyperloop|admin)/.*"

max by (endpoint) (err_rate_by_ep) > 0.05
```

- Примечания по эксплуатации:
  - Для малых RPS добавьте `unless req_by_ep_5m < 1` либо минимальный порог по запросам, чтобы не ловить шум на «тонких» маршрутах.
  - Окно 5–10 минут предпочтительнее для стабильности; для инцидент‑паники возможно отдельное правило на `irate(...[2m])` с более высоким порогом.
  - Для полноты картины отделяйте 5xx (server) и 4xx (user), а «test» 4xx храните отдельно в отчётах, но не учитывайте в алертах.
  - Для релизных окон выделяйте 502 в отдельную серию и применяйте квантование по профилям деплоя, чтобы исключить кратковременные пики.

- Приёмка:
  - Массовые вызовы инспекторов/валидации (Hyperloop/Admin) не триггерят алерт.
  - Реальные всплески 5xx приводят к срабатыванию в течение ≤10 минут.
  - Дэшборд показывает тренд error_rate и вклад маршрутов; документация обновлена.


### 14. Развёртывание и конфигурация Prometheus (prod)

- Развёртывание (системный сервис):
  - Пакет: `prometheus` (Ubuntu). Порт UI/API: `:9090`.
  - Конфиги: `/etc/prometheus/prometheus.yml`, правила: `/etc/prometheus/rules/*.yml`.
  - Управление: `systemctl restart prometheus` (перечитать конфиг/правила), готовность: `GET http://127.0.0.1:9090/-/ready`.

- Минимальная конфигурация сбора метрик SoulPulse:
```
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - /etc/prometheus/rules/rules_error_rate.yml
  - /etc/prometheus/rules/rules_dev_connect.yml

scrape_configs:
  - job_name: 'soulpulse'
    scheme: http
    metrics_path: /api/metrics/prometheus
    static_configs:
      - targets: ['127.0.0.1:8000']
```

- Правила алертов: файл `/etc/prometheus/rules/rules_error_rate.yml` (см. §13):
  - `HighErrorRate` (>2% 10m) и `HighErrorRateCritical` (>5% 5m) — test‑4xx исключены.
  - Окно расчёта: `rate(...[5m])`, интервал оценки: `30s`.

- Метрики, используемые алертами и дашбордом:
  - Глобальные: `soulpulse_requests_total`, `soulpulse_errors_total_by_kind{kind=user|system|test}`.
  - Процессор P30 (best‑effort): `processor_queue_len`, `processor_time_send_to_recv_ms_p95`, `processor_incidents_rate_per_min`.
  - Голос/ASR (best‑effort): `svc_tts_synthesize_p50_ms|p95_ms|p99_ms`, `svc_asr_transcribe_p50_ms|p95_ms|p99_ms`, `svc_tts_audio_bytes_p95`, `svc_asr_audio_bytes_in_p95`, `svc_asr_text_len_out_p95`.
  - DEV.CONNECT (P40 fast‑path): `dev_connect_latency_ms_p50|p95`, `dev_connect_total{status}`, `dev_connect_error_total{type}` (401/404/422/timeout).

- Приёмка Prometheus:
  - `/-/ready` = 200; API `GET /api/v1/targets` показывает `soulpulse` в состоянии `up`.
  - `GET /api/v1/rules` содержит группы `error_rate_rules` и `dev_connect_rules`, expr валиден.
  - На дашборде видны панели DEV.CONNECT (p50/p95, total{status}, error_total{type}); срабатывания соответствуют порогам.

### DEV.CONNECT (наблюдаемость)

- Метрики (экспорт Prometheus):
  - `dev_connect_latency_ms_p50|p95`
  - `dev_connect_total{status="success|error"}`
  - `dev_connect_error_total{type="401|404|422|timeout|other"}`
- Правила Prometheus:
  - Файл: `/etc/prometheus/rules/rules_dev_connect.yml`
  - Группа: `dev_connect_rules` (включает 401/404/422/timeout)
  - Новое (митигатор): `DevConnectTimeoutSpike` — срабатывает при `increase(dev_connect_error_total{type="timeout"}[5m]) > 3` или `dev_connect_latency_ms_p95 > 1600` (5m)
- Примеры PromQL:
  - Ошибки за 5m: `sum(rate(dev_connect_total{status="error"}[5m]))`
  - Таймауты за 5m: `sum(rate(dev_connect_error_total{type="timeout"}[5m]))`
  - Латентность p95 (sample): `histogram_quantile(0.95, sum(rate(dev_connect_latency_ms_bucket[5m])) by (le))`
- Критерии готовности:

### Автоматический митигатор DevConnectTimeoutSpike

- Цель: при всплесках таймаутов автоматически переводить трафик RS в безопасный режим и повышать таймауты, чтобы стабилизировать сервис.
- Действия:
  - Установить профиль `incident_python_only`: `rs.hyperloop.mode=python_only`, `rs.hyperloop.canary_share=0.0`.
  - Увеличить `rs.hyperloop.timeout_ms` в 2 раза (до 5000 мс максимум).
  - Добавить событие `mitigation` в инцидент (таймлайн).
- Реализация:
  - Активатор по таймеру: `ops/systemd/devconnect-mitigator.timer|service` → `backend/scripts/incident_devconnect_mitigator.py` → `IncidentAutoMitigator.run_once`.
  - Self‑test в `ProcessorScheduler`: периодически проверяет `dev_connect_latency_ms_p95` против бюджета `dev.connect.selftest.p95_budget_ms` и применяет те же действия.
- Настройки (в БД):
  - `dev.connect.selftest.period_sec` (по умолчанию 60), `dev.connect.selftest.p95_budget_ms` (по умолчанию 1600).
  - Флаги RS: `rs.hyperloop.mode`, `rs.hyperloop.canary_share`, `rs.hyperloop.timeout_ms`.

### LLM‑Gate — консенсус/аудит/TTL

- Логирование: каждое решение гейта фиксируется в `soul_audit_log` событием `llm_gate_consensus` c полями:
  - `consensus` (bool), `final_allow` (bool), `actions.{aux,primary,alt,primary_second}` (массивы строк).
- Метрики Prometheus (экспорт best‑effort):
  - `llm_gate_consensus_total`, `llm_gate_allow_total`.
- Хранилище/TTL:
  - Ключ в БД: `audit.consensus.ttl_days` (по умолчанию 7) — срок хранения событий.
  - Очистка: `ops/systemd/consensus-audit-cleanup.timer|service` (ежедневно 00:00 UTC).
- Отчёт/админ‑API:
  - `GET /api/admin/soul/audit/llm_consensus_report?hours=24` — агрегаты `total|consensus_yes|allow_yes` и доли за окно.
  - Targets `up` в `GET /api/v1/targets`.
  - Группа правил видна в `GET /api/v1/rules` (`dev_connect_rules`).
  - Панели Grafana отдают данные за 24h, алерты доставляются в Alertmanager (Telegram/Slack маршрут).

