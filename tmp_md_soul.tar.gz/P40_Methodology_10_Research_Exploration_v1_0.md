# M10 — Research/Exploration (v1.0)

Цель: управляемые эксперименты, быстрое получение знаний и принятие решений.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Hypothesis → Design → Experiment → Analyze → Decide → Archive.

Алгоритмы/метрики: Hypothesis AB/och, Statistical Power, p95.

Роли: Research Lead, Data Scientist, PM.

DSL: EXPERIMENT.ADD, HYPOTHESIS.ADD, METHODOLOGY.SET, INSPECTOR.RUN_ALL.

Acceptance: реестр гипотез/экспериментов в БД; панели экспериментов.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
