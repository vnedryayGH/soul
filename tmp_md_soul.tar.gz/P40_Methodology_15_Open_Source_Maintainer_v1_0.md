# M15 — Open‑Source Maintainer (v1.0)

Цель: устойчивая поддержка OSS‑проекта с прозрачными процессами.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Issue triage → Roadmap → PR review → Release → Community.

Алгоритмы/метрики: Issue SLA, PR Lead Time, p95, err_rate.

Роли: Maintainer, Reviewer, Contributor.

DSL: ISSUE.ADD, PR.REVIEW.SET, RELEASE.TAG, METHODOLOGY.SET.

Acceptance: метрики triage/release в БД; панели OSS.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
