# P52 — ТЗ: Режим Бодрствование (Wakefulness) v1.0

Статус: Самодостаточно; Канонично для реализации режима «Бодрствование» в Ядре Соул (ЯС). Интеграции: P16/P21/P22/P23/P25/P27/P28/P29/P30/P31/P35/P36/P38/P40/P46/P48.

## 0) Executive Summary

Цель: ввести в Ядро Соул явный режим «Бодрствование» с процессом «Пробуждения», при котором Нейронная Сеть Соул монтируется в оперативную память и связывается с объектами Ядра (Процессор, Оркестраторы, Шина). В бодрствовании обеспечиваются непрерывные мыслительные процессы в реальном времени под управлением Процессора (P30) с гарантиями подписей/качественных гейтов (P27/P29). В режиме «Сон» (P16) наработанные связи пишутся обратно: корректируются реляционные, графовые и векторные структуры БД Сознания.

### Ключевые положения

- Пробуждение: детерминированный монтаж нейронной сети из жестких структур БД (реляц./граф./вектор) в оперативное «нейронное состояние»: кэши, индексы, быстрые памяти, профили RT.
- Бодрствование: RT‑мышление (perceive→appraise→decide→act→observe→learn) в тесной связке с Квантами, Целями, Планом и Напоминаниями; поддержка микро‑батчей для закрытия RT‑разрывов.
- Засыпание: write‑back изменений — нормализация и пересборка связей (quant_links и производные) под контролем P46 (NeuroIntegrity) и P29 (инспекторы/уставы).
- Наблюдаемость/Безопасность: Delivery Guard (P27), Two‑Keys для опасных операций, метрики p95 стадий, трассы `signature_steps`.

## 0.1) Соответствие процедуре создания (шаги 1–7)

1) Report_Soul_AI_Scientific.md учтён: STRICT JSON квантов, единый SYSTEM‑промпт, pipeline Sense→Quant, Sleep/rewire метрики (см. §7, §8, §12.1 P35). Выжимка — §9, §11.
2) Лучшие практики/исследования (≥36 источников 2014–2025) по памяти/поиску/SSM/MoE/RAG/графам/быстрым весам — собраны и сведены в §9.
3) Маппинг на P‑серию — §8.
4) Документ самодостаточен.
5) Инварианты P27/P28/P29/P30/P36/P46 — отражены в §5/§6/§7/§10/§11.
6) Сверка с P01–P51 — требования и стыковки перечислены в §8.
7) Детализация: данные/кэши (§2), процессы (§3/§4/§5), DSL (§10), Acceptance (§7).

## 1) Архитектурная модель «Нейронная сеть Соул» (монтаж)

### Гипотеза

Гибридная нейросеть над ЯС — это двухконтурная система «Нейронный Рантайм ↔ База Сознания». Рантайм собирается при пробуждении из детерминированных источников БД и предоставляет:

- Быструю рабочую память: KV‑кэши, Modern Hopfield память, kNN‑LM/ретривер.
- Последовательную динамику: State Space Models (S4/S5/Mamba/RetNet/RWKV‑класс) для устойчивых длинных зависимостей и низкой латентности.
- Масштабирование вычислений: Mixture‑of‑Experts (MoE) и профили провайдеров LLM (P14) под управлением Матери Флагов (P28).
- Внешнюю память и знания: Retrieval‑Augmented Generation (RAG) над векторными индексами и графовыми связями (quant_links/Goals/Plan/Skills), согласованную со SchemaGuard (P10) и P35.

Нейронный Рантайм — это операциональный слой, не дублирующий БД как источник истины: он детерминированно «собирается» из БД (read‑only на пробуждении, с контролируемыми write‑back на засыпании) и живёт под управлением Процессора.

## 2) Данные и монтаж (Пробуждение)

### Входы пробуждения

- Профиль бодрствования: `wake.profile.active`, `wake.llm.profile`, лимиты RT, ключи ретриверов/индексов (таблица `soul_settings`, P28).
- Срезы БД: `quants`, `quant_links`, `goals`, `plan_tasks`, `reminders`, `skills/*`, `processor_policies`, `personality/*` (P51), `age_*` при наличии.

### Сборки/кэши (RAM)

- Vector индексы (HNSW/FAISS) для классов Квантов/Goals/Docs (порог свежести, поколение индексов).
- Graph проекции: adjacency‑кэши по `quant_links (to_entity_type,to_entity_id)` + веса/типы.
- KV‑кэш LLM и быстрые памяти (modern Hopfield): ограниченные объёмы, чистка по политике.
- SSM‑состояния: первичная инициализация/прогрев (пустые или из «тёплого» снапа, если доступно).

### Шаги пробуждения (детерминированно, под подпись P27)

1) perceive: читает `soul_settings` и профили бодрствования; валидирует RBAC/флаги (P28).
2) appraise: рассчитывает бюджет RT, лимиты микро‑батчей, активную личность (P51).
3) decide: выбирает профиль ретриверов/индексов (вектор/граф), SSM/LLM провайдер.
4) act: строит кэши (vector/graph/KV/Hopfield), связывает оркестраторы, включает обработчики RT микробатчей.
5) observe: фиксирует метрики прогрева (p50/p95), размер кэшей, «готовность» (wake.ready=true).

### Выходы пробуждения

- `wake.status=ready`, `wake.caches={vector,graph,kv,ssm}`.
- Трасса `signature_steps` с шагами `svc.processor.*`, `cmd.hyperloop.*`.

## 3) Режим «Бодрствование» — RT мышление

Определение: период, когда `wake.status=ready` и Процессор (P30) исполняет непрерывную петлю на входящих событиях (чат, напоминания, цели, инциденты), создавая/обновляя Кванты и возвращая видимые ответы под Delivery Guard (P27).

### Требования

- RT gap‑closure: поддержка микро‑батчей `n=1..3`, `TIMEOUT≤1500–3000ms`, `append=true` (см. P35 §9, §14.2). В реализации ядра: `processor.batch_max_events=3`, `processor.event_timeout_ms=3000` (по умолчанию).
- Строгий контракт ответа (STRICT_JSON_QUANT), парсинг `svc.parser.json_strict` (P10/P27).
- Минимальная цепочка подписи перед публикацией: `svc.soul.preanalysis, svc.soul.router_decide, svc.llm_client.send, svc.llm_client.recv, svc.parser.json_strict, svc.chat.reply_render`.
- Автономная обратная связь: при отсутствии feedback — ретраи/эскалации (P30, §5).

### Поддержание RT‑активности

- Фоновый RT‑инжектор очереди процессора: `processor.rt_inject.*` (см. §11). Инжектирует пачку из 50 событий каждые 10–15 минут для поддержания ненулевой активности. Дедуплицирует по `dedup_key`.
- Периодические e2e‑батчи пайплайна: событие `e2e.pipeline.batch` инициирует ~20 запусков `CORE.PIPELINE.RUN` за цикл с контролем QPS и таймаутом каждого прогона (по умолчанию 3000 мс).

### Рождение Квантов — пошагово (основная цепочка)

1) Источник возмущения (чат/harvest/reminder/goal) создаёт входное событие.
2) Препроцессинг: сбор `enriched_context` и `planner_feedback` (ограниченные бюджеты LLM, строгий JSON).
3) Генерация: `generate_quant|generate_quants` (LLMClient с таймаутами/ретраями из БД; batch — чанки=10, stateless DB в LLM).
4) Нормализация/обогащение: STRICT JSON → эмоции/теги/сенсорика/связи/действия.
5) Персист и линковка: API/DSL, защита от дрейфа схемы, шаги подписи (P27).
6) Наблюдаемость: `soul_llm_*`, `soul_pipeline_ok`, p95 стадий, `signature_steps`; инциденты при нарушениях (P50).

Примечание: Для stateless‑batch ветки `desired_action=[]` (несохраняемые действия), персист действий выполняется сервером по политикам.

## 4) Связи с объектами Ядра Соул

- Процессор (P30): оркестрирует пробуждение/бодрствование/засыпание как процессы, ведёт агенду, управляет бюджетами LLM/ретриверов.
- Оркестраторы (P35): Дирижёр/Роутер/Судья/Жандарм/Архивариус — подключены к RT‑петле и к DSL (P36).
- Шина/DSL (P36): Hyperloop — единый плоскостной контроль: `FLAGS.*`, `CORE.*`, `PROCESSOR.*`, `INSPECTOR.*`, `TEST.*`, `REQUEST.*`.
- Профили (P28): `wake.profile.*`, `delivery_guard.enforce`, `processor.*`, `meaning.*`.

## 5) Режим «Засыпание» — write‑back

Назначение: аккуратно перенести наработанные в бодрствовании связи/веса в БД Сознания под контролем P46 (NeuroIntegrity) и P29 (качество).

### Требования (write-back)

- Коррекция связей: обновление `quant_links(weight, relation_type)`, регуляризация дрейфа (эпсилон‑границы как в P35 §12.1 «Sleep/rewire»).
- Консистентность целей/плана/навыков/календаря: инспекторы P46.
- Ограничения: лимиты глубины/объёма правок за цикл (epsilon/radius/max_edges), Two‑Keys для опасных операций.

### 5.1 Управление переходом Сон → Бодрствование

Цель: детерминированно управлять моментом пробуждения, учитывая фактический прогресс процессов Сна и бюджет времени.

Определения и метрики (P21):

- `sleep.planned_minutes` — плановое окно Сна;
- `sleep.used_minutes` — фактически использованное время;
- `sleep.rewire_progress` — доля завершённости задач write‑back (0..1);
- `sleep.deficit_minutes = max(0, required_minutes - remaining_minutes)`;
- `sleep.early_wake_eligible` — условие «можно будить раньше» (см. ниже).

Правила:

- Раннее пробуждение (early wake): если `sleep.rewire_progress ≥ 1.0` либо остальные задачи укладываются в `≤ sleep.early_wake.tail_minutes`, система инициирует раннее пробуждение.
- Мягкое пробуждение (soft wake): если окно Сна истекает, а `sleep.rewire_progress < 1.0`, инициируется мягкое пробуждение:
  - выполняется минимальный монтаж для RT (кэши с пониженными лимитами);
  - формируется отчёт Архитектору с аналитикой дефицита по времени и списком незавершённых процессов;
  - Оркестратор планирует догоняющие шаги (по расписанию/в ночное окно), без деградации Guard.

Отчёт Архитектору (P29/P23):

- Содержимое: `deficit_minutes`, перечень незавершённых задач с оценкой времени, рекомендации (разовый +delta_minutes или системное увеличение `sleep.planned_minutes`).
- Доставка: заявка `REQUEST.CREATE type=architect_session subject="Sleep Deficit" payload={...}` и уведомление в панели Архитектора.

Настройки и управление (P28, см. §11):

- `sleep.planned_minutes`, `sleep.min_minutes`, `sleep.early_wake.enabled`, `sleep.early_wake.tail_minutes`, `sleep.soft_wake.enabled`, `sleep.report.architect_notify` — управляются из панели Архитектора (P23) и через FLAGS.* с Two‑Keys при рисковом увеличении.

Hyperloop DSL (эскизы):

```text
# Принудительный расчёт перехода
PROCESSOR.EVENT.INJECT kind=sleep_transition_check payload={"now":"auto"}
PROCESSOR.PROCESS_ONCE

# Разовая корректировка окна сна (+30 минут)
FLAGS.SET key=sleep.planned_minutes value=\"+30m\"

# Системное увеличение минимального окна до 90 минут (Two‑Keys)
TWO_KEYS.REQUEST operation=flags scope=sleep reason=\"increase baseline\"
FLAGS.SET key=sleep.min_minutes value=90

# Формирование отчёта Архитектору
REQUEST.CREATE type=architect_session subject=\"Sleep deficit report\" payload={"deficit_minutes":25}

```

Acceptance (переход):

- При `sleep.rewire_progress ≥ 1.0` система выполняет раннее пробуждение; метрики/трассы зафиксированы, Guard соблюдён.
- При дефиците времени формируется мягкое пробуждение и отчёт Архитектору; доступны кнопки управления в панели P23; изменения времени сна применяются и отражаются в `soul_settings`.

## 6) Наблюдаемость и безопасность

- Delivery Guard (P27): обязательная цепочка подписи перед публикацией; инцидент при нарушении.
- Метрики (P21): p50/p95 стадий RT, размеры кэшей, ratio ретри/эскалаций, coverage подписи, `wake.ready_time_ms`. Дополнительно: `processor.time_send_to_recv_ms` (e2e), `processor.queue_len`, RT‑инжектор счётчик `processor.rt_inject_created`.
- Инспекторы (P29/P46): `signature.required_steps.consistency`, `neuro.integrity.*`.
- RBAC/Two‑Keys (P44): для флагов/массовых правок.

## 7) Acceptance

### Минимально

1) Пробуждение: команда запуска возвращает `ok`, `wake.status=ready`, трасса есть, метрики прогрева в норме.
2) Бодрствование: ≥3 вида событий (чат/reminder/goal) обрабатываются; перед видимым ответом соблюдается цепочка P27; RT микро‑батчи проходят в целевом окне времени.
3) Засыпание: инспекторы P46 «зелёные» (или оформлены корректирующие заявки); записи/правки в БД лежат в лимитах.
4) Hyperloop смоки выполняются; ответы содержат `trace_id`, шаги `cmd.hyperloop.*` и `svc.*` сохранены.

## 8) Маппинг на P‑серию

- P01/P03: preanalysis/router — стабильные контракты для RT.
- P07: DesiredAction — закрытие петли observe→learn.
- P10: STRICT JSON — парсер и схемы.
- P14: провайдеры LLM/профили.
- P16: Sleep — окна write‑back и компакция.
- P21: Health/Monitoring — метрики p95, алерты.
- P22: фасады API admin/RT.
- P23: UI панель состояния бодрствования и метрик.
- P25: Skills/Routes — структурные связи памяти.
- P27/P29: подпись/гейты качества.
- P30: Процессор — ядро RT.
- P31/P39: мультисенсорные/сенсорные якоря в памяти.
- P35: эталонные процессы; RT gap‑closure/микро‑батчи.
- P36: Hyperloop — управляющий контур.
- P38: NeuroTraining — окно TRAIN и обучение из RT‑опыта.
- P40: план‑факт и трассировка работ.
- P46: NeuroIntegrity — инспекции топологии/полноты/согласованности.

## 9) Научная база и выбранные подходы (≥36 источников, выжимка)

- Память/внешняя память:
  - Graves et al., 2014 — Neural Turing Machines (NTM)
  - Graves et al., 2016 — Differentiable Neural Computer (DNC)
  - Grave et al., 2017 — kNN‑LM (непараметрическая память)
  - Borgeaud et al., 2022 — RETRO (RAG на претрейне)
  - Khandelwal et al., 2021 — Generalization via retrieval
  - Malkov & Yashunin, 2018 — HNSW индексация
  - Johnson et al., 2017 — FAISS

- Современная ассоциативная память:
  - Krotov & Hopfield, 2020 — Modern Hopfield Networks
  - Ramsauer et al., 2021 — Hopfield is All You Need

- Последовательные модели (SSM/RNN‑альтернатива):
  - Gu et al., 2021 — S4: State Space Models for Long Sequences
  - Smith et al., 2022 — S5
  - Dao et al., 2023 — FlashAttention‑2 (служебно)
  - Gu & Dao, 2023 — Mamba (selective SSM)
  - Sun et al., 2023 — Retentive Network (RetNet)
  - Peng et al., 2023 — RWKV (recurrent‑transformer blend)

- MoE/масштабирование:
  - Lepikhin et al., 2020 — GShard
  - Fedus et al., 2021 — Switch Transformer
  - Team DeepSeek, 2024 — Efficient MoE routing (практика)

- Графовые представления/нейрограф:
  - Kipf & Welling, 2016 — GCN
  - Veličković et al., 2017 — GAT
  - Hamilton et al., 2017 — GraphSAGE
  - Perozzi et al., 2014 — DeepWalk; Grover & Leskovec, 2016 — node2vec

- RAG/поиск/нейро‑ретривер:
  - Lewis et al., 2020 — RAG
  - Izacard et al., 2022 — Atlas / FiD‑style ретривер
  - Santhanam et al., 2022/23 — ColBERTv2/PLAID
  - Gao et al., 2023 — RAG survey (систематизация)

- Расширенные последовательные/длинные контексты:
  - Dai et al., 2019 — Transformer‑XL (recurrence over segments)
  - Beltagy et al., 2020 — Longformer (sparse attention)
  - Poli et al., 2023 — Hyena (implicit SSM convolution)
  - Wu et al., 2022 — Memorizing Transformers (external memory)
  - Jaegle et al., 2021 — Perceiver IO (latent cross‑attention)

- Быстрые веса/гиперсети/мета‑обучение:
  - Schmidhuber, 1992 — fast weights
  - Ba et al., 2016 — fast weight programmers
  - Ha et al., 2017 — HyperNetworks

- Нейронные ODE/непрерывная динамика:
  - Chen et al., 2018 — Neural ODEs

- Нейроморфные/спайковые (для перспективного железа/энергоэффективности):
  - Davies et al., 2018/2021 — Intel Loihi
  - Hasani et al., 2020 — Liquid Time‑Constant Networks

Выводы (коротко): гибрид «SSM + MoE + RAG + Hopfield/kNN память» обеспечивает устойчивую RT‑динамику и экономию контекста; графовый слой даёт структурную «семантическую шину» для смыслов/целей/плана; быстрые веса/гиперсети — перспективны для онлайновой адаптации под Guard.

## 10) Hyperloop DSL (эскизы команд, совместимо с P36)

Примечание: WAKE.* — спецификация; реализация допускается через существующие команды/макросы.

```text
# Пробуждение (монтаж)
WAKE.START profile="prod_safe" WITH TRACE

# Статус бодрствования
WAKE.STATUS

# Засыпание (write-back окно)
WAKE.SLEEP profile="deep" DRY_RUN

# Эквиваленты через текущие команды (без WAKE.*), допустимые сегодня:
FLAGS.APPLY_PROFILE name=prod_safe
CORE.PIPELINE.RUN input_text="wake warmup" WITH TRACE TIMEOUT=1500
INSPECTOR.RUN_ALL

# RT‑микробатчи и инжектор
FLAGS.SET key=processor.batch_max_events value=3
FLAGS.SET key=processor.event_timeout_ms value=3000
FLAGS.SET key=processor.rt_inject.enabled value=true
FLAGS.SET key=processor.rt_inject.period_minutes value=12
FLAGS.SET key=processor.rt_inject.batch_size value=50
FLAGS.SET key=processor.rt_inject.include_aux_smokes value=true

# e2e батчи пайплайна
FLAGS.SET key=processor.pipeline_batch.enabled value=true
FLAGS.SET key=processor.pipeline_batch.period_minutes value=30
FLAGS.SET key=processor.pipeline_batch.count value=20
FLAGS.SET key=processor.pipeline_batch.timeout_ms value=3000

```

Acceptance для DSL: ответы `ok`, присутствует `trace_id`, шаги `cmd.hyperloop.*` сохранены; при наличии WAKE.* — они транслируются в безопасные существующие команды.

## 11) Настройки (soul_settings — ключи)

```json
{
  "wake.profile.active": "prod_safe|dev_fast|diagnostics_on",
  "wake.caches": {"vector": true, "graph": true, "kv": true, "ssm": true},
  "wake.rt": {"micro_batch": {"enabled": true, "n_max": 3, "timeout_ms": 3000}},
  "wake.guard": {"delivery_guard.enforce": true},
  "wake.observability": {"metrics": ["p95_stages","cache_sizes","retry_ratio"]},
  "processor.batch_max_events": 3,
  "processor.event_timeout_ms": 3000,
  "processor.rt_inject.enabled": true,
  "processor.rt_inject.period_minutes": 12,
  "processor.rt_inject.batch_size": 50,
  "processor.rt_inject.kind": "user_query",
  "processor.rt_inject.include_aux_smokes": true,
  "processor.pipeline_batch.enabled": true,
  "processor.pipeline_batch.period_minutes": 30,
  "processor.pipeline_batch.count": 20,
  "processor.pipeline_batch.timeout_ms": 3000,
  "processor.pipeline_batch.qps": 2,
  "wake.llm.analysis": {
    "provider": "gigachat|deepseek|internal",
    "timeout_ms": 2000,
    "retries": 1,
    "budget_tokens": 800,
    "strict_json": true,
    "modes": ["summarize","compare","classify","score","policy_suggest"]
  },
  "sleep.planned_minutes": 60,
  "sleep.min_minutes": 45,
  "sleep.early_wake": {"enabled": true, "tail_minutes": 10},
  "sleep.soft_wake": {"enabled": true, "report.architect_notify": true}
}

```

## 12) Риски и смягчения

- Перегрев RT/очереди → квотирование LLM/ретриверов, снижение микро‑батчей, пауза вторичных процессов.
- Дрейф связей при write‑back → эпсилон‑ограничения/радиус, инспекторы P46, Two‑Keys.
- Ложные публикации → Delivery Guard строгий, уставы/тесты (P29), негативные сценарии.

## 13) Внедрение (по этапам)

1) Пробуждение v0 (кэши vector/graph, статус)
2) RT микро‑батчи и метрики
3) Засыпание write‑back под P46
4) UI панель (P23) и дашборды (P21)
5) WAKE.* макросы/обработчики в Hyperloop (P36)

### 13.1 План‑факт (P40)

- branch: `tz52-wakefulness`
- project_id: `f681c222-a1fc-4e51-b18a-aaca170e71ab`
- основная задача: `d7f5235b-a3dc-4c6d-83d0-5aa577f2eac8` — P52: детектор усталости и интеграция D0/политик Сна (якорная)
- подзадачи (FS зависимость от основной):
  - `3af69530-b96f-4f0b-986b-37b64916de17` — P52: fatigue detector — metrics and alerts
  - `159f7499-2182-4f72-bfac-6c5558df0c1e` — P52: D0 integration into sleep policies
  - `a683fa2a-1df7-45d7-970c-6917342081fb` — P52: Architect UI — manual sleep adjustments

### 13.2 Шаблоны DSL для QUANT.LINK (кванты‑ссылки на задачи)

Назначение: при появлении первого артефакта реализации (квант решения/изменения) сразу фиксировать принадлежность к задачам плана через `QUANT.LINK`.

Шаблоны (подставить `<QID>` квант‑идентификатор):

```text
# Anchor задача (общая): implements
QUANT.LINK from_quant=<QID> to_entity_type=plan_task to_entity_id=d7f5235b-a3dc-4c6d-83d0-5aa577f2eac8 relation_type=implements

# Подзадача 1: fatigue detector — implements/supports
QUANT.LINK from_quant=<QID> to_entity_type=plan_task to_entity_id=3af69530-b96f-4f0b-986b-37b64916de17 relation_type=implements
QUANT.LINK from_quant=<QID> to_entity_type=plan_task to_entity_id=3af69530-b96f-4f0b-986b-37b64916de17 relation_type=supports

# Подзадача 2: D0 sleep policies — implements/supports
QUANT.LINK from_quant=<QID> to_entity_type=plan_task to_entity_id=159f7499-2182-4f72-bfac-6c5558df0c1e relation_type=implements
QUANT.LINK from_quant=<QID> to_entity_type=plan_task to_entity_id=159f7499-2182-4f72-bfac-6c5558df0c1e relation_type=supports

# Подзадача 3: Architect UI — implements/supports
QUANT.LINK from_quant=<QID> to_entity_type=plan_task to_entity_id=a683fa2a-1df7-45d7-970c-6917342081fb relation_type=implements
QUANT.LINK from_quant=<QID> to_entity_type=plan_task to_entity_id=a683fa2a-1df7-45d7-970c-6917342081fb relation_type=supports

```

PowerShell (устойчиво через файл):

```powershell
'{ "commands": "QUANT.LINK from_quant=\"<QID>\" to_entity_type=plan_task to_entity_id=\"3af69530-b96f-4f0b-986b-37b64916de17\" relation_type=implements" }' | Set-Content -Path tmp_link.json -Encoding UTF8 -NoNewline
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -H "Content-Type: application/json" --data-binary "@tmp_link.json" https://mini.soulpulse.art/api/hyperloop/execute

```

Acceptance (линковка):

- Для каждого первого артефакта по подзадаче существует хотя бы одна запись `QUANT.LINK(... relation_type=implements)` к соответствующей `plan_task`.
- `QUANT.LINK.CHECK` возвращает покрытие ≥ 1 по выборке последних квантов.

## 14) Acceptance (итог)

- Документ самодостаточен; интеграции и схемы определены; нет регресса по объёму/смыслу.
- Пробуждение/Бодрствование/Засыпание демонстрируются смоками; подпись/гейты соблюдены; метрики/трассы доступны. RT‑микробатчи работают в целевом окне, RT‑инжектор поддерживает активность, e2e‑батчи видны по трассам с `trace_id` и укладываются в p95‑бюджеты.

---

## 15) Режимы связи с внутренней LLM (расширение анализа данных)

Цель: обеспечить безопасный и детерминированный доступ к внутренней сервисной LLM (малая модель) для задач анализа данных в бодрствовании без нарушения инвариантов P27/P29.

Классы задач анализа (STRICT JSON):

- summarize — сжатие/агрегация полей/трасс/инцидентов;
- compare — сравнение двух наборов метрик/версий/трасс;
- classify — отнесение событий/квантов к классам (политики/риски);
- score — вычисление скорингов/приоритетов (обоснование краткое);
- policy_suggest — предложения флагов/порогов с обоснованием (Two‑Keys при применении).

Контракты вызова:

- Вход: `{ "task": "summarize|compare|classify|score|policy_suggest", "context": { ... }, "constraints": { "timeout_ms": int, "max_tokens": int } }`.
- Выход: `{ "result": any, "confidence": 0..1, "notes?": string[] }` (строгая схема под конкретный `task`).

Интеграция с P27/P29/P30:

- Вызовы выполняются как `svc.llm_client.send/recv` с `strict_json=true`; парсинг `svc.parser.json_strict`.
- Перед видимой публикацией включён Delivery Guard; для невидимых служебных результатов — подпись `svc.processor.act` достаточна.
- Для `policy_suggest` применение рекомендаций проходит через Two‑Keys (P29) и `FLAGS.*`.

Hyperloop DSL (эскизы):

```text
LLM.SELECT provider=gigachat
LLM.EVAL task="summarize" context={"scope":"processor.runs","window":"24h"} WITH TRACE TIMEOUT=2000
LLM.EVAL task="compare" context={"a":"trace:py","b":"trace:rs"} WITH TRACE

```

### 15.1 Смоки через Hyperloop CLI (Windows PowerShell)

```powershell
# Выбор провайдера малой LLM для аналитики
python .\Soul\scripts\hyperloop_cli.py --dsl LLM.SELECT provider=gigachat

# Вызов служебной аналитики (сводка последних запусков процессора за 24ч)
python .\Soul\scripts\hyperloop_cli.py --dsl LLM.EVAL task=\"summarize\" context=\"{\\\"scope\\\":\\\"processor.runs\\\",\\\"window\\\":\\\"24h\\\"}\" WITH TRACE TIMEOUT=2000

# Сравнение двух трасс подписи (py vs rs) с трассировкой
python .\Soul\scripts\hyperloop_cli.py --dsl LLM.EVAL task=\"compare\" context=\"{\\\"a\\\":\\\"trace:py\\\",\\\"b\\\":\\\"trace:rs\\\"}\" WITH TRACE

```

## 16) Связь с «большой» LLM (решение сложных задач)

Назначение: подключать большую модель (DeepSeek/OpenAI и др., P14) для сложных генеративных/планировочных задач в бодрствовании, сохраняя инварианты безопасности/качества и бюджеты.

Область применения:

- сложный синтез текста/плана/артефактов, требующий длинного контекста;
- разветвлённое рассуждение и построение многошаговых планов (персистится Квантами);
- генерация пользовательского ответа под Delivery Guard (P27) и санитайзером.

Инварианты (P27/P29/P28):

- Вызовы большой LLM происходят через `CORE.PIPELINE.RUN` (встроенная сборка промпта Soul Core, §Report_Soul_AI_Scientific, P35 §11), возврат — STRICT JSON квантов.
- Видимая публикация возможна только при наличии обязательной цепочки: `svc.soul.preanalysis, svc.soul.router_decide, svc.llm_client.send, svc.llm_client.recv, svc.parser.json_strict, svc.chat.reply_render`.
- Профили и бюджеты (`wake.llm.big.*`) ограничивают токены/тайм‑ауты/стоимость; превышения требуют Two‑Keys.
- Для служебных шагов анализа предпочтительно использовать малую LLM (§15), большую — только для финального синтеза/сложного плана.

Настройки (дополнение к §11):

```json
{
  "wake.llm.big": {
    "provider": "deepseek|openai",
    "max_output_tokens": 3000,
    "temperature": 0.7,
    "timeout_ms": 30000,
    "retry_policy": {"max": 1, "backoff_ms": 500},
    "budget_usd": 0.50,
    "allow_micro_batch": true
  }
}

```

Роутинг и тактика (П30/P35):

- Процессор выбирает большую LLM при признаках «сложности» (длина контекста/класс задачи), иначе — малую LLM/эвристику.
- Допускаются RT микро‑батчи (1–3) с суммарным `TIMEOUT≤3000ms` для пробных ответов; финальный ответ — через основную большую LLM по бюджету.

Hyperloop DSL (эскизы):

```text
LLM.SELECT provider=deepseek
CORE.PIPELINE.RUN input_text="Сформируй план достижения цели X с ограничениями ..." WITH TRACE TIMEOUT=15000

```

Смоки через Hyperloop CLI (Windows PowerShell):

```powershell
python .\Soul\scripts\hyperloop_cli.py --dsl LLM.SELECT provider=deepseek
python .\Soul\scripts\hyperloop_cli.py --dsl CORE.PIPELINE.RUN input_text=\"Построй краткий план из 5 шагов по теме P52\" WITH TRACE TIMEOUT=15000

```

Acceptance (большая LLM):

- Ответы приходят в формате STRICT JSON квантов; перед публикацией соблюдается P27‑цепочка; бюджеты/тайм‑ауты не нарушены.
- При превышении бюджета или тайм‑аута — деградация на малую LLM/эвристику, инцидент P29 зафиксирован.

## 17) Когнитивная модель мышления Соул (научная основа)

Модель мышления — гибридная, опирается на:

- Реактивный контур (быстрый): SSM‑динамики (S4/S5/Mamba/RetNet/RWKV) + быстрые памяти (Modern Hopfield, kNN‑LM) и ретривер (RAG) для немедленного контекста и решений с микробатчами RT.
- Созерцательно‑планирующий контур (глубокий): большая LLM (§16) с длинным контекстом и структурированным синтезом (STRICT JSON квантов), под управлением Процессора (П30) и Delivery Guard (П27).
- Семантическая шина: граф `quant_links` (цели/план/навыки/календарь) как опорная структура для маршрутизации смыслов и закрепления результатов.

Память и саморазвитие:

- Рабочая память: KV/Hopfield буферы + стек контекстов; очистка/реплей по политикам.
- Долговременная: графовые/векторные индексы и кванты; новые связи рождаются в бодрствовании и закрепляются в Сне (write‑back §5).
- Регулярная пересборка в Сне — ключевое преимущество: снижает энтропию, исправляет дрейф и повышает устойчивость RT мышления после пробуждения.

Индикатор сложности D0 (фрактальная размерность):

- Источники: `backend/app/services/advanced_soul_optimization.py` (расчёт `d0_fractal_dimension`), аналитика в `Soul/FINAL_COMPLETION_REPORT_v2_0.md`.
- База концепции: `Soul/K0.md` (Круг двойного ноля — Д0) как теоретический фундамент сингулярной компоновки знаний (компактификация +∞/−∞ в 0, устойчивые переходы состояний).
- Интерпретация: `D0` отражает информационную сложность актуального состояния Сознания; стабилизация D0 около целевого значения повышает предсказуемость RT и снижает усталость.

Acceptance (когнитивная модель):

- В RT доступны оба контура (быстрый/глубокий) с корректным роутингом; новые кванты корректно линкуются к плану/целям.
- Метрики сложности/устойчивости (включая D0) экспортируются (P21) и влияют на политику Сна/пробуждения.

## 18) Усталость и потребность во Сне (детектор, триггеры)

Определение: усталость — агрегированный показатель деградации RT мышления и накопленной «потребности в пересборке».

Индикаторы (примерная формула):

```text
fatigue_score = w1*z(p95_over_budget) + w2*z(delivery_guard_failed_rate) + w3*z(queue_len) +
                 w4*z(error_rate) + w5*z(rt_microbatch_util) + w6*z(|D0 - D0_target|) +
                 w7*z(novelty_rate)

```

- `p95_over_budget` — превышение p95 стадий над бюджетами; `delivery_guard_failed_rate` — доля провалов Guard; `queue_len` — длина очереди Процессора; `error_rate` — доля ошибок этапов; `rt_microbatch_util` — доля слотов RT микробатчей, использованных с тайм‑аутом; `|D0 - D0_target|` — модуль дрейфа; `novelty_rate` — скорость появления новых связей/квантов.

Триггеры Сна:

- Мягкий переход (soft sleep): если `fatigue_score ≥ fatigue.soft.threshold` или `novelty_rate`/`D0_drift` выше порогов при допустимом окне — планируется ближайшее окно Сна; формируется отчёт Архитектору.
- Жёсткий переход (hard sleep): при критических превышениях `p95_over_budget`/`delivery_guard_failed_rate`/очереди — немедленная приоритизация Сна (Two‑Keys, если требуется).

Настройки (дополнение §11):

```json
{
  "fatigue.weights": {"p95": 0.2, "guard": 0.2, "queue": 0.15, "errors": 0.15, "rt_microbatch": 0.1, "d0": 0.1, "novelty": 0.1},
  "fatigue.soft.threshold": 1.0,
  "fatigue.hard.threshold": 2.0,
  "d0.target": 1.3,
  "d0.drift_threshold": 0.15
}

```

Hyperloop DSL (смоки):

```text
# Проверка усталости и возможного перехода в Сон
PROCESSOR.EVENT.INJECT kind=fatigue_check payload={"observe_window":"4h"}
PROCESSOR.PROCESS_ONCE

# Форсирование Сна при критике (с эскалацией)
REQUEST.CREATE type=architect_session subject="Force Sleep" payload={"reason":"hard fatigue"}

```

Acceptance (усталость/Сон):

- `fatigue_score` считается и экспонируется; при soft/hard порогах запускаются соответствующие сценарии; отчёты/заявки доступны Архитектору; настройки изменяемы из панели P23.

## 19) UI панели Архитектора — ручные корректировки Сна (P23)

Требования:

- Раздел "Sleep Control":
  - Показ текущих ключей: `sleep.planned_minutes`, `sleep.min_minutes`, `sleep.early_wake.tail_minutes`, `sleep.soft_wake.enabled`.
  - Показ метрик: `fatigue_score`, `p95_over_budget`, `delivery_guard_failed_rate`, `queue_len`, `|D0 - d0.target|`.
  - Действия:
    - Разовая корректировка окна сна: `+15m`, `+30m` (FLAGS.SET `sleep.planned_minutes`).
    - Системные изменения: задать `sleep.min_minutes`, `sleep.early_wake.tail_minutes` (Two‑Keys при повышении).
    - Включить/выключить `sleep.soft_wake.enabled`.
    - Триггер maintenance‑сна: кнопка `Run maintenance (5m)` вызывает `FLAGS.SET sleep.maintenance.enabled=true` и создаёт событие в планировщике; отображаются последние метрики Integrity.

Hyperloop (эскизы команд):

```text
FLAGS.SET key=sleep.planned_minutes value="+30m"
FLAGS.SET key=sleep.min_minutes value=90
FLAGS.SET key=sleep.early_wake.tail_minutes value=10
FLAGS.SET key=sleep.soft_wake.enabled value=true
FLAGS.SET key=sleep.maintenance.enabled value=true
FLAGS.SET key=sleep.maintenance.interval_minutes value=180
FLAGS.SET key=sleep.maintenance.duration_minutes value=5

```

Acceptance (UI):

- Из панели выполняются команды FLAGS.SET; значения отражаются в `soul_settings`; изменения видны в RT после следующего цикла чтения политик Процессором; шаги подписи фиксируются.

Настройки профиля:

- `wake.llm.analysis.provider`: предпочтительный провайдер для служебных задач (дефолт: gigachat).
- Ограничения времени/токенов и число ретраев задаются через `wake.llm.analysis.*`.
- Запрещены произвольные генерации текста; только строгий JSON.

### Приложение A. Выдержки из Report_Soul_AI_Scientific

- STRICT_JSON_QUANT и единый SYSTEM‑промпт — соблюдены (§2/§11 P35).
- Sleep/rewire: epsilon/radius/max_edges — перенесены в write‑back (

  см. §12.1 P35). Метрики Sleep: rewire_ratio/epsilon_p50/radius_p50/edges_updated_total — применимы в P52.

### Приложение B. Мини‑смоки (PowerShell)

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
$B=@{ commands='INSPECTOR.RUN_ALL' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

# Wake warmup (эквивалент WAKE.START)
$B=@{ commands='CORE.PIPELINE.RUN input_text="wake warmup" WITH TRACE' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

# Проверка обязательной цепочки и шага строгого парсера
$B=@{ commands='INSPECTOR.RUN key=signature.required_steps.consistency' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

```

QUANT.LINK — создание кванта‑ссылки (implements) для подзадачи fatigue detector:

```powershell
# Вариант 1: Hyperloop CLI (прямой DSL)
python .\Soul\scripts\hyperloop_cli.py --dsl "QUANT.LINK from_quant=\"<QID>\" to_entity_type=plan_task to_entity_id=\"3af69530-b96f-4f0b-986b-37b64916de17\" relation_type=implements"

# Вариант 2: устойчивый файл+curl.exe
'{ "commands": "QUANT.LINK from_quant=\"<QID>\" to_entity_type=plan_task to_entity_id=\"3af69530-b96f-4f0b-986b-37b64916de17\" relation_type=implements" }' | Set-Content -Path tmp_link.json -Encoding UTF8 -NoNewline
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -H "Content-Type: application/json" --data-binary "@tmp_link.json" https://mini.soulpulse.art/api/hyperloop/execute
```


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
