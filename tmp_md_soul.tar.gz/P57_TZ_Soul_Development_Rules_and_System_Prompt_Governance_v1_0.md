# P57 — ТЗ: Управление системным промптом и правилами разработки (Governance)

Версия: v1.0
Статус: актуально
Назначение: зафиксировать единые правила разработки и управления системным промптом для Агентов LLM в экосистеме Soul; обеспечить отсутствие дублирования и противоречий, согласованность с Hyperloop/Planning (P40) и инспекторами.

## 1. Область действия
- Все LLM-агенты, работающие в репозитории и через Hyperloop.
- Сопровождающие документы: `.cursorrules`, `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v*`, `docs/PROJECT_STRUCTURE_v*`.

## 2. Нормативные ссылки
- P27 Подпись и трассируемость данных.
- P36 Hyperloop DSL/CLI.
- P40 Планирование проектов.
- P45 Инжест/Кванты.
- P52 Режим бодрствования.

## 3. Обязательные правила (normative)
1) STRICT JSON для машинных ответов; перед выдачей — Delivery Guard (P27) с сохранением `signature_steps`.
2) Все данные/настройки — только из БД (`SoulSettingsService`, `SecretsService`); запрет локальных JSON как источника истины.
3) Ветка обязательна (P40): `INSPECTOR.RUN key=plan.branch action=claim_branch ...` перед изменениями; `... action=release_branch ...` после.
4) Hyperloop CLI обязателен для всех DSL/операций. Формат тела: `{ "commands": "<ONE LINE DSL>" }`.
5) Автозагрузка промпта для агентов (Cursor): `.cursorrules` должен быть самодостаточным, без внешних зависимостей.
6) Никаких фоновых/долгоживущих локальных процессов — только systemd на APP серверах.

## 4. Управление изменениями (.cursorrules Governance)
- Изменения проходят ревизию на дубли/противоречия; приоритет: краткость, однозначность для LLM.
- Все новые правила привязываются к соответствующим P‑сериям (ссылка на ТЗ) и отражаются в реестрах.
- Каждая правка сопровождается записью в `SYSTEM_MASTER_DOCUMENTS_REGISTRY` с bump минорной версии.

## 5. Требования к структуре .cursorrules
- Блоки: Global, Execution Policy, Canonical addresses/secrets, Entry Points, Planning, Workflow, Tools, Safety, Scoped rules.
- В блоках — только исполнимые, проверяемые правила.
- Раздел Addendum допускается для оперативных поправок, но должен быть сведён при следующей оптимизации.

### 5.1 Автоподготовка окружения (Cursor Worktrees)

- Обязателен `.cursor/worktrees.json` с автозапуском `./.cursor/setup.ps1` (Windows PowerShell, `-ExecutionPolicy Bypass`).
- `./.cursor/setup.ps1` выполняет:
  1) Создание и активацию `.venv`, установку `backend/requirements.txt`, `ruff`, `mypy`.
  2) Установку git‑hook: `scripts/setup_precommit_hook.ps1`.
  3) Установку `npm` зависимостей фронтенда (`npm ci`/`npm install`).
  4) Hyperloop префлайт и инспекторы: `INSPECTOR.RUN key=planning.enforce`, `INSPECTOR.RUN key=guard.canonical.urls`.
  5) Локальные проверки: `ruff check backend`, `mypy backend`.
  6) Генерацию индексов документации: `python scripts/generate_indices.py` (формирует `docs/ENV_INDEX.md` и `docs/API_ROUTES_INDEX.md`).
- Автоклейм ветки разрешён только при наличии `SOUL_TG_ID`, `SOUL_BRANCH`, `SOUL_SESSION`.
- Скрипт не должен запускать долговременные процессы и не должен записывать секреты/URL вне БД.

### 5.2 Pre-commit smoke (read-only)

- По умолчанию smoke отключён. Включение через переменную окружения `SOUL_PRECOMMIT_SMOKE=1`.
- Строгий режим (падение коммита при ошибке smoke): `SOUL_PRECOMMIT_STRICT_SMOKE=1`.
- Допустимые операции в smoke: только read-only инспекторы Hyperloop (`INSPECTOR.RUN key=planning.enforce`, `INSPECTOR.RUN key=guard.canonical.urls`) и проверка ветки в DRY_RUN (`DEV.CONNECT owner=<tg> branch=<key> DRY_RUN` при наличии `SOUL_TG_ID` и `SOUL_BRANCH`).
- Любые команды с побочными эффектами (изменения БД, FLAGS.SET и т.п.) запрещены в pre-commit.
- Результаты smoke фиксируются в артефакте `reports/precommit_smoke.txt`.

### 5.3 Docs Parity Guard (routes & ENV)

- Скрипт `scripts/guard_repo_parity.py` сравнивает:
  - актуальные маршруты бэкенда (`backend/app/routers/*`) с `docs/API_ROUTES_INDEX.md`;
  - список ENV из `docs/ENV_INDEX.md` с упоминаниями в P‑серии (`Soul/P*.md`) и `docs/PROJECT_STRUCTURE*.md`.
- Поведение:
  - Предупреждает о несовпадениях; при флагах `SOUL_STRICT_DOCS=1` и/или `SOUL_STRICT_ENV=1` — возвращает ошибку и блокирует коммит.
  - Проверяет, что мастер‑реестр документов `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY*_*.md` содержит ссылки на `ENV_INDEX.md` и `API_ROUTES_INDEX.md` (warning).
- Интеграция: запускается в pre-commit после генерации индексов.

## 6. Набор минимально необходимых команд Hyperloop (согласование с P58)
- `INSPECTOR.RUN key=plan.branch action=claim_branch owner="<tg>" branch="<b>" topic="<t>" session="<sid>"`
- `PROJECT.LIST`
- `PROJECT.GET id=<pid>`
- `PLAN.TASK.ADD project_id=<pid> title="..." [cpm_duration_days=<float>]`
- `PLAN.CPM.CALC project_id=<pid> WITH TRACE`

## 7. Прозрачность и метрики
- Экспортировать p95 для DEV.CONNECT/Hyperloop; инциденты P50 — человекочитаемые, с рекомендациями.

## 8. Критерии приёмки
- `.cursorrules` проходит инспектор `guard.canonical.urls` без нарушений.
- Hyperloop смоки успешны (health, PROJECT.LIST, CPM.CALC на тестовом проекте).
- Реестры документов обновлены и ссылаются на данное ТЗ.
- Новый worktree успешно выполняет bootstrap; `docs/ENV_INDEX.md` и `docs/API_ROUTES_INDEX.md` обновляются на каждом коммите через pre‑commit.


