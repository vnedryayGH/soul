# M16 — Embedded/Hardware (v1.0)

Цель: поставка прошивок/железа с управлением ревизиями и тестами.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Requirements → HW/SW Design → Prototype → Validation → Production.

Алгоритмы/метрики: Yield, p95 latency, Field Failure Rate.

Роли: HW Engineer, FW Engineer, QA.

DSL: BOM.SET, FW.RELEASE, TEST.STAND.RUN, METHODOLOGY.SET.

Acceptance: BOM/версии в БД; панели HW/FW.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
