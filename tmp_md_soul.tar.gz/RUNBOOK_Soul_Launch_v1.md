# RUNBOOK: Запуск Соул (test → prod, полная замена)

## Подготовка (test)

1. Применить `seeds_soul_rbac_v1.sql` (dev/test).
2. Задать переменные окружения по `env_soul_example.txt`.
3. Разместить промпты и конфиги:
   - `soul_core_prompt_human_fusion_v2_9.json`
   - `soul_quant_router_v1_1.json`
   - `modules_registry_v1.json`, `orchestrator_mapping_v1.json`, `context_policies_v1.json`
4. Включить `SOUL_ROUTER_ENABLED=true`.
5. Перезапустить backend воркеры/LLM-клиент.

## Проверка (test)

1. Health: `/api/soul/quants?limit=1` → 200
2. Маршрутизатор: прогоны из `router_test_cases_v1.json`.
3. Рождение Кванта: POST `/api/soul/process` с простым запросом → STRICT_JSON_QUANT.
4. Логи: зафиксировать `router_decision` и `_debug`.

## Выкат (prod, blue/green)

1. Поднять green‑инстанс с теми же настройками.
2. Применить seed‑RBAC и конфиги как на test.
3. Smoke‑тест: те же 3 шага проверки.
4. Переключить трафик (LB/ingress) на green.
5. Наблюдать метрики p95 времени и ошибок 15–30 мин.
6. Деактивировать blue.

## Откат

1. Переключить трафик обратно на blue.
2. Сохранить аудит и дампы; завести инцидент.

## Контрольный список

- [ ] 200 на health, 200 на quants
- [ ] STRICT_JSON_QUANT в ответах
- [ ] Решения роутера логируются
- [ ] desired_action autopublish > 0.6 работает
