---

## Индекс взаимных ссылок (P01–P37)

- P01 MeaningExtraction — гипотезы для извлечения смыслов.
- P03 RouterContext — гипотезы по выборке 30/70 и объёму контекста.
- P13 Eval — статистическая проверка гипотез.
- P14 MultiProviderRouting — A/B по провайдерам/моделям.
- P24 Integrated Tests — сценарии проверки.
- P28 FeatureFlags — включение веток A/B.
- P35/36 — исполнение гипотез в процессах/через DSL.

### ТЗ P04 — Гипотезы и эксперименты (Sandbox + A/B альтернативных правил)

Дата: 2025‑09‑14
Приоритет: P04 (ускорение развития, безопасно)
Статус: Реализовано (полный A/B контур + Hyperloop DSL)

---

### 0. Executive summary

- Цель: безопасно проверять гипотезы (альтернативные модули/правила/параметры) на офлайн‑наборах без влияния на прод‑память и включать победителей после ручного подтверждения.
- Интеграция: `experiments_service.py` + Hyperloop DSL (`EXPERIMENTS.*`) + санкбокс (stateless, `TEST_NO_DB`), KPI (валидность JSON, clarity/actionability, latency, cost), отчёт.
- Результат: ускоренная эволюция правил без регресса качества и без риска дрейфа личности.

---

### 1. Компоненты

- `experiments_service.py` — регистрация гипотез, план A/B, сбор метрик, публикация победителя через overrides (`soul_settings`).
- Санкбокс: отдельный поток без записи в основную память (`TEST_NO_DB`/изолированный storage).
- Набор KPI: JSON validity, clarity/actionability (mini‑judge), latency, cost.

Хранилище (создаётся IF NOT EXISTS на лету, Alembic не требуется):

- `experiments_hypotheses(id, key, variant_a, variant_b, notes, created_at, updated_at)`
- `ab_runs(id, hypothesis_key, started_at, finished_at, status, total_cases, kpi, winner)`
- `ab_results(id, run_id, hypothesis_key, case_idx, variant, kpi, raw, created_at)`

Контракты (Pydantic):

```python
class HypothesisSpec(BaseModel):
    key: str  # например, "module.flow.prompt.v2"
    variant_a: Dict[str, Any]
    variant_b: Dict[str, Any]
    notes: Optional[str]

class ABPlan(BaseModel):
    cases_path: str
    max_cases: int
    judge_profile: Optional[str] = None

class ABReport(BaseModel):
    kpi: Dict[str, Any]
    winner: Literal["A","B","tie"]
    delta: Dict[str, float]

```

---

### 2. Алгоритм (MVP)

1) Сгенерировать гипотезу (альтернативная секция модуля/правило).
2) Прогнать N кейсов (golden‑subset) на A и B.
3) Сравнить KPI; если B ≥ A + порог — пометить «кандидат к включению».
4) Включение — вручную через флаг/PR; запись источника и причин.

Пороговые KPI (пример):

- JSON validity (B − A) ≥ +0.5%
- Clarity/Actionability: обе ≥ baseline −1%, и минимум одна ≥ +2%
- Latency p95: не хуже A более чем на 10%

---

### 2.1. Hyperloop DSL (P36) — команды для P04

Поддерживаются команды (через `POST /api/hyperloop/execute`, тело: `{ "commands": "..." }`):

```text
EXPERIMENTS.REGISTER key=<str> a_json={<overridesA>} b_json={<overridesB>} [notes="..."]
EXPERIMENTS.AB.RUN key=<str> [cases_path=<path>|cases="c1|c2|..."] [case=<single>] [n=<int>] [reflect=<true|false>]
EXPERIMENTS.AB.PUBLISH key=<str> [winner=A|B]

```

Параметры/правила:

- `overrides*` — словарь ключей настроек (например, `{"router.hybrid_retrieval.enabled": true, "recent_ratio": 0.35}`) либо строка `k1=v1;k2=v2`.
- `cases|case|cases_path` — список кейсов (строк) или путь к файлу (JSON‑lines/строки).
- `n` — максимум кейсов (1..200), по умолчанию 20.
- `reflect=false` — выключить интроспекцию для ускорения (latency‑чувствительные смоки).
- Выход AB.RUN: `{ status, run_id, kpi: {A,B}, winner, delta }`.
- Публикация применяет overrides победителя в `soul_settings` (идемпотентно).

Примеры:

```text
EXPERIMENTS.REGISTER key=p04.hybrid_router_profile a_json={"router.hybrid_retrieval.enabled":false,"recent_ratio":0.2} b_json={"router.hybrid_retrieval.enabled":true,"recent_ratio":0.35}
EXPERIMENTS.AB.RUN key=p04.hybrid_router_profile cases="health|batch" n=2 reflect=false
EXPERIMENTS.AB.PUBLISH key=p04.hybrid_router_profile winner=B

```

Наблюдаемость (P27): шаги `cmd.hyperloop.experiments.*` пишутся в `signature_steps` вместе с trace_id.

### 3. Настройки/метрики

- `experiments.enabled=true`, `experiments.sandbox=true`
- Метрики: win‑rate, p95, стоимость, JSON validity.

Аудит:

- `ab_started` {hypothesis, cases}
- `ab_finished` {winner, kpi}
- `ab_publish_requested` {hypothesis}

Системные ключи, часто используемые в гипотезах (через overrides):

- `router.hybrid_retrieval.enabled` (bool)
- `recent_ratio` (float)
- `llm_temperature_default` (float), `max_tokens_default` (int)
- `meta.max_tokens` (int)

---

### 4. Безопасность/приватность

- Санкбокс stateless, без записи в прод‑память; PII‑санитизация кейсов и логов.
- Publish только руками через PR/флаг; хранить обоснование.

---

### 5. Acceptance

- Hyperloop: `EXPERIMENTS.REGISTER` → ok; `EXPERIMENTS.AB.RUN` → ok с `kpi` и `winner`; `EXPERIMENTS.AB.PUBLISH` → ok, `applied` отражает применённые ключи.
- Подпись (P27): присутствуют шаги `cmd.hyperloop.dispatch`, `cmd.hyperloop.experiments.*`.
- Sandbox/stateless режим: LLM‑вызовы допустимы с `db=None`; в stateless `desired_action=[]`.
- Логи/5xx — отсутствуют; latency для reflect=false в пределах таймаутов Nginx/systemd.

---

### 6. Ссылки

- Golden/Eval: `Soul/P13_TZ_Soul_Eval_v1_0.md`

---

### 7. Отметка принятия (2025-09-20)

- Реализованы: сервис экспериментов, A/B раннер, агрегация KPI, публикация победителя.
- Интеграция в Hyperloop DSL: `EXPERIMENTS.REGISTER`, `EXPERIMENTS.AB.RUN`, `EXPERIMENTS.AB.PUBLISH` (фиксация шагов в подписи P27).
- PROD смоки: регистрация гипотезы (ok), локальные AB.RUN (n=1,2; reflect=false) — ok, `winner=tie` (B демонстрирует лучшую latency при паритете качества), публикация `winner=B` — ok.
- Без регресса: stateless batch возвращает `desired_action=[]`; аудит/логи чистые; Nginx/systemd таймауты выдержаны.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
