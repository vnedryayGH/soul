### P36 — ТЗ «Гиперлуп» (Hyperloop DSL): безопасный командный интерфейс управления ядром Soul

#### 1. Назначение и цели

- **Цель**: предоставить единый, быстрый и безопасный интерфейс управления ядром Soul и системными службами (фичефлаги, санитайзеры, тесты, уставы, заявления) для людей, сервисов и LLM‑агентов.
- **Задачи**:
  - **Единый язык команд (DSL)** для минимизации ошибок и ускорения операций.
  - **Безопасность по умолчанию**: RBAC, двухключевой режим, dry‑run, проверка инвариантов (P27 Delivery Guard), полная трассировка шагов подписи.
  - **Наблюдаемость**: аудит, метрики, P27‑подпись (trace_id, signature_steps, incidents).
  - **Интеграция** с Mother of Flags, Father of Sanitizers, Gendarme, Judge, Archivarius, SoulSettingsService.

#### 2. Обоснование и мировой опыт

- **Практики**: Terraform/HCL, OpenFeature (LaunchDarkly/Flagd), Kubernetes (kubectl/kustomize), OPA/Policy‑as‑Code, AWS SSM Run Command.
- **Выводы для Soul**:
  - Читаемый **key=value** синтаксис + встроенный JSON даёт баланс скорости/строгости.
  - **Dry‑run/plan** и **policy‑gate** обязательны до применения.
  - **Idempotency** и **атомарность** команд уменьшают риск сбоев.
  - **Трассировка** (P27) и **RBAC+Two‑Keys** критичны для чувствительных действий.

#### 3. Область охвата

- Управление флагами и настройками (Feature Flags, SoulSettingsService).
- Управление санитайзерами (шаблоны «Father of Sanitizers»).
- Управление реестром тестов и их запуск (Gendarme).
- Управление уставами, проверки код‑политик (Judge).
- Сервисные заявления и статусы (Archivarius).
- Трассировка и Delivery Guard.

#### 4. Интерфейс (API)

- **POST /api/hyperloop/execute** (RBAC: `soul.admin` и `architect`)
  - Headers: `X-Telegram-User-ID: <admin_tg_id>`
  - Body:
    - `commands`: строка многострочного DSL
    - `options?`: `{ "dry_run": false, "stop_on_error": true }`
  - Response 200:
    - `results: [{ command, ok, data?, error? }]`
    - `signature: { trace_id, steps: [...] }`
    - `audit_ids: string[]`

#### 5. Командный язык (DSL)

- **Общее**:
  - Одна команда на строку; комментарии: `# ...`
  - Параметры: `key=value`; строки — в кавычках; JSON — `{...}`;
  - Модификаторы безопасности: `DRY_RUN`, `WITH TRACE`, `EXPECT key=value`, `IF key==value`, `TWO_KEYS`, `TIMEOUT=5000`.
- **Группы команд**:
  - FLAGS:
    - `FLAGS.SET key=delivery_guard.enforce value=true`
    - `FLAGS.UNSET key=diagnostic.visible_reply`
    - `FLAGS.APPLY_PROFILE name=prod_safe`
    - `FLAGS.RECONCILE policy=p27`
  - SANITIZER:
    - `SANITIZER.ADD name=visible_text pattern="\\[АНАЛИЗ\\][\\s\\S]*?\\[/АНАЛИЗ\\]"`
    - `SANITIZER.PREVIEW text="..."`
    - `SANITIZER.REMOVE name=visible_text`
  - TEST (Gendarme):
    - `TEST.REGISTER key=p27_guard_chain title="P27 Guard" severity=high`
    - `TEST.RUN key=p27_guard_chain`
    - `TEST.LIST filter=category:p27`
  - JUDGE:
    - `JUDGE.CHARTER.UPSERT name=code_safety version=1.0 text="..."`
    - `JUDGE.CHECK code="{...}"`
  - REQUEST (Archivarius):
    - `REQUEST.CREATE type=feature subject="Включить Guard" payload={"key":"delivery_guard.enforce","value":true}`
    - `REQUEST.STATUS id=<uuid>`
  - TRACE/GUARD:
    - `TRACE.STEPS trace_id=<uuid>`
    - `GUARD.REQUIRE chain="svc.soul.preanalysis,svc.soul.router_decide,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"`

#### 6. Грамматика (упрощённая)

- `COMMAND := IDENT ('.' IDENT)* SP PARAMS? MODS?`
- `PARAMS := (KEY '=' VALUE) (SP KEY '=' VALUE)*`
- `VALUE := STRING | NUMBER | TRUE | FALSE | JSON_OBJECT`
- `MODS := (SP (DRY_RUN|WITH TRACE|TWO_KEYS|EXPECT KEY '=' VALUE|IF KEY OP VALUE|TIMEOUT '=' NUMBER))*`

#### 7. Безопасность

- **RBAC**: `soul.admin` и `architect`; команды уровня архитектора (промпты сознания, уставы) — только `architect`.
- **Two‑Keys**: для опасных операций (изменение уставов, профилей флагов).
- **Dry‑Run**: доступен для всех команд; по умолчанию обязателен для неизвестных/небезопасных шаблонов.
- **Policy‑Gate**: Delivery Guard (P27), инварианты профиля (Mother of Flags), проверки Judge.
- **Аудит**: запись событий, P27 шагов подписи и инцидентов при нарушении.

#### 8. Интеграция с P27 (подписи/инциденты)

- Каждая команда порождает шаги подписи:
  - `cmd.hyperloop.dispatch` — разбор/маршрутизация;
  - `cmd.hyperloop.<group>.<action>` — исполнение;
  - при нарушениях — `signature_incidents` с деталями.
- `trace_id` возвращается в ответе; шаги дублируются в `signature_steps`.

#### 9. Потоки исполнения

1) Приём DSL → нормализация → парсинг → валидация (RBAC/Two‑Keys/IF/EXPECT) →
2) Построение `SignatureContext` (P27) → диспетчеризация к сервису →
3) Dry‑Run/Apply → Delivery Guard/политики → аудит → ответ.

#### 10. Совместимость и отказоустойчивость

- Команды — атомарные; при `stop_on_error=true` пакет останавливается на первой ошибке.
- Idempotency: повторное выполнение SET того же значения — `ok` без побочного эффекта.
- Ошибки — детерминированные коды/сообщения, 200 с `ok=false` для бизнес‑ошибок.

#### 11. Миграции и данные

- Используются существующие таблицы: `soul_settings`, `signature_steps`, `signature_incidents`, `soul_audit_log`.
- (Опционально v2) `hyperloop_audit` (DDL можно добавить в будущей версии при необходимости расширенного аудита).

#### 12. Реализация (MVP)

- `backend/app/services/hyperloop_engine.py` — парсер и диспетчер команд.
- `backend/app/routers/hyperloop_admin.py` — `POST /api/hyperloop/execute`.
- Подключение роутера в `app/main.py`.
- Интеграция с:
  - FeatureFlagsSupervisor/SoulSettingsService — FLAGS.*
  - SanitizerSupervisor — SANITIZER.*
  - GendarmeService — TEST.*
  - JudgeService — JUDGE.*
  - ArchivariusService — REQUEST.*
  - Signature SDK/Delivery Guard — TRACE/GUARD.*

#### 13. Тестирование

- Unit: парсер (позитив/негатив), диспетчеризация, dry‑run, EXPECT/IF.
- Интеграционные: FLAGS.SET/RECONCILE, SANITIZER.PREVIEW, TEST.RUN (dry‑run и реальный запуск), JUDGE.CHARTER.UPSERT (mock‑двухключевой режим).
- P27: наличие `trace_id`, шагов в `signature_steps`, инцидентов при нарушениях.

#### 14. Наблюдаемость и метрики

- Метрики: количество команд, успех/ошибки, доля dry‑run, латентность, частота Two‑Keys.
- Аудит: полные записи (кто/что/когда), ссылки на `trace_id`.

#### 15. Приёмка (Acceptance)

- **API доступен** и защищён RBAC.
- **Парсинг DSL**: ≥10 команд, включая FLAGS/SANITIZER/TEST/JUDGE/TRACE.
- **Dry‑Run** работает и не меняет состояние.
- **P27**: в ответе `trace_id`, шаги подписи сохранены; Delivery Guard блокирует выдачу при нарушении цепочки.
- **Документация**: примеры команд, правила безопасности, ошибки.

#### 16. Runbook (операции)

- Быстрая проверка:
  - `FLAGS.SET key=delivery_guard.enforce value=true`
  - `FLAGS.SET key=diagnostic.visible_reply value=false`
  - `TEST.RUN key=p27_guard_chain WITH TRACE`
  - `TRACE.STEPS trace_id=<...>`
- Диагностика:
  - Проверить `/api/hyperloop/execute` 200 и `results[].ok`.
  - Проверить `signature_steps` по `trace_id`.

#### 17. Раздел для LLM‑инженеров

- **Как использовать DSL**: формировать краткие команды из текущей задачи; по умолчанию — `DRY_RUN`, затем выполнять с `EXPECT`.
- **Инварианты**: не изменять уставы и критичные флаги без `TWO_KEYS`; следовать профилю `prod_safe`.
- **Отладка**: включать `WITH TRACE`, затем смотреть `TRACE.STEPS`/инциденты.
- **Шаблоны**:
  - «Включить Guard и скрыть диагностику»: две FLAGS.SET; затем TEST.RUN p27_guard_chain.
  - «Добавить санитайзер и проверить»: SANITIZER.ADD → SANITIZER.PREVIEW (DRY_RUN).

#### 18. Дорожная карта (после MVP)

- Полноценный парсер (ANTLR/PEG), автодополнение, мягкие алиасы команд.
- Расширенный two‑keys и политики Judge как предпроверка.
- Авто‑генерация документации по грамматике и справочник команд.

#### 19. Связанные документы

- P27: `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`
- P28: Feature Flags: `Soul/P28_TZ_FeatureFlags_Registry_and_Policies_v1_0.md`
- P29: Quality/Gendarme/Judge/Archivarius: `Soul/P29_TZ_Quality_Registry_Gendarme_and_Judge_v1_0.md`

#### 20. Расширение на коммуникации внутри Ядра (Core IPC на Hyperloop)

- Требование: все внутренние взаимодействия автоматических участников Ядра (RouterV2, SoulCoreManager, LLMClient, Parser, Persist, Dispatcher, Seeker, Mother of Flags, Father of Sanitizers, Gendarme, Judge, Archivarius) стандартизируются через язык команд Hyperloop.
- Новые группы команд (добавка к разделу 5):
  - CORE.PIPELINE:
    - `CORE.PIPELINE.RUN input_text="..." num_candidates=1 WITH TRACE` — запустить stateless‑pipeline ядра; вернуть краткий результат и `trace_id`.
  - CORE.MSG:
    - `CORE.MSG.AUDIT event="..." meta={...}` — записать событие в аудит Soul.
  - CORE.TRACE:
    - `CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.soul.router_decide,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"` — проверить наличие шагов (Delivery Guard).
- Политики:
  - Любой новый системный сервис, добавляющий фоновые/оркестрационные взаимодействия, обязан принимать/использовать Hyperloop‑команды как управляемый контракт.
  - Для чувствительных операций — TWO_KEYS + Judge‑политики как предусловие.
- Реализация (MVP):
  - В движке реализованы обработчики `CORE.PIPELINE.RUN`, `CORE.MSG.AUDIT`, `CORE.TRACE.REQUIRE`.
  - Для остальных команд определены спецификации; по мере внедрения сервисов добавляем обработчики в движок.

#### 21. Связи с другими ТЗ

- P27 (Signature & Data Lineage): шаги подписи для каждой команды; инциденты при нарушении инвариантов; `trace_id` в ответе.
- P28 (Feature Flags): FLAGS.* команды управляют Mother of Flags; reconcile/profiles и policy‑gate через P28.
- P29 (Quality/Gendarme/Judge/Archivarius): TEST.*, JUDGE.*, REQUEST.* команды и политики двух ключей.
