# План миграции v1.5: интеграция quant-aware роутера в бэкенд

Цель: подключить `soul_quant_router_v1_1.json` к конвейеру `SoulCoreManager`, чтобы активная Цель и текущий Квант Потока влияли на выбор модулей промпта и стратегию контекста.

## Этап 1. Конфигурация и пути

- Добавить пути загрузки JSON:
  - `Soul/soul_core_prompt_human_fusion_v2_9.json` (основной промпт)
  - `Soul/soul_quant_router_v1_1.json` (роутер)
  - Модули: `ved_prompt`, `flow_prompt`, `klee_prompt`, `prompt-4.json` (Тихий Чехов)

## Этап 2. API данных Потока

- Расширить `SoulContextService`:
  - `get_active_goal() -> {id, priority, tags, is_active}`
  - `get_current_quant(thread_id) -> {id, energy_weight, tags, distance_to_goal, entanglement_to_goal, flow_position}`
  - `get_flow_context_summary(thread_id) -> {recent_quants, cluster_entropy, avg_energy_weight}`

## Этап 3. Вызов роутера

1) На входе `POST /api/soul/process` собирать input для роутера.
2) Прогонять через лёгкую LLM (или локальный интерпретатор правил) `soul_quant_router_v1_1.json`.
3) Получать решение: `modules_order`, `context_load_policy`, `context_filters`, `goal_bias`, `boost_quants`.

## Этап 4. Формирование контекста (30/70_v2 + фильтры)

- Применить стратегию:
  - `recent`: последние сообщения
  - `deep`: поиск по связям/тегам/весу
  - `balanced`: 30% последние + 70% глубина
- Наложить `context_filters`:
  - min_energy_weight, include/exclude теги
  - prefer_connections: semantic/emotional/temporal/entanglement
  - при `boost_quants` — принудительно включить указанные id

## Этап 5. Сборка промпта

- Всегда: загрузить v2.9 core
- По решению роутера: добавить `klee`, `flow`, `ved`, `chekhov` (строгий порядок `modules_order`)
- Проставить `persona_bias` в системных инструкциях стиля

## Этап 6. Генерация и пост‑обработка

- Вызвать LLM → получить STRICT_JSON_QUANT
- Если есть `architect_feedback_processing` триггеры (по событию UI) — применить логику усиления/ослабления весов
- При выполнении `ritual_use_policy` — проверка (energy_weight, priority, теги)

## Этап 7. Логирование и аудит

- Сохранять решение роутера в `soul_audit_log` (event_type: `router_decision`)
- Хранить `_debug` из Кванта (если присутствует)

## Этап 8. Тесты

- Юнит: парсинг `soul_quant_router_v1_1.json` и маппинг в `ContextPlan`
- Интеграционные: сценарии crisis/goal_high/entanglement_high/entropy_high
- Нагрузочные: проверка экономии токенов и времени подбора контекста

## Готовность к релизу

- Флаги: `SOUL_ROUTER_ENABLED=true` на dev
- Ролл‑аут: dev → staging → prod, мониторинг ошибок, p95 времени и доли успешных desired_action
