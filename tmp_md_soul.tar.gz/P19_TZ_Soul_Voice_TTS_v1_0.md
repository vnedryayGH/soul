---

## Индекс взаимных ссылок (P01–P37)

- P20 TelegramBots Platform — голосовой вывод в Mini App.
- P23 UI Spec — состояния/элементы управления голосом.
- P33 Personification — язык/тон (опционально) для TTS.

### ТЗ Soul v1.0 — Голосовой модуль (TTS: текст → речь для ответов)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: К реализации (MVP без миграций; Stage‑2 — кеш/вложения/стриминг)

---

### 0. Executive summary

- Цель: озвучивать ответы по желанию пользователя; аналитика и память остаются текстовыми.
- Интеграция: условный шаг после генерации текста и перед отправкой в чат. Параметры — из пользовательских настроек. Без миграций.

---

### 1. Архитектура и точки интеграции

- Новые сервисы:
  - `backend/app/services/tts/tts_service.py` — маршрутизация провайдера, синтез, нормализация.
  - `backend/app/services/tts/audio_encode.py` — конвертация в OGG/Opus (voice) и MP3/M4A (audio).
- Обновления:
  - `chat_service.py` — при отправке ответа: читать настройки; если TTS включён, синтезировать и отправлять voice/audio согласно режиму.
  - `SoulSettingsService` — глобальные дефолты.
  - Admin/UI — секция настроек TTS в мини‑приложении.

---

### 2. Пользовательские настройки (mini‑app)

- Переключатель: «Озвучивать ответы» (on/off)
- Режим: `voice_only | voice_and_text`
- Провайдер/голос: список голосов (локаль/пол/тембр)
- Параметры: скорость (0.5–2.0), тон (pitch), громкость (опц.)
- Команда активации: фраза/ключ (текст/голос через ASR)

Пример JSON:

```json
{
  "tts": {
    "enabled": true,
    "mode": "voice_and_text",
    "provider": "yandex_tts",
    "voice": "oksana",
    "rate": 1.0,
    "pitch": 0.0
  }
}

```

---

### 3. Провайдеры TTS (плагин)

Интерфейс `TTSProvider`:

- `synthesize(text:str, *, lang:str, voice:str, rate:float, pitch:float) -> { audio_bytes:bytes, content_type:str, duration_sec:float }`

Реализации: `yandex_tts`, `google_tts`, `azure_tts`, `elevenlabs_tts`, `gigachat_tts`.

---

### 4. Алгоритм отправки ответа с голосом

1) Ядро сформировало `reply_text`.
2) Прочитать настройки пользователя (`tts.enabled` и др.).
3) Если выключен — отправить текст (выход).
4) Если включён:

   - Подготовить текст для озвучки (усечение/нормализация, max `tts.max_chars`).
   - `TTSService.synthesize(...)` по параметрам пользователя.
   - Конвертировать в формат отправки: Telegram voice (OGG/Opus) или audio (MP3/M4A).
   - Отправить: `voice_only` или `voice_and_text` (порядок — опция).

5) В БД хранить текст как и прежде; идентификаторы голосовых — опц. (Stage‑2).

Фоллбек: при ошибке TTS — отправить только текст, аудит `tts_fail`.

---

### 5. Настройки/флаги (SoulSettingsService)

- `tts.enabled=false`
- `tts.default_provider="yandex_tts"`
- `tts.default_voice="oksana"`
- `tts.default_rate=1.0`
- `tts.default_pitch=0.0`
- `tts.max_chars=1200`
- `tts.timeout_ms=10000`
- `tts.mode_default="voice_and_text"`
- `tts.opus_bitrate_kbps=16`

ENV: ключи провайдеров; путь к `ffmpeg`.

---

### 5.1 Параметры качества для Telegram

- Для sendVoice используем OGG Opus mono 48 kHz, рекомендуемый битрейт 96 kbps.
- Допускается FX‑пост‑обработка для профилей (pitch/equalizer/compressor) перед кодированием Opus.

### 11. Реестр голосов и выбор (мини‑приложение)

- Реестр: `tts.registry` (JSON: id→{provider, model, display_name}).
- Таблицы: `persona_voice_profile`, `user_persona_voice` — хранение выбора по персоне/пользователю.
- API:
  - `GET /api/voice/voices` — список доступных голосов (реестр + обнаруженные Piper модели).
  - `POST /api/voice/set_voice` — `{ persona_key?, voice_id, rate?, pitch? }` → сохраняет выбор (персона или дефолт).
- Профиль «Faina»: алиас `faina` на модель без акцента (например, `ru_RU-kseniya-medium`) с FX‑обработкой (понижение pitch, эквалайзер низов, компрессия).

---

### 6. Безопасность/приватность

- Перед TTS прогонять текст через `privacy_sanitizer`.
- Guard: TTS — только вывод; действий/команд не исполняет.
- Ограничивать длину/объём по лимитам провайдера/Telegram.

---

### 7. Наблюдаемость и аудит

События: `tts_request`, `tts_done`, `tts_fail`.
Метрики: `tts.p95_ms`, `tts.err_rate`, `tts.provider_usage`, `tts.mean_chars`, `tts.audio_duration_mean`.

---

### 8. Acceptance

- При включении TTS — ответы озвучиваются по параметрам; отправка voice/voice+text корректна.
- В БД — только текст; голос не влияет на память/ретривал.
- При ошибке синтеза — текст отправляется, `tts_fail` логируется.
- При отключении — поведение неизменно.

---

### 9. Stage‑2 (опционально)

- Кеш аудио (ключ: hash(text+voice+rate+pitch+lang)) с TTL.
- Вложения: `attachments`/`message_attachments`, авто‑очистка.
- Длинные ответы: авто‑суммаризация для TTS, разбиение на несколько voice‑сообщений.
- Стриминг (если провайдер поддерживает), индикатор прогресса.

---

### 10. Метрики, SLO, алерты

- Метрики: `tts.p95_ms`, `tts.err_rate`, `tts.provider_usage`, `tts.mean_chars`, `tts.audio_duration_mean`
- SLO: `tts.p95_ms ≤ 3000ms`, ErrRate ≤ 2%
- Алерты: `err_rate > 5%` (10мин), `p95_ms > 5s` (10мин)

---

### 2. Тест‑план

- Unit: кодеки/ffmpeg конвертация, лимиты длительности/битрейта, параметры голоса
- Integration: голос+текст режимы, корректность отправки в Telegram
- Perf: длинные ответы (разбиение/кеш) — удержание SLO

---

### 3. Rollout

- DEV: один провайдер (SpeechKit/Google), проверка ключей/лимитов
- STAGE: добавление второго провайдера, сравнение p95/качества
- PROD: gradual rollout; включение кеша аудио (Stage‑2)


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
