# P50 — ТЗ: Система управления инцидентами (Incident Management) v1.0

Назначение: ввести в Ядро Соул полноценную систему управления инцидентами (далее — Система Инцидентов), охватывающую обнаружение, тряж, эскалацию, расследование, устранение первопричин, верификацию и постмортем. Система интегрируется с P27 подписью/происхождением, P29 инспекторами/Жандармом, P30 Процессором, P21 метриками/наблюдаемостью, P25 Навыками, P38 Обучением/нейро‑циклом, P40 Планированием/Проектами, P48/RS мостом и Hyperloop DSL (P36). Без регрессий; без локальных JSON в качестве источника правды — только БД.

---

## 1. Термины и границы

- Инцидент (Incident): событие нарушения нормальной работы или риска её нарушения, требующее реакции. Имеет степень серьёзности (Severity) и приоритет (Priority), статусный поток и связанные сущности.
- Проблема (Problem): выявленная первопричина класса инцидентов; фиксируется как знание (KB) и/или «Протокол устранения» (Runbook).
- Известная ошибка (Known Error): документированный дефект с обходным решением до постоянного исправления.
- MTTA/MTTR: среднее время до реакции/восстановления.
- Постмортем: отчёт по закрытому инциденту с RCA, действиями, предотвращением рецидива.

Границы: Система Инцидентов не заменяет P40 проектные задачи, а дополняет их. Часть задач по факту являются инцидентами — они переводятся в Систему Инцидентов (связываются с `plan_tasks`) и устраняются по процессу IM. Все операции идут через API/DSL и БД.

---

## 2. Цели и требования

2.1. Функциональные:

- Авто‑создание инцидентов из источников: инспекторы P29, метрики/алерты P21, Delivery Guard P27 (отсутствие обязательных шагов), ошибки API/RS, сбои процессов P30, фронтенд‑алерты.
- Ручное создание/редактирование через DSL и админ‑UI.
- Полный жизненный цикл: Detect → Triage → Assign/Escalate → Mitigate → RCA → Fix → Verify → Close → Postmortem.
- Дефолтные SLA/Severity/Priority матрицы и профили (в БД через `soul_settings`).
- Связи инцидента: трасса подписи (P27 trace_id), кванты/цели, процессорные события, задачи проекта (P40), навыки (P25), персона/роль, RS‑акторы.
- Постмортем генерация (через LLM + факты из БД/трасс) с шаблонами и валидацией P27/P29.

2.2. Нефункциональные:

- Наблюдаемость: счётчики/гистограммы/гейджи Prometheus, отчёты и дашборды; p95 стадий triage/rca/fix.
- Безопасность/RBAC (P44): доступы по ролям; Two‑Keys на операции закрытия серьёзных инцидентов и изменения RCA.
- Строгая идемпотентность DSL‑команд и детерминированные схемы JSON.

---

## 3. Модель данных (БД)

Новые таблицы (alembic миграция, версии согласовать с существующими скриптами):

1. incidents

- id uuid PK
- title text not null
- description text
- severity smallint not null default 3  (1 — критический, 2 — высокий, 3 — средний, 4 — низкий)
- priority smallint not null default 3   (1 — p1, 2 — p2, 3 — p3, 4 — p4)
- status text not null default 'open'    ('open','ack','in_progress','mitigated','verifying','closed','reopened')
- detected_at timestamptz not null default now()
- acknowledged_at timestamptz
- resolved_at timestamptz
- closed_at timestamptz
- source text not null                    (inspector|api|processor|frontend|rs|manual)
- trace_id uuid                           (P27)
- root_cause text                         (RCA итог)
- resolution text                         (итоговое исправление)
- runbook_id uuid                         (ссылка на актуальный протокол)
- plan_task_id uuid                       (P40 связь, опционально)
- reporter_tg_id bigint                   (инициатор)
- assignee_tg_id bigint                   (ответственный)
- tags text[] default '{}'
- meta jsonb not null default '{}'        (структурированные поля источников)
- created_at timestamptz not null default now()
- updated_at timestamptz not null default now()

1. incident_events (история/таймлайн)

- id uuid PK
- incident_id uuid FK → incidents(id)
- kind text not null   ('status_change','note','metric','link','rca_update','assignment','escalation')
- details jsonb not null default '{}'
- author_tg_id bigint
- created_at timestamptz not null default now()

1. incident_links (связи с сущностями)

- id uuid PK
- incident_id uuid FK → incidents(id)
- to_kind text not null ('plan_task','quant','goal','processor_event','skill','rs_actor','document','trace')
- to_id text not null
- relation text not null default 'relates_to' ('caused_by','duplicate_of','blocks','relates_to')
- created_at timestamptz not null default now()

1. incident_runbooks (протоколы устранения)

- id uuid PK
- title text not null
- content markdown text not null
- created_by_tg_id bigint
- created_at timestamptz not null default now()
- updated_at timestamptz not null default now()

1. incident_kb (известные проблемы/кейсы)

- id uuid PK
- signature text unique                     (нормализованная сигнатура проблемы)
- summary text not null
- recommended_runbook_id uuid FK → incident_runbooks(id)
- examples jsonb not null default '[]'
- created_at timestamptz not null default now()
- updated_at timestamptz not null default now()

Индексы: по `severity`, `status`, `detected_at`, `trace_id`, `to_kind+to_id`, `signature`.

Инварианты:

- Все поля времени — UTC; UI использует `user_tz` только для отображения (как в [frontend/**] политиках).
- Никаких локальных JSON; только БД + аудиторские трассы (P27/P11).

---

## 4. Интеграции и источники

4.1. P27 Delivery Guard/Provenance (обязательные шаги):

- При создании/обновлении инцидента фиксировать шаги `svc.incident.*` и сохранять `trace_id` источника (если есть).
- Проверка наличия ключевых шагов инспекторами P29.

4.2. P29 Жандарм/Инспекторы:

- Инспекторы могут генерировать инциденты при нарушениях (например, `rs.performance_sla`, `delivery_guard.enforce`, `rs.security_limits`).
- Ключи инспекторов включаются в `meta.inspector_key`.

4.3. P21 Метрики/Алерты:

- Алерты из мониторинга инициируют `INCIDENT.CREATE` (источник `metric`/`api`), прикладывают снэпшоты метрик.

4.4. P30 Процессор/Последовательности:

- События Processor (analyze→search→answer/deliver→persist/learn) могут инициировать инциденты и добавлять события в таймлайн.
- Эскалация к Архитектору создаёт задание для LLM‑агента по номеру инцидента (см. 6.3).

4.5. P25 Навыки/Обучение P38:

- Инциденты помечаются навыками (skill keys) для маршрутизации к профильным агентам/алгоритмам.
- KB/Runbook используются Тренером (P38) для «лучших практик» при генерации решений.

4.6. P40 Проекты/Задачи:

- Задачи, являющиеся инцидентами, переводятся в `incidents` с сохранением `plan_task_id`. Дублирование запрещено (валидатор по связям).
- Обратная связь: закрытие инцидента может завершать связанные задачи/зависимости.

4.7. P48/RS мост:

- Инциденты класса RS фиксируют `meta.rs_actor`, метрики p95 актёров/rsbus и backpressure; используются инспектора `rs.parity`, `rs.performance_sla`.

4.8. P40 Планирование — инциденты подключения

- Классы:
  - `planning_connect_failure` — фатальная ошибка подключения (url_malformed|timeout|auth_forbidden), источник `api/hyperloop`.
  - `planning_connect_degraded` — деградация (повторные таймауты/ошибки) без полной блокировки.
- `meta`: `{ "type": "url_malformed|timeout|auth_forbidden|quotes_error|header_missing", "request": {"cmd":"..."}, "trace_id": "..." }`.
- SLA дефолт: failure → severity=2, MTTA≤15m, MTTR≤4h; degraded → severity=3, MTTA≤30m, MTTR≤8h.
- Runbook (эскиз): проверить заголовки/URL; выполнить fallback файл+curl; при повторении — эскалация и диагностика, запись инспектора.
- Acceptance: авто‑создание по правилам из системного промпта `incident_on_failure`.

---

## 5. DSL (Hyperloop, P36)

Все команды — строго одна строка, детерминированные поля, read‑only/side‑effect по спецификации. Примеры:

- INCIDENT.CREATE title="..." severity=2 priority=2 source="inspector" payload={"meta":{"inspector_key":"rs.performance_sla"}}
- INCIDENT.UPDATE id={uuid} fields={"status":"in_progress","assignee_tg_id":468326902}
- INCIDENT.LINK id={uuid} to_kind="plan_task" to_id={uuid} relation="blocks"
- INCIDENT.CLOSE id={uuid} resolution="..." root_cause="..." WITH POSTMORTEM
- INCIDENT.POSTMORTEM.GENERATE id={uuid} WITH TRACE
- INCIDENT.LIST filter={"status":"open","severity_lte":2}
- INCIDENT.ASSIGN id={uuid} assignee_tg_id=468326902
- INCIDENT.ROUTE.TO_ARCHITECT id={uuid} reason="need_llm_assistance"
- INC.KB.SEARCH query="react error 300 mini app"
- INC.RUNBOOK.SUGGEST incident_id={uuid}

RBAC/Two‑Keys:

– Закрытие `severity=1` и изменение `root_cause` требуют Two‑Keys (см. P44/P22 фасады `two-keys`).

---

## 6. API (P22), UI (P23)

- `GET /api/admin/incidents` — список с фильтрами/пагинацией
- `GET /api/admin/incidents/{id}` — детали (+таймлайн, связи)
- `POST /api/admin/incidents` — создать
- `PATCH /api/admin/incidents/{id}` — обновить поля/статус
- `POST /api/admin/incidents/{id}/close` — закрыть (+RCA/Resolution)
- `POST /api/admin/incidents/{id}/events` — добавить событие
- `POST /api/admin/incidents/{id}/links` — добавить связь
- `POST /api/admin/incidents/{id}/route/architect` — эскалация к Архитектору (LLM агент)
- `GET /api/admin/incidents/metrics` — агрегаты/метрики

Безопасность: `require_role_or_higher('architect')` на закрытие/эскалацию уровня 1–2, `soul.admin` — полный доступ.

6.2. Frontend (минимум):

- Страницы: `/incidents`, `/incidents/{id}` (список, фильтры, детали, таймлайн, действия, связи, постмортем). Включить в меню Architect.

6.3. Архитектор/LLM агент:

- При `INCIDENT.ROUTE.TO_ARCHITECT` формируется структурированный запрос: `{ id, title, summary, recent_events[], linked_entities[], metrics_snapshot, kb_matches[], runbook_suggestion }`.
- Агент запускается с ключом инцидента; результаты (шаги/решения) сохраняются в `incident_events` и `resolution`.

---

## 7. Метрики и отчётность (Prometheus, отчёты)

Метрики (минимум):

- `incidents_created_total{severity,source}` (counter)
- `incidents_open_total` (gauge)
- `incidents_resolved_total{severity}` (counter)
- `incident_mtta_ms` / `incident_mttr_ms` (histogram)
- `incident_stage_latency_ms{stage}` — triage/rca/fix/verify (histogram)
- RS: `rs_actor_incidents_total{actor,reason}`

Отчёты/дашборды:

- Сводка p50/p95/пик по стадиям; топ‑источники; reopen‑rate; соответствие SLA; карта связей к задачам/квантам.

---

## 8. SLA/Политики

- Матрица Severity×Priority → целевые MTTA/MTTR и обязательные уведомления/эскалации.
- Сохранены в `soul_settings` под префиксом `incident.sla.*`; изменение — через DSL `DB.UPSERT` (см. P36/P21/P24 шаблоны).

---

## 9. Миграции и внедрение

- Alembic: `backend/alembic/versions/20250926_000080_p50_incident_management.py` — создание таблиц/индексов.
- Backend: роуты/сервисы `backend/app/services/incident_service.py`, `backend/app/routers/incidents_admin.py`; интеграция в мониторинг/инспекторы.
- Frontend: страницы, маршруты, компоненты фильтров/таблиц, карточки связей; обновление меню Architect.
- Инспекторы: базовые `incident.required_steps` (подписи P27), `incident.sla_enforcement` (нарушение SLA → событие/эскалация).

---

## 10. Приёмка (Acceptance)

Минимальные критерии:

- Авто‑создание инцидента из инспектора `rs.performance_sla` → статус `open`, severity=2, есть `trace_id`, в таймлайне причина; метрики отражаются.
- Ручное закрытие с RCA/Resolution записывает событие, обновляет `resolved_at/closed_at`, метрики MTTR.
- Эскалация к Архитектору формирует структурированный запрос и сохраняет ответ агента в `incident_events`; предлагаемый Runbook прикладывается.
- Метрики Prometheus экспортируются; UI отображает список/детали с фильтрами.

---

## 11. Риски и соответствие правилам

- Отсутствие ветки/плана (P40) — блокирующий риск: все внедрения должны быть привязаны к `plan_task.id` и ветке разработки.
- Безопасность/PII: запрещено логировать персональные данные; только id/служебные поля.
- Производительность: индексация по ключевым полям, пагинация/фильтры на API.

---

## 12. Связанные документы и модули

- P27_TZ_Signature_and_Data_Lineage_v1_0.md
- P29_TZ_Quality_Registry_Gendarme_and_Judge_v1_0.md
- P30_TZ_Soul_Processor_v1_0.md
- P21_TZ_Soul_Health_Monitoring_v1_0.md
- P25_TZ_Soul_Skills_Routes_v1_0.md
- P36_TZ_Hyperloop_DSL_v1_1.md
- P40_TZ_Project_Management_Soul_v1_0.md
- P48_TZ_LLM_Mirror_Project_Integration_v1_0.md

---

## 13. План дальнейших работ (в рамках P50)

- Миграции БД и сервис бекенда (admin API/DSL, P27 шаги, P29 инспекторы)
- Admin‑UI страницы и интеграция в хаб Архитектора (P23)
- Интеграция источников: инспекторы/метрики/Processor/RS
- Постмортем генерация + KB/Runbook связывание, обучение (P38)
- Приёмка/смоки/док‑обновления, обновление реестров

---

## Дополнение 2025‑09‑30 — Реализация и статус (P50)

Реализовано и проверено (e2e, PROD‑safe):

- Admin API (`backend/app/routers/incidents_admin.py`): создание, чтение, события, связи, эскалация `POST /api/admin/incidents/{id}/route/architect`, закрытие `POST /api/admin/incidents/{id}/close`, закрытие с постмортем `POST /api/admin/incidents/{id}/close_with_postmortem`.
- RBAC/Two‑Keys: роль `architect` требуется для операций эскалации/закрытия sev1/2; Two‑Keys обязателен для закрытия sev1/2 и правок RCA. Проверено e2e через заявки/аппрувы.
- Инспекторы: зарегистрированы и включены в `INSPECTOR.RUN_ALL` ключи `incident.required_steps`, `incident.sla_enforcement` (видны в Prometheus/UI инспекторов).
- Метрики (P21): экспортируются показатели `incidents_created_total`, `incidents_open_total`, `incident_mtta_ms`, `incident_mttr_ms`, `incident_stage_latency_ms{stage}`; проверены p50/p95 выборочно.
- Индексы БД: применены конкурентно `CREATE INDEX CONCURRENTLY IF NOT EXISTS` из `Soul/db_indexes_incidents.sql` по `incidents(status, severity, detected_at, trace_id)`, `incident_links(to_kind, to_id)`, `incident_events(incident_id)`.
- E2E‑скрипты: `Soul/inc_finalize.py`, `Soul/tk_admin_finalize.py` — последовательности: Two‑Keys request→approve → create → close (sev1) → route to architect → close_with_postmortem. Все шаги возвращают 200 OK.

Ограничения/остаток работ:

- Frontend (P23): страницы `/incidents`, `/incidents/{id}` — требуется реализовать UI (список/детали/таймлайн/действия), вкл. Postmortem просмотр/экспорт.
- Метрики/дашборды: добавить панели Prometheus/Grafana по `incidents_*` и `incident_stage_latency_ms{stage}`; интегрировать в существующие дашборды.
- Тесты P24: добавить целевые тесты для новых эндпоинтов/DSL/инспекторов (RBAC/Two‑Keys сценарии).
- Alembic: консолидация применённых индексов в ревизию `20250926_000080_p50_incident_management.py` (без даунтайма).
- Постмортем экспорт: PDF/MD экспорт и версионирование финального отчёта, подтверждение ролями в UI.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
