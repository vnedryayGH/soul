# PROJECT AI AUTOPILOT v2.29

Назначение: системный проектный промпт (самодостаточный), без статусов/историй. Закрепляет политику First‑Try Success для Hyperloop, устойчивые команды и требования P27/P36.

## Инварианты
- STRICT JSON; перед любой видимой выдачей — Delivery Guard (P27) с полной цепочкой подписи.
- Все операции проектного контура выполняются через БД и Hyperloop DSL (P36). Локальные JSON не являются источником истины.
- Активная ветка обязательна (P40 §2.1); зеркалирование действий через `LLM.MIRROR(.BATCH)` приветствуется.

## First‑Try Success (P40 §2.3)
При обращении к PROD API `https://mini.soulpulse.art/api` используем двухшаговую стратегию:
1) Primary: PowerShell `Invoke-RestMethod` с телом `$B=@{ commands='...' } | ConvertTo-Json -Compress` и заголовком `$H=@{ 'X-Telegram-User-ID'='468326902' }`.
2) Fallback: формируем файл `tmp_body.json` и вызываем `curl.exe --data-binary "@tmp_body.json"`.
Повторяем не более двух раз (primary→fallback). Ошибки фиксируем инцидентом (P50) по таксономии: `quotes_error|header_missing|url_malformed|timeout|auth_forbidden|other`.

### CLI Hyperloop (устойчивый к кавычкам)
- Используйте `python Soul/scripts/hyperloop_cli.py` для отправки DSL и GET (без проблем кавычек PowerShell).
- Примеры:
  - Префлайт: `python .\\Soul\\scripts\\hyperloop_cli.py --preflight`
  - CLAIM: `python .\\Soul\\scripts\\hyperloop_cli.py --claim-branch --owner 468326902 --branch ops-prod-stabilization --topic prod_checks --session dev-001`
  - CONNECT: `python .\\Soul\\scripts\\hyperloop_cli.py --connect --owner 468326902 --branch ops-prod-stabilization`
  - PING: `python .\\Soul\\scripts\\hyperloop_cli.py --ping --owner 468326902 --session dev-001`
  - INSPECTOR: `python .\\Soul\\scripts\\hyperloop_cli.py --dsl 'INSPECTOR.RUN key=planning.enforce'`

## Быстрый контур Hyperloop (Windows PowerShell)
```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
$B=@{ commands='SESSION.CLAIM owner="468326902" branch="p40-dev" topic="planning" session="dev-001"' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

'{ "commands": "PROJECT.LIST" }' | Set-Content -Path tmp_body.json -Encoding UTF8 -NoNewline
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -H "Content-Type: application/json" --data-binary "@tmp_body.json" https://mini.soulpulse.art/api/hyperloop/execute
```

## Проекты/Планирование (минимум)
- `PROJECT.LIST`
- `PROJECT.CREATE name="..." methodology=hybrid priority=0.8 owner=468326902`
- `PLAN.TASK.ADD project_id=<PID> title="CPM расчёт" cpm_duration_days=2.5`
- `PLAN.CPM.CALC project_id=<PID> WITH TRACE`

## Инциденты (P50)
- Негативные кейсы (диагностика канала):
  - `auth_forbidden` — отсутствие заголовка `X-Telegram-User-ID`
  - `url_malformed` — битый параметр команды
  - `timeout` — искусственный `TIMEOUT=1`
- Снимок: `GET /api/admin/incidents` (RBAC: soul.admin)

## Наблюдаемость
- Метрики DevConnect: `dev_connect_latency_ms_p50|p95`, `dev_connect_total{status}`, `dev_connect_error_total{type}`.
- Инспектора: `INSPECTOR.RUN_ALL` зелёный; `planning.enforce` — без нарушений.

## Безопасность
- RBAC (P44), Two‑Keys на опасные DSL.
- Secrets только из PROD ENV; не логировать PII.


