# P40 — ТЗ: Проектное управление Соул (Project Management in Soul Core)

Статус: v1.0 (самодостаточно); Канонично для процессов проектного управления в Ядре Соул (ЯС)

## 0) Executive Summary

Цель: внедрить в Ядро Соул структурированную систему проектного управления для малой команды с опорой на лучшие мировые практики (BPM/PMBOK/PRINCE2/Agile/Lean/ITIL/ISO 9001/Process Mining), обеспечив детерминированность процессов, сквозную подпись шагов (P27), управление фичами/политиками (P28), гейты качества (P29), исполнение под контролем Процессора (P30) и управляемость через Hyperloop DSL (P36). Проекты — группа взаимосвязанных процессов для достижения Целей. Вводится роль Менеджер, а также агентные роли: Администратор, Агент Управления Изменениями (АУ), Библиотекарь, Разработчик, Оптимизатор, Тестировщик, Аналитик, Шаблонизатор, Сисадмин, Интегратор, Рискмен.

Ключевые положения:

- Проекты/Планы/Задачи — сущности первого класса (БД/DSL/UI), со связями с Квантами/Целями/Напоминаниями.
- План‑факт, критический путь (CPM), EVM (Earned Value Management) — как детерминированные алгоритмы.
- Управление изменениями/рисками — процессы с эскалацией (Two‑Keys, Судья/Жандарм) и обратной связью в P30.
- Hyperloop DSL расширен: PROJECT.*, PLAN.*, TASK.*, RISK.*, CHANGE.*, LIB.*; WITH TRACE, DRY_RUN, TIMEOUT.
- Acceptance: без регресса функционала; обязательная цепочка P27; статлес‑смоки выполняются.

## 0.1) Соответствие процедуре создания (шаги 1–7)

1) Критический анализ Report_Soul_AI_Scientific.md и PROCESS_ENHANCEMENT — учтён в разделах 3, 7, 11, 14.
2) Лучшие практики — имплементированы как Project Intelligence, Process Mining, Digital Twin проектов (§4/§7).
3) Сопоставление с P‑серией — сводка в §13; детальные привязки внутри каждого раздела.
4) Настоящий документ — ТЗ 40 (самодостаточно, без внешних приложений).
5) Повторный анализ целостности — инварианты P27/P28/P29/P30/P36 отражены в §2/§6/§9/§12/§15.
6) 39‑шаговая сверка P01–P39 — итоги и улучшения по каждому P‑документу в §16.
7) Детализация до уровня реализации — DDL/DSL/Acceptance и смоки в §9/§10/§12/§15.

## 0.2) Вводные (зафиксированные требования)

- Проектное управление внедряется в Ядро Соул (ЯС) как набор сущностей и процессов для достижения Целей через Проекты (группа взаимосвязанных процессов).
- Процессы строятся по лучшим практикам проектного управления с управлением рисками и изменениями, ориентированным на малые команды (каскадные и итерационные методологии).
- Вводится роль Менеджера и набор вспомогательных агентных ролей (Администратор, АУ, Библиотекарь, Разработчик, Оптимизатор, Тестировщик, Аналитик, Шаблонизатор, Сисадмин, Интегратор, Рискмен).
- Все проектные процессы транслируются в алгоритмы обработки Квантов и цикл Процессора (P30), включая обучение нейросети (P38) и DesiredAction (P07); соблюдается STRICT JSON и Delivery Guard (P27).
- Репозиторий проектных методологий — системный, версионируемый, доступен из UI (P23), без заглушек и с детерминированными вычислителями; настройки ролей и процессов конфигурируемы.

## 1) Термины и роли (ЯС Project Actors)

- Менеджер: планирование/декомпозиция/план‑факт/CPM/EVM; выбор методологии (каскадные/итерационные профили). Управляет через Hyperloop и UI (P23).
- Администратор: хранит репозиторий проекта (план, артефакты, статусы), управляет сервисными функциями (инъекции событий, сбор статусов, агрегации). Не планирует.
- Агент Управления Изменениями (АУ): анализ влияния задач/решений на проекты/цели/объекты; выявление пересечений/конфликтов; эскалация по критичности.
- Библиотекарь: формирование/классификация баз знаний; индексы/ссылки; инициирование поиска/очистки/миграций и контроль корректности индексации. Держатель правил индексации.
- Разработчик: пишет код/документы; имеет интерфейсы к средствам разработки/интернета/CLI; может запрашивать инструменты у Архитектора; задачи приходят от Менеджера через Администратора или от Процессора.
- Оптимизатор: выявляет дубли/аномалии процессов/целей/структур; предлагает консолидации и планы репликации структур в Квантовое Сознание (репликация в Кванты).
- Тестировщик: формальные проверки качества/соответствия требованиям/шаблонам; возврат в работу при несоответствии.
- Аналитик: поиск аналогов/кейсов/аналогий из разных областей для ускорения решения; поставка примеров решений.
- Шаблонизатор: поддерживает целостность жёстких структур памяти/шаблонов; фиксирует угрозы и уведомляет Процессор; допускает временный мораторий на сверки по решению Процессора.
- Сисадмин: анализ внешних/внутренних интерфейсов; предложения по упрощению взаимодействий; контроль целостности и оптимизации системных компонентов.
- Интегратор: анализ истории интеграций; рекомендации по упрощению; маршрутизация задач Менеджеру/Разработчику.
- Рискмен: процессы управления рисками (идентификация/оценка/план реагирования/мониторинг); безопасность, сроки/стоимость/качество.

Связи с P‑серией: подпись P27 на каждом шаге; фичефлаги/политики — P28; гейты качества/уставы — P29; исполнитель — P30; язык управления — P36; хранение знаний/индексов — см. P10/P16/P31/P38.

## 2) Модель данных: Проекты/Планы/Задачи/Риски/Изменения

Сущности (DDL — эскиз; совместим со Schema Guard P10, расширение Alembic при отсутствии):

```sql
create type pm_methodology as enum ('waterfall','iterative','agile','kanban','hybrid');
create type pm_task_status as enum ('todo','in_progress','blocked','done','cancelled');
create type pm_risk_severity as enum ('low','medium','high','critical');
create type pm_risk_prob as enum ('rare','unlikely','possible','likely','almost_certain');

create table projects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  owner bigint not null,
  methodology pm_methodology not null default 'hybrid',
  priority numeric(3,2) not null default 0.5,
  start_at timestamptz,
  due_at timestamptz,
  budget numeric(18,2),
  meta jsonb not null default '{}',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index idx_projects_owner on projects(owner);
create index idx_projects_due on projects(due_at);

create table plan_tasks (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  title text not null,
  description text,
  status pm_task_status not null default 'todo',
  progress numeric(3,2) not null default 0.0,
  priority numeric(3,2) not null default 0.5,
  start_at timestamptz,
  due_at timestamptz,
  assignee bigint,
  cpm_duration_days numeric(6,2),
  cpm_es date, -- ранний старт
  cpm_ef date, -- раннее окончание
  cpm_ls date, -- поздний старт
  cpm_lf date, -- позднее окончание
  cpm_slack_days numeric(6,2),
  evm_pv numeric(12,2) default 0, -- Planned Value
  evm_ev numeric(12,2) default 0, -- Earned Value
  evm_ac numeric(12,2) default 0, -- Actual Cost
  meta jsonb not null default '{}',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index idx_plan_tasks_project on plan_tasks(project_id);
create index idx_plan_tasks_status on plan_tasks(status);

create table plan_task_dependencies (
  id uuid primary key default gen_random_uuid(),
  predecessor uuid not null references plan_tasks(id) on delete cascade,
  successor uuid not null references plan_tasks(id) on delete cascade,
  dep_type text not null default 'FS', -- FS/SS/FF/SF
  lag_days numeric(6,2) default 0
);
create unique index uq_task_dep on plan_task_dependencies(predecessor, successor);

create table risks (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  title text not null,
  description text,
  severity pm_risk_severity not null,
  probability pm_risk_prob not null,
  exposure_score numeric(5,2) not null, -- детерминированный скор
  mitigation text,
  owner bigint,
  status text default 'open',
  meta jsonb not null default '{}',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index idx_risks_project on risks(project_id);

create table changes (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  title text not null,
  description text,
  impact jsonb not null default '{}', -- влияния на цели/задачи/сроки/ресурсы
  risk_delta jsonb not null default '{}',
  approved boolean default false,
  approved_by bigint,
  approved_at timestamptz,
  two_keys_request uuid, -- ссылка на заявку P29
  meta jsonb not null default '{}',
  created_at timestamptz default now()
);
```

Связи с Квантами (`quant_links`):

- Проект/Задача ↔ Квант: `relation_type in ('supports','confirms','closes','advances','assesses')`.
- Риск/Изменение ↔ Квант: `relation_type in ('identifies','mitigates','causes','adjusts')`.

Идемпотентность: ключи вида `dedup_key = <project_id>:<task_id>:<bucket>` на событиях Процессора (P30).

## 2.0) Реестр внутренних доработок (LLM‑Plan, обязательно)

- Единый обязательный источник правды для всех внутренних задач разработки/доработок, выполняемых LLM‑инженерами и сервисами ЯС.
- Создаётся системный проект `P40 — Internal LLM Development` с задачами‑единицами учёта.
- Любая разработка допускается только при наличии записи `plan_tasks` и ссылок на неё в коде/коммитах/доках.

Стандартизованные поля задачи (надстройка над `plan_tasks` через `meta`):

- `meta.dev`: `{ "branch": string, "pr_url": string, "commit_refs": [string] }`
- `meta.links.skills`: `[ { "skill_key": string, "proficiency_bias": number } ]`
- `meta.links.quants`: `[{ "quant_id": uuid, "relation_type": "implements|assesses|supports|closes" }]`
- `meta.links.goals`: `[{ "goal_id": uuid, "relation_type": "supports|advances" }]`
- `meta.tags`: `["p40.internal", "llm", "autopilot"]`

Контроль дубликатов (обязателен):

- Дедуп‑ключ: `p40plan:{normalized_title}:{project_id}`; нормализация: нижний регистр, урезка служебных слов, сжатие пробелов.
- Новая задача с совпадающим ключом → `409 conflict` и предложение линковать к существующей.

Обязательные связи (coverage):

- Каждая задача должна иметь минимум одну связь с Навыком (`quant_links.to_entity_type='skill'`) или Профессией/Специализацией (см. P25), и минимум один Квант, отражающий реализацию/оценку (`implements|assesses`).
- Для задач категории «Документация ТЗ» требуется ссылка на номерной P‑документ и обратная ссылка из P‑документа на `plan_task`.

Инспектор покрытия `planning.enforce` (см. §12/§15):

- Проверяет: кванты с `payload.plan` без `quant_links`, наличие связи к `skill`, дубликаты по `payload.plan.task_id`.
- Возвращает агрегаты и `violations` для панели мониторинга, включён в `INSPECTOR.RUN_ALL`.

События Процессора (P30):

- `plan_update` — при создании/изменении задач/связей;
- `goal_assess` — при оценке влияния задачи на цели; результаты фиксируются в квантах (`assesses`).

DSL (P36) — минимально необходимое:

- `PLAN.TASK.ADD project_id=<PID> title="..." meta={...}`
- `QUANT.LINK from=<QID> to_entity_type=plan_task to_id=<TID> relation_type=implements`
- `SKILL.LINK.TASK task_id=<TID> skill_key="..."`

Acceptance (смоки):

- Нельзя создать PR/деплой без ссылки на `plan_task.id` в теле задачи/коммита/документа (проверяется инспектором).
- `INSPECTOR.RUN key=planning.enforce` возвращает `status=passed` при отсутствии нарушений.

## 2.1) Ветвление работ LLM‑инженеров (branching/locks)

Цель: исключить конкуренцию/дублирование при параллельной разработке несколькими LLM‑агентами.

- Сущности блокировок:
  - Ветка (semantic branch): ключ `branch_key` вида `<area>/<module>/<topic>` (например, `P45/ingest/qc`), владелец, TTL (48h по умолчанию), опц. `session_id`.
  - Задача: `plan_task.id` → владелец, опц. `branch_key`, TTL (48h), опц. `session_id`.
- Правила:
  - Перед началом работ агент выполняет `INSPECTOR.RUN key=plan.branch action=claim_branch branch=<key> owner=<tg_id> [session=<session_id>]` и/или `... action=claim_task task_id=<UUID> owner=<tg_id> [session=<session_id>]`.
  - Повторная заявка при активной блокировке → `conflict`, если жива сессия владельца; при потере сессии (отсутствует heartbeat дольше `session_ttl_sec`, по умолчанию 30 мин) блокировка снимается GC автоматически.
  - Heartbeat и массовое снятие:
    - `INSPECTOR.RUN key=plan.branch action=session_ping session=<session_id> [owner=<tg_id>] [session_ttl_sec=1800]`
    - `INSPECTOR.RUN key=plan.branch action=release_session session=<session_id>`
  - По завершении работ: `action=release_branch|release_task`. Истёкшие или осиротевшие блокировки (без активной сессии) удаляются GC.
  - При заявках от Архитектора — проверка конфликтов: приоритет за уже существующими ветками и ветками в рамках конкретных ТЗ/модулей/функций/Целей.
- Наблюдаемость:
  - Состояние хранится в `processor_policies.key=planning.branch.locks` (jsonb), секции: `branches`, `tasks`, `sessions`.
  - Включён авто‑GC по TTL блокировок и по `session_ttl_sec` для сессий; блокировки, привязанные к потерянной сессии, освобождаются автоматически.
  - Журнал операций — в `processor_incidents` по результатам запуска Процессора/инспекторов.
- DSL/Примеры:
  - `INSPECTOR.RUN key=plan.branch action=claim_branch branch=P45/ingest/qc owner=468326902 session=dev-001 ttl_sec=172800 session_ttl_sec=1800`
  - `INSPECTOR.RUN key=plan.branch action=session_ping session=dev-001 owner=468326902`
  - `INSPECTOR.RUN key=plan.branch action=claim_task task_id=<UUID> owner=468326902 session=dev-001`
  - `INSPECTOR.RUN key=plan.branch action=release_session session=dev-001`
  - `INSPECTOR.RUN key=plan.branch action=list`

## 3) Методологии и профили (каскадные и итерационные)

Поддерживаемые профили проекта (настройка в `projects.methodology` и политиках P28):

- Waterfall: фиксированные фазы, строгий CPM/критический путь, baseline заморозка; изменения — через CHANGE.* с Two‑Keys.
- Iterative: короткие циклы план‑делай‑проверь‑действуй; задачи — итерации, velocity/throughput.
- Agile/Kanban: WIP‑лимиты, кумулятивные диаграммы потока, SLA по колонкам; изменения — lightweight через CHANGE.*.
- Hybrid: комбинация (дефолт). Менеджер может переключать профиль с миграцией полей (через ARCHIVARIUS.REQUEST + Two‑Keys при рисковом влиянии).

Методологические инварианты:

- P27 Delivery Guard — перед любым видимым ответом.
- Детерминированные расчёты CPM/EVM/риск‑скоринга (формулы ниже) → идемпотентные функции.
- Управление изменениями — через заявки (REQUEST.*) и Two‑Keys (P29) по опасным полям.

### 3.1 Репозиторий проектных методологий (дерево процессов)

- Назначение: хранить для каждой методологии (waterfall/iterative/agile/kanban/hybrid) полный набор проектных процессов ЯС в древовидном виде, детализированных по ролям.
- Структура хранения (пример):

```json
{
  "methodology": "hybrid",
  "version": "v1",
  "roles": {
    "manager": { "process_tree": [ {"key":"plan","steps":["init","wbs","schedule","cpm","evm"]} ] },
    "administrator": { "process_tree": [ {"key":"status_aggregation","steps":["collect","normalize","publish"]} ] },
    "change_agent": { "process_tree": [ {"key":"impact","steps":["detect","analyze","escalate","recommend"]} ] },
    "librarian": { "process_tree": [ {"key":"kb_ops","steps":["classify","index","link","validate"]} ] },
    "developer": { "process_tree": [ {"key":"delivery","steps":["design","implement","review","test"]} ] },
    "optimizer": { "process_tree": [ {"key":"dedupe","steps":["scan","cluster","consolidate"]} ] },
    "tester": { "process_tree": [ {"key":"qa","steps":["check","report","retest"]} ] },
    "analyst": { "process_tree": [ {"key":"analogies","steps":["search","map","propose"]} ] },
    "templater": { "process_tree": [ {"key":"guard_templates","steps":["monitor","alert","moratorium?"]} ] },
    "sysadmin": { "process_tree": [ {"key":"interfaces","steps":["survey","proposal","simplify"]} ] },
    "integrator": { "process_tree": [ {"key":"integration_improve","steps":["analyze","route","implement"]} ] },
    "riskman": { "process_tree": [ {"key":"risk_cycle","steps":["identify","score","plan","monitor"]} ] }
  },
  "policies": { "rbac": {"project.manager":["project.*","plan.*","task.*"]} }
}
```

- Хранение: таблица `project_methodologies(id, name, version, tree jsonb, enabled)`; индексы GIN по `tree`.
- Интеграция с DSL: `METHODOLOGY.LIST|GET|SET`, `ROLE.PROCESS.CONFIG`.
- UI (P23): экран «Методологии»: выбор профиля, редактирование деревьев по ролям, предпросмотр зависимостей.

### 3.2 Базовые (глубинные) настройки ролей

- Ролевые параметры: допуски/лимиты, SLA, подтверждения (Two‑Keys), политика автопубликации, источники данных.
- Хранение: `role_baseline_settings(role text pk, settings jsonb)`; пример ключей: `max_parallel_tasks`, `approval_required.change= true`, `sla.reply_ms`, `autopublish.rules=[]`.
- Применение: Процессор учитывает `role_baseline_settings` при appraise/decide; UI позволяет править параметры и снапшоты профилей.

## 4) Project Intelligence и Process Mining

- Источники: `signature_steps`, метрики P21/P24, статусы задач/рисков/изменений, связи `quant_links`.
- Аналитика: обнаружение дубликатов целей/процессов (Оптимизатор), узких мест, рассинхронизаций план‑факт.
- Digital Twin проекта: симуляции расписания/ресурсов перед применением изменений (DRY_RUN в DSL).

## 5) Детерминированные алгоритмы

### 5.1 CPM (Critical Path Method)

- Вход: DAG `plan_task_dependencies`, длительности `cpm_duration_days`.
- Расчёт: прямой/обратный проход → ES/EF/LS/LF; `slack = LS - ES`; критический путь: `slack=0`.
- Выход: поля `cpm_es/ef/ls/lf/slack_days` в `plan_tasks`.

### 5.2 EVM (Earned Value Management)

- Индикаторы: `PV` (план), `EV` (заработанная ценность по прогрессу), `AC` (факт затрат).
- Метрики: `CPI = EV/AC`, `SPI = EV/PV`; пороги алертов в `processor_policies.ev_thresholds`.

### 5.3 Риск‑скоринг

- База: матрица вероятность×серьёзность (5×4), численная шкала → `exposure_score`.
- Доп. факторы: близость due, критичность проекта, связность задач; весовые коэффициенты из P28.

Все функции — идемпотентны, с фиксированным порядком обхода (стабильная сортировка UUID/created_at).

### 5.4 Детерминизм и идемпотентность (общие правила)

- Порядок обхода коллекций фиксирован: первичный ключ — `created_at`, вторичный — `id`/`uuid` по возрастанию.
- Числовые результаты округляются до фиксированной точности (например, `days` — до 2 знаков, индексы EVM — до 3 знаков).
- Запрет побочных эффектов в расчётных функциях; любые записи в БД — только в обёртках уровня сервиса.
- Идемпотентность событий обеспечивается `dedup_key` вида `p40:{project_id}:{calc}:{ts_bucket}` (например, `calc=cpm|evm|risk`).
- При совпадении входов результат должен быть бинарно идентичен (deterministic pure functions + стабильная сортировка).

## 6) Интеграция с Процессором (P30)

- События: `plan_update|goal_signal|calendar_event_due|incident|change_request|risk_update` → очередь Процессора.
- Петля: perceive/appraise/decide/act/observe/learn — обновляет `plan_tasks.progress`, `risks.exposure_score`, `changes.approved` и связи `quant_links`.
- Guard: обязательные шаги подписи перед видимой выдачей; эскалации через REQUEST/JUDGE.

## 7) Роли и ответственности (RBAC, P32)

- Роли: `project.manager`, `project.operator`, `project.viewer`.
- Two‑Keys: утверждение изменений бюджета/сроков/целей; CHANGE.APPROVE требует request_id.

### 7.13 Мастер ключей (Key Master)

- Назначение: централизованный контроль секретов и каноники путей/портов/URL, интеграция с Инспектором и ядром.
- Функции:
  - Ведение мастер‑ключа шифрования секретов: контроль наличия `secrets.master_key` в `soul_settings`, ротации и целостности (Two‑Keys для чувствительных операций).
  - Автодетекция новых секретов из ENV/входных каналов/операторских вводов и запись в `public.soul_secrets` (pgcrypto) через `SecretsService` с аудитом.
  - Мониторинг неправильного использования секретов (чтение из файлов/хардкодов в коде), отчёты об обходе `SecretsService` и инциденты P50 при критичных нарушениях.
  - Каноника адресов/портов/URL: инспектор `guard.canonical.urls` (enforce/alert), поддержка whitelist, счётчики `canonical_violations_total{type}`.
  - Телеметрия: `secrets_events_total{type}`, `canonical_violations_total{type}`, `training_ingest_*` (для LIMA); экспозиция в `/api/metrics` и `/api/metrics/prometheus`.
  - Панели/Алерты: Grafana `ops/grafana/security_keymaster_dashboard.json`, Prometheus правила `ops/prometheus/rules_security.yml`.
- DSL (P36): `SCHEMA.SECRETS.ENSURE`, `SECRET.SET|GET` (Two‑Keys), `INSPECTOR.RUN key=guard.canonical.urls`, `FLAGS.*` для конфигурации каноники.
- Acceptance: `SECRET.GET` по целевым ключам даёт `exists=true`; инспектор фиксирует нарушения, enforce блокирует; панели отражают события и p95, без хардкодов в коде/конфиге.

### 7.1 Разработчик (Developer)

- Назначение: реализация задач проекта (код/утилиты/скрипты/документы) с использованием IDE Cursor, CLI и LLM‑помощников.
- RBAC/Настройки:
  - Роль: `actor.developer` (+ скопы `dev.env`, `dev.codegen`, `dev.deploy.safe`).
  - Ключи Settings: `dev.access.cursor=true`, `dev_env.workspaces=[...]`, `dev_env.allowed_hosts=[...]`.
  - Политики P28: квоты LLM, лимиты RT потоков, Two‑Keys для `DEPLOY.*`.
- Процессы/События (P30):
  - `dev_task_assigned`, `dev_task_progress`, `dev_skill_import_request`, `dev_codegen_request`.
  - Идемпотентность: `dedup_key="dev:{task_id}:{event}"`.
- Алгоритмы/Правила:
  - Кодогенерация — deterministic шаблоны + LLM, строгие контракты, санитайзер видимого текста.
  - Навыки — импорт/линк в систему Навыков (§11) с валидацией источников.
- Интерфейсы/Доступ:
  - IDE Cursor (рабочее место): список репозиториев/веток, RT‑смоки.
  - CLI: Hyperloop DSL (P36), безопасные макрокоманды, Secrets через P36 `SECRET.*`.
- DSL (эскизы):
  - `DEV.ENV.AUTHORIZE user=468326902 tool=cursor workspace="soulpulse"`
  - `DEV.TASK.START id=<DEV_TASK_ID> [branch="p40"]`
  - `DEV.CODEGEN.RUN task_id=<DEV_TASK_ID> prompt="..." [WITH TRACE]`
  - `SKILL.IMPORT key="llm.coder.cursor" source="kb://dev/skills"`
  - `SKILL.LINK.DEV user=468326902 skill_key="llm.coder.cursor"`
- UI/Панели (P23):
  - Консоль Разработчика: задачи, ветки, смоки, история кодогенераций, импорт навыков.
  - Дашборд нагрузки: WIP лимиты, время цикла, блокеры (P29 инциденты).
- Acceptance/Наблюдаемость:
  - Команды `DEV.*`/`SKILL.*` возвращают `ok` и подпись (P27); в `signature_steps` видны `cmd.hyperloop.*` и `svc.processor.*`.

### 7.1.2 JSON Schema (валидация полей)

- DEV.TASK (назначение задачи разработчику):

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://soul/p40/dev.task.schema.json",
  "type": "object",
  "required": ["id", "project_id", "title", "assignee"],
  "properties": {
    "id": {"type": "string", "minLength": 1},
    "project_id": {"type": "string", "minLength": 1},
    "title": {"type": "string", "minLength": 1},
    "description": {"type": "string"},
    "assignee": {"type": "integer", "minimum": 1},
    "branch": {"type": "string"},
    "priority": {"type": "number", "minimum": 0, "maximum": 1},
    "links": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["type", "entity", "id"],
        "properties": {
          "type": {"type": "string", "enum": ["relates_to", "blocks", "implements"]},
          "entity": {"type": "string", "enum": ["plan_task", "risk", "change", "doc"]},
          "id": {"type": "string", "minLength": 1}
        },
        "additionalProperties": false
      }
    }
  },
  "additionalProperties": false
}
```

- DEV.EVENT (прогресс/блокировки/завершение):

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://soul/p40/dev.event.schema.json",
  "type": "object",
  "required": ["task_id", "kind"],
  "properties": {
    "task_id": {"type": "string", "minLength": 1},
    "kind": {"type": "string", "enum": ["progress", "blocked", "done"]},
    "progress": {"type": "number", "minimum": 0, "maximum": 1},
    "notes": {"type": "string"},
    "attachments": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["type"],
        "properties": {
          "type": {"type": "string", "enum": ["commit", "pr", "artifact", "link"]},
          "ref": {"type": "string"},
          "url": {"type": "string", "format": "uri"}
        },
        "additionalProperties": false
      }
    }
  },
  "additionalProperties": false
}
```

- SKILL.IMPORT (импорт навыка):

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://soul/p40/skill.import.schema.json",
  "type": "object",
  "required": ["key", "title", "source", "version", "checksum"],
  "properties": {
    "key": {"type": "string", "pattern": "^[a-z0-9_.-]+$"},
    "title": {"type": "string", "minLength": 1},
    "source": {"type": "string", "minLength": 1},
    "taxonomy": {"type": "array", "items": {"type": "string"}},
    "content_uri": {"type": "string"},
    "version": {"type": "string"},
    "checksum": {"type": "string"}
  },
  "additionalProperties": false
}
```

- SKILL.LINK (привязка навыка к пользователю):

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://soul/p40/skill.link.schema.json",
  "type": "object",
  "required": ["user_id", "skill_key"],
  "properties": {
    "user_id": {"type": "integer", "minimum": 1},
    "skill_key": {"type": "string", "pattern": "^[a-z0-9_.-]+$"},
    "proficiency": {"type": "number", "minimum": 0, "maximum": 1},
    "acquired_at": {"type": "string", "format": "date-time"}
  },
  "additionalProperties": false
}
```

### 7.2 Администратор (Administrator)

- Функции: хранение репозитория проекта, рассылка поручений, сбор статусов, агрегирование сырых данных.
- События: `admin_dispatch`, `admin_collect_status`, `admin_report_ready`.
- UI: регистр поручений, статусы исполнителей, отчёт по срокам/рискам.

### 7.3 Агент управления изменениями (CMA)

- Функции: выявление влияний/пересечений между проектами/задачами/объектами, эскалации.
- Алгоритмы: граф зависимостей (quant_links), оценка критичности, маршрутизация уведомлений.
- UI: лента изменений, матрица влияний, очередь эскалаций.

### 7.4 Библиотекарь (Librarian)

- Функции: формирование/валидация/обогащение баз знаний, индексы и связи.
- События: `kb_validate`, `kb_enrich`, `kb_index_build`.
- DSL: `LIB.KB.LINK`, `LIB.KB.SCAN` (см. §9/§P36).

### 7.5 Оптимизатор (Optimizer)

- Функции: поиск дублей целей/процессов, нормализация структур, рекомендации по оптимизации.
- Алгоритмы: dedup по метрикам похожести и цели; отчёты для Менеджера.
- UI: отчёт пересечений, предложения слияния/удаления.

### 7.6 Тестировщик (Tester)

- Функции: формальные проверки результата на соответствие требованиям/шаблонам.
- Интеграция P29: `TEST.RUN key=p40.*` + отчёты.
- UI: реестр тестов, статусы, метрики стабильности.

### 7.7 Аналитик (Analyst)

- Функции: поиск аналогий/референсов из внешних доменов для ускорения решений.
- События: `analogy_search`, `pattern_suggest`.
- UI: библиотека кейсов/паттернов.

### 7.8 Шаблонизатор (Templater)

- Функции: поддержка целостности жёстких структур памяти/шаблонов, мониторинг деградаций.
- События: `template_guard_violation`, `template_update_request`.
- UI: реестр шаблонов, сравнения версий, диффы.

### 7.9 Сисадмин (Sysadmin)

- Зоны ответственности (IT‑безопасность по мировым практикам NIST/ISO/ITIL):
  - Сетевая безопасность: фаерволы L3/L7 (deny‑by‑default), allow‑list доменов/портов, профили сред (prod/dev/diag), журналирование изменений, Two‑Keys на опасные операции.
  - Маршрутизация и сегментация: внутренняя маршрутизация служб, сервисные зоны (Core/DMZ/Tools), egress‑контроль, NAT/прокси/туннели.
  - Доступ в Интернет и Даркнет: управляемые egress‑окна для внутренних пользователей/акторов (временные окна, списки разрешений); поддержка безопасного выхода в Tor/Onion (даркнет) через системный шлюз с санитайзером трафика.
  - Внутренняя безопасность: Zero‑Trust, принцип наименьших привилегий, RBAC (P32), аудит действий (P27/P29), защита протокола Ядра (Hyperloop DSL — только через контролируемые эндпойнты).
  - Интеграция с внешними системами и протоколами: контроль точек обмена (HTTP(S)/gRPC/Webhook/SMTP/IMAP/SFTP), шлюзы и адаптеры, сертификаты/ключи в Secrets.
  - Наблюдаемость: метрики egress/p95, счётчики блокировок/разрешений, алерты по отклонениям.

- DSL/управление (см. P36 — группа `NET.*`, только для роли `sysadmin`, опасные операции — с Two‑Keys):
  - `NET.FW.STATUS|APPLY_PROFILE|ALLOW|DENY|TEST` — фаервол/окна доступа.
  - `NET.ROUTE.SHOW|ADD|DEL` — маршруты/сегментация.
  - `NET.ACCESS.WINDOW OPEN|CLOSE` — временные окна egress по тегам/ролям.
  - `NET.DARKNET.ENABLE|DISABLE|STATUS|EGRESS.ALLOW` — управляемый выход в Tor.

- Политики/настройки (P28→`soul_settings`):
  - `net.fw.enabled=true|false`, `net.fw.profile=prod_lockdown|dev_fast|diagnostics_on`
  - `net.fw.allow_domains=["api.telegram.org:443","…"]`, `net.fw.block_domains=["*"]`
  - `net.route.tables={"core":[],"dmz":[]}`, `net.access.windows={...}`
  - `net.darknet.enabled=false`, `net.darknet.egress_allow=["*.onion:80","*.onion:443"]`

- Режим «замок» (all‑closed кроме строго разрешённого):
  - По умолчанию закрыто всё внешнее; открыты только:
    - Канал среды разработки Архитектора (IDE/SSH, whitelisted endpoints/keys)
    - Сервер БД (внутренний сегмент)
    - Контролируемое окно egress, открываемое `NET.ACCESS.WINDOW OPEN` (по TTL/тегу)
  - База доменов расширяется детерминированно Ремайндером/Сисадмином при реальном использовании (аудит в БД: `net_egress_registry`, `net_egress_usage`).

- Инцидент‑реакция (runbook):
  - Атака/аномалия → немедленно `NET.FW.KILL_SWITCH ttl=15m` (всё наружу закрыто), запись инцидента P29.
  - Ротация порта сервиса → `NET.SERVICE.PORT.SWITCH service=backend port=<new>` (Two‑Keys) и обновление прокси/health.
  - Повторная атака → усиленный локдаун (увеличение TTL, закрытие окон egress), уведомление Менеджера/Рискмена.
  - Возврат к работе: по окончании TTL локдауна — пошаговое восстановление allow‑листов и контроль `NET.FW.TEST`.

- События: `iface_gap_found`, `integration_channel_propose`, `net_policy_change`, `net_window_open`, `net_window_close`.

- UI: карта интерфейсов/каналов, панели фаервола/маршрутов/окон egress, журнал изменений и Two‑Keys заявок.

- Acceptance (смоки):
  - `NET.FW.APPLY_PROFILE name=prod_lockdown DRY_RUN` → ok, preview состояния; `NET.FW.STATUS` возвращает активный профиль и списки allow/deny.
  - `NET.FW.ALLOW domain=api.telegram.org port=443` → ok, запись в журнале; `NET.FW.TEST url=https://api.telegram.org` → ok.
  - `NET.DARKNET.ENABLE request_id=<UUID>` (Two‑Keys) → `status=enabled`; `NET.DARKNET.STATUS` отражает включённый шлюз.

### 7.10 Интегратор (Integrator)

- Функции: упрощение взаимодействий, подготовка заданий Разработчику/Менеджеру.
- События: `integration_task`, `integration_simplify_suggestion`.
- UI: журнал интеграций/барьеров, эффективность решений.

### 7.11 Рискмен (Riskman)

- Функции: реестр рисков, скоринг/пересчёт экспозиции, портфельный взгляд.
- Алгоритмы: матрица `probability×severity` + доп. факторы (см. §5.3).
- UI: тепловая карта, тренды CPI/SPI vs риск‑экспозиция, журнал мер.

### 7.12 Менеджер (Manager)

- Функции: планирование/декомпозиция/реплан, контроль критического пути, план‑факт.
- События: `plan_update`, `milestone_reached`, `rebaseline_request`.
- UI: план/Гантт, вехи, репланы, журнал решений (Two‑Keys на критичные).

## 8) UI (P23) — покрытие интерфейсами и дашбордами

### 8.1 Страницы

- Projects: список, карточка проекта, вкладки План/Задачи/Риски/Изменения.
- Gantt/CPM: диаграмма, критический путь, буферы, зависимость задач.
- EVM: PV/EV/AC, CPI/SPI, кривые и табличные срезы.
- Risks: тепловая карта, портфель рисков, меры/владельцы.
- Changes: очередь запросов, Two‑Keys, диффы планов.
- Methodologies: просмотр/редактирование `process_tree`, `ui_config`.
- Role Settings: базовые настройки ролей, снапшоты профилей.
- Developer Console: задачи разработчика, ветки/ПР, кодогенерации, импорт/линк навыков.

### 8.2 Дашборды

- Сводка проекта: прогресс, CPI/SPI, критический путь, риски/инциденты.
- Нагрузка акторов: WIP, распределение задач, узкие места.
- Производительность процесса: p95 стадий P30, блокировки Guard, тестовые статусы P29.

### 8.3 Навигация/Доступ

- RBAC фильтрует видимость секций; админские операции — через Two‑Keys.
- Встраиваемые смоки DSL для ключевых операций (CPM/EVM/DEV/Skills).

### 8.4 Метрики Developer Console

- Lead/Cycle time: `lead_time_ms`, `cycle_time_ms` (p50/p95).
- Поток: `wip_count_current`, `weekly_throughput`.
- Кодогенерация: `codegen_success_rate`, `codegen_latency_ms_p95`.
- Качество: `tests_pass_rate`, `incidents_open`.
- PR/Review: `pr_merge_time_ms_p50`, `pr_merge_time_ms_p95`, `review_latency_ms_p95`.
- Навыки: `skills_count_linked`, `skills_recent_imports_7d`.
- LLM: `llm_tokens_in_total`, `llm_tokens_out_total`.

### 9.2 Доп. команды DEV/Skills (эскизы)

```text
DEV.ENV.AUTHORIZE user=468326902 tool=cursor workspace="soulpulse"
DEV.TASK.START id=dev-001 branch="p40"
DEV.CODEGEN.RUN task_id=dev-001 prompt="Реализуй PLAN.CPM.CALC" WITH TRACE
SKILL.IMPORT key="llm.coder.cursor" source="kb://dev/skills"
SKILL.LINK.DEV user=468326902 skill_key="llm.coder.cursor"
```

## 11.1 Processor — политики для DEV‑событий (P30/P28)

- Ключи настроек (P28):

```json
{
  "processor.dev": {
    "enabled": true,
    "wip_limit": 3,
    "event_timeout_ms": 1500,
    "retry_policy": {"max": 2, "backoff_ms": 250},
    "llm_profile": "gigachat",
    "guard_visible_reply": false
  }
}
```

- События и обработка (P30):
  - `dev_task_assigned` → создать/линковать `plan_task`, проставить `assignee` и due.
  - `dev_task_progress` → обновить прогресс; при `blocked` — инцидент/эскалация.
  - `dev_skill_import_request` → валидация/импорт в Skills; линк к пользователю.
  - `dev_codegen_request` → безопасная кодогенерация (DRY_RUN по флагу), лог подписи.
- Инварианты Guard (P27):
  - Перед любой видимой выдачей требуется полная цепочка шагов; нарушения → блок и инцидент.
- Инспекторы/тесты (P29):
  - `TEST.RUN key=p40.dev_pipeline_smoke` — последовательно инжектирует DEV‑события, проверяет шаги и метрики.

## 11.1.1 Эскалации и SLA

- Эскалации:
  - `blocked` > 2 часа → уведомление Менеджеру/Администратору; > 8 часов → инцидент P29 и реплан.
  - Риск `exposure_score` > порога → уведомление Рискмену и эскалация Менеджеру.
- SLA и роутинг (P28 Settings):

```json
{
  "processor.dev": {
    "sla": {
      "respond_ms": {"p1": 900000, "p2": 1440000, "p3": 2880000},
      "resolve_ms": {"p1": 86400000, "p2": 172800000, "p3": 345600000}
    },
    "routing": {
      "priority_map": {"high": "p1", "normal": "p2", "low": "p3"},
      "queues": {
        "p1": {"worker_weight": 3},
        "p2": {"worker_weight": 2},
        "p3": {"worker_weight": 1}
      },
      "reorder_strategy": "priority_first_fifo"
    }
  }
}
```

- Мониторинг/алерты:
  - Алерты при `respond_ms`/`resolve_ms` > SLA; при росте `blocked` событий; при падении `tests_pass_rate`.

## 12) Acceptance/Наблюдаемость

- Подпись/Delivery Guard (P27) обязательно для видимых ответов.
- Инспекторы P29: `p29.quant_links_ownership`, `p27_guard_chain`, `processor_feedback_invariant` — зелёные.
- Метрики: p95 стадий P30, SPI/CPI, risk_exposure_avg, processor.queue_len, events_processed.
- UI: доступны страницы «Методологии», «Настройки ролей», «Developer Console», «Gantt/CPM», «EVM», «Risks/Changes»; все действия аудируются.
- DEV/Skills: команды `DEV.*`/`SKILL.*` выполняются (DRY_RUN допустим), подпись присутствует; навыки импортируются и линкуются к пользователю.

## 13) Сверка с P‑серией (ключевые интеграции)

- P27: обязательные шаги; Function Registry для PROJECT/PLAN/TASK функций как required.
- P28: профили `prod_safe|diagnostics_on|dev_fast` влияют на расчёты/RT, ключи `pm.*` в `soul_settings`.
- P29: Тесты/Жандарм/Судья; Two‑Keys для CHANGE.APPROVE и критичных флагов.
- P30: все операции идут через события/агенду/исполнитель; idempotency/dedup/incident логика.
- P36: Hyperloop DSL команды PROJECT/PLAN/TASK/RISK/CHANGE/LIB; WITH TRACE/DRY_RUN/TIMEOUT.
- P31/P16/P38: индексы/кванты/обучение — репликация структур знаний и практик.

## 14) Детерминизм/идемпотентность/безопасность

- Все вычислители (CPM/EVM/скоринг) — чистые функции от входа; порядок обхода стабилен.
- Все изменения — через Процессор/DSL с RBAC/Two‑Keys и аудитом.
- Stateless batch — без БД (db=None), desired_action=[]; persistent — полная персистенция с `quant_links`.

## 15) Смоки/Примеры PowerShell/DSL

PowerShell:

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
$B=@{ commands='PROJECT.CREATE name="P40 MVP" methodology=hybrid priority=0.8 owner=468326902' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress
```

DSL (одной строкой):

```text
PLAN.TASK.ADD project_id=<PID> title="CPM расчёт" cpm_duration_days=2.5
PLAN.TASK.DEPEND predecessor=<T1> successor=<T2> dep_type=FS
PLAN.CPM.CALC project_id=<PID> WITH TRACE
PLAN.EVM.UPDATE project_id=<PID>
RISK.ADD project_id=<PID> title="LLM таймаут" severity=high probability=likely
RISK.SCORE.CALC id=<RID>
METHODOLOGY.LIST
ROLE.BASELINE.GET name=Manager
```

Ожидание: ответ содержит `ok`, `signature.trace_id`, `signature_steps`.

### 15.2) Батч‑линковка квантов по payload.plan (FIND+AUTO)

- Назначение: массово проставить связи `quant_links` на основе внешних идентификаторов целей/задач, уже сохранённых в `payload.plan` у `*.good.jsonl`.
- Генератор DSL: `Soul/scripts/generate_find_and_auto_link_dsl.py` — сканирует `Soul/out/qc/**/*.good.jsonl`, извлекает `payload.plan.goal_id|task_id`, строит батч команд:
  - префиксные поиска: `PLAN.GOAL.FIND external_id="..."`, `PLAN.TASK.FIND external_id="..."` (с дедупликацией);
  - автолинки: `QUANT.LINK.AUTO from_quant="<uuid>" to=<goal|task> external_id="..." relation=supports`.
- Выход: файл DSL (по умолчанию `Soul/out/qc/hyperloop_find_and_auto_link.dsl`).
- Отправка: через надёжный отправщик DSL или CLI Hyperloop.

Примеры (Windows PowerShell):

```powershell
# 1) Сгенерировать батч DSL
python .\Soul\scripts\generate_find_and_auto_link_dsl.py --qc-dir Soul\out\qc --out Soul\out\qc\hyperloop_find_and_auto_link.dsl --relation supports

# 2a) Отправить батч через send_hyperloop_dsl.py (если используется)
python .\Soul\scripts\send_hyperloop_dsl.py --api https://mini.soulpulse.art --user-id 468326902 --file Soul\out\qc\hyperloop_find_and_auto_link.dsl --sleep-ms 150 --retry 2 --group 20

# 2b) Или порционно постить содержимое через Hyperloop CLI (надёжно через файл тела)
Get-Content -Raw Soul\out\qc\hyperloop_find_and_auto_link.dsl | ForEach-Object {
  $B=@{ commands=$_ } | ConvertTo-Json -Compress
  Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers @{ 'X-Telegram-User-ID'='468326902' } -Method Post -ContentType 'application/json' -Body $B | Out-Null
}
```

- Acceptance: после выполнения батча инспектор `planning.enforce` не должен находить «кванты с payload.plan без quant_links»; выборочная проверка покрытия связей ≥ 95%.

## 15.1) Быстрый Cookbook для LLM‑инженера (подключение, чтение, изменения)

- Подключение/ветка (RBAC `soul.admin`):
  - `SESSION.CLAIM owner="468326902" branch="p40-dev" topic="planning" session="dev-001"`
  - `SESSION.PING owner="468326902" session="dev-001"`
  - Быстро: `DEV.CONNECT owner="468326902" branch="p40-dev"`
- Чтение (без побочных эффектов):
  - `PROJECT.LIST`
  - `PROJECT.GET id=<PID>`
  - `INSPECTOR.RUN key=planning.enforce`
- Изменения (через DSL с подписью P27):
  - `PROJECT.CREATE name="P40 MVP" methodology=hybrid priority=0.8 owner=468326902`
  - `PLAN.TASK.ADD project_id=<PID> title="CPM расчёт" cpm_duration_days=2.5`
  - `PLAN.TASK.DEPEND predecessor=<T1> successor=<T2> dep_type=FS`
  - `PLAN.CPM.CALC project_id=<PID> WITH TRACE`
- Обновление документации и БД (инвариант «сначала ТЗ, затем факт»):
  - Любое изменение алгоритмов/контрактов → сперва правка этого ТЗ и `docs/PROJECT_STRUCTURE_v8_0_4.md`.
  - Затем операции через Hyperloop DSL/API (никаких локальных JSON): `PROJECT.*`, `PLAN.TASK.*`, `TASK.UPDATE` и связи `QUANT.LINK`.
  - Зафиксировать изменения в `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v*.md` с датой/кратким описанием.
- Освобождение ветки:
  - `SESSION.RELEASE branch="p40-dev" owner="468326902"` (или `INSPECTOR.RUN key=plan.branch action=release_branch branch=p40-dev owner=468326902`).

## 16) 39‑шаговое сопоставление P01–P39 (детально: улучшения и проверки)

### P01 — MeaningExtraction

- Улучшения: детект проектных сущностей (`project`, `plan_task`, `risk`, `change`) и intents (`plan_support`, `goal_progress`). Стандартизованные атрибуты (due, priority, duration).
- Проверки: `TEST.RUN key=p40.meaning_to_plan`; инспектор согласованности полей задач.
- DSL: `CORE.PIPELINE.RUN input_text="Выдели задачи проекта ..." WITH TRACE`.

### P02 — MetaLoop/Introspection

- Улучшения: авто‑рефлексия при просадке `SPI/CPI` → кванты `self_review|strategy_adjustment` (см. §30 P35).
- Проверки: пороги `ev_thresholds` в `processor_policies`; `INSPECTOR.RUN key=p29.processor_feedback_invariant`.

### P03 — RouterContext

- Улучшения: ключи `pm.profile`, `pm.goal_bias` в RouterContext; детерминированная загрузка контекстов плана.
- Проверки: `CORE.TRACE.REQUIRE ... svc.soul.router_decide`; инспектор применения профиля `pm.profile`.

### P04 — Hypothesis A/B

- Улучшения: A/B стратегий CPM (ресурсные/временные допуски); сравнение `time_to_achieve_ms`/`incident_rate`.
- Проверки: `TEST.RUN key=p40.cpm_ab` (категория P04), отчёт в `test_results`.

### P05 — Och

- Улучшения: тональные коррекции статусов/отчётов без смены личности; запрет экспонирования модулей.
- Проверки: `INSPECTOR.RUN key=sanitizer.patterns_consistency`.

### P06 — SelfConsistency

- Улучшения: согласованность план↔цели↔ресурсы; запрет конфликтов `due_at < start_at` и сумм длительностей.
- Проверки: `TEST.RUN key=p40.plan_consistency`.

### P07 — DesiredAction

- Улучшения: подсхемы действий `change_propose|risk_mitigate|plan_update`; `autopublish=false`.
- Проверки: валидация подсхем; `INSPECTOR.RUN key=signature.required_steps.consistency`.

### P08 — Privacy

- Улучшения: маскирование PII в `projects/plan_tasks/changes/risks`.
- Проверки: `INSPECTOR.RUN key=sanitizer.pii_mask_project`.

### P09 — Security

- Улучшения: роли `project.manager/operator/viewer`; Two‑Keys на `CHANGE.APPROVE`/опасные флаги.
- Проверки: `JUDGE.CHARTER.UPSERT ... enforced=true` (Two‑Keys); негативный кейс без approve → 403.

### P10 — SchemaGuard

- Улучшения: снапшоты схем P40‑таблиц; CI‑гейт несовместимых изменений.
- Проверки: `MIGRATIONS.STATUS`, `SCHEMA.COLUMNS table=projects` в smoke.

### P11 — Provenance

- Улучшения: привязка артефактов (доков/спек) к задачам/изменениям через `quant_links(assesses|adjusts)`.
- Проверки: `QUANT.LINK.CHECK` наличие связей.

### P12 — TraceViewer

- Улучшения: фильтры трасс по `project_id|plan_task_id` и шагам `cmd.hyperloop.*`.
- Проверки: `TRACE.STEPS trace_id=...` содержит P27‑цепочку.

### P13 — Eval

- Улучшения: метрики планирования (coverage плановых атрибутов, accuracy предсказаний длительности, on_time_rate).
- Проверки: `TEST.RUN key=p40.eval_planning_metrics`.

### P14 — Multi‑provider

- Улучшения: сервисный LLM (GigaChat) для анализа изменений/рисков; fallback на DeepSeek.
- Проверки: `admin/soul/llm/test?provider=gigachat` ок.

### P15 — Multilingual

- Улучшения: локализация названий/описаний; нормализация языка отчётов.
- Проверки: `LANG.SET`/`LANG.GET` работают; smoke на RU/EN.

### P16 — Sleep/Compaction

- Улучшения: компакция истории проектов/закрытых задач (safe‑mode) без потери связей.
- Проверки: `POST /api/soul/sleep?dry_run=true` — отсутствие удаления, индексы обновлены.

### P17 — Reminders/Search

- Улучшения: due‑уведомления задач, поисковые фасады по `projects/*`.
- Проверки (DSL): `PROCESSOR.EVENT.INJECT kind=reminder ...` → `PROCESSOR.PROCESS_ONCE` ok.

### P18/19 — Voice

- Улучшения: опциональные голосовые статусы задач/рисков.
- Проверки: маршруты P18/P19 без влияния на STRICT JSON квантов.

### P20 — Telegram Bots

- Улучшения: UI для проектных операций; RBAC, без сервер‑стартов в тестах.
- Проверки: фасады работают, smoke страницы в P23.

### P21 — Health/Monitoring

- Улучшения: SLO проектных калькуляторов (CPM/EVM) и алерты.
- Проверки: дашборд p95 по стадиям, алерты на рост latency/ошибок.

### P22 — API Alignment

- Улучшения: фасады `/api/projects/*`, `/api/plan/*` (dry‑run при необходимости).
- Проверки: OpenAPI фрагменты в P22; ответы 200.

### P23 — UI

- Улучшения: страницы Project/Gantt/Risks/EVM + «Методологии»/«Настройки ролей».
- Проверки: smoke‑кнопки DSL выполняются; RBAC.

### P24 — Tests/Monitoring

- Улучшения: регрессионные смоки проектного контура; интеграции с P29.
- Проверки: `INSPECTOR.RUN_ALL` зелёный; `TEST.RUN key=p40.*` проходят.

### P25 — Skills/Routes

- Улучшения: связка задач практик/навыков (`quant_links(plans|improves)`), расписание спейс‑репетиции.
- Проверки: `PROCESSOR.EVENT.INJECT kind=skill_signal ...` → обновления `user_skills`/`skill_practice`.

### P26 — Calendar/Transport

- Улучшения: бронь слотов, переносы; связи `triggers|updates|confirms|snoozes`.
- Проверки: due‑инъекции создают кванты `calendar_support` и связи.

### P27 — Signature

- Улучшения: обязательная цепочка перед любым видимым ответом; Function Registry для PROJECT/PLAN/TASK.
- Проверки: `CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,...,svc.chat.reply_render"`.

### P28 — FeatureFlags

- Улучшения: ключи `pm.*` (профиль методологии, пороги evm/cpm, ui.toggles); `FLAGS.RECONCILE policy=p27`.
- Проверки: `FLAGS.APPLY_PROFILE name=prod_safe` ok.

### P29 — Quality (Gendarme/Judge)

- Улучшения: инспекторы `p40.project_cpm_consistency`, `p40.evm_sanity`, `p40.roles_baseline_valid`.
- Проверки: `TEST.RUN key=p29.pipeline_smoke` + вышеуказанные инспекторы проходят.

### P30 — Processor

- Улучшения: события `plan_update|goal_signal|change_request|risk_update`; идемпотентность по `dedup_key`.
- Проверки: `PROCESSOR.EVENT.INJECT ...` → `PROCESSOR.PROCESS_ONCE` ок; шаги `svc.processor.*` в подписи.

### P31 — Multisensory

- Улучшения: (опц.) сенсорные сигналы задач.
- Проверки: без регресса подписи/STRICT JSON.

### P32 — RBAC/Subscriptions

- Улучшения: роли `project.*`; ограничения инъекций/фасадов.
- Проверки: доступ без роли → 403; с ролью → 200.

### P33 — Personification & Profile

- Улучшения: влияние профиля на приоритет/повестку проекта; без изменения личности.
- Проверки: сценарии с разными профилями меняют приоритеты/бюджеты.

### P34 — External Chat Proxy

- Улучшения: импорт задач/рисков; idempotency‑key и аутентификация источника.
- Проверки: инъекция прокси‑событий обрабатывается, трасса валидна.

### P35 — Processes (UNIFIED)

- Улучшения: согласование эталонных процессов рождения квантов/целей/напоминаний с проектным контуром.
- Проверки: `INSPECTOR.RUN key=signature.required_steps.consistency` зелёный на проектных трассах.

### P36 — Hyperloop DSL

- Улучшения: команды PROJECT/PLAN/TASK/RISK/CHANGE/LIB + `METHODOLOGY.*`, `ROLE.*`.
- Проверки: `POST /api/hyperloop/execute` возвращает `trace_id`, шаги `cmd.hyperloop.*` и `svc.*` сохранены.

### P38 — NeuroTraining

- Улучшения: репликация устойчивых проектных структур в память Квантов; метрики окна TRAIN.
- Проверки: `TRAIN.METRICS.WINDOW window=24h` ок; соблюдение STRICT JSON.

### P39 — Sensory Memory

- Улучшения: (опц.) сенсорные якоря для проектных заметок.
- Проверки: интеграция с P31 без деградации P27/P30.

## 17) Acceptance (итог)

- Документ самодостаточен; схемы/DSL/инварианты определены; нет регресса по объёму/смыслу.
- Смоки DSL выполняются; ответы содержат `trace_id` и шаги подписи.
- В окне 24ч присутствуют записи `svc.processor.*` и `cmd.hyperloop.*` по проектным командам; инспекторы зелёные.

## 21) Обновления 2025‑09‑30 (реализация DSL и публичных фасадов)

Реализованные команды Hyperloop DSL (совместимо с PROD схемой БД):

- PROJECT: `PROJECT.GET`, `PROJECT.UPDATE`, `PROJECT.DELETE`
- RISK: `RISK.ADD`, `RISK.UPDATE`, `RISK.LIST`, `RISK.DELETE`
- CHANGE: `CHANGE.ADD`, `CHANGE.UPDATE`, `CHANGE.LIST`, `CHANGE.DELETE`
- METHODOLOGY: `METHODOLOGY.GET`, `METHODOLOGY.SET`, `METHODOLOGY.LIST`
- ROLE (RBAC P44): `ROLE.LIST`, `ROLE.USER.LIST`, `ROLE.LIMITS.LIST`
- LLM (P42): `LLM.SELECT`, `LLM.EVAL`

Публичные фасады API (read‑only) на базе фактических данных:

- `/api/personality/*`: `active`, `influence`, `catalog`
- `/api/media/*`: `artifacts`, `by-quant/{id}`
- `/api/monitoring/*`: `snapshot`, `incidents`
- `/api/incidents/metrics`
- `/api/subscriptions/*`: `status`, `plans`
- `/api/process/*`: `summary`, `incidents`

Статус смоков PROD:

- Health/DB/Dispatcher — OK (200), подписи присутствуют
- Новые DSL‑команды (PROJECT.GET/RISK.LIST/CHANGE.LIST) — ожидают деплоя на PROD (локально реализованы в `backend/app/services/hyperloop_engine.py`)

## 18) Примечания по реализации

- Реализация DSL‑команд добавляется в `hyperloop_engine.py`; хранение — через БД‑фасады/Policy P28.
- Опасные операции — только через Two‑Keys; статусы/отчёты — в панелях P23/P21.

- Детерминированные функции CPM/EVM/скоринга оформляются как чистые утилиты с unit‑тестами.

### 2.3 Примеры методологий (process_tree) и базовые настройки ролей

## 21.A) Ссылки на активные проекты (Plan‑Fact)

- P52 — Wakefulness (Режим Бодрствование):
  - branch: `tz52-wakefulness`
  - project_id: `f681c222-a1fc-4e51-b18a-aaca170e71ab`
  - anchor task (main): `d7f5235b-a3dc-4c6d-83d0-5aa577f2eac8`
  - subtasks (FS from anchor):
    - `3af69530-b96f-4f0b-986b-37b64916de17` — fatigue detector — metrics and alerts
    - `159f7499-2182-4f72-bfac-6c5558df0c1e` — D0 integration into sleep policies
    - `a683fa2a-1df7-45d7-970c-6917342081fb` — Architect UI — manual sleep adjustments

Примечание:

- При появлении первого артефакта реализации необходимо создать кванты‑ссылки через Hyperloop DSL:
  - `QUANT.LINK from_quant=<QID> to_entity_type=plan_task to_entity_id=<TASK_ID> relation_type=implements`
  - при продвижении плана/целей — relation_type: `supports|advances`.

- Waterfall (v1):

```json
{
  "Manager": ["Plan", "Decompose", "Assign", "Track", "Close"],
  "Administrator": ["Dispatch", "CollectStatus", "Report"],
  "Developer": ["Implement", "SelfTest", "Deliver"],
  "Tester": ["PlanTests", "RunTests", "ReportDefects"],
  "Riskman": ["Identify", "Score", "Mitigate"]
}
```

- Iterative (v1):

```json
{
  "Manager": ["Backlog", "SprintPlan", "Review", "Retrospective"],
  "Developer": ["Implement", "Demo"],
  "Administrator": ["BoardUpdate", "Metrics"],
  "Tester": ["DefineDoD", "RunRegression"],
  "Riskman": ["TrackSprintRisks"]
}
```

- Hybrid (v1):

```json
{
  "Manager": ["Plan", "SprintPlan", "MilestoneReview"],
  "Developer": ["Implement", "Demo"],
  "Administrator": ["Dispatch", "BoardUpdate"],
  "Tester": ["PlanTests", "RunTests"],
  "Riskman": ["Identify", "Score", "Mitigate"]
}
```

- role_baseline_settings (prod/dev дефолты):

```json
{
  "Manager": {"wip_limit": 5, "replan_window_days": 7},
  "Developer": {"wip_limit": 3, "code_review_required": true},
  "Tester": {"auto_regression": true},
  "Administrator": {"remind_overdue_ms": 3600000},
  "Riskman": {"score_threshold": 0.6}
}
```

- PROJECT.CREATE/UPDATE:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://soul/p40/project.schema.json",
  "type": "object",
  "required": ["name"],
  "properties": {
    "name": {"type": "string", "minLength": 1},
    "description": {"type": "string"},
    "methodology": {"type": "string", "enum": ["waterfall","iterative","agile","kanban","hybrid"]},
    "priority": {"type": "number", "minimum": 0, "maximum": 1},
    "owner": {"type": "integer"},
    "status": {"type": "string", "enum": ["active","archived"]}
  },
  "additionalProperties": false
}
```

- PLAN.TASK.ADD/UPDATE:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://soul/p40/plan.task.schema.json",
  "type": "object",
  "required": ["project_id", "title"],
  "properties": {
    "project_id": {"type": "string"},
    "title": {"type": "string"},
    "status": {"type": "string", "enum": ["todo","doing","done","blocked"]},
    "progress": {"type": "number", "minimum": 0, "maximum": 1},
    "cpm_duration_days": {"type": "number", "minimum": 0},
    "start_at": {"type": "string", "format": "date-time"},
    "due_at": {"type": "string", "format": "date-time"},
    "assignee": {"type": "integer"},
    "priority": {"type": "number", "minimum": 0, "maximum": 1}
  },
  "additionalProperties": false
}
```

- PLAN.TASK.DEPEND:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://soul/p40/plan.depend.schema.json",
  "type": "object",
  "required": ["predecessor", "successor", "dep_type"],
  "properties": {
    "predecessor": {"type": "string"},
    "successor": {"type": "string"},
    "dep_type": {"type": "string", "enum": ["FS","SS","FF","SF"]},
    "lag_days": {"type": "number", "minimum": 0}
  },
  "additionalProperties": false
}
```

- RISK.ADD/UPDATE:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://soul/p40/risk.schema.json",
  "type": "object",
  "required": ["project_id", "title"],
  "properties": {
    "project_id": {"type": "string"},
    "title": {"type": "string"},
    "severity": {"type": "string", "enum": ["low","medium","high","critical"]},
    "probability": {"type": "string", "enum": ["unlikely","possible","likely","almost_certain"]},
    "status": {"type": "string", "enum": ["open","mitigating","closed"]}
  },
  "additionalProperties": false
}
```

- CHANGE.ADD/APPROVE:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://soul/p40/change.schema.json",
  "type": "object",
  "required": ["project_id", "title"],
  "properties": {
    "project_id": {"type": "string"},
    "title": {"type": "string"},
    "type": {"type": "string", "enum": ["scope","schedule","budget","quality"]},
    "reason": {"type": "string"},
    "approved": {"type": "boolean"}
  },
  "additionalProperties": false
}
```

### 10.2 OpenAPI — расширенные фрагменты

```yaml
openapi: 3.1.0
info: { title: P40 API, version: 1.0.0 }
paths:
  /api/projects:
    get:
      summary: List projects
      parameters:
        - in: query
          name: owner
          schema: { type: integer }
        - in: query
          name: status
          schema: { type: string, enum: [active, archived] }
      responses: { '200': { description: OK } }
    post:
      summary: Create project
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: 'https://soul/p40/project.schema.json'
      responses: { '201': { description: Created } }
  /api/projects/{id}:
    get:
      summary: Get project
      parameters:
        - in: path
          name: id
          required: true
          schema: { type: string }
      responses: { '200': { description: OK }, '404': { description: Not Found } }
    put:
      summary: Update project
      parameters:
        - in: path
          name: id
          required: true
          schema: { type: string }
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: 'https://soul/p40/project.schema.json'
      responses: { '200': { description: Updated } }
    delete:
      summary: Delete project
      parameters:
        - in: path
          name: id
          required: true
          schema: { type: string }
      responses: { '204': { description: No Content } }
  /api/plan/tasks:
    post:
      summary: Add plan task
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: 'https://soul/p40/plan.task.schema.json'
      responses: { '201': { description: Created } }
    get:
      summary: List plan tasks
      parameters:
        - in: query
          name: project_id
          required: true
          schema: { type: string }
      responses: { '200': { description: OK } }
  /api/plan/tasks/{id}:
    get:
      summary: Get task
      parameters:
        - in: path
          name: id
          required: true
          schema: { type: string }
      responses: { '200': { description: OK }, '404': { description: Not Found } }
    patch:
      summary: Update task
      parameters:
        - in: path
          name: id
          required: true
          schema: { type: string }
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: 'https://soul/p40/plan.task.schema.json'
      responses: { '200': { description: Updated } }
    delete:
      summary: Delete task
      parameters:
        - in: path
          name: id
          required: true
          schema: { type: string }
      responses: { '204': { description: No Content } }
  /api/plan/dependencies:
    post:
      summary: Add dependency
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: 'https://soul/p40/plan.depend.schema.json'
      responses: { '201': { description: Created } }
    delete:
      summary: Remove dependency
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: 'https://soul/p40/plan.depend.schema.json'
      responses: { '204': { description: No Content } }
  /api/risks:
    post:
      summary: Add risk
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: 'https://soul/p40/risk.schema.json'
      responses: { '201': { description: Created } }
    get:
      summary: List risks
      parameters:
        - in: query
          name: project_id
          required: true
          schema: { type: string }
      responses: { '200': { description: OK } }
  /api/risks/{id}:
    patch:
      summary: Update risk
      parameters:
        - in: path
          name: id
          required: true
          schema: { type: string }
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: 'https://soul/p40/risk.schema.json'
      responses: { '200': { description: Updated } }
  /api/changes:
    post:
      summary: Propose change
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: 'https://soul/p40/change.schema.json'
      responses: { '201': { description: Created } }
  /api/changes/{id}/approve:
    post:
      summary: Approve change (Two-Keys)
      parameters:
        - in: path
          name: id
          required: true
          schema: { type: string }
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              properties:
                approved: { type: boolean }
                request_id: { type: string, format: uuid }
              required: [approved, request_id]
      responses: { '200': { description: Approved } }
```

### 3.3.1 SQL DDL (эскиз)

```sql
create table projects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  methodology text check (methodology in ('waterfall','iterative','agile','kanban','hybrid')),
  priority double precision check (priority between 0 and 1),
  owner bigint,
  status text default 'active' check (status in ('active','archived')),
  created_at timestamptz not null default now()
);

create table plan_tasks (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  title text not null,
  status text default 'todo' check (status in ('todo','doing','done','blocked')),
  progress double precision default 0 check (progress between 0 and 1),
  cpm_duration_days double precision,
  cpm_es date, cpm_ef date, cpm_ls date, cpm_lf date, slack_days double precision,
  start_at timestamptz, due_at timestamptz,
  assignee bigint,
  priority double precision,
  created_at timestamptz not null default now()
);
create index idx_plan_tasks_project on plan_tasks(project_id);
create index idx_plan_tasks_due on plan_tasks(due_at);

create table plan_task_dependencies (
  id uuid primary key default gen_random_uuid(),
  predecessor uuid not null references plan_tasks(id) on delete cascade,
  successor uuid not null references plan_tasks(id) on delete cascade,
  dep_type text not null check (dep_type in ('FS','SS','FF','SF')),
  lag_days double precision default 0
);
create unique index uq_plan_dep_pair on plan_task_dependencies(predecessor, successor);

create table risks (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  title text not null,
  severity text check (severity in ('low','medium','high','critical')),
  probability text check (probability in ('unlikely','possible','likely','almost_certain')),
  status text default 'open' check (status in ('open','mitigating','closed')),
  exposure_score double precision,
  created_at timestamptz not null default now()
);
create index idx_risks_project on risks(project_id);

create table changes (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  title text not null,
  type text check (type in ('scope','schedule','budget','quality')),
  reason text,
  approved boolean,
  created_at timestamptz not null default now()
);
create index idx_changes_project on changes(project_id);
```

### 3.4 Alembic — эскиз миграции

```python
from alembic import op
import sqlalchemy as sa

revision = 'p40_init'
down_revision = None

def upgrade():
    op.execute("""
    -- SQL из §3.3.1
    """)

def downgrade():
    op.execute("""
    drop table if exists plan_task_dependencies;
    drop table if exists plan_tasks;
    drop table if exists risks;
    drop table if exists changes;
    drop table if exists projects;
    """)
```

### 3.5 Seed‑данные (эскиз)

```sql
insert into projects(name, methodology, priority, owner) values
 ('P40 MVP','hybrid',0.8,468326902);

with p as (
  select id as project_id from projects where name='P40 MVP'
)
insert into plan_tasks(project_id, title, cpm_duration_days, due_at)
select project_id, 'CPM расчёт', 2.5, now() + interval '7 days' from p union all
select project_id, 'EVM расчёт', 1.0, now() + interval '8 days' from p union all
select project_id, 'UI: Gantt', 3.0, now() + interval '10 days' from p;

insert into risks(project_id, title, severity, probability)
select project_id, 'LLM таймаут', 'high', 'likely' from p union all
select project_id, 'Недоступность БД', 'critical', 'possible' from p;
```

### 11.2 Приоритеты событий и Runbooks

- Приоритеты и очереди:
  - p1: `incident`, `change_request(critical)`, `dev_task_progress(blocked)`
  - p2: `plan_update`, `risk_update(high)`, `dev_task_assigned`
  - p3: `risk_update`, `change_request(normal)`
- dedup_key примеры:
  - `dev:{task_id}:progress:{ts_bucket}`
  - `plan:{project_id}:cpm:{yyyy_mm_dd}`
- Runbooks эскалаций: матрица P‑классов, ответственные (Менеджер/Администратор/Рискмен), авто‑реплан, уведомления.

### 19) UX/UI

- Состояния карточек: empty/error/loading; RU/EN локализация; доступность (клавиатура, контраст).

### 20) Операции/регламенты

- Инциденты: MTTA/MTTR цели и процедура.
- Регламенты: расписание проверок/архивации; политика версионирования (semver P‑серии).

## 2.2) Обязательная проектная ветка и автозагрузка промпта (Cursor/Soul)

Цель: исключить нерегламентированные изменения и обеспечить трассируемость проектных работ всеми LLM‑агентами.

Правила (обязательно для всех агентов и интеграций):

- Перед началом любой активности агент обязан заявить семантическую ветку (см. §2.1):
  - `INSPECTOR.RUN key=plan.branch action=claim_branch branch=<area/module/topic> owner=<tg_id>`
  - По завершении работ выполнить `action=release_branch`.
  - Быстрый путь (Hyperloop DSL для Cursor/Soul):
    - `SESSION.CLAIM owner="<tg_id>" branch="<area/module/topic>" topic="<t>" session="<sid>"`
    - `SESSION.PING owner="<tg_id>" session="<sid>"`
    - `DEV.CONNECT owner="<tg_id>" branch="<area/module/topic>"` — claim+heartbeat одной командой
    - `LLM.MIRROR owner="<tg_id>" branch="<key>" topic="dev" user_command="..." agent_reply="..." [plan_task_id=<UUID>]` — план‑факт зеркало действий
- Все запросы агентов должны сопровождаться автозагрузкой системного промпта разработки, включающего:
  - Правила ветвления/блокировок (P40 §2.1) и требование активной ветки.
- Структуру проектных документов и реестр (`docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md`).
  - Структуру Проектного модуля (этот документ, §3–§5) с методологиями, ролями и инвариантами.
  - Требование зеркалирования действий через `INSPECTOR.RUN key=llm.mirror` (P48) с `payload.plan.task_id`.
- Запросы без активной ветки или без промпта считаются нарушением процесса; ядро имеет право блокировать выполнение и регистрировать инцидент.

Наблюдаемость/Контроль:

- Инспектор `planning.enforce` проверяет наличие `payload.plan`/`quant_links` и ветки.
- Инспектор `llm.mirror` формирует кванты с `tags` и ссылками на `plan_task/skills/goals`.
- В `.cursorrules` зафиксировано обязательное применение проектной ветки и автопромпта.

## 2.3) Быстрый контур работы с проектным репозитарием (Hyperloop, Windows PowerShell)

Назначение: единый, быстрый и безошибочный способ выполнять рутинные операции с проектным репозитарием и план‑фактом через Hyperloop DSL. Все команды выполняются через PROD API и требуют заголовок `X-Telegram-User-ID: 468326902`.

### 2.3.0 Политика «First‑Try Success» и автокоррекция (обновление: Hyperloop CLI)

- Инвариант: запросы должны выполняться с первого раза без подбора кавычек/вариантов.

Алгоритм:

1) Primary: PowerShell `Invoke-RestMethod` либо `python .\Soul\scripts\hyperloop_cli.py` с `--dsl` (REMAINDER) и `--post-json-rem`.
2) Fallback: формирование файла `tmp_body.json` и вызов `curl.exe --data-binary "@tmp_body.json"` при ошибках кавычек/заголовков/URL; для POST рекомендуется `--post-json-file` в CLI.
3) Максимум две попытки (primary → fallback). При повторной ошибке — зафиксировать инцидент (P27/P29) и выполнить `INSPECTOR.RUN key=planning.enforce` для диагностики.
4) Всегда зеркалировать действия `LLM.MIRROR(.BATCH)` с `payload.plan.task_id` (если задан) — P48.

#### 2.3.0.1 Таксономия ошибок подключения (канонично)

- quotes_error: ошибки кавычек/экранирования (PowerShell строки, JSON)
- header_missing: отсутствует `X-Telegram-User-ID` или неверный `Content-Type`
- url_malformed: ошибка URL/домен/прокси (bad hostname/malformed)
- timeout: сетевой/гейтвей таймаут (502/504)
- auth_forbidden: недостаточные права/RBAC
- other: прочее (с детализацией `error_message`)

Метрики: `planning_connect_error_total{type}`; отчёт по p50/p95 времени первого успешного подключения.

#### 2.3.0.2 Матрица тестов стабильности (смоки)

1) Primary успех: SESSION.CLAIM (если доступно) → PROJECT.LIST (200, есть `signature_steps`). DEV.CONNECT — опционально.
2) quotes_error симуляция → fallback через файл выполняется успешно.
3) header_missing → авто‑добавление корректных заголовков и повтор (1 раз).
4) url_malformed → фиксируется инцидент, без повторов, диагностический INSPECTOR.RUN planning.enforce.
5) timeout (502/504) → повтор через fallback, затем INCIDENT.CREATE severity=2 при повторении.
6) auth_forbidden → 403 фиксируется, без повторов; рекомендация RBAC.

Примеры устойчивых вызовов (CLI):

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
$B=@{ commands='SESSION.CLAIM owner="468326902" branch="p40-dev" topic="planning" session="dev-001"' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

'{ "commands": "PROJECT.LIST" }' | Set-Content -Path tmp_body.json -Encoding UTF8 -NoNewline
python .\Soul\scripts\hyperloop_cli.py --http-post https://mini.soulpulse.art/api/hyperloop/execute --post-json-file tmp_body.json

# DSL с остатком (WITH TRACE): ставьте --dsl последним
python .\Soul\scripts\hyperloop_cli.py --dsl CORE.PIPELINE.RUN input_text=\"health check\" WITH TRACE

'{ "commands": "PROJECT.LIST" }' | Set-Content -Path tmp_body.json -Encoding UTF8 -NoNewline
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -H "Content-Type: application/json" --data-binary "@tmp_body.json" https://mini.soulpulse.art/api/hyperloop/execute
```
