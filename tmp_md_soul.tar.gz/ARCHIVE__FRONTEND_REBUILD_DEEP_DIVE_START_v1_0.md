# ARCHIVE — устаревший документ, заменён P23 (см. Soul/P23_TZ_Soul_UI_Rebuild_v1_0.md, Soul/P23_TZ_UI_Spec_v2_1.md)

> Внимание: документ устарел и консолидирован в номерной P‑серии. Актуальные требования и рунбуки перенесены в `Soul/P23_TZ_Soul_UI_Rebuild_v1_0.md` и `Soul/P23_TZ_UI_Spec_v2_1.md`.

## Soul — Frontend Rebuild Deep‑Dive Start v1.0

Версия документа: v1.0

Основано на: `Plan/FRONTEND_CLEAN_REBUILD_PLAYBOOK_v1_0.md`, `Soul/P23_TZ_Soul_UI_Rebuild_v1_0.md`, `Soul/P23_TZ_UI_Spec_v2_1.md`.

Плейсхолдеры, заполнённые для быстрого старта:
- API_BASE: https://mini.soulpulse.art/api
- ADMIN_TG_ID: 468326902

Документ самодостаточный: включает доступы/секреты (для локального хранения), SSH/деплой‑рунбуки, реестры, правила разработки, чек‑листы и быстрые проверки. Не коммитьте реальные секреты в репозиторий.

---

### 0) Контекст ветки

- Ветка: {BRANCH_NAME}, версия: {BRANCH_VERSION}, дата: {DATE}
- Цели инкремента (пример):
  - Восстановить чистый фронтенд (Mini‑App + Web) без регресса согласно P23
  - Включить Stage 1 (Header, Start, Chat, DatesReminders), DIAG, безопасный старт
  - Подготовить RBAC‑грид (read‑only API) и админ‑кнопки BotControl (start/stop/status)
- Ограничения: фичефлаги (`ROUTES_STAGE`, `ENABLE_PERMS`), бюджеты TTI (Mini‑App ≤ 1.5s; Web ≤ 2.0s)

---

### 1) PROD/DEV окружение (канонично)

- API: https://mini.soulpulse.art/api
- Обязательный заголовок: `X-Telegram-User-ID: 468326902`
- PROD пути:
  - ENV: `/etc/soulpulse/miniapp_backend.env`
  - systemd: `soulpulse-backend.service`
  - Nginx: `/etc/nginx/sites-enabled/03-mini_soulpulse.conf`
- PowerShell (Windows):

```powershell
$OutputEncoding = [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
```

---

### 2) Доступы, ключи и секреты (консолидация)

Внимание: хранить локально (вне репозитория). Источники инвентаря: `docs/SECRETS_INVENTORY_2025-09-15.md`, Guardian `Plan/guardian/storage/data/servers.json`.

#### 2.1 Переменные окружения (prod)

- Хранятся в: `/etc/soulpulse/miniapp_backend.env`
- Ключевые переменные: `DATABASE_URL`, `BOT_TOKEN`, `BOT_TOKENS`, `JWT_SECRET`, `DEEPSEEK_API_KEY`, `CORS_ORIGINS`, `SOUL_DISABLE_QUANT_PERSIST_BATCH`, `TEST_NO_DB`, `LLM_PROVIDER`, `DEEPSEEK_MODEL`
- Получение (SSH):

```bash
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art \
  "grep -E '^(DATABASE_URL|BOT_TOKEN|BOT_TOKENS|JWT_SECRET|DEEPSEEK_API_KEY|LLM_PROVIDER|DEEPSEEK_MODEL)=' /etc/soulpulse/miniapp_backend.env"
```

Локальные примерные значения (для личного хранения, не коммитить):

- `DATABASE_URL=postgresql+asyncpg://miniapp_user:miniapp_pwd@46.173.24.4:5432/miniapp_db`
- `BOT_TOKEN=8236996666:AAFdY2uSqoNIxFibTXolnrLBYjTTK_DWF-E`
- `BOT_TOKENS=8236996666:AAFdY2uSqoNIxFibTXolnrLBYjTTK_DWF-E`
- `JWT_SECRET=15Z9NIaD2LRfmVHaTt96T3pOiHu1fWnI9HwhAjj9mJVoh0Pq`
- `DEEPSEEK_API_KEY=sk-32a76a58a2384977b8d05fb9bee194bb`
- `CORS_ORIGINS=https://mini.soulpulse.art`
- `LLM_PROVIDER=deepseek`
- `DEEPSEEK_MODEL=deepseek-chat`

#### 2.2 Telegram/боты (локальные примеры)

- `BOT_TOKENS (local test)=8260946317:AAGkYKYWD8WNnEIgFXghqk_pToYKJRcN2FM` (не использовать в PROD)
- `TELEGRAM_BOT_TOKEN (example)=your_bot_token_here`

#### 2.3 База данных

- PROD host: `46.173.24.4`, DB: `miniapp_db`, User: `miniapp_user`
- Тестовый DSN (пример): `postgresql+asyncpg://miniapp_user:miniapp_pwd@127.0.0.1:5432/miniapp_db`

#### 2.4 SSH доступы

- Приложение (prod): `root@mini.soulpulse.art:22` (ключ: `deploy/ssh_keys/app_server_key`)
- Пользователь приложения: `soulpulse@mini.soulpulse.art:22`
- Сервер БД: `root@46.173.24.4:22` (ключ: `deploy/ssh_keys/db_server_key`)

Проверка:

```bash
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "hostname"
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new soulpulse@mini.soulpulse.art "whoami"
ssh -i deploy/ssh_keys/db_server_key  -o StrictHostKeyChecking=accept-new root@46.173.24.4 "hostname"
```

#### 2.5 SSL/домены

- Домен PROD: `mini.soulpulse.art`
- Сертификаты: `/etc/letsencrypt/live/mini.soulpulse.art/fullchain.pem`, `privkey.pem`

Проверка срока:

```bash
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art \
  'openssl x509 -in /etc/letsencrypt/live/mini.soulpulse.art/fullchain.pem -noout -enddate'
```

---

### 3) Реестры и документы (must‑read)

- Индекс документации: `docs/DOCUMENTATION_INDEX_v4_2.md`
- Структура проекта: `docs/PROJECT_STRUCTURE_v8_0_4.md`
- Soul pipeline: `docs/SOUL_PIPELINE_v1_1.md`
- Структура БД: `docs/DATABASE_STRUCTURE_v8_0_2.md`
- OpenAPI (P20): `docs/openapi-p20-telegram-bots.yaml`
- P‑серия (источник истины): `Soul/` (в т.ч. P23)
- Научный отчёт: `Soul/Report_Soul_AI_Scientific.md`
- Project AI Autopilot: `Soul/PROJECT_AI_AUTOPILOT_v2_26.md`
- Регистры: `docs/REGISTRIES_INDEX.md`, `docs/DOCS_REGISTRY_v8_0_4.md`
- CI/Метрики: `scripts/ci_generate_metrics.py` (артефакты `Soul/CI/*`)

Чек‑лист актуализации после изменений:

- Обновить соответствующий P‑документ (если меняется функциональность)
- Синхронизировать OpenAPI ↔ Pydantic ↔ БД (Alembic)
- Обновить `PROJECT_STRUCTURE_v8_0_4.md` и индексы
- Прогнать `scripts/ci_generate_metrics.py` и приложить отчёт
- Обновить гайды (тесты, системные обзоры, инфраструктура)

---

### 4) Правила разработки (жёсткие)

- Stateless batch вначале: LLM‑вызовы с `db=None`; строго‑валидный JSON; в stateless `desired_action=[]`
- Фоллбек: batch→single; persistent включать после стабилизации
- Никаких заглушек; только исправление корневых причин
- Модули policy‑extract; NEGATIVE‑санитизация обязательна
- Единая сборка SYSTEM/USER: `[CORE][ROUTER_CONTEXT][MODULES][OUTPUT_SPEC][NEGATIVE] + history + input_text`
- Контракты: Pydantic Strict, `row_version`, `ETag/If-Match` для PATCH/PUT
- Schema Guard: снимок схем, semver; CI‑гейт
- RBAC/Scopes и two‑keys для чувствительных операций
- Observability by default: события/метрики/трейсинг; SLO/алерты

---

### 5) Быстрые проверки PROD (после деплоя)

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/health
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/admin/soul/db/check
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/soul/llm/test?provider=deepseek&prompt=ping' -Headers $H -Method Get
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/dispatcher/run_for?minutes=1' -Headers $H -Method Post | ConvertTo-Json -Compress
Start-Sleep -Seconds 2
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/dispatcher/metrics' -Headers $H -Method Get | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/dispatcher/stop' -Headers $H -Method Post | ConvertTo-Json -Compress
$Q='P07: desired_action: [{"type":"reminder","text":"Позвонить маме","when":"2025-09-15T10:00:00Z"}]'
$B=@{ input_text=$Q } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/soul/process' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Depth 12 -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/soul/sleep?dry_run=true' -Headers $H -Method Post | ConvertTo-Json -Depth 8 -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/soul/qa/quants_sanity?limit=10' -Headers $H -Method Get | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/soul/refresh-rank' -Headers $H -Method Post | ConvertTo-Json -Compress
```

---

### 6) Режимы исполнения

- Batch/stateless: верхний уровень STRICT JSON, `desired_action=[]`, LLM вызовы с `db=None`
- Single/persistent: транзакция message→quant→relations/goals; строгая валидация `desired_action: List[dict]`

---

### 7) Acceptance (принятие инкремента)

- Batch(stateless) — валидный массив квантов; `desired_action=[]`
- Single — корректная персистенция кванта/связей/целей
- Health/DB/LLM/Dispatcher/Sanity/Refresh/Sleep — 200; логи чистые; 5xx нет

---

### 8) Траблшутинг

- ImportError `system_api`: защитить импорт флагом; быстрая деактивация через ENV; корректный фикс в `app/main.py`
- 504/таймауты: снизить `num_quants` до 1–3; проверить Nginx `proxy_*_timeout`, systemd `Restart=always`
- STRICT JSON: верхний уровень — массив/объект без markdown; числа → float; `tags: List[str]`
- `desired_action`: в stateless всегда `[]`
- `greenlet_spawn`: все LLM‑вызовы stateless — с `db=None`

---

### 9) Rollback (без простоя)

```powershell
scp -i .\Arh\spbd_ed25519 -o StrictHostKeyChecking=accept-new backend/app/services/soul_core_manager.py `
  root@217.12.38.238:/opt/soulpulse/app/Telegram_Bot/backend/app/services/
ssh -i .\Arh\spbd_ed25519 -o StrictHostKeyChecking=accept-new root@217.12.38.238 `
  "systemctl restart soulpulse-backend.service ; systemctl is-active soulpulse-backend.service ; journalctl -u soulpulse-backend.service -n 50 --no-pager"
```

---

### 10) Nginx/Backend sanity (SSH)

```bash
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art \
  'nginx -t && systemctl reload nginx && echo RELOADED'
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art \
  'ss -ltnp | egrep ":(22|80|443|8000)" ; systemctl is-active soulpulse-backend.service'
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art \
  'tail -n 120 /var/log/nginx/error.log'
```

---

### Оперативные рунбуки (из Playbook)

Аварийная форма `/minimal`:

```powershell
$f = "$PWD/tmp/sp_minimal_index.html"; New-Item -Force -ItemType Directory tmp | Out-Null; Set-Content -Path $f -Value (Get-Content -Raw Plan/FRONTEND_CLEAN_REBUILD_PLAYBOOK_v1_0.md | Select-String -Pattern '<!doctype html>' -Context 0,0).Matches[0].Value -Encoding utf8
scp -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new $f root@mini.soulpulse.art:/var/www/soulpulse/frontend/minimal/index.html
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc 'nginx -t && systemctl reload nginx && echo READY && curl -sI https://mini.soulpulse.art/minimal/ | head -n 1'"
```

Чистый старт фронтенда в `/var/www/soulpulse/frontend`:

```powershell
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc 'set -e; BASE=/var/www/soulpulse; ts=`$(date +%Y%m%d_%H%M%S); [ -d "`$BASE/frontend" ] && cp -a "`$BASE/frontend" "`$BASE/frontend_backup_`$ts" || mkdir -p "`$BASE/frontend"; echo BACKUP:frontend_backup_`$ts'"
$h='<!doctype html><html lang="ру"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/><title>SoulPulse — аварийный старт</title><meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/><meta http-equiv="Pragma" content="no-cache"/><meta http-equiv="Expires" content="0"/><style>:root{--bg:#0f172a;--card:#111827;--text:#e5e7eb;--muted:#93c5fd}*{box-sizing:border-box}html,body{height:100%;margin:0}body{display:flex;align-items:center;justify-content:center;background:var(--bg);color:var(--text);font:14px ui-monospace,monospace}.card{background:var(--card);border:1px solid #1f2937;border-radius:14px;padding:20px;min-width:300px;max-width:680px;box-shadow:0 10px 30px rgba(0,0,0,.35)}h1{margin:.2rem 0 1rem 0;font-size:18px}.muted{color:var(--muted)}.err{color:#fca5a5}img{max-width:160px;border-radius:12px;border:1px solid #1f2937;display:block;margin:0 auto 10px auto}</style></head><body><div class="card"><img src="./Soul6.png" alt="Soul" onerror="this.style.display=\"none\""/><h1>SoulPulse — аварийный старт</h1><div class="muted">PROD · mini.soulpulse.art · <span id="ts"></span></div><div class="err" id="errmsg">Основной интерфейс временно недоступен. Попробуйте обновить мини‑апп позже.</div></div><script>(function(){try{document.getElementById("ts").textContent=new Date().toISOString();var u=new URL(window.location.href);var m=u.searchParams.get("err");if(m){document.getElementById("errmsg").textContent=m;}}catch(e){}})();</script></body></html>'
New-Item -Force -ItemType Directory tmp | Out-Null; Set-Content -Path .\tmp\sp_index.html -Value $h -Encoding utf8
scp -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new .\tmp\sp_index.html root@mini.soulpulse.art:/var/www/soulpulse/frontend/index.html
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc 'nginx -t && systemctl reload nginx && echo READY && curl -sI https://mini.soulpulse.art/ | head -n 1'"
```

Rollback фронтенда:

```powershell
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc 'set -e; BASE=/var/www/soulpulse; L=`$(ls -1dt `$BASE/frontend_backup_* 2>/dev/null | head -n1); if [ -n "`$L" ]; then cp -a "`$L" "`$BASE/frontend"; fi; nginx -t && systemctl reload nginx и echo ROLLED'"
```

---

### Требования к Nginx (PROD)

```nginx
root /var/www/soulpulse/frontend;
location / { try_files $uri /index.html; }
location /assets/ {
  try_files $uri =404;
  expires 30d;
  add_header Cache-Control "public, max-age=2592000, immutable";
  types { application/javascript js; text/css css; }
}
add_header Cache-Control "no-store";
charset utf-8;
charset_types text/plain text/css application/javascript application/json text/xml application/xml;
```

---

### Минимальный фреймворк UI (Stage 0 → Stage 1)

- Router: `MemoryRouter`
- Флаги: `window.__SP_FLAGS__` (SAFE_BOOT, NOREDIRECT, DIAG, ROUTES_STAGE, ENABLE_PERMS)
- Детект Mini‑App: `Telegram.WebApp`/UA/referrer (без зависимости от `tg_id`)
- Mini‑App: без авторедиректов; `WebAuth` только для Web
- Метка сборки: `window.__SP_BUILD__=<timestamp>` (DIAG/футер)

---

Этот документ является входной точкой для восстановления фронтенда без регресса. Следуйте этапам раскатки, поддерживайте реестры и индексы в актуальном состоянии и выполняйте быстрые проверки после каждого шага.
