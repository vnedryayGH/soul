---

## Индекс взаимных ссылок (P01–P37)
- P13 Eval — связь с измерениями качества.
- P21 Monitoring — алерты качества.
- P33 Personification — гварды качества ответов Mini Chat.
- P36 Hyperloop DSL — запуск проверок правил.
## P29 — ТЗ: Реестр Тестов, Жандарм (тест-оркестратор) и Судья (контроль Уставов)

Версия: v1.1  
Статус: MVP работает; Suite зелёный на PROD (см. статус тестов)

### 1. Цели
- Централизовать описание тестов и их запуск/анализ (Жандарм).
- Ввести Уставы (charters) и Судью, проверяющих соблюдение правил (качество, чистота кода, политика автокодинга).
- Вести Заявления (requests) и Архивариуса (учёт, обмен с Архитектором).

### 2. Схемы (ensure скрипт)
- `tests_registry`, `test_results`, `charters`, `charter_incidents`, `service_requests` — см. `backend/tools/ensure_quality_tables.py`.

— Связь с P36 (Hyperloop DSL): тесты и проверки должны быть доступны из DSL через `TEST.RUN` и `INSPECTOR.RUN(_ALL)`, а результаты — видимы в нормализованном ответе Hyperloop (`results[]`, `signature.steps`, `incidents`).

### 3. Жандарм
- Сервис: `backend/app/services/gendarme_service.py`
- Админ‑API: `backend/app/routers/gendarme_admin.py`
  - `POST /api/admin/gendarme/tests/register` — регистрация/обновление теста
  - `GET  /api/admin/gendarme/tests` — список
  - `POST /api/admin/gendarme/tests/run` — запуск теста
  - `POST /api/admin/gendarme/tests/run-suite` — запуск набора тестов (по категории)
- Панель: `/admin/gendarme` — список тестов, запуск, последние результаты
- Хранилище результатов: `test_results(id, test_key, status, metrics jsonb, detail text)`

#### 3.1 Тесты цепочек навыков (Skill Chains)
- Ключи тестов (реестр/плагины):
  - `skill_chain.apply_and_trace` — единичное применение навыка с трассировкой P27; wrapper: `skill_chain_apply_and_trace_demo_skill`
  - `skill_chain.golden_eval` — проверка против golden‑кейсов; wrapper: `skill_chain_golden_eval_demo_skill`
  - `skill_chain.sleep_optimize_then_apply` — оптимизация во сне и повторное применение; wrapper: `skill_chain_sleep_optimize_then_apply_demo_skill`
- Expected outcome (пример для demo.skill):
```json
{
  "skill_key": "demo.skill",
  "status": "passed",
  "metrics": {
    "json_valid": true,
    "signature_steps_present": [
      "svc.soul.preanalysis",
      "svc.soul.router_decide",
      "svc.llm_client.send",
      "svc.llm_client.recv",
      "svc.parser.json_strict",
      "svc.chat.reply_render"
    ]
  }
}
```
- Вызов через Hyperloop (см. P36): `SKILL.TEST key=skill_chain.golden_eval.demo.skill`

### 4. Судья и Уставы
- Реестр Уставов: `charters(name, version, text, enforced)`
- Судья: сервис проверки соблюдения (lint, policy, запрет автокодинга вне регламента, чистота PR)
- Инциденты Устава: `charter_incidents`
- Интеграции: при нарушениях — запись инцидента, Заявление Архитектору, запуск тестов Жандармом.
- Админ‑API (план расширения): `POST /api/admin/judge/charter/upsert`, `POST /api/admin/judge/check`

— Инциденты Судьи (реализация): метод `JudgeService.record_incident(...)` пишет строки в `charter_incidents`.
— Hyperloop DSL команды `JUDGE.CHARTER.UPSERT` и `JUDGE.CHECK` доступны (см. P36), фиксируют шаги `cmd.hyperloop.judge.*`.
— Архивариус: заявки (`service_requests`) доступны через админ‑API `archivarius_admin` и DSL `REQUEST.*` (см. P36).

### 4.1 Two-Keys для опасных операций (MVP)
- Чувствительные операции требуют двукратного подтверждения (Two-Keys):
  - `JUDGE.CHARTER.UPSERT` с `enforced=true` или категориями `core_safety|danger|security`
  - `FLAGS.SET` для ключей: `delivery_guard.enforce`, `hyperloop.allow_signed`, `processor.enabled`
- Процедура:
  1) Создать заявку: `POST /api/admin/two-keys/requests { operation, scope, reason }`
  2) Получить `request_id` и передать его в DSL: `... request_id=<UUID>`
  3) Подтверждение: `POST /api/admin/two-keys/approve { request_id }`
- Без валидного `request_id` опасные команды в DSL вернут ошибку: `two-keys approval required`.

Пример (Hyperloop):
```text
# Созданный заранее request_id=... (через API)
FLAGS.SET key=delivery_guard.enforce value=true request_id=<UUID>
JUDGE.CHARTER.UPSERT name=core_safety version=v1 text="no dangerous ops" enforced=true request_id=<UUID>
```

### 5. Заявления и Архивариус
- Сущность: `service_requests(type, subject, payload, status)`
- Архивариус: сервис/роуты для обмена с Архитектором и фиксации исполнения.

### 6. Политики/флаги
- Политики процессора: `processor_policies(key text primary key, value jsonb, updated_at)`
  - Примеры ключей: `block.all`, `block.chat_message`
- Настройки (флаги): `soul_settings` через `SoulSettingsService`
  - `gendarme.enabled` (bool) — включение планировщика Жандарма
  - `gendarme.scheduler_interval_sec` (int)
  - `hyperloop.allow_signed` (bool) — разрешить подписанный внешний DSL (по умолчанию true, вызовы внешние могут быть отключены на PROD)

### 7. Acceptance
- Таблицы созданы; API Жандарма работает (регистрация/список/запуск, запись результата).
- Минимальные кейсы заведены в `tests_registry` и/или доступны как плагины `backend/app/gendarme_tests/*`.
- Логи/аудит фиксируют операции (best‑effort).
- Сервисный анализ фейлов выполняется через LLM (GigaChat по умолчанию, таймаут 1.5s, retries=0; fallback на DeepSeek).
  - Формат ответа анализа: `ANALYSIS: <кратко>; ACTIONS: [a; b; c]`.
- Hyperloop DSL процедуры тестирования (обязательное покрытие):
  - `INSPECTOR.RUN_ALL` возвращает сводный статус инспекторов, включая `signature.required_steps.consistency`.
  - Для трасс из `CORE.PIPELINE.RUN ... WITH TRACE` шаги `svc.soul.router_decide` и `svc.chat.reply_render` присутствуют в `signature_steps` (best‑effort фиксация движком Hyperloop и коммит в БД).
  - Возврат нормализованного ответа с `signature.trace_id` и возможностью получить `TRACE.STEPS`.

### 8. Runbook
- Инициализация: `PYTHONPATH=. venv/bin/python tools/ensure_quality_tables.py`
- Регистрация теста: `POST /api/admin/gendarme/tests/register`
- Запуск: `POST /api/admin/gendarme/tests/run {"test_key":"p29.pipeline_smoke"}`
- Suite: `POST /api/admin/gendarme/tests/run-suite {"category":"P29"}`

### 9. Статус тестов (последний прогон)
- p29.processor_cycle — passed
- p29.pipeline_smoke — passed
- p29.hyperloop_policy_block — passed
- p29.judge_charter — passed (JudgeService задеплоен)
- skill_chain.golden_eval.demo.skill — passed (duration_ms≈31263)
- skill_chain.sleep_optimize_then_apply.demo.skill — passed (duration_ms≈39266)
- skill_chain.apply_and_trace.demo.skill — passed (duration_ms≈34808)

### 10. Следующие шаги
- Починить кейсы HyperloopEngine для команд `JUDGE.*` и довести P29 Suite до 100% зелёного.
- Добавить авто‑правила Судьи (пороговые политики) и тренды в панели Жандарма.
 - Формализовать профили запуска Hyperloop для регрессионного набора (prod_safe/dev_full), описать в P36 и реестре.

### 11. Ограничения и отложенные работы
- Задача «Довести P29 Suite до 100% зелёного» — НЕ ВЫПОЛНЕНА, ОТЛОЖЕНО.
  - Блокер: отсутствует `judge_service` на PROD для кейса `p29.judge_charter`.
  - Действия для разблокировки: задеплоить `backend/app/services/judge_service.py` и зависимости; повторить Suite.

### 12. Интеграция с P36 (Hyperloop DSL)
- Единый формат (см. `P36_TZ_Hyperloop_DSL_v1_1.md`):
  - Внутренний `POST /api/hyperloop/execute` (RBAC `soul.admin`)
  - Внешний `POST /api/hyperloop/execute-signed` (HMAC, флаг `hyperloop.allow_signed=true`)
  - Запрос: `{ "commands": "...\n...", "options": {"stop_on_error": true} }`
  - Ответ: нормализованный e2e с `results[]`, `signature.steps`, `incidents`, `ok`
- Вызовы Жандарма через DSL:
  - `TEST.RUN key=<test_key>` — запуск теста из `tests_registry`
  - `SKILL.TEST key=<skill_test_key>` — запуск теста цепочки навыка
  - `SKILL.SUITE category=<skills|skill_chain|...>` — запуск набора тестов по категории
  - `INSPECTOR.RUN key=<id>` — запуск инспектора (реестра P28)
- Примеры команд:
```
TEST.RUN key=p29.pipeline_smoke
TEST.RUN key=p29.processor_cycle
SKILL.TEST key=skill_chain.apply_and_trace.demo.skill
SKILL.TEST key=skill_chain.golden_eval.demo.skill
SKILL.TEST key=skill_chain.sleep_optimize_then_apply.demo.skill
SKILL.SUITE category=skill_chain
INSPECTOR.RUN key=sanitizer.patterns_consistency
JUDGE.CHARTER.UPSERT name="core_safety" version="v1" text="no dangerous ops" enforced=true
JUDGE.CHECK code="no dangerous ops here"
```
- Требования:
  - Все зарегистрированные тесты P29 должны быть доступны через `TEST.RUN`
  - Инспекторы (санитайзеры/guard/processor) доступны через `INSPECTOR.RUN*`
  - Панель Жандарма отображает результаты команд Hyperloop (последние `results`/артефакты)

### 13. Инспекторы: функциональность, задачи и интерфейсы
Общий контракт инспектора (плагина):
```
async def run(db: AsyncSession, context: dict | None = None) -> dict:
    return {"status": "passed|failed", "detail": "...", "metrics": {...}}
```
- Размещение: `backend/app/gendarme_tests/*` (Жандарм/Судья/Процессор) и `backend/app/feature_plugins/*` (фичфлаги/санитайзеры)
- Регистрация в БД (если требуется управление через реестр): `feature_inspectors(key, module, callable, scope, enabled, config)`
- Вызовы: панель/админ‑API/Hyperloop (`INSPECTOR.RUN key=...`)

13.1 Жандарм (качество/стабильность)
- Задачи: запуск Suite, запись `test_results`, авто‑политики при фейлах (опционально)
- Инспекторы: smoke процессора, блок‑политики, пайплайн ядра, консистентность профилей
- Метрики: `duration_ms`, pass/fail, частота фейлов по ключу

13.2 Мать флагов (FeatureFlagsSupervisor)
- Задачи: reconcile профиля (`prod_safe` и др.), контроль инвариантов P27, детект дрейфа
- Интерфейсы: `FLAGS.*`, `INSPECTOR.RUN key=feature.reconcile`, админ‑API `/api/admin/feature-flags/*`
- Хранилище: `soul_settings`, профиль и история изменений (аудит)

13.3 Отец Санитайзеров (Sanitizer Supervisor)
- Задачи: валидация паттернов, охват маскирования PII, конфликт правил, влияние на UI
- Интерфейсы: `sanitizer.*` ключи в `soul_settings`, `INSPECTOR.RUN key=sanitizer.*`
- Отчёты: список несоответствий, рекомендуемые фиксы

13.4 Судья (Judge)
- Задачи: реестр уставов, проверка диффов/политик кодогенерации, фиксация инцидентов
- Интерфейсы: `JUDGE.*` (Hyperloop), админ‑API `judge_admin`
- Хранилище: `charters`, `charter_incidents` (привязка к commit/PR/id задачи — опционально)

13.5 Архивариус (Archivarius)
- Задачи: постановка/ведение `service_requests`, связь с результатами инспекций/судьи
- Интерфейсы: `REQUEST.CREATE/STATUS` (Hyperloop), админ‑API `archivarius_admin`
- Хранилище: `service_requests` с типами/статусами

13.6 Инспекторы Процессора (P30)
- Задачи: доступность очереди, SLA e2e, guard pass, incidents rate, политика блокировок
- Интерфейсы: `PROCESSOR.*`, `INSPECTOR.RUN key=processor.*`, админ‑API процессора
- Метрики: p95 стадий, очередь, `incidents_rate_per_min`

### 14. Не реализовано (к реализации)
- Плагинный реестр инспекторов `feature_inspectors` и загрузчик с RBAC — НЕ РЕАЛИЗОВАНО
- Инспекторы Санитайзера (паттерны/PII/конфликты) — НЕ РЕАЛИЗОВАНО
- Судья: расширенные уставы/инциденты и UI выбора политик — ЧАСТИЧНО
- Архивариус: сценарии связки с инспекциями/тестами — ЧАСТИЧНО
- Hyperloop: `INSPECTOR.RUN(_ALL)` — НЕ РЕАЛИЗОВАНО
  (Примечание: в текущей реализации движка Hyperloop команды инспекторов реализованы; статус раздела следует держать синхронизированным с фактическим кодом `backend/app/services/hyperloop_engine.py`.)
- Панель трендов/регрессии Жандарма — НЕ РЕАЛИЗОВАНО

### 15. Синхронизация с Процессором (P30)
- Инспекторы P30 обязаны:
  - не блокировать основную обработку (асинхронный запуск)
  - уважать политики блокировок (`processor_policies`) и не создавать циклов
  - писать результаты в `test_results` для агрегирования на панели
- Процессор предоставляет API/метрики и эвенты для тестов/инспекций

### 16. План реализации
1) БД: `feature_inspectors` + ensure‑скрипт; загрузчик плагинов в Жандарме
2) Hyperloop: `INSPECTOR.RUN`, `INSPECTOR.RUN_ALL`
3) Инспекторы: sanitizer.*, signature.*, processor.* (MVP набор)
4) Панели: список инспекторов, запуск, отчёты/история
5) Документация: обновить P27/P28/P29/P36 и Master Registry
