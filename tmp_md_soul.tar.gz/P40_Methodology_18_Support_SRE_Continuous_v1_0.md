# M18 — Support/SRE Continuous (v1.0)

Цель: устойчивость и поддержка сервиса с SLO/SLA и инцидент‑менеджментом.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Monitor → Detect → Mitigate → Resolve → Postmortem → Improve.

Алгоритмы/метрики: SLI/SLO, p95, error_rate, MTTR, alert fatigue.

Роли: SRE, On‑call, Product Owner.

DSL: SLO.SET, ALERT.RULE.SET, INCIDENT.ADD, METHODOLOGY.SET.

Acceptance: SLO/алерты/инциденты в БД; панели SRE.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
