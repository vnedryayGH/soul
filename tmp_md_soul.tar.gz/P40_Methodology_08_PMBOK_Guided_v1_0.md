# M08 — PMBOK Guided (v1.0)

Цель: управление проектом по областям знаний PMBOK с адаптацией под Soul.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Integration/Scope/Schedule/Cost/Quality/Resource/Communications/Risk/Procurement/Stakeholders.

Алгоритмы/метрики: EVM, CPI/SPI, Risk Exposure, p95.

Роли: PM, Sponsor, Tech Lead, QA.

DSL: PLAN.TASK.ADD, PLAN.TASK.DEPEND, RISK.ADD, METHODOLOGY.SET, INSPECTOR.RUN_ALL.

Acceptance: артефакты и KPI в БД; инспекторы зелёные; панели EVM/Risk.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
