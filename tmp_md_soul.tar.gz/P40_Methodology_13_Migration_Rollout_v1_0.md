# M13 — Migration/Rollout (v1.0)

Цель: безопасный перенос и раскатка изменений с контролем обратной совместимости.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Assess → Plan → Pilot → Phased Rollout → Cutover → Post‑mortem.

Алгоритмы/метрики: Error Budget, p95, rollback rate.

Роли: Migration Lead, Dev Lead, SRE, QA.

DSL: ROLLOUT.PHASE.ADD, FEATURE.FLAG.SET, METHODOLOGY.SET, INSPECTOR.RUN_ALL.

Acceptance: план миграции/флаги в БД; панели раскатки/ошибок.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
