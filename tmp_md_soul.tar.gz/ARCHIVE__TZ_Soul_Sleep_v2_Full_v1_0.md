# ARCHIVE — устаревший документ, заменён P16 (см. Soul/P16_TZ_Soul_MemoryCompaction_v1_0.md)

### ТЗ Soul v1.0 — Модуль «Сон» (Sleep v2) — полный план с интеграцией Optimize/Harvest

> Внимание: документ устарел и заменён номерным ТЗ P16: `Soul/P16_TZ_Soul_MemoryCompaction_v1_0.md`. Актуальные этапы E0–E10 и интеграции консолидированы там.

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: К реализации (MVP без миграций; Stage‑2 — расширенные структуры)

---

### 0. Executive summary

- Цель: обеспечить ночной (или плановый) конвейер «Сон» для оздоровления памяти: пересчёт рангов, дедупликация/каноникализация, якоря/прюнинг шума, архивация/компакция, ревью целей/навыков, план «дыр» (research), rebuild индексов, maintenance и безопасное завершение с возможностью отката.
- Интеграция: с дневным пайплайном (30/70, роутер), со смежными модулями Optimize (пересчёты/кэш/энергетика) и Harvest (внешние данные под политиками). Вся работа — через сервисы Sleep под флагами, без изменения схемы БД в MVP.

---

### 1. Актуальная реализация (аудит)

- Точки и артефакты:
  - Endpoint Sleep: `POST /api/soul/sleep?dry_run=true|false` (см. `docs/PROJECT_STRUCTURE_v8_0_4.md`).
  - Настройки: `backend/app/services/soul_settings_service.py` содержит категории `sleep`/`energy` (например, `energy_decay_rate`, `connection_threshold`, `sleep_interval_hours`, `archive_threshold`).
  - Технические заметки Sleep v2: `Arh/Доработки1.txt` (этапы Э0–Э10, батчинг×10, SLO/rollback/алерты).
  - Работающие подмодули: rank_refresh/maintenance (отмечены как ✅ в чек‑листе).
- Вывод: есть каркас и базовые настройки. Необходимы модульная реализация этапов «Сна», общий оркестратор, аудит/метрики и интеграция с Optimize/Harvest.

---

### 2. Архитектура Sleep v2 (этапы, вход/выход, SLO)

Общие параметры:
- Триггеры: cron (например, 02:30), ручной запуск, эвенты (высокая энтропия/падение качества).
- Батч‑размер: 10 элементов; транзакции на батч.
- Целевой SLO ночного запуска: ≤ 20 минут (MVP).

Этапы:
- Э0. Префлайт
  - Вход: нет. Выход: снимок «до» (объём памяти, p95 ретривала, JSON validity).
  - Действия: проверка БД/представлений/индексов, установка read‑mostly режима, baseline‑метрики.
  - Аудит: `sleep_preflight {db_ok, mv_ok, index_ok, baseline}`.

- Э1. Health Check 2.0
  - Проверки: целостность `quants`/`quant_connections`/`quant_rank_mv`; доля NULL/пустых, «сырость» индексов, версии схем.
  - Аудит: `sleep_health {issues[], counters}`. При критике — мягкая остановка.

- Э2. Rank Refresh 2.0
  - Пересчитать `rank_score` (энергетика/связность/свежесть) и обновить `quant_rank_mv`.
  - Подтверждённые связи → увеличить `connection_strength` (cap 1.0).
  - Аудит: `sleep_rank_refresh {updated, coeffs, p95_ms, drift}`.

- Э3. Дедуп/Каноникализация (см. `dedup_canonical.py`)
  - Кластеризация по эмбеддингам+Jaccard; пороги `{sim≥0.88, jaccard≥0.6}`.
  - Выбор «канона»; связи `is_duplicate_of`; переназначение внешних связей dup→canon.
  - Аудит: `sleep_dedup {clusters, merged, kept_canon}`.

- Э3.5. Архивация/Компакция (см. `archive_compaction.py`)
  - Кандидаты: `energy_weight < archive_threshold` и низкая связность, без статуса anchor/goal.
  - Суммаризация групп (малый LLM/эвристика) → создание `archive_summary` кванта; связи `summary` origin→summary; ослабление исходных связей/весов.
  - Аудит: `sleep_archive_compact {groups, summarized, new_summaries}`.

- Э4. Якоря и Прюнинг шума (`anchors_prune.py`)
  - Выбор anchor‑квантов top‑k per topic/goal (`sleep.anchors.per_topic`); прюнинг «листьев» с низкой полезностью.
  - Аудит: `sleep_anchors {anchors_count, pruned_count}`.

- Э5. Ревью целей (`goals_review.py`)
  - По активным целям: прогресс, статус, next steps (малой LLM), обновление полей/связей.
  - Аудит: `sleep_goals_review {updated_goals, stalled_goals}`.

- Э6. Навыки и Curriculum (`skills_consolidation.py`)
  - Автодетект навыков по паттернам/тегам; счётчик успешных применений; генерация мини‑квестов (до 10).
  - Аудит: `sleep_skills {learned, quests_new, quests_closed}`.

- Э7. «Дыры»/Любознательность (`research_planner.py`)
  - Детект тем с высокой энтропией/низким покрытием; подготовка `desired_action=research` (persistent) или дневных задач.
  - Аудит: `sleep_research_plan {holes_count, actions_prepared}`.

- Э8. Индексы и представления (`index_rebuild.py`)
  - Обновить текстовый (BM25) и векторный индексы, рефреш `quant_rank_mv`.
  - Sanity‑метрики ретривала на golden‑set.
  - Аудит: `sleep_index_rebuild {bm25_rebuilt, vec_rebuilt, mv_refreshed}`.

- Э9. Maintenance (`maintenance.py`)
  - VACUUM/ANALYZE целевых таблиц; снимок «после».
  - Аудит: `sleep_maintenance {vacuumed, analyzed}`.

- Э10. Safety/Rollback (`safety_gate`)
  - Gate: RBAC/NEGATIVE/ограничители на изменения целей/слияния/планы research.
  - Транзакции на батч=10; компенсирующие операции; алерты SLO/аномалии.
  - Аудит: `sleep_safety_gate`, `sleep_rollback`, `sleep_done`.

---

### 3. Компоненты и файлы

Создать/обновить:
- `backend/app/services/system/modules/sleep/health_check.py` (обновить)
- `backend/app/services/system/modules/sleep/rank_refresh.py` (обновить)
- `backend/app/services/system/modules/sleep/dedup_canonical.py` (новый)
- `backend/app/services/system/modules/sleep/archive_compaction.py` (новый)
- `backend/app/services/system/modules/sleep/anchors_prune.py` (новый/дополнить)
- `backend/app/services/system/modules/sleep/goals_review.py` (новый)
- `backend/app/services/system/modules/sleep/skills_consolidation.py` (новый)
- `backend/app/services/system/modules/sleep/research_planner.py` (новый)
- `backend/app/services/system/modules/sleep/index_rebuild.py` (новый/дополнить)
- `backend/app/services/system/modules/sleep/maintenance.py` (обновить)
- `backend/app/services/system/orchestrator_v2.py` — сценарий sleep_v2: последовательность этапов, батчинг×10, таймауты, мягкая остановка, алерты.
- (опц.) `backend/app/services/system/router_v2.py` — профиль «sleep_v2» при необходимости внутренних решений.

---

### 4. Интеграция с Optimize/Harvest

- Optimize v2 (смежный модуль):
  - В дневное время: быстрая энергетическая релаксация, обновление кэша рангов/индексов (light), дефрагментация малых компонент связности.
  - Sleep использует коэффициенты/веса, рассчитанные Optimize; Optimize читает результаты Sleep (каноны, якоря) для быстрых эвристик.

- Harvest v2 (смежный модуль):
  - Контролируемый приток внешних данных по политикам (источники, частоты, объёмы).
  - Sleep учитывает свежие «урожаи» (новые кванты/связи), консистентно их канонизирует и включает в индексы.

---

### 5. Настройки (soul_settings) и ENV

- Основные:
  - `sleep.enable_v2=true`
  - `sleep.safe_mode=true` (Э0–Э2+метрики; без изменений данных)
  - `sleep.batch_size=10`
  - `sleep.max_runtime_sec=1200`
  - `sleep.rank.weights={w1:0.4,w2:0.35,w3:0.15,w4:0.10}`
  - `sleep.dedup.thresholds={sim:0.88, jaccard:0.6}`
  - `sleep.anchors.per_topic=5`
  - `sleep.archive_threshold=0.05`
  - `sleep.index.vec_model='all-MiniLM-L6-v2'` (пример)
  - `energy_decay_rate=0.01`, `connection_threshold=0.1`, `sleep_interval_hours=24`

ENV используются как дефолты; источником истины является БД настроек.

---

### 6. API/Управление

- `POST /api/soul/sleep?dry_run=true|false` — запустить конвейер Sleep v2 (если `sleep.enable_v2=true`).
- (опц.) `GET /api/admin/soul/sleep/status` — состояние оркестратора и counters.
- (опц.) `POST /api/admin/soul/sleep/cancel` — мягкая остановка.

RBAC: только `soul.admin`.

---

### 7. Наблюдаемость и алерты

- События: `sleep_*` на каждом этапе + `sleep_done`.
- Метрики:
  - Ретривал accuracy на golden‑set (до/после), p95 ретрива, объём активной памяти, доля дубликатов/архивных, число якорей.
  - Цели/навыки: прогресс/неделя, освоенные навыки.
- Алерты:
  - Runtime > `sleep.max_runtime_sec` — предупреждение/остановка.
  - Падение accuracy golden‑set > X% — rollback/stop.

---

### 8. Acceptance

- Конвейер завершается ≤ 20 мин на PROD‑данных (ориентир), без ошибок.
- Активная память уменьшена/упорядочена без деградации ретривала (допуск ≤ −2%).
- Появились summary‑кванты и связи `summary`/`is_duplicate_of`; якоря сохранены.
- Индексы обновлены, p95 ретрива не вырос > 10%.
- Все шаги логируются; есть отчёт «до/после».

---

### 9. Траблшутинг

- Агрессивная компакция → поднять `archive_threshold`, увеличить `anchors.per_topic`, включить `sleep.safe_mode`.
- Слабая дедупликация → ослабить пороги, добавить нормализацию; проверить эмбеддинги.
- Ухудшение ретривала → увеличить квоту якорей, исключить summary из активного индекса.
- Долгий runtime → уменьшить `batch_size`, частично выполнить этапы, оптимизировать индексы.

---

### 10. Быстрая реализация (≤ 2–3 дня)

1) Оркестратор `orchestrator_v2.py` (последовательность этапов, батчинг, остановка при критике).
2) Реализовать модули: `dedup_canonical.py`, `archive_compaction.py`, `anchors_prune.py`, `goals_review.py`, `skills_consolidation.py`, `research_planner.py`, дополнить `index_rebuild.py` и обновить `health_check.py`/`rank_refresh.py`/`maintenance.py`.
3) Прокинуть настройки/флаги в `soul_settings_service.py`.
4) Метрики/аудит, dry‑run режимы, golden‑set замер до/после.

---

### 11. Stage‑2 (опционально)

- Доп. структуры БД: `archive_groups`, `canonical_map`, `quant_canonical_tags`, `attachments` для объяснений.
- Расширенные ML‑модели для кластеризации/ранжирования, адаптивные пороги, A/B эталон.
- Инкрементальные nightly‑задачи с backpressure, интеграция с Conductor.

---

### 12. Ссылки на проектные файлы/документы

- Настройки: `backend/app/services/soul_settings_service.py`
- Технический план Sleep v2: `Arh/Доработки1.txt`
- Пайплайн и системные точки: `docs/PROJECT_STRUCTURE_v8_0_4.md`
- Память/компакция: `Soul/TZ_Soul_MemoryCompaction_v1_0.md`
