# P40 — ТЗ: Project Log & Methodology Workflow (v1.0)

Статус: draft → ready for implementation
Ветка: p40-project-log-methodology
Покрытие: P27/P28/P29/P30/P36/P40

## 0) Цель

Внедрить стандарт «Проектный лог + Выбор методологии» для LLM‑агентов и людей: каталог проектов в PROD, структурированные логи, чтение/запись ссылки на лог через БД (PROJECT meta), выбор методологии и генерация предварительной структуры плана через Hyperloop DSL.

## 1) Инварианты

- Истина — только БД; пути/URL/токены читаются через SoulSettings/Secrets.
- Все операции — через Hyperloop DSL; видимые ответы проходят P27 цепочку.
- Проектная ветка обязательна (INSPECTOR.RUN key=plan.branch claim_branch).

## 2) Модель данных (расширения P40)

- Таблица `projects` уже содержит `meta jsonb`.
- Ключ `meta.project_log` — относительный путь к лог‑файлу в репозитории/каталоге проекта.
- Ключ `meta.features` — признаки для выбора методологии (см. Policy).

## 3) DSL (P36) — дополнения

### 3.1 PROJECT.LOG.SET/GET (алиасы над DB.UPSERT/DB.SEARCH)

- PROJECT.LOG.SET id=`PID` path=`REL_PATH`
- PROJECT.LOG.GET id=`PID`

Ответ: `{ ok, data: { id, path } }`

### 3.2 METHODOLOGY.SELECT (обёртка Policy)

- METHODOLOGY.SELECT project_id=`PID` [features_json=`JSON`]

Ответ: `{ key, confidence, reasons[], profile_overrides{} }`

### 3.3 PROJECT.FILES.ENSURE (создание каталога на PROD)

- PROJECT.FILES.ENSURE id=`PID` name=`NAME` [dry_run]

Политика: путь = `soul_settings.project.files.root_dir` + `/<pid>-<slug(name)>/` с подпапками `logs, docs, artifacts`.

## 4) Политика выбора методологии

Основана на `Soul/P40_Methodology_Selection_Policy_v1_0.md`. Вход: `features` (тип инициативы, риск, сроки, compliance, data/ml и т.д.). Выход: `methodology_key` (M01..M18), уверенность и причины.

## 5) Процессы (LLM‑friendly)

1) Claim ветки → DEV.CONNECT.
2) PROJECT.LIST/GET → выбор проекта или создание (PROJECT.CREATE).
3) PROJECT.FILES.ENSURE (DRY_RUN→apply).
4) Создать проектный лог и записать `PROJECT.LOG.SET`.
5) METHODOLOGY.LIST → METHODOLOGY.SELECT → PROJECT.UPDATE(methodology=...).
6) Сформировать предварительные `PLAN.TASK.ADD` и `PLAN.CPM.CALC`.
7) Вести лог: все промежуточные артефакты/ссылки, фрагменты кода с версиями/датами.

## 5.1) Непрерывный PM‑цикл и LLM‑оркестрация

- Автотики: `pm.auto.enabled`, `pm.scheduler.interval_ms`, список `pm.auto.projects`.
- Новые DSL (P36):
  - `PM.TICK project_id=<PID>` — фоновой тик проекта (Processor event `pm.tick`).
  - `PM.ASSIGN project_id=<PID> tasks_json=[...]` — раздача задач по ролям/персонам (event `pm.assign`).
  - `PM.AGENT.REQUEST project_id=<PID> to=<cursor|deepseek|phi4> action=<k> spec_json={}` — запрос к LLM‑агенту (event `pm.agent.request`).
  - `PM.INCIDENTS.REVIEW project_id=<PID> policy_json={}` — группировка/классификация инцидентов (event `pm.incidents.review`).
  - `PM.DECISION.SAVE incident_id=<UUID> decision=<project|quick_fix|defer|close> [project_id] [priority] [meta_json]` — запись решений (таблица `pm_decisions`).

- Политики: `pm.persona.*` (участие), `pm.incidents.policy` (groups/severity/decision_policy), маршрутизация LLM: `pm.llm.routing.*`.

- Acceptance: тик создаёт хотя бы одно действие (assign/agent.request) при наличии работы; решения инцидентов записываются; лог проекта обновляется; метрики/подписи присутствуют.

### 5.2) Интеграция с Telegram (уведомления/подтверждения)

- Создание/открытие проекта:
  - При `PROJECT.CREATE` отправляется уведомление Архитектору в Telegram (через оркестратор) с названием и `project_id`.
  - При `PROJECT.UPDATE ... status=active` отправляется уведомление об открытии проекта (best‑effort).
- Закрытие проекта (гейт подтверждения):
  - Попытка `PROJECT.UPDATE ... status=archived|closed` блокируется до получения подтверждения Архитектора в Telegram.
  - Архитектор получает сообщение c inline‑кнопкой `✅ Подтвердить закрытие`; нажатие устанавливает флаг `project.close.confirmed.<PID>=true` в БД.
  - Повтор `PROJECT.UPDATE` с тем же статусом после подтверждения проходит успешно.

Acceptance:

- Нотификации доставляются (enqueue в оркестратор без ошибок); флаг подтверждения учитывается при закрытии.

## 6) Структура лога

Разделы: Назначение, Источники, Требования, Практики (12), Предварительная структура, Инвентарь артефактов, План DSL, Политика каталогов, Риски, Хронология.

## 7) 12 практик (референсы)

ADR, PRINCE2 (реестры), PMBOK (PMP/Docs), RAID, Lean A3, Inception Deck, SAFe PI Planning, SRE Postmortem, DevOps Runbook, CRISP‑DM, MLOps CD, NASA SE Handbook.

## 8) Acceptance

- PROJECT.FILES.ENSURE создаёт каталог/подпапки (dry_run/real) с записью шага подписи.
- PROJECT.LOG.SET устанавливает и PROJECT.LOG.GET возвращает путь в meta.
- METHODOLOGY.SELECT возвращает устойчивый выбор при одинаковых features.
- Предварительные задачи/CPM создаются, PLAN.CPM.CALC возвращает valids.
- В реестре документов отражены новые файлы; инспекторы RUN_ALL зелёные.

## 9) Безопасность/наблюдаемость

- Метрики: `project_files_ensure_ms_p95`, `methodology_selected_total{key}`.
- Инциденты: `project_files_error`, `methodology_select_error`.

## 10) Примеры команд (Windows PowerShell)

```text
METHODOLOGY.LIST
PROJECT.LOG.SET id=PID path="Plan/P40_Project_Log_Methodology/PROJECT_LOG_p40_project_log_methodology_v1_0.md"
PROJECT.LOG.GET id=PID
PROJECT.FILES.ENSURE id=PID name="P40 Project Log & Methodology"
METHODOLOGY.SELECT project_id=PID features_json={"type":"delivery","risk_level":"medium"}
PLAN.TASK.ADD project_id=PID title="Обновить Cursor системный промпт (методологии/логи)" cpm_duration_days=0.5
PLAN.CPM.CALC project_id=PID WITH TRACE

```

## 11) Изменения в документах

- Добавить записи в `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` и ссылку в `docs/PROJECT_STRUCTURE_v8_1_2.md`.

## 12) RCA — Root Cause Analysis (глубокая проработка первопричин)

Цель: системно выявлять и устранять первопричины проблем, предотвращая их повтор.

Объект RCA:

- Единичные критичные события и повторяющиеся инциденты в проектах.

Сбор данных:

- Логи, трассы P27/TRACE, `processor_incidents`, отчёты Hyperloop/RS, метрики Prometheus, артефакты задач/квантов.

Методология/этапы:
1) Описание проблемы: факты, временная шкала, последствия (для будущей идентификации).
2) Выявление первопричины и корневых причин: аналитические методы (5 Why, Ishikawa, fault tree), связь с процессами/данными/оборудованием/системами Ядра Соул.
3) Корректирующие мероприятия: способы/инструменты исправления; ответственные; сроки; метрики эффективности.
4) Предотвращение повторов: изменения в процессах/конфигурации/контролях; алерты; тесты/инспекторы.
5) Контроль эффективности: статус, ревью через PM‑цикл; решение о создании системного инцидента.

Репозиторий RCA (един для всех проектов):

- Хранит записи: `project_id?`, `title`, `problem`, `impact`, `root_cause`, `contributing_causes{}`, `fix{actions,tools,rollbacks}`, `prevention`, `links[]`, `severity`, `tags[]`, `owner`, `status`, `created_at`, `updated_at`.
- Доступ LLM‑агентам через Hyperloop DSL (RCA.*).

Hyperloop DSL (предусмотрено):

- `RCA.SCHEMA.ENSURE` — создать/обновить схему репозитория (идемпотентно).
- `RCA.RECORD.ADD project_id=<PID> title=... problem=... [impact] [root_cause] [contributing_json={}] [fix_json={}] [prevention] [links_json=[]] [severity] [tags_json=[]] [owner] [status]`.
- `RCA.RECORD.UPDATE id=<UUID> [...]` — частичное обновление.
- `RCA.GET id=<UUID>` — получить запись.
- `RCA.SEARCH [project_id=<PID>] [q=...] [tag=...] [limit=20]` — поиск по тексту/тегам.
- `RCA.LIST [project_id=<PID>] [limit=20]` — список последних записей.

Acceptance:

- Каждая критичная/повторяющаяся проблема сопровождается записью RCA и планом корректирующих действий.
- Результаты RCA попадают в общий репозиторий и используются LLM‑агентами при анализе/планировании.
- При необходимости создаётся системный инцидент для масштабных исправлений.

Глоссарий:

- Термины и определения согласуются с `Soul/P53_TZ_Soul_Glossary_v1_0.md` и используются в полях RCA (`severity`, `tags`, виды причин/мероприятий).


## Мировые аналоги и практики

- Project Logs/ADR: Architecture Decision Records (ADR) — каноника фикса решений
- PM методологии: PRINCE2 / PMBOK / SAFe / Kanban / Scrum / Lean A3 / Inception Deck / SRE Postmortem / DevOps Runbook / CRISP‑DM / MLOps CD / NASA SE Handbook
- Git‑центричное управление проектами: GitOps/FluxCD/Argo — декларативность и аудит изменений
- Change Management: ITIL v4 (RFC/Change/Release) — согласование и аудит
- Policy‑Driven PM Orchestration: GitHub Projects/Issues + Protected Branches/Reviews
- Knowledge base структуры: Diátaxis/Docs‑as‑Code — единая структура пользовательская/техническая/как‑сделать/референс
