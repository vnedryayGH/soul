# P27 — ТЗ: Подпись данных, Трассировка и Поиск Нарушителей (Signature & Data Lineage)

## Индекс взаимных ссылок (P01–P37)

- P21 Health/Monitoring — отчётность по подписям.
- P30 Processor — подпись событий/шагов.
- P33 Personification — Mini Chat подпись ключевых шагов.
- P35/36 — процессы и DSL для инспекции подписи.
- P45 Quant Generation Modes — подпись на этапах офлайн генерации/загрузки квантов (JSONL→SQL/Hyperloop), требования к шагам `svc.persist.quant`/`cmd.hyperloop.*`.

Ссылки (интеграции и реестры):

- `docs/PROJECT_STRUCTURE.md` — карта модулей/интеграций (P27/P28/P30/P36)
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр документов
- `Soul/Report_Soul_AI_Scientific.md` — сводка нормализации и «Нереализованные требования — сводка»
- `Soul/P28_TZ_FeatureFlags_Registry_and_Policies_v1_0.md` — фичефлаги/инспекторы
- `Soul/P30_TZ_Soul_Processor_v2_0.md` — события/подпись процессора
- `Soul/P36_TZ_Hyperloop_DSL_v1_1.md` — команды/инспекторы/подписанные вызовы
- `docs/DOCS_INVENTORY_SOUL.md` — инвентарь документов каталога Soul (актуально)
- `docs/DOCS_INVENTORY_DOCS.md` — инвентарь каталога docs (актуально)
- `tmp_p_series_plan.json` — план анализа P‑серии (дубль/слияния)

Версия: v1.1  
Статус: Частично реализовано (DEV/PROD), активный роллаут и тестирование; приоритет P0

## 1. Цель и мотивация

Обеспечить детерминируемую трассировку всех пакетов данных в системе (чат, SoulCore, API, планировщик, напоминания, персистенция), чтобы:

- исключить утечки служебных блоков в пользовательские ответы;
- мгновенно диагностировать, где в цепочке произошла подмена/упрощение/эхо входа вместо ответа ЛЛМ;
- иметь «Подпись» (Signature), позволяющую восстановить все шаги обработки пакета данных и выявить «Нарушителя» (функцию/утилиту, нарушившую контракт);
- визуализировать активность сервисов и автоматически искать «серые» (непомеченные) данные.

Критическая проблема, воспроизведённая в PROD: «мгновенный двойной ответ» с тех‑разбором (Accepted meanings/§sense/…) вместо реального ответа ЛЛМ. Требуется устранить первопричину и ввести системную защиту.

### 1.1 Обзор мирового опыта и аналитика выбора решений (информационно)

- Подпись и родословная данных (Data Lineage):
  - Практики из финансов/банкинга (BCBS 239), здравоохранения (HIPAA Audit Trail) и крупной ML‑платформенной практики (Uber Michelangelo, TFX ML Metadata) указывают на необходимость сквозной неизменяемой трассировки артефактов, событий и решений модели.
  - Для latency‑чувствительных систем предпочтение отдаётся лёгким контекстным меткам и пост‑фактум агрегации в быструю side‑таблицу (signature_steps) с индексами по trace_id/packet_id.
- Криптографическое обеспечение целостности:
  - Современный стек — JCS (JSON Canonicalization Scheme) + BLAKE3 (скорость/безопасность) + Ed25519 (минимальный размер подписи) — де‑факто best practice для высоконагруженных сервисов; совместимо с Rust/PyO3 для горячего пути.
  - Для независимой проверяемости и «прозрачного журнала» (CT‑подобные системы, Sigstore/Rekor) применяют периодическую мерклизацию пачек шагов и анкор в L2‑сети (Polygon/Base) — компромисс между стоимостью on‑chain и необходимостью доказуемости.
- Инварианты доставки (Delivery Guard):
  - Подобно Safety‑политикам крупных ассистентов, перед пользовательской выдачей проверяется наличие обязательных стадий (send/recv/parser). Отсутствие шага — блокировка выдачи и формирование отчёта.
- Поиск нарушителей (Seeker):
  - Подход инспекции хвостов трасс за скользящее окно (N минут) и корреляция «быстрых ответов без LLM‑шага» используется в production‑SRE практиках как дешёвый и эффективный сигнал деградаций (rule‑based до внедрения ML‑детекторов аномалий).
- Выбор решений для проекта:
  - Минимальный оверхед: v1 на Python‑SDK с последующим выносом горячего пути в Rust (PyO3).
  - Локальная подпись в `meta/payload` + side‑таблица шагов для аналитики; анкор L2 — опциональная, асинхронная стадия v2.
  - Enforcement через Function Registry: явные политики required/optional/forbidden и CI‑гейты покрытия.

### 1.2 Инцидент Архитектор→Соул (RCA: корневая причина и подтверждение в коде)

Симптомы:

- Видимый ответ содержит тех‑разбор и эхо входного текста, латентность ≈0–1 мс (невозможна для реального LLM‑пути).
- В подписи отсутствуют шаги `svc.llm_client.send/recv` и `svc.parser.json_strict` перед `svc.chat.reply_render`.
- Включён показ тех‑информации в видимом тексте (диагностический режим).

Причина:

- Сработал упрощённый/диагностический фоллбек без вызова LLM/парсера; Delivery Guard был в observe/неполном режиме → не заблокировал выдачу; диагностические блоки попали в видимый текст.

Подтверждение (ключевые места реализации):

- Delivery Guard (обязательные шаги):

  ```1:33:backend/app/services/delivery_guard.py
  REQUIRED_STEPS_SINGLE: ["svc.soul.preanalysis","svc.soul.router_decide","svc.llm_client.send","svc.llm_client.recv","svc.parser.json_strict","svc.chat.reply_render"]


  ```

- Ветка чата/Соул (встраивание подписи и проверка Guard):

  ```108:1142:backend/app/services/chat_service.py
  ok_guard, reason_guard = _guard(sig_ctx.to_dict(), required_steps=[...])
  ai_message.meta = {..., "signature": sig_ctx.to_dict(), "delivery_guard": {"ok": ok_guard, "reason": reason_guard}}


  ```

  ```401:782:backend/app/routers/soul.py
  ok_guard, reason_guard = verify_before_reply(sig_ctx.to_dict()); запись инцидента при провале


  ```

- Диагностические блоки (мок/локальный режим LLM) теперь управляются настройкой `diagnostic.visible_reply=false` по умолчанию, шаги `send/recv` фиксируются даже в мок‑ветке:

  ```215:238:backend/app/services/llm_client.py
  if disable_ext or (env in test/dev and no api key):
    visible_reply = "Я на связи..."; text = visible_reply (без [АНАЛИЗ] при show_diag=false)
    signature_ctx.append_step("svc.llm_client.send"); signature_ctx.append_step("svc.llm_client.recv")


  ```

### 1.3 Контрольный чек‑лист соответствия P27 (инварианты выдачи)

- Подпись/цепочка (каждый ответ):

  `svc.soul.preanalysis → svc.soul.router_decide → svc.llm_client.send → svc.llm_client.recv → svc.parser.json_strict → svc.chat.reply_render`.

- Хранение подписи: `messages.meta.signature`, `quants.payload.signature` (jsonb); side‑таблица `signature_steps` — консистентные `trace_id`.
- Реестр функций: на критичных `signature_policy=required`; отсутствие шага → инцидент `signature_required_missing`.
- Delivery Guard: `delivery_guard.enforce=true`; при отсутствии любого шага — блокировка ответа и запись инцидента `delivery_guard_failed`.
- Диагностика/санитайз: `diagnostic.visible_reply=false`; из видимого текста вычищены `Accepted meanings`, `[АНАЛИЗ]..[/АНАЛИЗ]`, `§sense{}`, `§qtags[]`, `§qew[]`.
- LLM‑реальность: латентность >100–300 мс (кроме кэша), `tokens_out > 0` или валидный провайдер; кэш помечен `cached=true` и не нарушает инвариантов.
- Persist: шаги `svc.persist.*` пишутся, подпись присутствует в `quants.payload.signature`.
- Seeker: нет «серых» записей без подписи; нет `traces_missing_required` за окно N минут.
- Политики/покрытие: `GET /api/admin/soul/trace/signature/stats` растёт по шагам; `.../incidents` отражает нарушения.
- Инварианты PROD: unit `soulpulse-backend.service` активен; таблицы/индексы P27 созданы; ENV/секреты в порядке.
- UX: при `diagnostic.visible_reply=false` — чистый ответ; при `true` — тех‑вывод отделён и не дублируется.

### 1.4 План фикса (флаги/Acceptance)

- Флаги PROD: `delivery_guard.enforce=true`, `diagnostic.visible_reply=false`, `SIGNATURE_ENABLED=1` (sdk по умолчанию), `ANCHOR_ENABLED=0` (позже).
- Acceptance:
  - При отсутствии любого из обязательных шагов цепочки ответ блокируется, возвращается нормированный объект ошибки с выдержкой подписи.
  - В `signature_steps` видна полная цепочка для последних трасс; в `signature_incidents` фиксируются нарушения.
  - Видимый ответ лишён тех‑блоков/эха запроса, подпись присутствует в meta/payload.

### 1.5 Мировые аналоги и практики (референсы ≥ 6)

- OpenLineage / Marquez — открытый стандарт и сервис lineage для данных и пайплайнов (`https://openlineage.io`, `https://marquezproject.github.io/marquez/`).
- Apache Atlas — метаданные/lineage/глоссарий и классификация объектов данных (`https://atlas.apache.org/`).
- DataHub (LinkedIn) — метаданные/линейность/поиск, сильные граф‑связи и политики (`https://datahubproject.io/`).
- OpenTelemetry — единый стандарт трасс/метрик/логов; экспорт шагов подписи как спаны (`https://opentelemetry.io/`).
- Sigstore / Rekor — прозрачный журнал подписей артефактов; публикация и проверка подписи (`https://rekor.dev`).
- JCS (RFC 8785) — каноникализация JSON для криптоподписей (`https://datatracker.ietf.org/doc/html/rfc8785`).
- BLAKE3 / Ed25519 — быстрые хэши и компактные подписи (`https://github.com/BLAKE3-team/BLAKE3`, `https://ed25519.cr.yp.to/`).
- ML Metadata (TFX) — ведение lineage артефактов ML‑конвейеров (`https://www.tensorflow.org/tfx/guide/mlmd`).

Рекомендации для Соул (адаптация best‑practice):

- Экспортировать P27‑шаги в OpenTelemetry как спаны и кореллировать с `signature_steps`.
- Оставить локальный side‑лог подписи + добавить опциональный «прозрачный журнал» через Rekor для критичных артефактов.
- Утвердить JCS как канон сериализации для вычисления хэшей и подписей; для горячего пути — BLAKE3, для внешней проверки — Ed25519.
- Свести глоссарий и metadata‑термины P27 в P53 (глоссарий) с типами и связями.
- При импорте/экспорте артефактов ML задействовать модель MLMD (минимальный подмножество) для совместимости.

## 2. Термины

- Пакет данных (Data Packet): любая сущность, проходящая по цепочке — входное сообщение, промежуточный объект анализа, квант, JSON‑ответ ЛЛМ, запись в БД, уведомление.
- Подпись (Signature): минимальный, неизменяемый и наращиваемый атрибут пакета, фиксирующий «родословную» обработки: кто/когда/с чем работал.
- Шаг подписи (Signature Step): одна запись внутри подписи: функция/контракт, версия, вход/выход (хэши), статус.
- Реестр функций (Function Registry): перечень всех функций/конвейеров/эндпоинтов, обязанных ставить подпись.
- Дирижёр (Orchestrator): контроллер полноты/чистоты реестра и панель мониторинга активности.
- Ищейка (Seeker): сервисный сканер, выявляющий непомеченные данные и места нарушения цепочки.
- Нарушитель (Violator): функция/утилита, модифицировавшая/пропустившая данные вне контракта (без подписи или с повреждённой подписью).

## 3. Общая идея «Подписи»

- Подпись наращивается по мере жизненного пути пакета. Каждый шаг добавляет новую запись со стандартными полями.
- Подпись хранится вместе с пакетом данных (в meta/служебных полях БД/объекта) и передаётся между слоями (API → сервис → LLM → парсер → БД → нотификации).
- Пользовательский видимый текст никогда не содержит служебные подписи/маркеры. Подпись хранится отдельно (в meta, JSONB, заголовке/контексте), а не в видимом payload.
- Для протоколов/носителей без мета‑канала (временное ограничение) допускается «сигнал» sig_hint только в административных/закрытых каналах, но не в пользовательском ответе.

## 4. Формат подписи (Signature v1)

```json
{
  "sig_version": "1.0",
  "packet_id": "uuid",            
  "trace_id": "uuid",             
  "owner": {
    "user_tg_id": "468326902",
    "context": "architect_chat|miniapp|api"
  },
  "created_at": "ISO8601",
  "steps": [
    {
      "ts": "ISO8601",
      "function_id": "svc.chat.send_message",
      "function_version": "2.6.1",
      "input_hash": "sha256:...",
      "output_hash": "sha256:...",
      "scope": "chat|soul_core|router|llm_client|parser|persist|notify",
      "status": "ok|warn|error",
      "notes": "короткий reason, например: preanalysis, batch->single fallback"
    }
  ],
  "crc": "sha256:..."  
}


```

Правила:

- `packet_id` устойчив к переупаковкам (при создании из сообщения/кванта — UUID сообщения/кванта).
- `trace_id` общий для цепочки от входа до ответа.
- Все шаги неизменяемы; добавление шага — только append.
- `crc` — хэш подписи для быстрой верификации целостности.

## 5. Реестр функций (контролируемый Дирижёром)

Хранится в БД (`function_registry`), управляется DDL/API:

- Поля: `id`, `function_id` (уникальный), `title`, `owner`, `version`, `scope`, `signature_policy` (required|optional|forbidden), `latency_budget_ms`, `enabled`.
- Для каждой функции включаем «обязательность подписи». Попытка сохранить/пропустить пакет без подписи → ошибка/лог/алерт по политике.
- Оператор «Дирижёр» следит за полнотой: никакие рабочие функции не остаются вне реестра.

API (админ):

- `POST /api/admin/signature/register` — регистрация/обновление функции.
- `GET /api/admin/signature/functions` — список/фильтр.
- `GET /api/admin/signature/stats` — покрытие, нарушения, свежесть.

## 6. Библиотека Signature SDK (декораторы/мидлвары)

Язык: Python (backend). Компоненты:

- `@with_signature(function_id, scope, version)` — декоратор функций/хендлеров; делает:

  1) извлекает/создаёт подпись из контекста (trace_id/packet_id);
  2) считает `input_hash` по сериализованным входам (без PII);
  3) вызывает функцию; после — считает `output_hash` и добавляет шаг;
  4) для ошибок — статус `error` и причину в `notes`;
  5) валидирует наличие в `function_registry` и политику `signature_policy`.

- `SignatureContext` — передача подписи через слой: FastAPI dependency, LLMClient мета, Persist layer.
- Вызовы LLM: подпись не встраивается в промпт; передаётся мета через `LLMClient.send(..., context={trace_id, packet_id})` и логируется отдельно.

## 7. Ищейка (Seeker)

Назначение: автоматически находить непомеченные/аномальные данные и «Нарушителя».

Алгоритм (каждые N минут):

1) Сканирует таблицы `messages`, `quants`, `quant_desired_actions`, `soul_audit_log` на отсутствие/повреждённость подписи (`meta.signature` отсутствует/невалиден/не консистентен с trace_id/packet_id).
2) Сопоставляет временные окна: ищет «быстрые» ответы (<= T мс) без LLM‑шага при том, что контекст ожидает LLM — это первичный индикатор «эхо/техразбор».
3) Строит «диаграмму» шагов по `trace_id`: если отсутствует `llm_client.send/recv` или `parser.json_strict` между `chat.preanalysis` и `reply`, это нарушение.
4) Пытается локализовать «Нарушителя»: последняя функция до ответа без корректного шага подписи.
5) Результат отправляет Дирижёру; создаёт запись инцидента с примерами payload (без PII) и рекомендациями.

Выход:

- Таблица `signature_incidents`: id, created_at, trace_id, packet_id, severity, suspect_function_id, count, sample, actions.
- API: `GET /api/admin/signature/incidents`.

## 8. Дирижёр (Orchestrator) — панель мониторинга

Панель Архитектора (добавить виджеты):

- Покрытие подписью по функциям и по потокам (чат/SoulCore/API/планировщик/уведомления).
- Нарушения за период: график, список топ‑нарушителей.
- Реестр функций: фильтр по `required/optional/forbidden`.
- Инциденты Ищейки: список/детали; кнопка «открыть RCA».

## 9. Схемы данных (DDL, кратко)

```sql
-- Реестр функций
create table function_registry (
  id uuid primary key default gen_random_uuid(),
  function_id text unique not null,
  title text,
  owner text,
  version text,
  scope text,
  signature_policy text not null default 'required',
  latency_budget_ms int,
  enabled boolean not null default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Инциденты Ищейки
create table signature_incidents (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  severity text,
  trace_id uuid,
  packet_id uuid,
  suspect_function_id text,
  count int,
  sample jsonb,
  actions jsonb
);


```

Хранение подписи:

- `messages.meta -> signature` (jsonb), `quants.payload -> signature` (jsonb) — не в видимом тексте.

## 10. Интеграция с текущей системой

Точки подключения декоратора `@with_signature` (минимально):

- `ChatService.send_message` (вход/выход чата) — function_id: `svc.chat.send_message`.
- `SoulCoreManager.generate_quants`/`generate_quant`/`_generate_single_quant_core` — `svc.soul.generate_*`.
- `LLMClient.send` — `svc.llm_client.send` (фиксируем факт отправки/получения, provider, таймаут/ретраи).
- Парсер `json_strict.ensure_strict_json_array` — `svc.parser.json_strict`.
- Персистенция (вставка в `messages`, `quants`, `quant_desired_actions`) — `svc.persist.*`.
- Уведомления Telegram — `svc.notify.telegram`.

Политики:

- Для всех перечисленных — `signature_policy=required`.
- Любое сохранение ассистентского сообщения без шага `soul/llm_client/parser` → инцидент.

## 11. Поток Архитектор → Соул (частный пример)

Сценарий: Архитектор пишет Соулу; родятся Кванты и ответ.

Шаги (ожидаемые подписи):

1) `svc.chat.send_message` (input_hash от текста) → ok
2) `svc.soul.preanalysis` (meaning_extraction) → ok
3) `svc.soul.router_decide` → ok
4) `svc.llm_client.send` (provider=deepseek; timeout/retries) → ok
5) `svc.llm_client.recv` (size, latency) → ok
6) `svc.parser.json_strict` (strict array; batch/single) → ok
7) `svc.soul.desired_action` → ok
8) `svc.persist.message/quant/qda` → ok
9) `svc.notify.telegram` (если нотификация) → ok
10) `svc.chat.reply_render` (итоговый текст; без техблоков) → ok

Ищейка ловит нарушения:

- Получен `svc.chat.reply_render` без `llm_client.recv` и `parser.json_strict` между preanalysis и reply → подозрение «эхо»; регистрируется инцидент.

## 12. Безопасность и приватность

- В хэши не включаем PII/сырые данные; используем усечённые SHA‑256 от нормализованных токенов.
- Подписи не добавляются в пользовательский видимый текст.
- Админ‑панель доступна по RBAC (Architect/Admin).

## 13. Наблюдаемость

- Метрики: coverage_% по функциям; incidents_rate; avg_signature_steps_per_packet; time_between_send_recv; time_send_to_recv_ms{p50,p95}; time_recv_to_reply_ms{p50,p95}; rt_gap_closures_count.
- Алерты: «reply без send/recv за Xм», «parser пропущен», «подпись отсутствует на persist».

## 14. Acceptance

- 100% покрытие подписью перечисленных функций (п.10) в DEV/PROD.
- Ищейка находит 0 непомеченных ответов за 24ч в PROD.
- При инциденте формируется запись и отчёт в панели Архитектора.
- Ветка Архитектора: тех‑маркеры не попадают в видимый ответ; есть валидные шаги `send/recv/parser`.

## 15. Роллаут

Этап 1 (DEV):

- Реестр, SDK, подпись для chat/send_message, llm_client, parser.
- Включить Ищейку; панель покрытий.

Этап 2 (STAGE):

- Расширить точки подписи до persist/notify.
- Настроить алерты.

Этап 3 (PROD):

- Включить `signature_policy=required` для критичных функций.
- CI‑проверка покрытия (Schema Guard снапшот подписи).

### 15.1 PROD: пути, секреты, политики (операционные требования)

- Пути сервисов/среды (актуально на PROD):
  - Backend working dir (systemd): `/var/www/soulpulse/backend`
  - Service unit: `/etc/systemd/system/soulpulse-backend.service`
  - ENV файл: `/var/www/soulpulse/backend/.env` (prod)
  - Venv: `/var/www/soulpulse/backend/venv`
  - Логи юнита: `journalctl -u soulpulse-backend.service`
  - Nginx site: `/etc/nginx/sites-enabled/03-mini_soulpulse.conf`

- Секреты/переменные окружения (минимум):
  - `DATABASE_URL` — DSN PostgreSQL (prod)
  - `DEEPSEEK_API_KEY` — ключ LLM провайдера (prod)
  - `CORS_ORIGINS` — разрешённые источники
  - `LLM_PROVIDER`, `DEEPSEEK_MODEL` — профиль LLM
  - (при необходимости) `DISABLE_BACKGROUND_TASKS`, `ENABLE_CALENDAR_SYNC`

- Политики и фичефлаги:
  - `SIGNATURE_ENABLED=1` — включение SDK/декораторов подписи
  - `DELIVERY_GUARD_ENFORCE=1` (поэтапно) — блокировка при отсутствии обязательных шагов
  - `ANCHOR_ENABLED=0/1` — включение анкора L2 (после стабилизации)
  - Function Registry (required): `svc.chat.reply_render`, `svc.soul.preanalysis`, `svc.soul.router_decide`, `svc.llm_client.send/recv`, `svc.parser.json_strict`, `svc.persist.message/quant/qda`

- DDL/сервисные таблицы (должны существовать):
  - `function_registry(function_id, version, scope, signature_policy, ...)`
  - `signature_steps(trace_id, packet_id, function_id, ts, status, input_hash, output_hash)`
  - `signature_incidents(trace_id, packet_id, function_id, incident_type, detail, created_at)`
  - `artifact_records(kind/name/version/hash/signature/...)` — при использовании артефактов

- Сетевые/доступы:
  - SSH деплой (ключ): `root@mini.soulpulse.art` (или пользователь `www-data` через sudo‑правила) — строго `StrictHostKeyChecking=accept-new`
  - API заголовок для админских проверок: `X-Telegram-User-ID: 468326902`

- Безопасность:
  - RBAC: доступ к админ‑эндпоинтам только для ролей Architect/Admin
  - Two‑keys (при необходимости для чувствительных операций)

## 16. Риски и ограничения

- Нагрузка: добавление шагов/хэшей — +1‑3% CPU/IO; оптимизировать хэширование и сериализацию.
- Совместимость: разные версии схем в таблицах (динамическая интроспекция колонок сохранена).
- UX: запрещено добавлять подпись в пользовательский текст (избегаем прошлой ошибки с §sense/Accepted meanings).

## 17. Приложение — Псевдокод декоратора

```python
def with_signature(function_id: str, scope: str, version: str):
    def _wrap(fn):
        async def inner(*args, **kwargs):
            ctx = SignatureContext.ensure(kwargs)  # trace_id/packet_id
            input_hash = hash_inputs(args, kwargs, exclude_pii=True)
            try:
                result = await fn(*args, **kwargs)
                status = "ok"
            except Exception as e:
                result = raise_or_record(e)
                status = "error"
            output_hash = hash_outputs(result, exclude_pii=True)
            ctx.append_step(function_id=function_id, version=version, scope=scope,
                            input_hash=input_hash, output_hash=output_hash, status=status)
            ctx.commit_crc()
            return result
        return inner
    return _wrap


```

## 18. Гибридный метод (локальная подпись + анкор в блокчейн)

- Вся «Подпись v1» ведётся локально (в meta БД и журналах Дирижёра) в реальном времени.
- Каждые N секунд (30–60) Batch Merkle Service строит Merkle‑root по новым трассам/шагам и публикует один root в L2 (Polygon/Arbitrum/Base). На‑чейн уходит только root‑хеш.
- Панель Дирижёра показывает список anchor‑tx с возможностью построить Merkle‑proof для конкретного `trace_id|packet_id`.
- Анкор асинхронный, не влияет на SLO запроса; при недоступности сети — ретраи, backoff.

Архитектура анкора:

- `signature_anchor_roots(root_hash, window_from, window_to, root_seq, chain)`
- Верификатор: `verify_on_chain(trace_id|packet_id) -> {on_chain: bool, tx_hash, merkle_proof}`

## 19. Локальная «Подпись v1» (минимальный оверхед)

- Подпись хранится в `messages.meta.signature` и/или `quants.payload.signature` (jsonb), без попадания в видимый текст.
- Все ключевые функции используют SDK‑декоратор. Средняя добавка к латентности < 3 мс/запрос (хэш входа/выхода + append шага).
- Поддерживается офлайн‑верификация: загрузка трассы по `trace_id`, сверка CRC и (при наличии) Merkle‑proof.

## 20. Delivery Guard (инварианты доставки и соответствия запроса)

Инварианты (жёстко):

- Архитектор (и любой пользователь) не получает данные, которые он не запрашивал по контексту/ветке/роуту.
- Перед отправкой видимого ответа выполняется проверка «цепочки обязательных шагов» по Подписи:
  - `svc.soul.preanalysis` → `svc.soul.router_decide` → `svc.llm_client.send` → `svc.llm_client.recv` → `svc.parser.json_strict` → `svc.chat.reply_render`.
  - Проверяется принадлежность `trace_id/packet_id` активному запросу; сопоставление ветки (architect_chat) и профиля маршрутизации.
  - Отсутствие любого шага в окне времени ответа → блокировка ответа пользователю, формирование отчёта об ошибке.
- Любые служебные маркеры/диагностические строки фильтруются до этапа `reply_render`.

API/вызовы:

- `DeliveryGuard.verify_before_reply(trace_id, packet_id, required_steps[]) -> ok|fail(reason, signature_excerpt)`
- Точка интеграции: перед публикацией `reply_prefixed_text/html` в ChatService и в HTTP‑эндпоинтах.

## 21. Отчёт об ошибке и «Подпись» для быстрого RCA

Структура отчёта (пример JSON):

```json
{
  "ts": "2025-09-17T00:42:15Z",
  "trace_id": "...",
  "packet_id": "...",
  "error_code": "DELIVERY_GUARD_MISSING_STEP",
  "required_steps": ["svc.llm_client.recv", "svc.parser.json_strict"],
  "found_steps": ["svc.soul.preanalysis", "svc.soul.router_decide"],
  "suspect": "svc.chat.send_message",
  "signature_excerpt": {
    "sig_version": "1.0",
    "steps_tail": [ {"ts": "...", "function_id": "..."} ]
  },
  "actions": ["block_reply", "notify_orchestrator", "log_incident"],
  "anchor": {"on_chain": false}
}


```

Отчёт виден в панели Дирижёра; отправляется Архитектору только в случае блокировки, без PII и без служебных маркеров.

## 22. Acceptance (дополнения)

- Перед любой пользовательской доставкой Delivery Guard подтверждает наличие обязательной цепочки шагов; при отсутствии — ответ не публикуется, ошибка с подписью.
- Панель Дирижёра показывает соответствие запрос↔ответ: для последних 1000 трасс нет нарушений (0 false delivery).
- Гибридный анкор активен: не менее 95% трасс за сутки имеют опубликованный Merkle‑root (окно анкора ≤ 60 сек).

### 22.1 Текущее состояние реализации (v1.1)

- Реализовано:
  - SDK `SignatureContext` + декоратор `@with_signature`, запись шагов, сохранение `signature_steps`.
  - Метки шагов: `svc.soul.preanalysis/router_decide`, `svc.llm_client.send/recv`, `svc.parser.json_strict`, `svc.chat.reply_render`, persist‑шаги.
  - Подпись в данных: `messages.meta.signature`, `quants.payload.signature`.
  - Delivery Guard (минимально) в chat/HTTP ветке.
  - Function Registry + политики (required) + enforcement в декораторе; Seeker встроен в диспетчер.
  - PROD конфигурация подтверждена: `/var/www/soulpulse/backend`, health=ok.

- В работе/запланировано:
  - UI панели (Signature/Incidents/Artifacts/Guard), метрики/дашборды/алерты.
  - Hybrid Anchor (Merkle+L2), Rust/PyO3 (JCS+BLAKE3+Ed25519), CI‑автоподпись артефактов.
  - Интеграционные/E2E тесты (ветка Архитектора), Golden‑set.

## 23. Роллаут (дополнения)

Этап 1: локальная Подпись v1 + Delivery Guard (только проверка обязательных шагов) на chat/SoulCore/parser/llm_client.

Этап 2: включение Merkle‑анкора; панель верификации на панель Архитектора.

Этап 3: расширение покрытия до persist/notify и сценариев batch; алерты по инвариантам доставки.

## 24. Crypto/Perf Profile (best practices)

- Хэширование: BLAKE3 (SIMD/MT), совместимость: SHA‑256 по необходимости.
- Подписи: Ed25519 (libsodium), batch verify (где возможно), ключи в KMS/Vault/HSM, ротация 90 дн., CRL у Дирижёра.
- Канонизация: JSON Canonicalization Scheme (JCS) перед хэшем/подписью (детерминизм).
- Прозрачный журнал: Merkle‑деревья, CT‑подобная верификация; анкор в L2 (Polygon/Arbitrum/Base) раз/30–60с.
- Приватность: хэшируем нормализованные поля без PII; на‑чейн только корневой хэш.

## 25. SDK Core (Rust) и интерфейсы PyO3

Цель: вынести hot‑path в Rust для мс‑латентности без глобальных переделок Python‑ядра.

Модули (Rust → PyO3):

- `jcs_canon.canon_json(input: &str) -> Vec<u8>` — потоковая канонизация JSON.
- `blake3_hash(data: &[u8]) -> [u8; 32]` — быстрый хэш (в hex/бинарном виде на выбор).
- `merkle_batch.push(hash: [u8;32])`, `finalize() -> root:[u8;32], proof_for(idx) -> Vec<[u8;32]>` — инкрементальная мерклизация.
- `ed25519.sign(msg: &[u8], sk_ref: KeyRef) -> Signature`, `ed25519.verify(msg, sig, pk) -> bool`, `batch_verify(...)`.

Python‑обвязка (пример сигнатур):

- `signature_sdk.hash_json(obj: dict) -> str` (JCS+Blake3 hex)
- `signature_sdk.sign_step(ctx: SignatureContext, function_id: str, scope: str, version: str, input_obj: dict, output_obj: dict) -> SignatureStep`
- `signature_sdk.append_step(ctx, step) -> None`
- `signature_sdk.build_merkle_and_anchor(batch: list[Trace]) -> AnchorTx` (асинхронно)

Интеграция точек:

- Декоратор `@with_signature(...)` остаётся Python, вызывает Rust‑ядро для канонизации/хэш/подписи.
- LLMClient/Parser/Chat/SoulCore/Persist — только добавление декоратора и передачи `SignatureContext`; бизнес‑логика не меняется.

## 26. Совместимость и реализуемость в текущем Ядре

- Точки интеграции — поверхностные (декораторы/мидлвары):
  - `ChatService.send_message`, `SoulCoreManager.generate_*`, `LLMClient.send`, `json_strict.ensure_strict_json_array`, операции вставки в `messages/quants/quant_desired_actions`.
- Delivery Guard — хук перед отправкой ответа (в `ChatService` и HTTP‑роутерах) с проверкой «обязательных шагов» — без затрагивания основной логики генерации.
- Хранение подписи — в уже используемых `meta` (jsonb) и `payload` (jsonb): миграций БД не требуется (опциональная side‑таблица `signature_steps` добавляется независимо).
- Анкор сервис — отдельный компонент; не влияет на существующие вызовы ЛЛМ/БД; включается фичефлагом.
- Вывод: реализация возможна без глобальных переделок кода; изменения локализованы в SDK/декораторах и точках вызова.

## 27. План внедрения с учётом производительности

- D0–D2: SDK Core (Rust), PyO3‑биндинги, JCS+BLAKE3+Ed25519; интеграция в декоратор; метрики.
- D3–D5: подключить в Chat/SoulCore/LLMClient/Parser; Delivery Guard (проверка шагов) — фичефлаг DEV.
- D6–D8: Merkle‑батч/анкор в L2 (тестнет), панель верификации, Seeker‑правила «обязательных шагов».
- D9–D12: оптимизации (batch verify/zero‑copy), side‑таблица `signature_steps`, алерты Дирижёра; включение в PROD минимум для ветки Архитектора.

## 28. Компоненты реализации и зоны ответственности

- Signature SDK (Python + Rust Core): канонизация (JCS), хэш BLAKE3, подпись Ed25519, ведение `SignatureContext`, append шагов, вычисление CRC, сериализация/десериализация подписи.
- Decorators/Middleware: `@with_signature`, интеграция в Chat/SoulCore/LLMClient/Parser/Persist/Notify/HTTP.
- Delivery Guard: Pre‑reply проверка «обязательных шагов»; блокировка ответа, формирование ошибочного отчёта с подписью.
- Function Registry: таблица/сервис реестра функций с политиками; валидация `required/optional/forbidden` на входе SDK.
- Seeker (Ищейка): периодический сканер БД/логов; детектор непомеченных/аномальных пакетов; генерация инцидентов.
- Anchor Service (optional): Merkle batcher + L2 publisher; хранит метаданные якорей, выдаёт proof.
- Orchestrator (Дирижёр): панель покрытий/инцидентов/якорей; API администрирования функций/ключей; алерты.

## 29. Карта интеграции (встраивание без глобальных переделок)

- Chat слой:
  - `backend/app/services/chat_service.py::ChatService.send_message` — обернуть декоратором; вызвать `DeliveryGuard.verify_before_reply` перед публикацией ответа.
  - `backend/app/routers/chat.py` — при необходимости, для HTTP отправки сообщений.
- SoulCore:
  - `backend/app/services/soul_core_manager.py::generate_quants/generate_quant/_generate_single_quant_core` — декоратор шагов preanalysis/router/llm_send/llm_recv/parser/desiredaction.
  - `backend/app/lib/json_strict.py::ensure_strict_json_array` — декоратор `svc.parser.json_strict` (параметр batch/single).
- LLM:
  - `backend/app/services/llm_client.py::LLMClient.send` — шаги `svc.llm_client.send/recv` (в send логируем отправку, после возврата — приём).
- Persist:
  - `backend/app/routers/soul.py::_process_soul_impl` и `process_soul_batch` — обернуть операции вставки в `messages`, `quants`, `quant_desired_actions` шагами `svc.persist.*`.
- Notify:
  - `backend/app/telegram.py::send_message` — `svc.notify.telegram` (для админских уведомлений/архитектора).

Фичефлаги:

- `SIGNATURE_ENABLED` — включение SDK/декораторов.
- `DELIVERY_GUARD_ENFORCE` — блокировка ответа при отсутствии цепочки шагов (старт в DEV).
- `ANCHOR_ENABLED` — включение анкора в L2 (по мере готовности).

## 30. Схемы/Хранение/Индексы

- Подпись внутри `messages.meta` (jsonb), `quants.payload` (jsonb): ключ `signature`.
- Side‑таблица `signature_steps(trace_id uuid, packet_id uuid, step_no int, ts timestamptz, function_id text, status text, input_hash bytea, output_hash bytea)` — для быстрого поиска.
- Индексы:
  - `messages (created_at desc)`, GIN по `meta` при необходимости.
  - `quants (created_at desc)`, GIN по `payload` при необходимости.
  - `signature_steps`: btree `(trace_id)`, btree `(packet_id)`, btree `(function_id, ts)`.
- Реестр функций: `function_registry(function_id unique)`, btree по `scope`, `enabled`.
- Инциденты: `signature_incidents (created_at desc)`, btree по `suspect_function_id`.

Миграции:

- Создать `function_registry`, `signature_incidents`, `signature_steps` (опционально), индексы.
- Ретро‑подпись не требуется; SDK добавляет подписи только для «новых» событий.

## 31. API/Контракты

- Admin:
  - `GET /api/admin/signature/functions`, `POST /api/admin/signature/register`.
  - `GET /api/admin/signature/stats` — покрытие, последние нарушения, частота шагов.
  - `GET /api/admin/signature/incidents` — инциденты Ищейки.
  - `POST /api/admin/signature/verify` — верификация подписи/цепочки по trace_id/packet_id; (при включённом анкоре) возвращает proof/tx.

## 32. CI/CD и политика контроля

- Pre‑commit: линтеры/форматирование; (опционально) снапшот схемы подписи (Schema Guard подписи).
- CI: unit (SDK Core), интеграционные (Chat/Soul/Parser/LLMClient), e2e (Architect flow); публикация метрик покрытия подписью.
- Release gates: для критичных функций `signature_policy=required` — билд блокируется, если покрытие < X%.

## 33. Тестирование (стратегия)

- Unit:
  - Rust Core: канонизация JCS, BLAKE3, Merkle finalize/proof, ed25519 sign/verify.
  - Python SDK: сериализация/десериализация, CRC, append шагов, ошибки.
- Интеграция:
  - Chat → SoulCore → LLMClient → Parser → Persist → Reply: проверка наличия «обязательных шагов»; Delivery Guard блокирует при отсутствии.
  - Batch/Single сценарии, пустые/ошибочные ответы LLM: формирование отчёта об ошибке с подписью.
- E2E (ветка Архитектора):
  - «Ответ без техблоков», «Нет эха», «Есть send/recv/parser в подписи»; панель Дирижёра отражает цепочку.

Негативные кейсы:

- Принудительно выбросить исключение до LLM → Delivery Guard должен заблокировать и выдать отчёт об ошибке с подписью.
- Подмена подписи (CRC mismatch) → Delivery Guard блокирует; инцидент.

## 34. Мониторинг/Алерты/Дашборды

- Метрики:
  - coverage_signature_percent, incidents_rate_per_hour, avg_steps_per_packet, time_send_to_recv_ms, time_recv_to_reply_ms.
  - anchor_roots_count, anchor_lag_seconds (если включён анкор).
- Дашборды Дирижёра: покрытие по функциям/потокам, последние инциденты (таблица+гистограмма), живые anchor‑tx.
- Алерты:
  - «reply без send/recv/parser за X мин», «подпись отсутствует на persist», «anchor lag > 5мин».

## 35. Пошаговая последовательность внедрения (детально)

Шаг 0: Флаги/конфиги

- Ввести `SIGNATURE_ENABLED`, `DELIVERY_GUARD_ENFORCE`, `ANCHOR_ENABLED`; значения по умолчанию: `1/0/0` в DEV, `1/0/0` в PROD.

Шаг 1: SDK Core (Rust) + PyO3 биндинги

- Реализовать модули JCS, BLAKE3, ed25519, Merkle; собрать wheel; добавить в requirements.
- Python SDK: контекст, декоратор, CRC, сериализация; юнит‑тесты.

Шаг 2: Интеграция точек

- Обернуть ChatService, SoulCoreManager, LLMClient.send, json_strict, persist/notify функциями декоратора.
- Delivery Guard: хук перед ответом в ChatService и HTTP `/api/soul/process`.

Шаг 3: БД и индексы

- Применить миграции для `function_registry`, `signature_incidents`, `signature_steps` (опц.), индексы.
- Добавить GIN по `meta`/`payload` только при необходимости запросов.

Шаг 4: Ищейка/Дирижёр

- Реализовать Seeker; cron/async job каждые N мин; вывод на панель.
- Доработать панель: покрытие, инциденты; API верификации.

Шаг 5: Анкор (опц.)

- Запустить Batch Merkle Service (тестнет), публиковать root; добавить verify‑панель.

Шаг 6: Включение Delivery Guard enforcement

- DEV → STAGE: включить блокировку; убедиться, что инциденты ≈ 0; потом включить частично в PROD (ветка Архитектора).

## 36. Миграции/Переиндексации/Ретенции

- Миграции создают новые таблицы; существующие `messages/quants` не меняются.
- Индексы — только там, где запросы реальны (избегаем избыточности).
- Ретеншн подписи: хранить все шаги 30–90 дней онлайново; архивировать в холодное хранилище (S3) с сохранением Merkle‑деревьев и map‑файлов.

## 37. Риски/Снижение

- Снижение SLO: Rust Core + BLAKE3/Ed25519 минимизируют латентность; Merkle/anchor — асинхронно.
- Ложные блокировки: Delivery Guard сначала в observe‑режиме, затем enforce; белые списки для редких системных путей.
- Управление ключами: KMS/Vault, периодическая ротация, CRL у Дирижёра; алерты при невалидных ключах.

## 38. Совместимость/Откаты

- SDK и Guard включаются фичефлагами; отключение = возврат к прежнему поведению без подписи.
- Анкор — полностью опционален, не влияет на обработку запроса.
- Откат: отключить `DELIVERY_GUARD_ENFORCE`, затем `SIGNATURE_ENABLED` → чистый возврат.

## 39. Подпись крупных артефактов: промпты, программные файлы, секреты, схемы

Цель: расширить «Подпись v1» на артефакты, влияющие на поведение системы, и обеспечить доказуемость их происхождения/целостности.

Классы артефактов:

- Промпты (основные/модули/персоны), шаблоны Router/Modules, OpenAPI‑спеки.
- Программные файлы/сборки (wheel, контейнерные образы), SBOM.
- Секреты/конфиги (ENV, токены; только метаданные и хэши, не содержимое).

Общий подход (Data Integrity):

- Канонизация → хэш (BLAKE3/SHA‑256) → подпись Ed25519 → запись в «Реестр артефактов» у Дирижёра.
- При использовании артефакта в рантайме соответствующий шаг Подписи добавляет ссылку на артефакт (id/hash/signature).

## 40. Реестр артефактов (Artifacts Registry)

DDL (сводно):

```sql
create table artifacts (
  id uuid primary key default gen_random_uuid(),
  kind text not null,               -- prompt|file|container|openapi|sbom|secret-meta
  name text not null,               -- путь/логическое имя
  version text,                     -- semver/label/git sha
  hash_alg text not null,           -- blake3|sha256
  hash_hex text not null,           -- hex
  signature bytea,                  -- ed25519
  signer text,                      -- service_id/key_id
  created_at timestamptz default now(),
  meta jsonb                        -- произвольно (e.g., locale/persona for prompts)
);
create unique index on artifacts(kind, name, coalesce(version,''));


```

API:

- `POST /api/admin/artifacts/register` (только метаданные/хэши/подпись; содержимое не хранится)
- `GET /api/admin/artifacts?kind=&name=&version=`
- `POST /api/admin/artifacts/verify` — верификация подписи и соответствия текущему файлу/контенту.

## 41. Промпты: политика версионирования и подпись

- Каждый промпт (системный/модульный) имеет `name`, `locale`, `version` (semver), `hash_hex`, `signature`.
- В рантайме `SoulPromptsService.get_prompt` добавляет шаг подписи `svc.prompts.load` с `artifact_id` и `hash_hex`.
- Delivery Guard проверяет: промпт, реально использованный при `llm_client.send`, зарегистрирован и валиден (hash совпадает).
- CI‑проверка: изменение промпта → автоматическая регистрация в реестре (pre‑commit hook), генерация подписи сервисным ключом.

## 42. Программные файлы/сборки

- Коллектим SBOM (CycloneDX) на сборках; генерим хэш колеса/образа; подписываем.
- В `ai_message.meta`/`soul_audit_log` пишем `build_id`, `artifact_id` образа/сборки.
- Orchestrator показывает «какая сборка/образ» породила конкретный ответ; верификация против реестра артефактов.

## 43. Секреты/конфиги (метаданные)

- Содержимое секретов не подписываем и не храним; подписываем «мета‑снимок» (названия, дата выпуска, issuer KMS, версии ротации) — hash+signature.
- При чтении ENV критических ключей (e.g., `DEEPSEEK_API_KEY`) фиксируем шаг `svc.secrets.use` со ссылкой на meta‑artifact.
- Дирижёр может показать: для конкретного trace_id использовалась версия секрета «v2025‑09‑17», чей issuer — Vault/KMS key X.

## 44. Верификация в рантайме (минимальные изменения кода)

- В местах загрузки артефактов (промпт/модель/спеки) добавить вызов `signature_sdk.attach_artifact(ctx, artifact_ref)`; SDK сверяет hash/signature через Orchestrator cache/API.
- При несовпадении — отчёт/инцидент, Delivery Guard блокирует ответ (для критичных артефактов: prompts, llm route specs).

## 45. Мониторинг/дашборды для артефактов

- Панель: «Активные артефакты за 24ч» (top‑N), «Несовпадения/отказ верификации», «Покрытие промптов подписями».
- Метрики: artifacts_verified_rate, artifact_mismatch_rate, secrets_meta_version_usage.

## 46. Тестирование и внедрение

- Unit: расчёт hash/signature для промптов/файлов; верификация Py+Rust; отрицательные кейсы (подмена).
- Интеграция: Chat/SoulCore/LLM — проверка, что шаги содержат валидные ссылки на артефакты; Delivery Guard блокирует при несоответствии.
- E2E: сценарий «обновление промпта» → новая версия регистрируется, используется в ответах; панель отражает версию.

## 47. Интерфейс Архитектора (управление, статистика, хранилища, мониторинг)

### 47.1 Разделы панели

- Обзор (Overview)
  - Карточки: coverage_signature_percent, incidents_rate, anchor_lag_seconds, replies_blocked_by_guard.
  - Графики: time_send_to_recv_ms (p50/p95), incidents_per_hour, anchors_per_hour.

- Реестр функций (Function Registry)
  - Таблица: function_id, title, owner, scope, version, signature_policy, enabled, latency_budget_ms, last_seen.
  - Действия: enable/disable, policy (required/optional/forbidden), edit latency_budget, просмотр последних шагов.

- Трассы/Подписи (Traces & Signatures)
  - Поиск по trace_id/packet_id/user_tg_id/диапазону времени.
  - Древовидный просмотр шагов подписи; экспорт JSON/CSV; Merkle‑proof (если анкор включён).
  - Кнопка «Verify» — локальная проверка CRC + опционально proof‑проверка.

- Ищейка / Инциденты (Seeker / Incidents)
  - Список инцидентов: severity, suspect_function_id, count, sample, actions.
  - Детали: подпись хвоста, причина блокировки/подозрения, кнопки «пометить ложноположительным», «создать задачу исправления».

- Артефакты (Prompts/Builds/Secrets)
  - Таб лица по артефактам: kind, name, version, hash, signature, signer, created_at.
  - Действия: verify (сравнение текущего файла/контента), скачать SBOM/мета; фильтры по kind/версиям.

- Delivery Guard
  - Политики: список «обязательных шагов»; режим observe/enforce; белые списки функций/веток.
  - Метрики блокировок; истории блокировок с отчётами.

- Anchor (опционально)
  - Последние anchor‑tx: сеть (L2), tx_hash, window, root_seq; задержка; статус.
  - Верификация конкретной трассы: загрузка proof и проверка соответствия root.

### 47.2 Навигация и UX

- Быстрые ссылки из инцидентов в соответствующие трассы и артефакты.
- Подсветка нарушений в дереве шагов (красный/жёлтый статус).
- Пагинация, экспорт, копирование ссылок на объекты (deep‑link).

### 47.3 API панели (сводно)

- `GET /api/admin/signature/stats` — данные для Overview.
- `GET/POST /api/admin/signature/functions` — CRUD/настройки реестра функций.
- `GET /api/admin/signature/traces?trace_id|packet_id|...` — список и детали шагов.
- `GET /api/admin/signature/incidents` — список инцидентов; `POST /.../ack|ignore` — пометки.
- `GET/POST /api/admin/artifacts` — реестр артефактов и верификация.
- `GET/POST /api/admin/delivery_guard` — политики, белые списки, режим.
- `GET /api/admin/anchor/roots` — якоря; `POST /api/admin/anchor/verify` — proof‑проверка.

### 47.4 Хранилища

- Подпись по месту происхождения: `messages.meta.signature`, `quants.payload.signature` (jsonb); расширенный лог шагов — `signature_steps`.
- Реестры: `function_registry`, `artifacts`, `signature_incidents`, (опц.) `anchor_roots`.

### 47.5 Мониторинг

- Источники: Prometheus метрики SDK/Delivery Guard/Anchor; логи аудита `soul_audit_log`.
- Дашборды: Overview, Functions Coverage, Incidents, Anchor, Artifacts.
- Алерты: по KPI из раздела 34.

### 47.6 Роли и доступ

- RBAC: Architect/Admin доступ к панели; просмотр/редактирование реестров; подтверждение инцидентов.
- Аудит действий Архитектора: изменения политик/включение enforce/регистрация артефактов.

## 48. Runbook: PROD деплой и smoke‑проверки P27

Предпосылки:

- PROD backend: `/var/www/soulpulse/backend` (systemd unit `soulpulse-backend.service`).
- Ключ SSH: `deploy/ssh_keys/app_server_key`

 
## Мировые аналоги и практики
- OpenLineage / Marquez — стандарт lineage для пайплайнов: `https://openlineage.io`, `https://marquezproject.github.io/marquez/`
- Apache Atlas — метаданные и lineage: `https://atlas.apache.org/`
- DataHub (LinkedIn) — метаданные/каталоги/lineage: `https://datahubproject.io/`
- OpenTelemetry — трассировка шагов (spans) и корреляция: `https://opentelemetry.io/`
- Sigstore / Rekor — прозрачный журнал подписи артефактов: `https://rekor.dev`
- JCS (RFC 8785) — каноникализация JSON: `https://datatracker.ietf.org/doc/html/rfc8785`
