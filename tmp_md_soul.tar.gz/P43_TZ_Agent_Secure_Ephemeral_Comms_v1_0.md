# P43 — ТЗ: Агент временной безопасной связи (Secure Ephemeral Comms)

Версия: v1.3 (WebRTC сигналинг/ICE/метрики, «главный экран», управление сессиями/комнатами (disconnect/kill), опциональный автодопуск, Permissions-Policy для камеры/микрофона)

## 1. Назначение

- Организация эфемерных каналов связи между пользователями через мастер‑страницу управления комнатами.
- Безопасность: разрешения на подключение (перманент по TG ID и сессионное по имени), TTL/продление, аудит запросов.

## 2. UI

- Мастер‑страница: `GET /api/agent/comm/master`
  - Просмотр списка комнат: id, имя, создана, действует до, pending‑запросы, списки разрешённых (perm/session)
  - Создать комнату: имя + TTL (мин)
  - Продлить комнату: +30 минут (или произвольный TTL)
  - Переименовать комнату
  - Просмотр и управление сессиями комнаты: pause/resume/disconnect; авто‑пауза по неактивности
  - Одобрение входа: по TG ID (перманент) или по имени (до конца сессии)

- Страница агента: `GET /agent/comm`
  - Поля: Имя (обязательно), Telegram ID (опционально), Room ID (опционально)
  - Кнопки: «Отправить запрос», «Создать запрос» (эфемерная сессия), «Восстановить сессию комнаты», отправка сообщений, лог‑панель
  - Поведение восстановления: сначала попытка восстановления сессии комнаты, затем создание/восстановление эфемерной сессии

### 2.1 Клиентское поведение и локальное хранилище

- Хранение в `localStorage`:
  - `agent_comm_sid` — ID эфемерной сессии агента
  - `agent_room_id` — ID комнаты
  - `agent_name` — имя пользователя
  - `agent_tg` — Telegram ID (опционально)
  - `agent_room_session_id` — ID сессии пользователя в комнате
- Восстановление сессии комнаты:
  - Если `room_id` отсутствует, но есть `name` и/или `tg_id`, происходит попытка «умного» разрешения комнаты:
    - по перманентному разрешению (tg_id) в `agent_room_perms`
    - по сессионному разрешению (name) в `agent_room_perms`
    - по ранее существующим активным/paused сессиям в `agent_room_sessions`
  - При успешном нахождении создаётся/возобновляется `agent_room_session_id`, найденный `room_id` сохраняется в `localStorage`
  - При ошибке `room not resolved`/`not allowed`/404 автоматически отправляется глобальный join‑запрос (без `room_id`), чтобы админ одобрил на мастер‑странице
- Эфемерная сессия агента:
  - При 404 на `/api/agent-comm/status` создаётся новая сессия автоматически, `agent_comm_sid` обновляется
- Heartbeat комнаты: POST `/api/agent-rooms/sessions/heartbeat` каждые 15с для поддержания активности; при отсутствии heartbeat >45с сервер переводит статус в paused
- Клиентское логирование: отправка логов на `/api/agent-rooms/log` (принимает GET и POST)

## 3. API (HTTP)

- Создать комнату: `GET/POST /api/agent-rooms/create?name=<str>&ttl_minutes=<int>`
- Список комнат: `GET /api/agent-rooms/list`
- Продлить комнату: `GET/POST /api/agent-rooms/extend?room_id=<uuid>&ttl_minutes=<int>`
- Переименовать комнату: `GET/POST /api/agent-rooms/rename?room_id=<uuid>&name=<str>`
- Запрос на вход: `GET/POST /api/agent-rooms/join?room_id=<optional uuid>&name=<str>&tg_id=<optional>` (алиас: `request_join`)
- Одобрение: `GET/POST /api/agent-rooms/approve?room_id=<uuid>&name=<str>&tg_id=<optional>&permanent=true|false`
- Отклонение: `GET/POST /api/agent-rooms/deny?room_id=<uuid>&name=<str>&tg_id=<optional>`
- Списки заявок: `GET /api/agent-rooms/pending` (глобальные и по комнатам)
- Сессии комнаты:
  - Регистрация: `GET/POST /api/agent-rooms/sessions/register?room_id=<uuid>&name=<optional>&tg_id=<optional>`
  - Список: `GET /api/agent-rooms/sessions/list?room_id=<optional uuid>`
  - Heartbeat: `GET/POST /api/agent-rooms/sessions/heartbeat?session_id=<uuid>`
  - Pause: `GET/POST /api/agent-rooms/sessions/pause?session_id=<uuid>`
  - Resume: `GET/POST /api/agent-rooms/sessions/resume?session_id=<uuid>`
  - Disconnect: `GET/POST /api/agent-rooms/sessions/disconnect?session_id=<uuid>`
  - Find or create: `GET/POST /api/agent-rooms/sessions/find_or_create?room_id=<optional uuid>&name=<optional>&tg_id=<optional>`
- Логирование клиента/мастера: `GET/POST /api/agent-rooms/log` (query/body: `scope, level, session_id, room_id, room_session_id, message`)
- WebRTC конфигурация ICE: `GET /api/agent-rooms/webrtc/config` → `{ ok, iceServers, maxParticipants }`
- Статус сессии: `GET /api/agent-rooms/sessions/status?session_id=<uuid>` → `{ ok, status, last_seen }`
- Метрики WebRTC: `POST /api/agent-rooms/webrtc/metrics?room_id=<uuid>&session_id=<uuid>` (body: JSON метрик)
- Принудительное завершение сессии: `GET/POST /api/agent-rooms/sessions/kill?session_id=<uuid>`
- Удаление комнаты: `GET/POST /api/agent-rooms/kill?room_id=<uuid>`
- Флаг автодопуска: `GET/POST /api/agent-rooms/auto_resume?room_id=<uuid>&enabled=true|false`
- Канал агента (fallback):
  - Отправка: `GET/POST /api/agent-comm/send?session_id=<uuid>&text=<str>`
  - Poll: `GET /api/agent-comm/poll?session_id=<uuid>&last=<int>`
  - Статус: `GET /api/agent-comm/status?session_id=<uuid>`
  - Закрытие: `GET/POST /api/agent-comm/close?session_id=<uuid>`

Примечание: UI страницы `GET /agent/comm` и `GET /api/agent/comm/master` отдаются с заголовком `Cache-Control: no-store` для исключения проблем с кешированием скриптов.

Примечание: мастер‑страница сейчас доступна без RBAC; действия API временно защищаются заголовком `X-Telegram-User-ID: 468326902` (временная мера для DEV). Авторизацию для Telegram пока не делаем: поле `tg_id` у пользователя — опционально (нужно лишь для перманентного допуска). План — перенести под RBAC/Two‑Keys после включения WS‑прокси в Nginx.

## 4. Политики доступа

- Если указан `tg_id` и `permanent=true` — пользователь добавляется в постоянный allow‑list комнаты.
- Если указан только `name` — разрешение до конца сессии (сбрасывается при перезапуске).
- Время действия комнаты — TTL, можно продлить через API/UI.
- Авто‑join при невозможности восстановления: если комната не определена/доступ запрещён, клиент отправляет глобальную заявку без `room_id`; администратор выбирает комнату в мастере и одобряет.

## 5. Непрерывность работы (fallback)

- При недоступности WebSocket UI использует HTTP‑polling и гарантирует доставку сообщений.
- План: после включения WS‑прокси в Nginx переключить на wss `wss://mini.soulpulse.art/api/ws/agent-comm/session/{id}`.
- Логирование: `/api/agent-rooms/log` принимает GET/POST; используется для клиентской/мастер‑диагностики и аудита.

## 5.1 Nginx (прокси маршрутов API и WebSocket)

- Требуются явные `location` для:
  - `/agent/comm`, `/api/agent/comm` — прокси на бекенд
  - `/ws/`, `/api/ws/` — прокси WebSocket с заголовками `Upgrade`/`Connection` и увеличенными таймаутами
- Таймауты прокси: `proxy_read_timeout`/`proxy_send_timeout` ≥ 120s

### 5.2 Политика разрешений камеры/микрофона

- Страница агента `GET /agent/comm` отдаёт заголовок `Permissions-Policy: camera=(self), microphone=(self)`.
- UI обрабатывает отказ пермишенов и предлагает: повторить запрос, включить только микрофон, открыть во внешнем браузере.

### 5.2 WebSocket сигналинг (room scope)

- Endpoint: `GET WS /api/ws/agent-rooms/{room_id}/signal?peer_id=<agent_room_session_id>&name=<optional>`
- Сообщения (JSON):
  - Клиент → Сервер: `{"type":"hello"}`
  - Сервер → Клиент: `{"type":"welcome","participants":[peer_id,...]}`
  - Offer/Answer/ICE: `{"type":"offer|answer|ice","to":"<peer_id>","sdp"|"candidate":...}`; сервер ретранслирует адресату с `from`
  - События: `peer_join`, `peer_leave`, `chat` (`{"type":"chat","from":"...","name":"...","text":"..."}`),

    `draw` (кораблинг холста), `set_main` (назначение главного), `main_changed` (обновление у всех),
    `peer_stream_changed` (`{"type":"peer_stream_changed","id":"<peer_id>","kind":"camera|screen|mic_only"}`)

  - Ошибки: `{"type":"error","code":"peer_not_found|room_full|bad_request|...","message":"..."}`
  - Лимиты: `maxParticipants=8` (переменная), отказ при переполнении: `room_full`

ENV для ICE (в `.env.prod` или системном env):

- `ICE_STUN=stun:stun.l.google.com:19302,stun:global.stun.twilio.com:3478`
- `ICE_TURN_URI=turns:turn.example.com:5349` (или `turn:`)
- `ICE_TURN_USERNAME=<user>`
- `ICE_TURN_PASSWORD=<secret>`
- `ICE_TURN_TLS=1` (по умолчанию включено)

## 6. Acceptance

- Мастер‑страница открывается и позволяет:
  - создать комнату; увидеть её в списке; продлить TTL;
  - принять запрос (perm/session);
  - пользователь после approve может общаться в канале (WS или HTTP‑fallback).

Версия: v1.3  
Статус: Реализовано (MVP: комнаты, мастер, сигналинг WebRTC, ICE конфигурация, минимальный UI на `/agent/comm`, метрики, опция автодопуска, kill сессий/комнат, Permissions-Policy)  
Источник истины: этот файл; при изменениях — обновлять `docs/PROJECT_STRUCTURE_v8_0_4.md` и `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8_2.md`.

## 0) Назначение и контекст

Агент — актор (персонаж Ядра Соул), чья основная функция — организация временного, устойчивого, помехозащищённого, безопасного и по возможности незаметного e2e‑канала связи между Телами/Агенами/Хранилищами Соул. Канал мультимодальный (данные/аудио/видео/управляющие команды), по умолчанию — полноэкранная CLI‑сессия с возможностью групповой передачи аудио/видео и запуском модулей в открытом канале. Вспомогательная функция — окно коммуникаций с выбором участников (аналог Zoom) под RBAC/Two‑Keys.

Инварианты проекта: P27 подпись/линейдж, P28 фичефлаги/политики, P29 качество/гейты, P36 Hyperloop DSL управление, P44 RBAC/Two‑Keys. Каноничные API/проверки — см. раздел Acceptance.

## 1) Критический обзор (Report_Soul_AI_Scientific.md)

Найденный отчёт подтверждает инварианты STRICT_JSON, stateless batch, централизованные ENV и наблюдаемость. Для P43 выводы:

- Единая сборка контекста/правил (CORE/ROUTER_CONTEXT/MODULES/OUTPUT_SPEC/NEGATIVE) совместима: Агент не изменяет личность «Соул», выступает транспортным слоем и интерфейсом управления сетью через DSL.
- P27/P36 уже задают обязательные шаги/трейсы — использовать для канала связи и его туннелей.
- P44 задаёт Two‑Keys для опасных NET/DEPLOY/DB/SCHEMA — расширить на NET.* (каналы/окна/маршрутизация/даркнет).

## 2) Требования (функциональные)

F1. Временный e2e‑канал связи (данные/аудио/видео) с автозакрытием/ротацией ключей.  
F2. Групповые сессии: выбор участников/ролей; базовая функциональность конференций (микрофон/камера/демо экрана, Mute/Hand/Chat).  
F3. CLI‑режим по умолчанию: полноэкранная командная строка с совместным сигналом и запуском модулей в открытом канале.  
F4. Поддержка мульти‑транспорта: TCP/UDP/QUIC/WebRTC/SRT/RIST/SSH‑reverse/MASQUE/OHTTP; динамический выбор, мультипас и репликация.  
F5. Обфускация/стелс: TLS1.3+ECH, DoH/DoQ, domain fronting (если легально), pluggable transports (obfs4/snowflake/meek), padding/traffic‑shaping.  
F6. Шифрование/ротация: Double Ratchet/X3DH/MLS для групп; пер‑сессионные динамические ключи; форвард‑секрс и пост‑компрометационная безопасность.  
F7. Устойчивость: FEC (RaptorQ/RS), ARQ, jitter‑buffer, packet reordering; зеркалирование/эхо/экранирование; адаптация битрейта.  
F8. Распределённые VPN/overlay: мульти‑хоп туннели, split‑routing, сборка сигнала на краях; MPTCP/Multipath QUIC.  
F9. Совместимость: низкоуровневые компоненты совместимы с Ядром Соул и Hyperloop; управление через DSL NET.* и UI.  
F10. Приёмник: любой современный браузер/WebRTC‑клиент или малый нативный агент без установки.  
F11. Наблюдаемость/аудит: подпись шагов `svc.agent.net.*`, метрики p95, incident‑лог; скрытая диагностика, без тех‑блоков наружу.

## 3) Требования (нефункциональные)

N1. Безопасность: Zero‑Trust, PoLP, RBAC/ABAC, Two‑Keys на опасные операции (создание/изменение туннелей, даркнет‑маршруты).  
N2. Производительность: p95 `time_send_to_recv_ms` ≤ 1200ms (данные), ≤ 250ms (аудио), ≤ 400ms (видео 360p@15).  
N3. Устойчивость: непрерывность при потере до 10% пакетов (FEC+ARQ), автоматический failover транспорта/маршрута < 3s.  
N4. Незаметность: профиль трафика маскируется под допустимый (HTTPS/HTTP3/DoH/DoQ) с ограничением утечек SNI (ECH) и детектируемых паттернов.  
N5. Совместимость/портативность: Linux x86_64/arm64; браузеры с WebRTC; сервер без root‑прав там, где возможно.

## 4) Архитектура и компоненты

- Agent Core (Rust/Go): сессии, ключевая матрица, транспорты, FEC/FEC‑планировщик, obfuscation, NAT traversal.
- Key Service: X3DH/Double Ratchet для p2p; MLS для групп; хранилище только эфемерных публичных ключей; секреты — в памяти.
- Transport Multiplexer: QUIC/WebRTC/SRT/RIST/SSH‑reverse/MASQUE/OHTTP; политика выбора и мультипас.
- Stealth Layer: ECH/TLS1.3, padding/shape, pluggable transports (obfs4/snowflake/meek); адаптация под политику среды.
- Overlay/VPN: WireGuard/Headscale совместимость; split‑routing, сборка на краях; MPTCP/MP‑QUIC.
- Observability: экспорт метрик/трейсов, шаги подписи P27, алерты; скрытый диагностический канал.
- Interfaces:
  - Hyperloop DSL: `NET.*` (см. §7), RBAC=sysadmin + Two‑Keys.
  - UI (P23): окно связи/список сессий/приглашений, контроль битрейта/транспорта, статус/метрики.
  - API (P22): фасады `/api/admin/net/*` (только безопасные операции, без выдачи секретов).

## 5) Протоколы/транспорты и тактики

- Ключи: X3DH → Double Ratchet (1:1); MLS для групп; pre‑keys, rekey каждые N секунд/МБ, post‑compromise safety.
- Аудио/видео: WebRTC SRTP + SFrame e2e; симулькаст/слисинг; адаптация битрейта, NACK/PLI/FEC.
- Данные/CLI: QUIC (HTTP/3), WebTransport; альт: SRT/RIST для устойчивых потоков; OHTTP для запросов; MASQUE для туннелей.
- Обход/стелс: ECH, DoH/DoQ, domain fronting (при соблюдении политики), obfs4/snowflake/meek; padding/time‑jitter.
- Мультипас и FEC: MP‑QUIC/MPTCP; RaptorQ/RS уровни; зеркалирование/эхо/подмена пакетов (как защитная помехоустойчивость на гранях).

### 5.1 Таблица совместимости транспортов

| Транспорт | Тип трафика | NAT traversal | FEC/ARQ | Стелс/обфускация | Плюсы | Минусы |
|---|---|---|---|---|---|---|
| WebRTC (SRTP+SFrame) | Аудио/Видео/Данные | STUN/TURN/ICE | NACK/PLI + опц. FEC | ECH/DoH/DoQ через сигналинг | Широкая поддержка браузерами, адаптивность | Зависимость от ICE/TURN, сигнатуры RTP |
| QUIC (HTTP/3/WebTransport) | Данные/CLI | Хорошая через UDP | Встроенный ARQ, без FEC | ECH, маскируется под HTTPS/HTTP3 | Низкая латентность, мультиплексирование | UDP‑блокировки в ряде сетей |
| SRT | Видео/потоки | средняя | ARQ+опц. FEC | Обфускация ограниченная | Устойчив к потерям/джиттеру | Не браузерный, требует клиента |
| RIST | Видео/потоки | средняя | ARQ | Ограничено | Надёжность, совместимость вещания | Нужны гейтвеи, не веб |
| SSH reverse | Данные/CLI | через TCP | Нет | Возможен через прокси | Простота, проходимость TCP | Высокая латентность, не для AV |
| MASQUE | Туннели/маршруты | высокая | Зависит от внутреннего | Под HTTPS/QUIC | Незаметные туннели поверх HTTP/3 | Сложность, поддержка ограничена |
| OHTTP | Запросы/ответы | высокая | Нет | Скрытие источника запроса | Приватность запросов | Не для потоков |

## 6) Безопасность и RBAC/P44

- RBAC/ABAC/Two‑Keys (P44): команды `NET.*` требуют роли `sysadmin` и согласования на чувствительные действия (создание внешних окон, даркнет‑маршрутов, domain‑fronting).  
- Политики P09/P08: приватность, минимизация экспозиции; логи без PII, ключи не пишутся на диск.  
- Delivery Guard (P27): перед публикацией пригласительных/URL/ICE‑кандидатов — цепочка `svc.processor.*`/`svc.rbac.*`/`svc.guard.*`.

## 7) Hyperloop DSL (P36) — NET.* команды

- `NET.SESSION.CREATE mode="cli|av|hybrid" participants=[...] TTL=600s WITH TRACE`  
- `NET.SESSION.JOIN session_id=<id> role="speaker|viewer|admin"`  
- `NET.SESSION.END session_id=<id>`  
- `NET.TRANSPORT.SET session_id=<id> prefer="quic|webrtc|srt|rist|ssh" multipath=true fec="raptorq:rate=20%"`  
- `NET.STEALTH.APPLY session_id=<id> profile="ech+http3+padding"`  
- `NET.VPN.ROUTE.ADD session_id=<id> via="wireguard" split=true`  
- `NET.METRICS session_id=<id>`  
- Все опасные варианты (VPN/STEALTH/fronting) — Two‑Keys.

### 7.1 Спецификация параметров/ошибок

- Общие параметры:
  - `session_id: str(uuid)` — идентификатор сессии.
  - `mode: enum(cli|av|hybrid)` — тип канала.
  - `participants: List[str|int]` — tg_id участников.
  - `TTL: duration` — время жизни сессии, формат `120s|10m|1h`.
  - `prefer: enum(quic|webrtc|srt|rist|ssh)` — предпочтительный транспорт.
  - `multipath: bool` — включить мультипуть.
  - `fec: str` — формат `raptorq:rate=10..50%|rs:rate=...`.
  - `profile: str` — профиль stealth, например `ech+http3+padding`.
  - `split: bool` — split‑routing для VPN/overlay.

- Коды ошибок DSL:
  - `NET_ERR_INVALID_ARG` — некорректные параметры/несовместимые опции.
  - `NET_ERR_RBAC_DENIED` — отказ RBAC/Two‑Keys.
  - `NET_ERR_TRANSPORT_UNAVAILABLE` — транспорт недоступен/политиками запрещён.
  - `NET_ERR_STEALTH_POLICY` — запрещён профиль stealth (политика/юридические ограничения).
  - `NET_ERR_VPN_FAILURE` — ошибка overlay/VPN маршрута/ключей.
  - `NET_ERR_SESSION_NOT_FOUND` — не найдена сессия.
  - `NET_ERR_INTERNAL` — иные сбои.

### 7.2 Примеры использования

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
$B=@{ commands='NET.SESSION.CREATE mode="av" participants=["468326902"] TTL=10m WITH TRACE' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B

$C=@{ commands='NET.TRANSPORT.SET session_id="<id>" prefer="webrtc" multipath=true fec="raptorq:rate=20%"' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $C

```

### 7.3 JSON‑шаблоны ответов/ошибок

Успех (CREATE):

```json
{
  "ok": true,
  "command": "NET.SESSION.CREATE",
  "session": {
    "id": "f1c2db1e-7b2a-4e8d-ae2e-3f6b2c1e9a00",
    "mode": "cli",
    "ttl_seconds": 120,
    "participants": ["468326902"],
    "transport": { "active": "quic", "multipath": true, "fec": "raptorq:rate=20%" }
  },
  "signature": { "trace_id": "<trace>", "signature_saved_steps": 3 }
}

```

Метрики (METRICS):

```json
{
  "ok": true,
  "command": "NET.METRICS",
  "session_id": "f1c2db1e-7b2a-4e8d-ae2e-3f6b2c1e9a00",
  "metrics": {
    "latency_ms": { "data_p50": 80, "data_p95": 420, "audio_p95": 180 },
    "packet_loss_ratio": 0.03,
    "failovers_total": 1,
    "fec_overhead_ratio": 0.18
  },
  "signature": { "trace_id": "<trace>" }
}

```

Ошибка (RBAC/Two‑Keys):

```json
{
  "ok": false,
  "error": {
    "code": "NET_ERR_RBAC_DENIED",
    "message": "Two-Keys approval required for NET.STEALTH.APPLY",
    "details": { "request_id": "<request>", "ttl": 300 }
  },
  "signature": { "trace_id": "<trace>" }
}

```

Успех (JOIN):

```json
{
  "ok": true,
  "command": "NET.SESSION.JOIN",
  "session_id": "<id>",
  "role": "viewer",
  "signature": { "trace_id": "<trace>" }
}

```

Успех (END):

```json
{
  "ok": true,
  "command": "NET.SESSION.END",
  "session_id": "<id>",
  "released": true,
  "signature": { "trace_id": "<trace>" }
}

```

Успех (TRANSPORT.SET):

```json
{
  "ok": true,
  "command": "NET.TRANSPORT.SET",
  "session_id": "<id>",
  "transport": { "active": "webrtc", "multipath": true, "fec": "raptorq:rate=20%" },
  "signature": { "trace_id": "<trace>" }
}

```

Успех (STEALTH.APPLY):

```json
{
  "ok": true,
  "command": "NET.STEALTH.APPLY",
  "session_id": "<id>",
  "profile": "ech+http3+padding",
  "signature": { "trace_id": "<trace>" }
}

```

Успех (VPN.ROUTE.ADD):

```json
{
  "ok": true,
  "command": "NET.VPN.ROUTE.ADD",
  "session_id": "<id>",
  "route": { "via": "wireguard", "split": true },
  "signature": { "trace_id": "<trace>" }
}

```

Коды ошибок (справочник):

```json
{
  "NET_ERR_INVALID_ARG": "Некорректные параметры/несовместимые опции",
  "NET_ERR_RBAC_DENIED": "Недостаточно прав или отсутствует Two-Keys",
  "NET_ERR_TRANSPORT_UNAVAILABLE": "Выбранный транспорт недоступен/запрещён",
  "NET_ERR_STEALTH_POLICY": "Профиль stealth запрещён политикой",
  "NET_ERR_VPN_FAILURE": "Ошибка VPN/overlay (ключи/маршруты)",
  "NET_ERR_SESSION_NOT_FOUND": "Сессия не найдена",
  "NET_ERR_INTERNAL": "Внутренняя ошибка"
}

```

## 8) Интеграции с P‑серией

- P27: шаги `svc.agent.net.*`, корреляция trace_id; инспекторы наличия событий.  
- P28: флаги профилей `net.*` (prod_safe/rt_low_latency/stealth_aggressive).  
- P29: gendarme‑тесты: отсутствие тех‑маркеров, RBAC/Two‑Keys соблюдены, JSON‑контракты UI/API.  
- P30: Processor события: request→plan NET.SESSION/TRANSPORT/STEALTH→act→observe; инциденты при сбоях.  
- P36: DSL `NET.*` и `CORE.TRACE.REQUIRE` для смоков.  
- P44: роли/лимиты/окна egress; ownership на сессии.

## 9) Acceptance и смоки

API/Hyperloop (смоки после деплоя):

- `CORE.PIPELINE.RUN input_text="health check" WITH TRACE` → trace_id ok.  
- `INSPECTOR.RUN_ALL` → присутствуют `svc.agent.net.*` за 24h.  
- `NET.SESSION.CREATE mode="cli" participants=["468326902"] TTL=120s WITH TRACE` → ok, возвращает `session_id`, `signature.trace_id`.  
- `NET.METRICS session_id=<id>` → p95 метрики, `signature_saved_steps>0`.  
- Завершение: `NET.SESSION.END` → ok, ресурсы освобождены.

### 9.1 Acceptance для конференций/WebRTC (P43)

- 2+ участника в одной комнате видят друг друга (сетка тайлов), `peer_join/leave` фиксируются в логах.
- Демонстрация экрана видна всем участникам; завершение демонстрации автоматически возвращает камеру (если доступна).
- Клик по тайлу назначает «главный экран»; событие `main_changed` приходит всем; основное окно синхронно обновляется.
- Кнопки мастера: pause/resume/disconnect/kill — выполняются; после действия список комнат/сессий обновляется без перезагрузки страницы.
- Удаление комнаты завершает все WS‑соединения, очищает память/БД; комната исчезает из списка.
- Флаг `auto_resume` управляет допуском по прошлым сессиям: при включении — автодопуск, при выключении — только после explicit approve.

API проверки (PowerShell, заголовок `X-Telegram-User-ID: 468326902`):

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body (@{ commands='NET.SESSION.CREATE mode="cli" participants=["468326902"] TTL=120s WITH TRACE' } | ConvertTo-Json -Compress)

```

Критерии приёмки:

- Зеленые Health/DB/LLM/Dispatcher/Sanity/Refresh/Sleep.  
- В окне 24h — `svc.agent.net.*`; `CORE.PIPELINE.RUN ... WITH TRACE` выдаёт `signature_steps`.  
- Для stateless путей — `db=None`; greenlet_spawn=0; STRICT JSON на всех контрактах.  
- RBAC/Two‑Keys срабатывают для опасных команд.

## 10) Последовательность реализации (без заглушек)

- S1. Каркас NET.* в Hyperloop DSL (роутер/сервис), шаги подписи/метрики (P27), RBAC/Two‑Keys (P44).  
- S2. Transport Multiplexer: QUIC/WebRTC базово; метрики; CLI‑сессия.  
- S3. Ключевой контур: X3DH+Double Ratchet; эфемерные ключи; ротация.  
- S4. MLS для групп; WebRTC AV; адаптивный битрейт, NACK/PLI/FEC.  
- S5. Stealth Layer (ECH/TLS1.3/shape) и pluggable transports; профили P28.  
- S6. Overlay/VPN (WireGuard/Headscale), MP‑QUIC/MPTCP; split‑routing.  
- S7. UI (P23): экран «Связь/Сессии» с управлением NET.*; скрытая диагностика.  
- S8. Gendarme/Judge (P29) и инспекторы; финальные смоки и Acceptance.

### 10.1 Оставшиеся задачи

1) Мастер‑страница:

   - Добавить «Удалить комнату», «Автодопуск» (галка) и «Обновить» (ручной рефреш).
   - После действий (approve/deny/extend/rename/pause/resume/disconnect/kill/auto_resume) — автообновление списка.

2) Страница агента (`/agent/comm`):

   - Чат поверх сигналинга (`type=chat`).
   - Сетка тайлов с именами; клик по тайлу → `set_main`; отдельное «Основное окно» + Fullscreen.
   - Пошаговая отладка: текст → голос → видео.
   - Обработка отказов пермишенов: повтор/только микрофон/внешний браузер.

3) Nginx ws‑прокси: проверить `/api/ws/*` (Upgrade/Connection, таймауты ≥ 120s).

4) Метрики: агрегация WebRTC метрик в `agent_comm_logs` и экспорт в Prometheus.

5) Тесты (P24): e2e сценарии для chat/voice/video, выбор главного, disconnect/kill, auto_resume.

## 11) Риски и меры

- Детектируемость трафика: использовать ECH/shape/fronting (по политике) и ротацию маршрутов.  
- Латентность/джиттер: адаптивный битрейт, FEC+ARQ, приоритет аудио.  
- Ключевые компромиссы: короткий TTL сессий, пост‑компрометационная устойчивость.  
- Совместимость браузеров: graceful‑degradation на QUIC/SRT; fallback CLI‑данные.  
- Правовые ограничения: domain fronting/обход — включаются только при явной политике и Two‑Keys.

## 12) Обновления документации

- Включить документ в `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8_2.md` (P‑серия).  
- Добавить разделы/ссылки в `docs/PROJECT_STRUCTURE_v8_0_4.md` (акторы/DSL/метрики/приёмка).  
- Инспекторы: добавить `inspector.agent.net.coverage` в P27/P36.

— Конец спецификации P43.

## 13) Метрики/подпись/инспекторы (P27/P21/P29)

- Подпись шагов (P27): `svc.agent.net.session_create`, `svc.agent.net.transport_set`, `svc.agent.net.metrics`, `svc.agent.net.session_end`, `cmd.hyperloop.net.*`.
- Метрики (Prometheus/`/api/metrics`):
  - `net_active_sessions` — gauge
  - `net_latency_ms` — histogram {phase="data|audio|video"}
  - `net_packet_loss_ratio` — gauge
  - `net_failovers_total` — counter
  - `net_fec_overhead_ratio` — gauge
  - `net_errors_total` — counter {code}
- Инспекторы (P29/P36): `inspector.agent.net.coverage` (наличие шагов за 24h), `inspector.agent.net.slo` (проверка p95), `inspector.agent.net.guard` (RBAC/Two‑Keys соблюдены).

## 13.1 SLO‑профили и алерты (P21/P28)

- prod_safe:
  - SLO: data p95 ≤ 1200 ms, audio p95 ≤ 250 ms, video p95 ≤ 400 ms; failover < 3 s; error_rate < 1%.
  - Алерты: warning при превышении 80% SLO (960/200/320 ms), critical при нарушении SLO 3×/15 мин или error_rate ≥ 1%.
- rt_low_latency:
  - SLO: data p95 ≤ 600 ms, audio p95 ≤ 150 ms, video p95 ≤ 300 ms; failover < 2 s.
  - Алерты: warning 80% порог (480/120/240), critical при нарушении 3×/10 мин.
- stealth_aggressive:
  - SLO: data p95 ≤ 1500 ms, audio p95 ≤ 350 ms, video p95 ≤ 600 ms; failover < 4 s; detect_rate (DPI) ≤ целевого порога.
  - Алерты: warning при росте detect_rate, critical при превышении порога 2×/30 мин.
  - Примечание: повышение `fec_overhead_ratio` до 30% допустимо при активной обфускации.

## Приложение A — Отметки выполнения шагов (по заданной последовательности)

- Шаг 1. Критический анализ `Report_Soul_AI_Scientific.md` — выполнено (секции §1, §6, §8 интегрированы в P43).
- Шаг 2. Сбор best‑practices e2e/stealth/multipath/FEC — выполнено (учтены Double Ratchet/X3DH/MLS, ECH/TLS1.3/DoH/DoQ, MASQUE/OHTTP, obfs4/snowflake/meek, MP‑QUIC/MPTCP, RaptorQ/RS, WebRTC SFrame).
- Шаг 3. Общее ТЗ на систему канала связи — выполнено (этот документ, разделы §2–§11).
- Шаг 4. Анализ целостности и стыковки с Ядром Соул — выполнено (см. §6, §8, Acceptance §9).
- Шаг 5. Цикл сопоставления с P01…P44 — выполнено первично (см. Приложение B), детальная агрегация данных продолжается итеративно без регресса.
- Шаг 6. Детализация до уровня быстрой реализации без заглушек — выполнено (см. §10 «Последовательность реализации», §7 DSL, §9 смоки/приёмка).

## Приложение B — Сопоставление P01…P44 (влияния, риски, интеграции)

- P01 MeaningExtraction: влияние нулевое на формат канала; требования к STRICT_JSON неизменны; риск утечек — нет (канал транспортный).
- P02 MetaLoop/Introspection: диагностический канал скрыт; доступ к NET.* — только у ролей с Two‑Keys; логи без PII.
- P03 RouterContext: контекст канала не меняет политику модулей; Router решает только логические модули; NET.* вне роутара диалогов.
- P04 Hypothesis A/B: допускается A/B профилей транспорта/stealth через Hyperloop (NET.*) с метриками p95; Delivery Guard обязателен.
- P05 Och: тональные коррекции не касаются транспортного слоя; UI сообщения — санитизированы.
- P06 SelfConsistency: непричастно; однако отчёты о сбоях транспорта учитываются в рефлексии Processor.
- P07 DesiredAction: канальные действия (invite/end/set_transport) не являются пользовательскими DA; публикуются только через RBAC.
- P08 Privacy: ключи эфемерные, не пишутся на диск; трафик маскируется; минимизация экспозиции ICE/URL.
- P09 Security: Zero‑Trust, PoLP, ECH/TLS1.3; анти‑MITM за счёт e2e и динамической ротации ключей; Two‑Keys обязательны для опасных команд.
- P10 Schema Guard: изменения фасадов `/api/admin/net/*` и DSL `NET.*` описываются в схемах/контрактах; breaking‑детектор включён.
- P11 Provenance: шаги `svc.agent.net.*` и `cmd.hyperloop.net.*` сохраняются; трассы связаны с сессиями/итерациями.
- P12 TraceViewer: видимость шагов NET.* в `signature_steps`; UI фильтры по `svc.agent.net.*` и trace_id.
- P13 Eval: сценарии смоков по каналам (latency, packet loss tolerance, failover) добавлены в тест‑наборы.
- P14 Multi‑provider Routing: не затрагивает LLM; но профили провайдеров сети (QUIC/SRT/WebRTC) могут иметь флаги P28.
- P15 Multilingual: UI/подписи каналов локализованы; транспорт независим от языка.
- P16 Sleep/Memory: не взаимодействует напрямую; Processor может понижать приоритет NET событий при перегрузе.
- P17 Reminders/Search: каналы не влияют; уведомления о сессиях идут как события, без DA autopublish.
- P18 Voice ASR: AV‑сессии используют WebRTC/SRTP; ASR — локально после e2e расшифровки на клиенте/крае при политике.
- P19 Voice TTS: e2e поток аудио; битрейт/формат адаптивны; UI — кнопки Mute/Unmute, выбор голоса вне канала.
- P20 Telegram Bots: приглашения/ссылки — через RBAC/Two‑Keys; заголовок `X‑Telegram-User-ID` обязателен.
- P21 Health/Monitoring: новые метрики `net_*` (latency p95, loss, fec_overhead, failovers, active_sessions).
- P22 API Alignment: фасады `/api/admin/net/*` документированы; OpenAPI securitySchemes применены.
- P23 UI Rebuild/Frontman: экран «Связь/Сессии», минимализм; skeleton до ролей/разрешений; нет тех‑блоков в ответах.
- P24 Integrated Tests: смоки Hyperloop `NET.*`, нагрузочные с потерями 1–10%, инспектор покрытия событий.
- P25 Skills/Routes: не взаимодействует; канал транспортный.
- P26 Calendar/Transport: планирование совещаний — генерация приглашений через Two‑Keys; ссылки — TTL/одноразовые.
- P27 Signature/Lineage: обязательные шаги `svc.agent.net.*` и `cmd.hyperloop.*`; при отсутствии — блокировка Delivery Guard.
- P28 FeatureFlags: профили `net.prod_safe`, `net.rt_low_latency`, `net.stealth_aggressive`.
- P29 Quality (Gendarme/Judge): правила на отсутствие тех‑маркеров/секретов в видимом UI; блок без Two‑Keys.
- P30 Processor: события очереди `net.session.create|join|end|metrics`; инциденты на failover>3s, p95 превышения, ошибки RBAC.
- P31 Multisensory Quants: AV‑сигналы не сохраняются как кванты; метаданные сессии — в аудит/метриках.
- P32 RBAC/Subscriptions: роли `sysadmin|architect`; лимиты окон/egress; привязки пользователя по tg_id.
- P33 Personification: отображение активной персоны в углу UI сохраняется; канал не меняет голос/роль ядра.
- P34 External Chat Proxy: совместимо; WebRTC/QUIC предпочтительны; мобильные SDK — опциональны.
- P35 Processes: процессы Process Intelligence учитывают NET инциденты; интеграция мониторинга.
- P36 Hyperloop DSL: реализованы `NET.*`; `WITH TRACE` обязателен для критичных команд.
- P38 NeuroTraining: не затрагивает; обучающие метрики только агрегированы, без контента каналов.
- P39 Sensory Memory: не применимо к e2e каналам; запрещено сохранять содержимое AV.
- P40 Project Management: артефакты сессий как задачи/риски — по политике; нет контента каналов.
- P43 Этот документ: актор связи, каноника.
- P44 Roles & Authorization: Two‑Keys, default‑deny, PoLP; журнал отказов/разрешений.

## 14) RBAC матрица и Two‑Keys сценарии (P44)

- Роли и права (PEP→PDP):
  - architect: просмотр метрик/трасс NET.*, dry‑run команд; создание сессий в dev.
  - sysadmin: полный доступ к NET.*, управление маршрутами/VPN/STEALTH (с Two‑Keys на опасные).
  - user: участие в сессиях, без управления транспортом.
- Матрица команд:
  - NET.SESSION.CREATE/END — architect(dev), sysadmin(prod)
  - NET.TRANSPORT.SET — sysadmin (prod), architect(dev) — при prod_safe=0
  - NET.STEALTH.APPLY, NET.VPN.ROUTE.ADD — sysadmin + Two‑Keys
  - NET.METRICS — architect/sysadmin
- Two‑Keys (опасные действия):
  - Объект заявки: {request_id, actor, command, payload_hash, ttl, reason}
  - Поток: submit → approve(иной субъект) → execute; audit записывается с trace_id.
  - Отказ/таймаут → 409; повтор — по новому request_id.

## 15) Профили фич‑флагов (P28) и ENV

- Флаги P28:
  - net.prod_safe=1 — запрещены STEALTH/VPN/fronting без Two‑Keys; по умолчанию в PROD.
  - net.rt_low_latency=0|1 — агрессивные таймауты/битрейт для аудио.
  - net.stealth_aggressive=0|1 — padding/jitter/obfs включены.
- ENV (примеры):
  - NET_DEFAULT_TTL=600
  - NET_ALLOWED_TRANSPORTS=quic,webrtc,srt,rist
  - NET_STEALTH_PROFILES=ech+http3+padding,none
  - NET_FEC_DEFAULT=raptorq:rate=20%
  - NET_MAX_FAILOVER_SECONDS=3

## 16) Ранбук: деплой/траблшутинг

- Деплой:
  - Обновить .env.prod переменными NET_*; перезапуск `soulpulse-backend.service`.
  - Проверить `/api/health`, затем смоки §9 (NET.*).
- Nginx/systemd:
  - Убедиться в `proxy_read_timeout=120s` и `proxy_send_timeout=120s`.
  - Логи `journalctl -u soulpulse-backend.service -n 200` — нет ошибок NET.*.
- Траблшутинг:
  - Ошибка RBAC/Two‑Keys → сверить роль/заявку; повторить approve.
  - Высокий p95 latency → снизить битрейт, включить FEC/ARQ, сменить транспорт на QUIC/WebRTC.
  - Блокировки сети/цензуры → применить ECH/DoH/DoQ, obfs4/snowflake; при политике — MASQUE/OHTTP.
  - Потери >10% → повысить FEC rate, включить multipath.

## 17) Угрозы/квоты/ретенция/тест‑план/дашборд

- Модель угроз:
  - MITM на уровне сигналинга/ICE — смягчение: e2e (SFrame/Double Ratchet), ECH/TLS1.3; минимизация экспозиции ICE.
  - DPI/блокировка UDP — смягчение: QUIC fallback→HTTP/3, obfs4/snowflake, MASQUE поверх HTTPS.
  - Кража ключей с узла — смягчение: эфемерные ключи в памяти, короткий TTL, post‑compromise safety (Double Ratchet/MLS).
  - Traffic analysis — смягчение: padding/time‑jitter, мультипас/эхо/зеркалирование по профилю.
- Квоты/лимиты:
  - `net.sessions.max_per_user`, `net.sessions.max_participants`, `net.bandwidth.max_kbps`, `net.failovers.max_per_hour` — настраиваются через P28/Settings.
- Ретенция/логи:
  - Содержимое AV/данных не сохраняется. Хранятся только агрегаты метрик и подписи шагов (`trace_id`, коды ошибок, p95). TTL логов — по политике (например, 7–30 дней).
- Тест‑план (P24/P36):
  - Функциональные: CREATE/JOIN/END, TRANSPORT.SET, STEALTH.APPLY (deny без Two‑Keys), VPN.ROUTE.ADD (deny/allow), METRICS.
  - Нагрузочные/устойчивость: потери 1/5/10%, джиттер, failover < 3s, p95 цели.
  - Обход: блокировка UDP/443 — проверка fallback на HTTP/3/MASQUE/SSH reverse.
  - Безопасность: отсутствие тех‑маркеров в UI, отсутствие PII в логах, RBAC/Two‑Keys сценарии.
- Дашборд (P21):
  - Карточки: Active sessions, p95 latency (data/audio/video), packet loss, failovers, errors by code, FEC overhead.
  - Фильтры: по профилю (prod_safe/rt_low_latency/stealth_aggressive), по транспорту, по региону.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
