# P20 — Пошаговая реализация и контроль (Implementation Playbook, v1.1)

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — актуальные инвентари документов.
- `tmp_p_series_plan.json` — план анализа P‑серии (сверка дублей/версий/приоритетов).
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр документов.
- `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`, `Soul/P30_TZ_Soul_Processor_v2_0.md`, `Soul/P36_TZ_Hyperloop_DSL_v1_1.md` — ключевые интеграции подписи/процессора/DSL.

Статус: готово к реализации (детальный план)
Консолидация: базовая версия — этот документ (v1.1); источники v1.0/Platform см. раздел «Consolidation» ниже.

Ссылки (реализация и спецификации):

- OpenAPI (P20): `docs/openapi-p20-telegram-bots.yaml`
- Backend: `backend/app/telegram.py`, `backend/app/telegram_phi.py`, `backend/app/main.py` (маршруты `/webhook/telegram`, `/webhook/telegram/phi`)
- Проектная структура: `docs/PROJECT_STRUCTURE.md`
- Мастер‑реестр: `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md`
- Аналитический отчёт: `Soul/Report_Soul_AI_Scientific.md` (разделы P20/P30/P27/P28/P36)

## Объекты и файлы (точки изменений)

- Backend (Python):
  - `backend/app/main.py` — вебхуки `/webhook/telegram`, `/webhook/telegram/phi`, health.
  - `backend/app/telegram.py`, `backend/app/telegram_phi.py` — intake/ветки, callback/typing.
  - `backend/app/services/chat_service.py` — чат‑пайплайн, Delivery Guard, кванты/desired_action, фоновые этапы.
  - `backend/app/services/reminder_service.py` — создание/планирование напоминаний, dedup.
  - `backend/app/services/llm_client.py` — провайдеры/таймауты/кэш‑ключи, Aux health.
  - `backend/app/services/soul_settings_service.py` — ключи БД (webhook_url, pools, aux/phi, QoS).
  - `backend/app/services/processor_scheduler.py` — WRR/lanes, retry/backoff, quarantine.
  - `backend/app/routers/rs_actors.py` — `phi.chat.incoming.*`, подписи.
  - `backend/app/middleware/rbac_middleware.py` — `require_role_or_higher|require_permission`.
- Nginx: `/etc/nginx/sites-enabled/03-mini_soulpulse.conf` — `location` для `/webhook/telegram` и `/webhook/telegram/phi`.
- Docs: обновление `docs/PROJECT_STRUCTURE_v*`, `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md`.

## Пошаговая реализация (минимальные риск‑шаги)

- Шаг A (конфиги/ключи — безопасно):
  - Добавить в БД ключи: `bot.phi.webhook_url`, `phi.webhook.require_secret`, `telegram.phi.secret_token` (или Secrets `bot.secret.soul_phi`), `comm.fallback.db_enabled` (false), пулы `db.pool.{system|processor|llm|chat}.*`.
  - QoS kinds: `processor.kind_priority.*`, `processor.kind_limits.*`, `processor.kind_retry.*` для `phi.chat.incoming.*` и due‑классов.
- Шаг B (Nginx):
  - Вставить `location = /webhook/telegram/phi { proxy_pass http://127.0.0.1:8000/webhook/telegram/phi; }`; убедиться в единственном `server_name`; `nginx -t && systemctl reload nginx`.
- Шаг C (webhook/секреты):
  - `main.py` — фолбэк матчинга секрета Phi: `telegram.phi.secret_token` → `bot.secret.soul_phi`.
  - Строгий режим: учитывать `phi.webhook.require_secret` для `/webhook/telegram/phi`.
- Шаг D (изолированность веток):
  - В `/api/chat/threads*` добавить фильтр `(ChatThread.type IS NULL OR ChatThread.type != 'phi_chat')`; отдельные админ‑просмотры — по `type=phi_chat`.
- Шаг E (оркестратор токенов):
  - В `telegram_phi.py` и/или оркестраторе: при `phi_chat` всегда использовать токен Phi для `answerCallbackQuery` и `sendChatAction`.
- Шаг F (наблюдаемость/метрики):
  - Добавить `llm_aux_req_total|err_total|latency_ms`, `orch_sent_total{mode,status}`, `webhook_phi_drop{reason}`; Алёрты/панели.
- Шаг G (Aux health фолбэк):
  - `GET /api/aux-llm/health` — позволить ENV `LLM_AUX_API_URL`, если БД недоступна/ключ пуст; статус 200 при живом сервисе.
- Шаг H (Telegram backoff/429):
  - Экспоненциальный backoff, троттлинг, `drop_pending_updates` при `setWebhook`.
- Шаг I (RBAC/безопасность):
  - Явно отметить `soul.admin` для админ‑эндпойнтов (typing/webhook инспектора); маска PII.
- Шаг J (Processor/pools):
  - Обновить WRR/lanes; включить раздельные пулы; acceptance на TooManyConnections.

## Интеграции — контрольный список

- Nginx: единый `server_name`, `location` для обоих вебхуков; reload ok.
- RBAC: маршруты с `require_permission|require_role_or_higher`, без try/except импортов.
- RS: `comm.incoming.phi.{mtype}`; акторы `phi.chat.incoming.*` активны.
- DB pools: `db.pool.system|processor|llm|chat` настроены; чат не starving критичные.
- Aux: `llm.phi.*`, `llm.aux.*`; health с ENV фолбэком.

## Инспектор‑тесты (передаваемые на контроль)

- Guard canonical: отсутствуют хардкоды URL/портов/доменов в исходниках (кроме docs/примеров).
- Planning: `INSPECTOR.RUN key=planning.enforce` — ок; ветка/сессия заявлены/закрыты.
- Delivery Guard: наличие шагов `svc.llm_client.send/recv`, `svc.chat.reply_render` в трейсе чата.
- Processor: `GET /api/admin/soul/processor/metrics` — очередь в допустимых пределах; due‑классы не копятся.
- Phi/Aux: метрики `llm_aux_*` присутствуют; `webhook_phi_drop{reason}` фиксируется при bad_secret.
- Mini‑App API: фильтрация `phi_chat` подтверждена выборкой.
- Nginx: `nginx -t` — зелёный.

## Внедрение (rollout) и откат

- Фичефлаги: `phi.webhook.require_secret`, `comm.fallback.db_enabled`, ключи QoS kinds; поэтапное включение.
- Canary: включать `location` для Phi и фолбэк секрета по одному инстансу; наблюдать p95/err_rate.
- Откат: отключить строгий секрет, выключить `location /webhook/telegram/phi`, вернуть прежний матч.

## Настройки и сид‑данные

- Установить значения по умолчанию (БД):
  - `phi.webhook.require_secret=false`, `comm.fallback.db_enabled=false`.
  - QoS kinds: приоритет/лимиты для `phi.chat.incoming.text` и due‑видов.
  - Пулы: `db.pool.system.*=резерв`, `db.pool.processor.*=средний`, `db.pool.llm.*=ограниченный`, `db.pool.chat.*=общий`.
- Секреты/URL: `bot.secret.soul_phi`, при необходимости `telegram.phi.secret_token`, `bot.phi.webhook_url`.

## Приёмка (успех/негатив)

- Успех: `//пхи` → ACK и лог, `current_chat_mode='phi_chat'`; inline‑кнопка через токен Phi; `typing` — Phi; Mini‑App без `phi_chat`; health Aux 200 с ENV фолбэком; Nginx ok; метрики/алерты обновлены.
- Негатив: неверный секрет → soft‑ACK и `webhook_phi_drop{reason=bad_secret}`; пик чата → без TooManyConnections, due не стагнируют.

---

## Consolidation (merge notes)

- Источники для слияния (архив):
  - `Archive/CLEANUP_20251009_005735/duplicates/P20_TZ_Telegram_Bot_Orchestrator_and_E2E_Dataflow_v1_0.md`
  - `Archive/CLEANUP_20251009_005735/duplicates/P20_TZ_Soul_TelegramBots_Platform_v1_0.md`
- Принятые решения:
  - Базовая версия — v1.1; v1.0/Platform используются как уточнения/примеры.
  - Разделы Platform (SDK/админ‑панель/потоки, см. P20 Platform §§1.2,1.3,1.4,1.8,3–5) интегрированы; дубли удалены.
  - Ссылки на P14/P27/P30/P42/P51 выровнены с актуальной реализацией и ключами БД (каноника настроек/секретов подтверждена `guard.canonical.urls`).
  - Навигация: реестр обновлён в `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` (раздел «Нормализация документации — Repo Cleanup (P54)»); архивы оставлены ссылочными).

 
## Мировые аналоги и практики
- Telegram Bot API — вебхуки и обновления: [Webhook Mode](https://core.telegram.org/bots/api#setwebhook)
- Best practices вебхуков (OWASP): [API Security Guidelines](https://owasp.org/www-project-api-security/)
- Nginx reverse‑proxy и бэкенд‑таймауты: [Nginx Proxying](https://nginx.org/en/docs/http/ngx_http_proxy_module.html)
- Очереди задач и backpressure: [Redis Streams](https://redis.io/docs/latest/develop/data-types/streams/), [RabbitMQ Patterns](https://www.rabbitmq.com/tutorials/)
- Идемпотентность запросов (ключи): [Idempotency Keys — Stripe](https://stripe.com/docs/idempotency)
- Rate limiting/троттлинг: [Token Bucket (IETF)](https://www.rfc-editor.org/rfc/rfc970)
