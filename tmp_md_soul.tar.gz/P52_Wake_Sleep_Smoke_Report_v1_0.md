# P52 — Smoke Report: Wakefulness / Sleep / Maintenance / Wake Warmup v1.0

Статус: все смоки пройдены; цепочка подписи полная; инспекторы зелёные.

## 1) Бодрствование (Wake warmup)

- Команда: `CORE.PIPELINE.RUN input_text="wake warmup" WITH TRACE`
- Ожидание: шаги `svc.soul.preanalysis, svc.llm_client.send/recv, svc.soul.router_decide, svc.parser.json_strict, svc.chat.reply_render`
- Результат: ok; `trace_id` зафиксирован; шаги подписи сохранены.

## 2) Инспекторы (Guard/Signature/SLA)

- Команда: `INSPECTOR.RUN_ALL`
- Ожидание: `signature.required_steps.consistency=passed`, `guard.delivery.enforceable=passed`, `incident.sla_enforcement=passed`
- Результат: passed (non‑blocking: `incident.required_steps` предупреждение о пост‑морем — вне области данного смока)

## 3) Сон (Maintenance Safe)

- Флаги:
  - `FLAGS.SET key=sleep.maintenance.enabled value=true`
  - `FLAGS.SET key=sleep.maintenance.interval_minutes value=180`
  - `FLAGS.SET key=sleep.maintenance.duration_minutes value=5`
- Планировщик: `ProcessorScheduler` (авто‑триггер safe‑sleep)
- Метрики: пишет `sleep.maintenance.triggered{mode=auto}` и запись инсайта `maintenance_integrity` в `processor_incidents` (best-effort)
- Результат: ok, инспекторы зелёные после окна

## 4) Просыпание (Wake readiness)

- Опционально повторить warmup: `CORE.PIPELINE.RUN input_text="wake warmup" WITH TRACE`
- Ожидание: RT готов; подпись полная

## 5) Усталость (инжект)

- Надёжный формат: `PROCESSOR.EVENT.INJECT kind=fatigue_check payload_json="{\"observe_window\":\"3m\"}"`
- Однократная обработка: `PROCESSOR.PROCESS_ONCE`
- Ожидание: событие обработано; метрики доступны; Guard/Signature — ок

## Приложение A — Мини‑скрипт PowerShell (PROD API)

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
$B=@{ commands='CORE.PIPELINE.RUN input_text="wake warmup" WITH TRACE' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

$B=@{ commands='INSPECTOR.RUN_ALL' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

$B=@{ commands='FLAGS.SET key=sleep.maintenance.enabled value=true' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

```

## Приложение B — Контрольные acceptance‑критерии

- Полная цепочка подписи присутствует перед видимыми ответами
- Инспекторы Guard/Signature — зелёные
- Maintenance‑сон работает по расписанию; Integrity инсайт сохранён
- Инжект усталости и процессинг — ok; метрики доступны


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
