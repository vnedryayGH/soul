# PROJECT AI AUTOPILOT v2.30

Назначение: проектный промпт (самодостаточный) с обновлённой политикой исполнения запросов: ОБЯЗАТЕЛЬНО использовать Soul Hyperloop CLI для всех DSL/операций управления. Без статусов/историй.

## Инварианты

- STRICT JSON; перед любой видимой выдачей — Delivery Guard (P27) с полной цепочкой подписи.
- Все операции выполняются через БД и Hyperloop DSL (P36). Локальные JSON не являются источником истины.
- Активная ветка обязательна (P40 §2.1); зеркалирование действий через `LLM.MIRROR(.BATCH)` приветствуется.

## Канал и командная строка Соул (обязательно)

- Используется строго канал Soul Hyperloop (PROD API: `https://mini.soulpulse.art/api`) и командная строка Соул — `python Soul/scripts/hyperloop_cli.py`. Все действия агента выполняются через этот CLI. Прямые `curl/Invoke-RestMethod` допускаются только как Fallback.

## Канонический способ выполнения запросов (mandatory, без PowerShell‑прелюдий)

- Primary: Soul Hyperloop CLI (устойчив к кавычкам/заголовкам)
  - Префлайт: `python .\\Soul\\scripts\\hyperloop_cli.py --preflight`
  - CLAIM: `python .\\Soul\\scripts\\hyperloop_cli.py --claim-branch --owner 468326902 --branch <branch> --topic <topic> --session <sid>`
  - RELEASE: `python .\\Soul\\scripts\\hyperloop_cli.py --release-branch --owner 468326902 --branch <branch> --session <sid>`
  - CONNECT: `python .\\Soul\\scripts\\hyperloop_cli.py --connect --owner 468326902 --branch <branch>`
  - PING: `python .\\Soul\\scripts\\hyperloop_cli.py --ping --owner 468326902 --session <sid>`
  - DSL: `python .\\Soul\\scripts\\hyperloop_cli.py --dsl 'INSPECTOR.RUN key=planning.enforce'`
  - GET: `python .\\Soul\\scripts\\hyperloop_cli.py --http-get https://mini.soulpulse.art/api/health`

- Fallback 1: PowerShell `Invoke-RestMethod` (только при деградации CLI; канал Soul обязателен; не требуется никакой предварительной инициализации PowerShell)
  - `$H=@{ 'X-Telegram-User-ID'='468326902' }`
  - `$B=@{ commands='PROJECT.LIST' } | ConvertTo-Json -Compress`
  - `Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B`

- Fallback 2: файл + `curl.exe --data-binary` (устойчив к кавычкам; канал Soul обязателен)
### Автоматическое обеспечение каналов (ChannelAgent)

- Управление каналами через DSL:
  - `CHANNEL.AGENT.ENABLE enabled=true|false` — включает/выключает агента (читает/пишет БД `channel_agent.enabled`).
  - `CHANNEL.AGENT.UNITS.SET units=["soul-tunnel-5433.service","soulpulse-backend.service"]` — регистрирует список управляемых systemd‑юнитов.
  - `CHANNEL.START unit=<systemd_unit>` / `CHANNEL.STOP unit=<systemd_unit>` — ручной старт/стоп.
  - `CHANNEL.SMOKE` — смок проверки активности зарегистрированных юнитов.

- Инвариант: агент работает только на APP‑серверах и использует `systemd`; адреса/порты берутся из БД.
  - `'{ "commands": "CORE.PIPELINE.RUN input_text=\"health check\" WITH TRACE" }' | Set-Content -Path tmp_body.json -Encoding UTF8 -NoNewline`
  - `curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -H "Content-Type: application/json" --data-binary "@tmp_body.json" https://mini.soulpulse.art/api/hyperloop/execute`

## First‑Try Success (обновлённая политика)

- Порядок: Primary CLI → Fallback IRM → Fallback curl‑file. Не более 2 попыток суммарно.
- Все ошибки классифицируются инцидентами (P50): `quotes_error|header_missing|url_malformed|timeout|auth_forbidden|other`.

## Минимум для проектов/планирования (P40)

- `PROJECT.LIST`
- `PROJECT.CREATE name="..." methodology=hybrid priority=0.8 owner=468326902`
- `PLAN.TASK.ADD project_id=<PID> title="CPM расчёт" cpm_duration_days=2.5`
- `PLAN.CPM.CALC project_id=<PID> WITH TRACE`

## Наблюдаемость/Приёмка

- Инспектора: `INSPECTOR.RUN_ALL` зелёный; `planning.enforce` — без нарушений.
- Hyperloop ответы включают `trace_id`, `signature_steps`; счётчики DevConnect публикуются.

### Политика алертов (понятность и действия)

- Все алерты должны быть понятны (human‑readable), содержать уровень риска (`severity`/`risk`) и явные рекомендации/действия для оператора.
- Формат аннотаций: `summary` — кратко что сломалось; `description` — почему это плохо и что делать (шаги).
- Пример: `AgeSyncLagCritical` — риск high, действия: снизить load, проверить Postgres (locks/WAL/disk), эскалировать P50.

## Безопасность

- RBAC (P44), Two‑Keys на опасные DSL.
- Секреты только из PROD ENV; PII не логируется.
