---

## Индекс взаимных ссылок (P01–P46)
- P21 Health/Monitoring — метрики очереди/исполнения.
- P27 Signature/Lineage — подпись событий/шагов.
- P28 FeatureFlags — управление поведением.
- P33 Personification — Mini Chat события (§svc→task/reminder).
- P35 Processes Unified — процессные цепочки поверх процессора.
- P36 Hyperloop DSL — инжекция/обработка событий.
- P45 Quant Generation Modes — офлайн и пакетная генерация квантов, JSONL→SQL/Hyperloop, связи с планом/целями (plan_update/goal_assess).
 - P46 NeuroIntegrity — управляющий контур запуска нейроцелостности (Sleep/Batch), инспекторы и корректирующие действия
# P30 — ТЗ: Процессор Ядра Соул (Real‑time Orchestrated Thinking)

Версия: v1.1 (ready→MVP)
Ответственность: Архитектор ядра / Оркестратор
Статус: Готов к внедрению MVP; интеграция P27/P36/P28/P29 — активный роллаут

## 0) Executive summary

Цель: дать «спинному мозгу» Соул непрерывный мыслительный процесс в реальном времени, который:

- Инициирует рождение Квантов реактивно (события/триггеры) и проактивно (повестка/цели).
- Добивается обратной связи по каждому значимому действию (feedback‑seeking invariant).
- Управляет всем ядром на макроуровне: Дирижёр (процессы), Матерь флагов (режимы), Отец санитайзеров (чистота и безопасность), Жандарм, Архивариус, Судья...
- Интегрирован с P27 (подпись/трассировка), P28 (флаги), P29 (качество), P16 (Sleep), P23 (UI), P24 (тесты), P21 (health), P14 (multi‑provider), P20 (боты).

Результат: непрерывная петля Perceive→Appraise→Agenda→Plan→Act→Observe→Learn, производящая релевантные Кванты и действия с подтверждаемой линией происхождения (Signature v1), метриками качества и защитами.

## 1) Мотивация и принципы

- Автономность поверх внешних LLM: Процессор — мозжечок/спинной мозг, LLM — кора/ресурсы. Процессор всегда живёт, LLM подключается по необходимости/бюджету.
- Обратная связь обязательна: если нет feedback, Процессор ищет её, эскалирует, меняет стратегию или ставит элемент в отсрочку с меткой риска.
- Инварианты безопасности/этики/негатива (NEGATIVE) — не нарушаются процессом.
- Прозрачность: каждый шаг подписан (P27), наблюдаем (P21), подчинён политикам (P28/P29), виден в UI (P23).

## 2) Термины и роли

- Процессор: главный цикл принятия микрорешений и запуска действий.
- Дирижёр: планировщик/оркестратор запусков процессов ядра (сканеры/оптимизаторы/синтезаторы).
- Матерь флагов: менеджер режимов/feature‑flags/политик (P28), профилей эксплуатации и деградаций.
- Отец санитайзеров: хозяин NEGATIVE/санитайзеров/редактуры; гарант чистого пользовательского текста.
- Агенда: упорядоченный список текущих задач/триггеров/целей с приоритетами и бюджетами.
- Жандарм: оркестратор тестов качества, запуск `TEST.RUN`, запись результатов в `test_results` (P29).
- Судья: уставы/политики, `JUDGE.CHARTER.UPSERT`/`JUDGE.CHECK`, инциденты `charter_incidents` (P29).
- Архивариус: заявки/запросы сервиса, `REQUEST.CREATE/STATUS/LIST`, хранение `service_requests` (P29/P36).

## 3) Архитектура (высокий уровень)

Событийная петля (event‑driven):

- Источники событий: входящие сообщения, напоминания/календарь, инциденты/алерты, состояние целей, расписания, системные сигналы.
- Очередь событий: in‑memory + durable (postgres jsonb) буфер «processor_events» с дедупликацией.
- Оценка (appraisal): быстрые правила приоритета/срочности/риска; бюджет времени/LLM.
- Агенда (agenda manager): сортировка, дедлайны, тайм‑слайсинг, вытеснение; частично предвычисляемая.
- Планирование (planner): выбор тактики: локальная эвристика, вызов LLM‑планировщика, воспроизведение шаблонов.
- Исполнитель (effectors): запуск шагов ядра (LLMCore, Sleep, Reminders, Router, Seeker, Delivery Guard и т.п.).
- Наблюдение (observer): сбор обратной связи/метрик/инцидентов; закрытие петли.

Интеграции (обязательные):

- P27: каждый шаг `svc.processor.*` подписан; Delivery Guard применяется для ответов.
- P28: флаги и профили режимов; централизованные политики включения/ограничения.
- P29: качественные гейты/оценки для выпускаемых Квантов/ответов.
- P16: ночные/периодические оптимизации (Sleep v2) под дирижированием.
- P23: UI панель «Процессор»: статус, очередь, последние решения, ручные триггеры.
- P24: интеграционные цепочки и дымовые тесты «после деплоя».

## 4) Алгоритмическая петля (микро‑уровень)

Шаги (на событие):

1) perceive: собрать минимальные факты/контекст; метки риска/цели.
2) appraise: оценить приоритет/срочность/бюджет; проверить политики (P28/P29).
3) decide: выбрать тактику: эвристика/LLM/шаблон; назначить профили/модели. Ответ ЛЛМ и исполнение квант‑пайплайна допускают параллелизм: ЛЛМ отвечает в своём окне, квант‑пайплайн формирует структуру/валидацию и готовит Persist/Guard; синхронизация перед публикацией выполняется Delivery Guard (P27). Дополнительный подключаемый шаг «Voice Delivery» может быть включён политикой канала.
4) act: выполнить один атомарный шаг (например, параллельно с ожиданием ЛЛМ запустить подготовку квант‑структуры/контролей; вызвать SoulCore для рождения Квантов; отправить уведомление; обновить цель).
5) observe: дождаться подтверждения/результата; при отсутствии — ретрай/эскалация/отсрочка.
6) learn: обновить метрики/политики; записать инциденты/успехи.

Каждый шаг добавляет `signature.step` с `function_id=svc.processor.<stage>`.

## 5) Политики и инварианты

- feedback_required: для классов действий A/B/C обязательна обратная связь за ≤ T секунд; иначе эскалация (N попыток, затем инцидент).
- circuit_breakers: блоки при росте ошибок/латентности; перевод в деградацию (fallback/блок некоторых модулей).
- autopublish_policies: что можно публиковать без ручной верификации; two‑keys для чувствительных действий.
- delivery_guard_enforce=true: выпуск ответа только при наличии всех обязательных подпроцессов. Ошибкой считается только пустой ответ после попытки фоллбэка DeepSeek (при наличии маршрутов), иначе фиксируется инцидент и проводится деградация, но цикл не рушится.
- sanitizer_enforce=true: пользовательский текст очищён от тех‑блоков, ролей, внутренних маркеров.

## 6) Схемы хранения (PostgreSQL, JSONB)

- processor_runs(id, started_at, finished_at, status, agenda_snapshot jsonb, metrics jsonb, created_by)
- processor_events(id, kind, payload jsonb, dedup_key, priority, due_at, status, retries, created_at)
- processor_incidents(id, run_id?, event_id?, type, detail, created_at)
- processor_policies(id, key, value jsonb, updated_at)

Индексы: по `kind`, `priority`, `due_at`, `status`, `dedup_key` (btree/hash), GIN по `payload`.

## 7) SDK/подпись (P27)

Требуемые шаги подписи для выпускаемого ответа (видимый ответ пользователю):
`svc.processor.perceive → svc.processor.decide → svc.soul.preanalysis → svc.soul.router_decide → svc.llm_client.send → svc.llm_client.recv → svc.parser.json_strict → svc.chat.reply_render → (опц.) svc.persist.*`
Delivery Guard (P27) блокирует публикацию при отсутствии обязательной цепочки шагов.

Отдельные шаги для служебных процессов (Sleep/Seeker/Reminder/GoalUpdater) фиксируются как `svc.processor.act/<name>`.

## 8) API/Админ (OpenAPI фрагменты)

GET `/api/admin/soul/processor/status` → { active:boolean, queue:int, last_run:{id,started_at,status}, mode:{profile,flags} }

POST `/api/admin/soul/processor/start` → запускает фоновый цикл (RBAC: architect)

POST `/api/admin/soul/processor/stop` → мягкая остановка (RBAC: architect)

GET `/api/admin/soul/processor/agenda` → список топ‑N задач (RBAC)

POST `/api/admin/soul/processor/event` { kind, payload, priority?, due_at? } → инъекция события (RBAC)

GET `/api/admin/soul/processor/runs` → последние M запусков и метрики

GET `/api/admin/soul/processor/incidents` → последние инциденты

Заголовок: `X-Telegram-User-ID` обязателен. Аудит всех действий.

## 9) Фичефлаги/ENV (P28)

- `PROCESSOR_ENABLED=1`
- `PROCESSOR_PROFILE=prod|canary|dev`
- `PROCESSOR_MAX_QPS`, `PROCESSOR_MAX_LATENCY_MS`
- `DELIVERY_GUARD_ENFORCE=1`, `SIGNATURE_ENABLED=1`, `DIAGNOSTIC_VISIBLE_REPLY=0`
- Надёжность обработки: `processor.max_retries` (int, по умолчанию 3), `processor.backoff_base_sec` (int, по умолчанию 10)
- Политики: в БД (`processor_policies`), ENV — дефолты.
- Опциональный сервисный LLM в анализе: `keyword_analysis.use_llm` (bool), `keyword_analysis.provider` (string), `keyword_analysis.timeout_ms` (int), `keyword_analysis.retries` (int)

## 10) Метрики/наблюдаемость (P21)

- Счётчики: `processor.events_in/processed/failed`, `processor.queue_len`, `processor.runs_ok/failed`, `processor.incidents{type,kind}`.
- Латентности: p50/p95 по стадиям perceive/decide/act/observe; e2e `processor.time_send_to_recv_ms{kind}`.
- Качество/Guard: `processor.guard_chain_pass_rate{kind}`; coverage подписи `processor.coverage_signature_percent{kind}`.
- Алерты: рост `delivery_guard_failed`, рост p95, нет feedback > T, рост очереди > N, частые `dead_letter`/`act_error`.

## 11) Тест‑план (P24)

- Integration: сценарии триггеров (входящее сообщение, напоминание, инцидент), выпуск ответов с подписью и guard.
- E2E: автозапуск smoke‑цепочек после деплоя; проверка UI панелей статуса/агенды.
- Scenario QA: отсутствие обратной связи → ретраи/эскалация; деградация LLM → переключение профиля провайдера (P14).

## 12) Безопасность/этика (P09/P08)

- RBAC на админ‑операции; аудит всех API; rate limit инъекций событий.
- Санитайзеры обязательны; privacy‑маскирование чувствительных данных в payload событий.

## 13) Rollout/Prod runbook

Каталоги PROD:

- Backend: `/var/www/soulpulse/backend`
- Systemd unit: `soulpulse-backend.service`

Шаги:

1) Деплой backend; миграции Alembic (таблицы processor_*).
2) Включить флаги: `PROCESSOR_ENABLED=1`, `DELIVERY_GUARD_ENFORCE=1`, `DIAGNOSTIC_VISIBLE_REPLY=0`.
3) Smoke: `GET /api/admin/soul/processor/status`, инъекция тест‑события, проверка рождённого Кванта и подписи.
4) Наблюдаемость: дашборды p95/очередь/инциденты; алерты.

Откат:

- `PROCESSOR_ENABLED=0`; `alembic downgrade -1` для последних изменений схем (если нужно); контрольная дымовая проверка UI/API.

## 14) Риски и митигирование

- Вихрь событий/рост очереди → бэк‑прешер, квотирование, пауза второстепенных задач, приоритет критичных.
- Отсутствие обратной связи → ограниченные ретраи, эскалация/инцидент, переработка тактики.
- Деградация LLM/внешних API → профиль `canary/dev`, переключение провайдера, упрощённая тактика (эвристики/шаблоны).

## 15) Связь с мировым опытом и принятыми правилами

- Blackboard/agenda‑based agents, event‑loop FSM (операционные агенты, AutoGen/LangGraph/LlamaIndex Agents) — подход к закрытым петлям.
- ReAct/Reflexion — планирование и самооценка; guardrails/policy‑as‑code для безопасного выпуска.
- Control‑theory loops (observe‑orient‑decide‑act) — инвариант обратной связи.
- Проектные правила соблюдены: STRICT_JSON, NEGATIVE, RBAC, без хардкода, централизованные настройки/ENV, batch/stateless.

## 16) Мысли и ключевые выводы (для ядра)

- Процессор — минимально достаточный автономный контур, делающий Соул «живым» между вызовами LLM и во время них.
- Инвариант обратной связи — критический: он делает поведение обучаемым и надёжным, а не «однонаправленным».
- Подпись P27 превращает Процессор в проверяемую систему: каждая мысль/действие обретают происхождение и ответственность.
- Следующие шаги: маленькая реализация v0 (события чата/напоминаний), затем расширение на инциденты/оптимизации.

---

## 17) Интеграция с P36 (Hyperloop DSL) — управляющий контур

- Процессор предоставляет и потребляет команды Hyperloop как единый «control plane» ядра:
  - `CORE.PIPELINE.RUN` — запуск статлесс‑цепочки ядра с возвратом `trace_id` и краткого результата.
  - `CORE.TRACE.REQUIRE` — проверка обязательной цепочки шагов (P27 Delivery Guard) перед публикацией.
  - `FLAGS.*`/`SANITIZER.*` — управление профилями режимов и санитайзерами (P28), применяемыми Процессором.
  - `TEST.*`/`JUDGE.*`/`REQUEST.*` — интеграция с P29 (Жандарм/Судья/Архивариус) для проверки/оркестрации качества и согласований.
- `REQUEST.*` связывает события Процессора и служебные процессы (эскалации, ручные подтверждения) через Архивариуса.
- Требования безопасности: RBAC (`architect|soul.admin`), Two‑Keys для опасных операций; все команды порождают шаги подписи `cmd.hyperloop.*` (P27).
- Acceptance: `POST /api/hyperloop/execute` выполняет ≥10 сценариев, в ответе возвращается `trace_id`, шаги сохраняются в `signature_steps`.

## 18) Карта влияния на номерные ТЗ (алгоритмы и действия)

- P01 MeaningExtraction: Процессор триггерит preanalysis для оценки повестки; задача P01 — экспорт быстрой эвристики приоритета.
- P03 RouterContext: Процессор учитывает контексты маршрутизации; задача P03 — стабильный контракт «веток» для agenda.
- P07 DesiredAction: Процессор закрывает петлю observe→learn по действиям; задача P07 — статусы и обратная связь в `quant_desired_actions`.
- P10 SchemaGuard: снапшот схем подписи/процессорных таблиц в CI; задача P10 — правила и гейт на расхождения.
- P14 Multi‑provider: переключение профилей провайдеров при деградации; задача P14 — API быстрого свитча и лимитов.
- P16 Sleep v2: расписания ночных/периодических шагов под дирижированием; задача P16 — сигналы готовности/окна обслуживания.
- P17 Reminders: события напоминаний как вход очереди; задача P17 — idempotent‑события и статусы исполнения.
  - ReminderActor: обработка kind=reminder через Actor (обогащение → генерация → доставка), шаги подписи `svc.reminder.*`, инспектор `reminder.actor.coverage`.
- P20 Bots Platform: события чатов/инбокса; задача P20 — чёткие фасады `/api/soul/process` и аудит источника.
- P21 Health: метрики/алерты цикла; задача P21 — панели p95/очередь/инциденты для Процессора.
- P22 API Alignment: админ‑эндпоинты Процессора; задача P22 — спецификация и RBAC/Headers.
- P23 UI Rebuild: раздел «Процессор» на панели Архитектора; задача P23 — виджеты очереди/решений/инцидентов.
- P24 Tests/Monitoring: интеграционные/дымовые цепочки «после деплоя»; задача P24 — сценарии feedback‑инварианта и guard.
- P27 Signature: шаги `svc.processor.*` и guard перед ответом; задача P27 — регистрация функций и Ищейка по цепочке.
- P28 FeatureFlags: профили `prod_safe/diagnostics_on` и reconcile‑правила; задача P28 — ключи и авто‑enforce P27.
- P29 Quality: гейты качества, Жандарм/Судья; задача P29 — тест `p27_guard_chain`, уставы на безопасную выдачу.
- P31 Multisensory Quants: сенсорные события/оценки как вход; задача P31 — сигналы в agenda и приоритеты.
- P32 RBAC/Subscriptions: роли `processor.admin`, лимиты LLM; задача P32 — права на admin/API/Hyperloop.
- P33 Personification: профиль пользователя влияет на приоритет/тактику; задача P33 — атрибуты профиля в appraise.
- P34 External Chat Proxy: новые источники событий; задача P34 — контракты и аутентификация источника.
- P36 Hyperloop DSL: управляющий язык; задача P36 — HANDLERS для `CORE.*` и `TRACE.*`.

## 19) Задачи в смежных ТЗ (исполняются в рамках P30/P36)

- P27: зарегистрировать `svc.processor.perceive/decide/act/observe/learn` в Function Registry (`required`); добавить правила Seeker для пропусков.
- P28: добавить ключи `processor.enabled/profile/max_qps/max_latency_ms`; профиль `prod_safe` — включает Guard и скрывает диагностику.
- P29: добавить тесты `p27_guard_chain`, `processor_feedback_invariant`, интеграцию Judge для опасных Hyperloop‑команд (Two‑Keys).
- P22: опубликовать эндпоинты `/api/admin/soul/processor/*` и `/api/hyperloop/execute` в OpenAPI; заголовок `X-Telegram-User-ID` обязателен.
- P23: реализовать панель «Процессор»: статус, очередь, последние решения, инциденты, ручные триггеры.
- P21: добавить метрики/алерты Процессора; дашборды.
- P16: задать окна Sleep/обслуживания и сигналы готовности для дирижирования.
- P32: добавить роль `processor.admin`; связать с админ‑эндпоинтами и Hyperloop.

## 20) Мировой опыт (расширение)

- Event‑orchestration: Temporal/Airflow — надёжные воркфлоу, идемпотентность, retry/backoff, дедупликация.
- Autonomous agents: AutoGen/LangGraph — планирование/рефлексия, замкнутые петли, инструменты.
- Guardrails: OpenPolicyAgent/OPA, policy‑as‑code; Delivery Guard как обязательный gate перед выдачей.
- Ops интерфейсы: Terraform/HCL, Kubernetes kubectl — dry‑run/plan, RBAC, атомарность.

## 21) Acceptance (MVP, расширено)

- Цикл Процессора запускается и обрабатывает ≥3 вида событий (чат, reminder, инцидент); шаги подписи `svc.processor.*` фиксируются; для reminder создаётся инцидент `reminder_enriched`.
- Перед пользовательской выдачей Delivery Guard подтверждает обязательную цепочку шагов; при нарушении — блокировка и отчёт.
- Hyperloop: `POST /api/hyperloop/execute` выполняет ≥10 команд, в ответе есть `trace_id`; шаги `cmd.hyperloop.*` в `signature_steps`.
- E2E: `CORE.PIPELINE.RUN ... WITH TRACE` → `REQUEST.CREATE` → `REQUEST.STATUS done` — проходит, шаги `cmd.hyperloop.request.*` фиксируются, список заявок доступен.
- UI Панель «Процессор» показывает статус/очередь/последние решения; доступ по RBAC.
- Метрики и алерты Процессора доступны на дашбордах; smoke‑цепочки P24 зелёные «после деплоя».

## 21.A) Бэклог задач реализации (сводно по P‑серии)

Цель: сформировать детализированный список задач для быстрой LLM‑разработки Процессора без деградации требований и объёма функциональности. Каждая задача формулируется атомарно, с ожидаемыми результатами, Hyperloop‑проверками и ссылками на сопряжённые P‑ТЗ.

1) P27 Signature — регистр и обязательные шаги
   - Реализовать `svc.processor.perceive/decide/act/observe/learn` в Function Registry как required.
   - Включить Delivery Guard цепочку: `preanalysis, router_decide, llm send/recv, parser, reply_render`.
   - Проверка: `INSPECTOR.RUN_ALL scope=signature` зелёный; `CORE.TRACE.REQUIRE` проходит.

2) P28 FeatureFlags — профили и политики
   - Ключи: `PROCESSOR_ENABLED`, `PROCESSOR_PROFILE`, `DELIVERY_GUARD_ENFORCE`, лимиты QPS/latency.
   - Профиль `prod_safe` — enforce Guard, скрыта диагностика.
   - Проверка: `FLAGS.APPLY_PROFILE name=prod_safe`; изменение политики через `PROCESSOR.POLICY.SET`.

3) P29 Quality — инспекторы и тесты
   - Тесты: `p27_guard_chain`, `processor_feedback_invariant`, `p29.quant_links_ownership`.
   - Инциденты: эскалации при отсутствии feedback, off_track, act_error.
   - Проверка: `TEST.RUN key=p27_guard_chain`, `INSPECTOR.RUN_ALL`.

4) P36 Hyperloop — управляющие сценарии
   - Обработчики: `PROCESSOR.EVENT.INJECT`, `PROCESSOR.PROCESS_ONCE`, `PROCESSOR.POLICY.SET`.
   - Смоки: `CORE.PIPELINE.RUN ... WITH TRACE`, `TRACE.STEPS`.
   - Проверка: ответ содержит `trace_id`, `signature_steps` сохранены.

5) P01/P03/P22 — Контекст/Роутер/API
   - Интеграция RouterContext в appraise/decide; экспорт краткой повестки для ядра.
   - Админ‑API `/api/admin/soul/processor/*` — статус/agenda/event/incidents/runs.
   - Проверка: `GET status/agenda`, инъекция события и `process_once`.

6) P16/P17/P26 — Sleep/Напоминания/Календарь
   - Ночные слоты: запуск оптимизаторов; due‑обработчики reminder/calendar.
   - Проверка: `PROCESSOR.EVENT.INJECT kind=reminder|calendar_event_due` → `PROCESSOR.PROCESS_ONCE`.

7) P24 — Интеграционные тесты/мониторинг
   - Дымовые сценарии после деплоя; дашборды p95/очередь/инциденты.
   - Проверка: панель и алерты; отчёт зелёный.

8) P31 — Мультисенсорные события (расширение)
   - Добавить kinds `audio_input|vision_signal` (эскиз), без деградации требований.
   - Проверка: инъекции событий → `PROCESSOR.PROCESS_ONCE` ок; шаги подписи присутствуют.

9) P32 — RBAC/Subscriptions
   - Роль `processor.admin`; квоты LLM; ограничение инъекций.
   - Проверка: доступ к админ‑эндпоинтам ограничен; попытки без роли → 403.

10) P33 — Personification
   - Влияние профиля на приоритет/тактику (appraise/decide), без модификации пользовательского текста.
   - Проверка: сценарий с разными профилями меняет приоритеты/бюджеты.

11) P34 — External Chat Proxy
   - Приём внешних событий с аутентификацией; корреляция/идемпотентность.
   - Проверка: инъекция прокси‑события; трасса и подпись корректны.

12) P38 — NeuroTraining (RT микро‑батчи)
   - Поддержка микро‑батчей для gap‑closure (TIMEOUT≤1500–3000, append=true) без деградации Guard.
   - Проверка: `CORE.PIPELINE.RUN ... TIMEOUT=1200`; метрики RT в норме.

Примечание: AGE‑синхронизация — `relation_type=COALESCE(connection_type::text,'semantic')` для совместимости с существующими граф‑скриптами.

## 21.B) Матрица Acceptance/Hyperloop проверок (по задачам)

Ключ: OK — ожидается успешный ответ с `trace_id` и сохранёнными `signature_steps` (для Hyperloop), 200 — для админ‑API.

| Блок | Команда | Ожидание |
| --- | --- | --- |
| P27 | `INSPECTOR.RUN_ALL scope=signature` | OK |
| P27 | `CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,...,svc.chat.reply_render"` | OK |
| P28 | `FLAGS.APPLY_PROFILE name=prod_safe` | OK |
| P29 | `TEST.RUN key=p27_guard_chain` | OK |
| P36 | `CORE.PIPELINE.RUN input_text="P30 smoke" WITH TRACE` | OK + trace_id |
| P22 | `GET /api/admin/soul/processor/status` | 200 |
| P22 | `POST /api/admin/soul/processor/event {...}` | 200 |
| P22 | `POST /api/admin/soul/processor/process_once` | 200 |
| P16/17/26 | `PROCESSOR.EVENT.INJECT kind=reminder|calendar_event_due` | OK |
| P31 | `PROCESSOR.EVENT.INJECT kind=audio_input` | OK |
| P32 | Доступ без роли к admin API | 403 |
| P38 | `CORE.PIPELINE.RUN ... TIMEOUT=1200` | OK + метрики RT |

## 22) PROD: пути/секреты/флаги (консолидация)

- Пути: backend `/var/www/soulpulse/backend`; unit `soulpulse-backend.service`; venv `/var/www/soulpulse/backend/venv`.
- Секреты/ENV: `DATABASE_URL`, LLM ключи, `PROCESSOR_ENABLED=1`, `DELIVERY_GUARD_ENFORCE=1`, `DIAGNOSTIC_VISIBLE_REPLY=0`, `PROCESSOR_PROFILE=prod_safe`.
- Политики: Function Registry — `required` для `svc.processor.*` и цепочки chat/llm/parser/persist; Mother of Flags — профиль `prod_safe`.

## 23) Runbook (быстрые команды Hyperloop для запуска)

Примеры:

- `FLAGS.APPLY_PROFILE name=prod_safe`
- `FLAGS.SET key=delivery_guard.enforce value=true`
- `CORE.PIPELINE.RUN input_text="Проверка P30/P27" WITH TRACE`
- `CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.soul.router_decide,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"`

Админ‑API smoke (после деплоя):

- Статус: `GET /api/admin/soul/processor/status`
- Включить: `POST /api/admin/soul/processor/start`
- Снять блокировку: `PUT /api/admin/soul/processor/policies {"key":"block.chat_message","value":{"enabled":false}}`
- Инъекция chat: `POST /api/admin/soul/processor/event {"kind":"chat_message","payload":{"text":"processor ping"},"priority":10}`
- Обработка одного: `POST /api/admin/soul/processor/process_once`
- Инъекция reminder: `POST /api/admin/soul/processor/event {"kind":"reminder","payload":{"reminder_id":"r-123","user":{"id":468326902}},"priority":5}`
- Инциденты/запуски: `GET /api/admin/soul/processor/incidents`, `GET /api/admin/soul/processor/runs`

### 23.1 Практические проверки (API/PowerShell)

- Базовый URL: `API_BASE`
- Заголовок: `X-Telegram-User-ID: ADMIN_TG_ID`

```powershell
$H=@{ 'X-Telegram-User-ID'='ADMIN_TG_ID' }
Invoke-RestMethod -Uri 'API_BASE/admin/soul/processor/status' -Headers $H -Method Get | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'API_BASE/admin/soul/processor/start' -Headers $H -Method Post | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'API_BASE/admin/soul/processor/agenda' -Headers $H -Method Get | ConvertTo-Json -Depth 6 -Compress
$E=@{ kind='chat_message'; payload=@{ text='processor ping' } } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'API_BASE/admin/soul/processor/event' -Headers $H -Method Post -ContentType 'application/json' -Body $E | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'API_BASE/admin/soul/processor/process_once' -Headers $H -Method Post | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'API_BASE/admin/soul/processor/incidents' -Headers $H -Method Get | ConvertTo-Json -Depth 6 -Compress
Invoke-RestMethod -Uri 'API_BASE/admin/soul/processor/runs' -Headers $H -Method Get | ConvertTo-Json -Depth 6 -Compress
$B=@{ commands='CORE.PIPELINE.RUN input_text="P30 smoke" WITH TRACE' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'API_BASE/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Depth 12 -Compress
```

Ожидается: `ok` на админ‑эндпоинтах, в Hyperloop‑ответе есть `trace_id`, шаги `svc.soul.preanalysis, svc.soul.router_decide, svc.llm_client.send, svc.llm_client.recv, svc.parser.json_strict, svc.chat.reply_render` видны в `signature_steps`.

---

## 17.1) Подтверждения через Telegram (ACK) — контроль Оркестратором (P20)

- Процессор формирует заявки/эскалации как `REQUEST.CREATE …` c каналом доставки `telegram_dm|telegram_group`.
- Доставка и форматирование выполняются через Бот‑Оркестратор (P20):
  - Очереди исходящих, троттлинг, бэкофф, Retry‑After.
  - Единый санитайзер HTML, нормализация префиксов (без «AI»).
  - Inline‑кнопки: `confirm|reject|details` c `callback_data` с TTL/идемпотентностью.
- Обработка callback:
  - Оркестратор валидирует роль (Архитектор/владелец) и направляет в Processor API.
  - Processor обновляет статус заявки/кванта; подпись `svc.processor.observe` фиксируется; сообщение редактируется (снятие клавиатуры).
- Инварианты:
  - Идемпотентность по (chat_id,message_id,callback_data); логи с маской PII (P08/P09).
  - Акцепт/отказ отражается в TraceViewer (P12) и Provenance (P11).

Приложение А. DDL (эскиз Alembic)

```sql
CREATE TABLE IF NOT EXISTS processor_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind text NOT NULL,
  payload jsonb NOT NULL,
  dedup_key text,
  priority int DEFAULT 0,
  due_at timestamptz,
  status text DEFAULT 'pending',
  retries int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_processor_events_status ON processor_events(status);
CREATE INDEX IF NOT EXISTS ix_processor_events_due ON processor_events(due_at);
CREATE INDEX IF NOT EXISTS ix_processor_events_kind ON processor_events(kind);
CREATE INDEX IF NOT EXISTS ix_processor_events_payload ON processor_events USING gin(payload);

CREATE TABLE IF NOT EXISTS processor_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  started_at timestamptz DEFAULT now(),
  finished_at timestamptz,
  status text,
  agenda_snapshot jsonb,
  metrics jsonb,
  created_by text
);

CREATE TABLE IF NOT EXISTS processor_incidents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id uuid REFERENCES processor_runs(id) ON DELETE SET NULL,
  event_id uuid REFERENCES processor_events(id) ON DELETE SET NULL,
  type text NOT NULL,
  detail text,
  created_at timestamptz DEFAULT now()
);
```

## 24) Связь Квантов и План‑Факт (детализация)

Цель: формализовать влияние входящих стимулов на рождение Квантов по предназначению «выполнение плана», обеспечить детерминированную цепочку от активации до фиксации прогресса/закрытия, встроенную в петлю Процессора и управляемую через Hyperloop (P36).

- Источники активации: входящие сообщения пользователя/бота, календарные события, инциденты/сигналы, изменения статуса целей/задач.
- Рождение Кванта: при активации Процессор порождает Квант(ы) класса plan_support либо goal_progress, привязанные к конкретной задаче плана.
- Квант‑триггер: каждый такой Квант инициирует атомарное действие (служебная процедура/команда) для приближения к цели плана.
- Выбор инструмента: Процессор решает, какой инструмент применить из данных Кванта:
  - прямо исполняемый Hyperloop DSL (напр. CORE.PIPELINE.RUN / REQUEST.CREATE / PROCESSOR.*);
  - поиск Кванта‑ответа (reuse ранее полученного решения);
  - инициирование нового Кванта (разветвление цепочки) при нехватке данных.
- Учёт прогресса: Квант обновляет отметки продвижения по задаче плана. При достижении критериев закрытия — фиксируется закрытие и двунаправленная связь Квант↔элемент плана.
- Итерации до результата: если задача не решена, Процессор формирует запрос/инициирует новый Квант и продолжает цикл до выполнения.
- Квант‑подтверждение: завершение шага порождает подтверждающий Квант (result/confirmation), формируя цепочку Квантов, направленную на решение конкретной задачи плана/достижение цели.
- Самоадаптация: пока задача не выполнена, Процессор генерирует потребность в Квантах, оценивает эффективность (метрики качества, SLO), корректирует требования/приоритеты.
- Достижение цели: при закрытии ключевой задачи может быть достигнута цель; цель транслируется в Квант статуса (status_update) с инициированием следующего действия: фиксация статуса/переключение на следующую задачу/уведомление об успехе.
- Базовая связка: «информация‑активатор → рождение Кванта → переоценка весов/связей». Дополнительные алгоритмы используются для структур задач на языке Hyperloop и логике Процессора.

### 24.1 Контракты данных и связи (ядро)

- Сущности:
  - `plan_tasks(id, project_id, title, status, progress, due_at, priority, meta jsonb)`
  - `quants(id, class, purpose, payload jsonb, created_at, created_by, tags text[])`
  - `quant_links(id, from_quant, to_entity_type, to_entity_id, relation_type, weight float, created_at)`
- Связи:
  - Квант→Задача плана: `relation_type='supports'|'closes'|'confirms'` (по назначению Кванта);
  - Обновление прогресса: атомарно, с фиксацией в `plan_tasks.progress` и аудитом `processor_incidents(type='plan_progress_update')`.
- Политики:
  - Идемпотентность по `dedup_key` (в событиях) для исключения дубликатов.
  - Two‑Keys (P29) для опасных действий (массовые изменения статусов).

### 24.2 Интеграция с петлёй Процессора (P30)

- perceive/appraise: извлечь цель/элемент плана из контекста; оценить срочность/бюджет.
- decide: выбрать тактику (эвристика/LLM/шаблон); при необходимости — порождение Кванта уточнения.
- act: выполнить шаг(и): создать/обновить связи Квант↔План; при необходимости — Hyperloop команды.
- observe: ждать подтверждение (подтверждающий Квант или служебный результат); при отсутствии — ретраи/эскалация.
- learn: обновить ранги/веса/приоритеты задач; записать метрики.
- Подпись (P27): `svc.processor.perceive → svc.processor.decide → svc.llm_client.send → svc.llm_client.recv → svc.processor.act → svc.processor.observe → svc.chat.reply_render` (+ steps Hyperloop `cmd.hyperloop.*` при исполнении).

### 24.3 Hyperloop (P36) — команды и сценарии

- Порождающие/служебные:
  - `PROCESSOR.EVENT.INJECT kind=plan_update payload={...}` — инъекция события плана.
  - `REQUEST.CREATE type=plan_update subject="..." payload={...}` — оформление служебной заявки (Архивариус).
  - `CORE.PIPELINE.RUN input_text="План: ..." WITH TRACE` — stateless‑смок с подписью и трассой.
- Проверочные:
  - `CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"`
  - `INSPECTOR.RUN key=signature.required_steps.consistency`

Пример (одна строка DSL):

```powershell
$B=@{ commands='PROCESSOR.EVENT.INJECT kind=plan_update payload={"project_id":"p-1","task_id":"t-42","delta":0.25}' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri '{API_BASE}/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B
```

### 24.4 Acceptance (План‑Факт)

- Рождение Кванта класса plan_support при активации стимула.
- Корректная привязка Квант↔Задача плана; обновление прогресса в `plan_tasks` и запись связи в `quant_links`.
- Подтверждающий Квант на завершение шага; цепочка Квантов прослеживается по `quant_links`.
- Наличие обязательных шагов подписи (P27) в `signature_steps` для план‑сценариев в окне 24ч.
- Hyperloop сценарии выполняются; `trace_id` возвращается; шаги `cmd.hyperloop.*` и `svc.*` сохранены.

### 24.5 Наблюдаемость/метрики

- `processor.plan.progress_updated{project_id,task_id}` счётчик.
- `processor.plan.p95_act_ms` латентность стадий act/observe в план‑сценариях.
- `processor.plan.chain_length` длина цепочки Квантов до закрытия.
- Алерты: отсутствие подтверждающих Квантов > T; стагнация `progress` при активной генерации Квантов.

### 24.6 Пошаговая реализация (код)

1) Схема БД (Alembic):
   - Убедиться в наличии таблиц: `processor_events`, `processor_incidents`, `processor_policies`, `quant_links`, `plan_tasks`.
   - Индексы: `processor_events(status, due_at, priority)`, GIN по `payload`; `quant_links(to_entity_type,to_entity_id)`.
   - Примечание (AGE sync): для источников AGE задавать `relation_type` как `COALESCE(connection_type::text,'semantic')`.

2) Процессор (`backend/app/services/processor_scheduler.py`):
   - В `_process_one(...)` при kind in {`chat_message`,`plan_update`} добавлять `quant_links` и обновлять `plan_tasks.progress` (через `db.execute(text(...))`).
   - Фиксировать шаги подписи: `svc.processor.perceive/decide/act/observe`.
   - Guard: перед пользовательской публикацией проверять `verify_before_reply(...)`.

3) Ядро Соул (`backend/app/services/soul_core_manager.py`):
   - Использовать `generate_quants(..., db=None, signature_ctx=ctx)` для stateless рождения Квантов; класс/назначение: `plan_support`.
   - Возврат кандидатов — не сохранять в БД при batch/stateless; в single/persistent — персистить.

4) Hyperloop (`backend/app/services/hyperloop_engine.py`):
   - Команды: `PROCESSOR.EVENT.INJECT kind=plan_update payload={...}`; `PROCESSOR.PROCESS_ONCE`.
   - В `CORE.PIPELINE.RUN ... WITH TRACE` гарантировать шаги `svc.soul.router_decide`, `svc.chat.reply_render` и `persist_signature_steps`.

5) Инспекторы (P27):
   - `signature.required_steps.consistency` — добавить ключи `svc.soul.router_decide`, `svc.chat.reply_render`, `svc.processor.*` в конфигурацию.

6) Acceptance (smoke):
   - Вызвать: `INSPECTOR.RUN_ALL scope=signature`; `CORE.PIPELINE.RUN input_text="План: ..." WITH TRACE`;
   - Инъекция: `PROCESSOR.EVENT.INJECT kind=plan_update payload={...}` → `PROCESSOR.PROCESS_ONCE`;
   - Проверка: `TRACE.STEPS trace_id=...` содержит обязательные шаги; в БД появились `quant_links` и обновлён `plan_tasks.progress`.

## 25) Модель движения Кванта (FSM + инварианты)

Определение: Квант — атомарная единица смысла/действия, проходящая через конечный автомат (FSM) состояний под управлением Процессора.

Состояния FSM:

- created: возник из стимула/плана/цели; связки с источником.
- appraised: оценён приоритет/срочность/бюджет; присвоены теги/контекст.
- planned: выбран исполнительный путь (эвристика/LLM/шаблон/Hyperloop).
- acted: выполнено атомарное действие (эффектор); зафиксирован результат/артефакт.
- observed: получено подтверждение/обратная связь или истёк таймаут.
- confirmed|escalated|retry_scheduled: ветки исхода — подтверждение, эскалация, ретрай с backoff.
- closed: цель данного Кванта достигнута; связи/веса обновлены; следующее действие инициировано.

Переходы (детерминированные):

- created → appraised (policy P28/P29)
- appraised → planned (decision policy)
- planned → acted (executor)
- acted → observed (wait/collect)
- observed → confirmed|escalated|retry_scheduled (feedback policy)
- confirmed → closed; escalated → planned|closed; retry_scheduled → planned

Инварианты (P27/P29):

- На каждом переходе фиксируется шаг подписи `svc.processor.*` +, при наличии Hyperloop, `cmd.hyperloop.*`.
- Перед публикацией пользователю — Delivery Guard: цепочка `preanalysis, send, recv, parser, reply_render` присутствует.
- Идемпотентность: повторные стимулы с одним `dedup_key` не порождают новые закрытые ветви.

Сценарии симуляции (минимум):

- S1 Chat→Plan: created(chat)→...→confirmed(close task) — прогресс в plan_tasks↑; quant_links фиксируют трассу.
- S2 Reminder: created(reminder)→acted(enrich)→confirmed — инцидент `reminder_enriched` + запись в links.
- S3 Incident: created(incident)→planned(judge/test)→observed→escalated — заявка через REQUEST.CREATE.

Метрики FSM: coverage переходов, p95 по переходам, частота ретраев/эскалаций, средняя длина цепочки до closed.

## 26) Автономность и непротиворечивость квантовым алгоритмам

Автономность:

- Петля OODA (P30) обеспечивает движение без внешнего надзора: события→план→действие→обратная связь.
- Источники LLM используются как инструмент (кора), а не управляющий элемент; решения и политика — внутри Процессора.

Непротиворечивость «квантовому сознанию» (практики AutoGen/LangGraph/ReAct):

- Дискретность (квантизация) действий и мыслей: атомарные Кванты и шаги подписи.
- Обратная связь и рефлексия: observe→learn с ретраями и корректировкой тактик (Reflexion‑подход).
- Управляемая экзекуция: agenda/planner/executor аналог графа инструментов (LangGraph) с явными узлами/ребрами.
- Политики/Guard: policy‑as‑code (P29) гарантирует безопасный выпуск.

Доказательство выполнимости (эскиз):

- Для каждого события существует конечный путь по FSM к состоянию closed или устойчивое состояние escalated с ограниченным числом ретраев (ограниченность по retry + backoff → отсутствие бесконечных циклов без прогресса).
- Наличие Delivery Guard исключает публикацию несогласованных состояний.

## 27) Сверка с лучшими мировыми практиками (маппинг)

- OODA/Control‑theory loops → разделы 4, 25: петля и FSM, обратная связь обязательна.
- ReAct/Reflexion → разделы 4, 26: рассуждение с действиями; рефлексия через observe/learn.
- LangGraph/Tool‑agents → разделы 3, 24, 25: agenda/planner/executor и Hyperloop как единый control plane инструментов.
- Guardrails/OPA → P29/P27: уставы/инспекторы/подпись/guard перед публикацией.
- Workflow engines (Temporal/Airflow) → разделы 3, 25: идемпотентность, дедупликация, ретраи, наблюдаемость.

Acceptance для разделов 25–27:

- Три симуляционных сценария (S1–S3) проходят на стейдже с записью `signature_steps` и ожидаемыми инцидентами/связями.
- Метрики FSM экспортируются; coverage переходов ≥ 90% в дымовых прогонах.
- Политики Guard/Two‑Keys срабатывают в негативных кейсах; публикации без цепочки P27 не происходят.

## 30) Кванты и Рефлексия (детализация)

Цель: формализовать механизм самооценки и корректировки поведения на уровне Квантов и Процессора, обеспечив обратную связь как инвариант системы и улучшение траекторий достижения целей/плана.

Типы рефлексивных Квантов:

- `self_review` (оценка качества ответа/действия);
- `error_analysis` (разбор провала/инцидента);
- `strategy_adjustment` (коррекция тактики/порогов/приоритетов);
- `hypothesis_test` (проверка гипотезы улучшения);
- `meta_feedback` (агрегированная обратная связь по цепочке).

Точки триггера:

- несоответствие P27‑цепочки (Guard блокирует публикацию);
- инциденты P29 (`delivery_guard_failed`, `off_track`, `act_error`, `dead_letter`);
- пользовательская обратная связь/редактирование ответа;
- ухудшение метрик (рост p95, падение on_time_delivery_rate, снижение coverage подписи).

### 30.1 Контракты данных и связи

Сущности:

- `processor_incidents` (уже есть) — источник триггеров;
- `reflections(id, trace_id, kind, subject, body jsonb, status, created_at)` — журнал рефлексий;
- `quant_links` — связи рефлексивного Кванта с исходными Квантами/целями/планом (`relation_type='reviews'|'adjusts'|'explains'`).

Политики:

- лимиты на частоту рефлексии (debounce) по `trace_id`/`subject`;
- Two‑Keys для опасных `strategy_adjustment` (влияющих на политики/флаги);
- STRICT JSON для сохранения тела `body`.

### 30.2 Интеграция с петлёй Процессора

- perceive: собрать контекст неуспеха/отклонения (подпись, инциденты, метрики);
- appraise: классифицировать тип рефлексии (review|analysis|adjustment|hypothesis);
- decide: выбрать инструменты (эвристика/сервисный LLM GigaChat с таймаутами/ретраями) и политику воздействия;
- act: породить рефлексивный Квант, записать `reflections`, создать `quant_links` и при необходимости инициировать `PROCESSOR.EVENT.INJECT` для коррекции (новые Кванты);
- observe: подтвердить улучшение (мониторинг метрик/повторная проверка инспектора);
- learn: обновить веса стратегий/порогов, профиль флагов (через Mother of Flags по Two‑Keys).

Шаги подписи: `svc.processor.*`, `svc.llm_client.send/recv` при использовании LLM, `cmd.hyperloop.*` при изменении флагов/политик.

### 30.3 Hyperloop — команды и сценарии

- Запуск регрессионной проверки: `INSPECTOR.RUN_ALL scope=*`;
- Смок‑рефлексия: `TEST.RUN key=p29.processor_feedback_invariant`;
- Исправление политики: `TWO_KEYS.REQUEST operation=flags scope=signature reason="enable guard"` → `TWO_KEYS.APPROVE id=<id>` → `FLAGS.SET key=delivery_guard.enforce value=true`.

Пример:

```powershell
$B=@{ commands='INSPECTOR.RUN_ALL\nTEST.RUN key=p29.processor_feedback_invariant' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri '{API_BASE}/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B
```

### 30.4 Acceptance (Рефлексия)

- При инциденте `delivery_guard_failed` создаётся рефлексивный Квант `error_analysis` и запись в `reflections`;
- При многократных `act_error` формируется `strategy_adjustment` (через Two‑Keys при изменении флагов);
- `INSPECTOR.RUN_ALL` возвращает «зелёный» статус после серии корректировок; `signature_steps` включают шаги P27.

### 30.5 Наблюдаемость/метрики

- `processor.reflection.created{kind}` счётчики;
- `processor.reflection.time_to_green_ms` — время до восстановления «зелёного» статуса;
- `processor.reflection.adjustments_applied`.

### 30.6 Пошаговая реализация (код)

1) Схема БД (Alembic):
   - Создать `reflections` (если отсутствует): `(id uuid pk, trace_id text, kind text, subject text, body jsonb, status text, created_at timestamptz default now())` и индексы.

2) Процессор (`backend/app/services/processor_scheduler.py`):
   - В `_process_one` при ошибках/инцидентах — формировать рефлексивные Кванты (по политике) и запись в `reflections` + `quant_links(reviews|adjusts)`.

3) Ядро Соул (`backend/app/services/soul_core_manager.py`):
   - При необходимости порождать `self_review` stateless‑кандидат для лаконичной оценки видимого ответа (без публикации).

4) Hyperloop (`backend/app/services/hyperloop_engine.py`):
   - Использовать `INSPECTOR.RUN/ALL`, `TEST.RUN`, `TWO_KEYS.*`, `FLAGS.*` для управляемых корректировок.

5) Инспекторы/Тесты (P27/P29):
   - Проверки на покрытие шагов P27, отсутствие тех‑блоков в видимом ответе; ретраи/эскалации при провалах.

6) Acceptance (smoke):
   - Вызов `INSPECTOR.RUN_ALL` после корректировок — зелёный; созданные `reflections` и связи присутствуют; целевые метрики улучшены.

### 30.7 Контракт промптов сервисного LLM (STRICT JSON)

- Вход (context): trace_id, last_steps (≤10), incident (type, detail), user_visible (bool), last_reply_excerpt, policies (active), environment.
- Выход (strict JSON):
  - `cause`: string (краткая причина);
  - `remediation_steps`: string[] (≤5 конкретных шагов);
  - `policy_suggestions`: { flag?: string, value?: any, justification?: string }[];
  - `risk`: { level: "low"|"medium"|"high", rationale: string };
  - `next_action`: "adjust_flags"|"retry"|"escalate"|"no_action";
  - `confidence`: number (0..1).

Пример запроса (фрагмент): `svc.llm_client.send` с system: "Верни ТОЛЬКО строгий JSON по схеме ...", user: контекст из подписи/инцидента; parser: `svc.parser.json_strict`.

### 30.8 Сценарии Hyperloop для быстрых корректировок

- Повторные `delivery_guard_failed` ≥ N за 10 мин:
  - `TWO_KEYS.REQUEST operation=flags scope=signature reason="enforce guard"` → `TWO_KEYS.APPROVE id=<id>` → `FLAGS.SET key=delivery_guard.enforce value=true`;
  - `INSPECTOR.RUN key=signature.required_steps.consistency`.
- Рост `processor.time_send_to_recv_ms p95`:
  - `PROCESSOR.POLICY.SET key=llm.timeouts value={"send_ms":15000,"recv_ms":30000}`;
  - `INSPECTOR.RUN_ALL`.

### 30.9 Дашборды/алерты (P21)

- Панели: `reflection.created{kind}`, `time_to_green_ms`, распределение `next_action`, доля `policy_suggestions` применённых.
- Алерты: `time_to_green_ms > SLO`, всплеск `error_analysis` (> X/час), `adjustments_applied` без улучшения метрик (коррелировать окна).

### 30.A DDL (рефлексии) — эскиз Alembic

```sql
CREATE TABLE IF NOT EXISTS reflections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trace_id text,
  kind text NOT NULL,
  subject text,
  body jsonb NOT NULL,
  status text,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_reflections_trace ON reflections(trace_id);
CREATE INDEX IF NOT EXISTS ix_reflections_kind ON reflections(kind);
CREATE INDEX IF NOT EXISTS ix_reflections_body ON reflections USING gin(body);
```

### 30.B Миграции/совместимость

- Миграция add `reflections`; backfill: по последним 7 дням инцидентов создать агрегаты в отчётах (без ретро‑квантов).
- Совместимость: при отсутствии `reflections` — логировать рефлексию в `processor_incidents(type='reflection_log')`.

### 30.C Тест‑план (unit/integration)

- Unit: маппинг incident→reflection kind; STRICT JSON парсер для LLM; two‑keys ветки.
- Integration: искусственно вызвать `delivery_guard_failed` → появление `error_analysis` и последующая нормализация инспекторов; метрики `time_to_green_ms` < SLO.

## 31) Кванты и Навыки (детализация)

Цель: превратить взаимодействия пользователя и системные сигналы в устойчивое формирование и укрепление навыков через Кванты классов `skill_*`, интегрированные с расписанием, планом и целями.

Источники активации:

- входящие сообщения с намерением «учиться/практиковаться» (детектируется P01/P03);
- плановые задачи/цели, требующие развития навыка (связь с разделами 24/29);
- напоминания практики (спейс‑репетиция/стрики, P17/P26);
- результаты сессий (успех/ошибка/оценка качества).

Классы Квантов:

- `skill_detect` (идентификация навыка из контекста);
- `skill_plan` (назначение практики/микрозадачи);
- `skill_session` (проведение практической сессии);
- `skill_feedback` (оценка результата сессии);
- `skill_adjustment` (коррекция уровня/сложности/интервала);
- `skill_reflection` (мета‑оценка прогресса навыка).

### 31.1 Контракты данных и связи

Сущности (эскиз):

- `skills(id, key text unique, name text, description text, meta jsonb)`
- `user_skills(user_id bigint, skill_id uuid, level int, streak int, last_practiced_at timestamptz, next_due_at timestamptz, proficiency float, meta jsonb, primary key(user_id, skill_id))`
- `skill_practice(id uuid, user_id bigint, skill_id uuid, session_at timestamptz, duration_sec int, outcome text, score float, notes text, meta jsonb)`
- `quant_links(id uuid, from_quant uuid, to_entity_type text, to_entity_id text, relation_type text, weight float, created_at timestamptz)`

Связи и семантика:

- Квант→Навык: `relation_type='improves'|'plans'|'assesses'|'adjusts'|'schedules'`.
- Спейс‑репетиция: вычисление `next_due_at` (SM‑подобная модель, параметры в `processor_policies['skills.spaced_repetition']`).
- Прогресс: `user_skills.proficiency` и `level` обновляются из `skill_feedback.score/outcome`.

Политики:

- Идемпотентность по `dedup_key=<user_id>:<skill_id>:<bucket(session_at)>`.
- Two‑Keys для опасных изменений (сброс уровня/массовые переносы due).
- Ограничение частоты практик (анти‑спам).

### 31.2 Интеграция с петлёй Процессора

- perceive: извлечь кандидат‑навык из контекста (P01/P03), прочитать `user_skills`/`next_due_at`, проверить конфликты календаря;
- appraise: оценить срочность (due/просрочка), приоритет (цель/план), выбрать бюджет/формат практики;
- decide: `plan_session | run_session | adjust_level | schedule_reminder`;
- act: создать/обновить `skill_practice`/`user_skills`, записать связи `quant_links`, при необходимости — инъекция напоминания (P17) или плановой задачи (раздел 24);
- observe: получить `skill_feedback` (оценка/скор), либо ожидать подтверждение; ретрай/эскалация при отсутствии;
- learn: обновить модель интервалов (policy), веса форматов практики, `level/proficiency/streak`.

Подпись: `svc.processor.*` на каждом этапе; при генерации текста практики через ядро — `svc.soul.preanalysis|svc.llm_client.*|svc.parser.json_strict|svc.chat.reply_render`; при управлении планом/напоминаниями — `cmd.hyperloop.*`.

### 31.3 Hyperloop — команды и сценарии

- Сигнал навыка: `PROCESSOR.EVENT.INJECT kind=skill_signal payload={"user":{"id":468326902},"skill_key":"typing_speed"}`
- Результат сессии: `PROCESSOR.EVENT.INJECT kind=skill_session_result payload={"user":{"id":468326902},"skill_key":"typing_speed","score":0.82,"duration_sec":600}`
- Политика интервалов: `PROCESSOR.POLICY.SET key=skills.spaced_repetition value={"base":1.3,"min_hours":8}`
- Обработка одного: `PROCESSOR.PROCESS_ONCE`

Пример:

```powershell
$B=@{ commands='PROCESSOR.EVENT.INJECT kind=skill_signal payload={"user":{"id":468326902},"skill_key":"typing_speed"}\nPROCESSOR.PROCESS_ONCE' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri '{API_BASE}/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B
```

### 31.4 Acceptance (Навыки)

- При сигнале `skill_signal` создаётся Квант `skill_plan`, формируется или обновляется `user_skills` (next_due_at), создаётся связь `quant_links(plans|schedules)`;
- При результате `skill_session_result` создаётся Квант `skill_feedback`, обновлены `proficiency/level/streak`, записан `skill_practice`, рассчитан новый `next_due_at`;
- При превышении/просрочке due создаётся соответствующее событие напоминания (P17) и фиксируется в `quant_links`;
- В `signature_steps` присутствуют шаги P27; Hyperloop сценарии возвращают `trace_id`.

### 31.5 Наблюдаемость/метрики

- `processor.skill.sessions_count`, `sessions_duration_total_sec`
- `processor.skill.on_time_practice_rate`, `retention_7d/30d`
- `processor.skill.level_up_count`, `proficiency_delta_avg`
- p95 `processor.skill.session_to_feedback_ms`

### 31.6 Пошаговая реализация (код)

1) Схема БД (Alembic):
   - Создать `skills`, `user_skills`, `skill_practice` (если отсутствуют); индексы: `user_skills(next_due_at)`, `skill_practice(session_at, outcome)`; GIN по `meta`.

2) Процессор (`backend/app/services/processor_scheduler.py`):
   - В `_process_one` добавить kinds: `skill_signal`, `skill_session_result`:
     - `skill_signal`: создать/обновить `user_skills` (инициализировать `level=1, streak=0` при отсутствии), рассчитать `next_due_at`, записать связь `quant_links(plans|schedules)`;
     - `skill_session_result`: записать `skill_practice`, обновить `proficiency/level/streak`, пересчитать `next_due_at`, создать `quant_links(assesses|improves)`.

3) Ядро Соул (`backend/app/services/soul_core_manager.py`):
   - Stateless генерация контента практики (инструкции/мини‑задания) по `skill_key` и текущему уровню — Квант `skill_session` (без персистенции в batch режиме).

4) Hyperloop (`backend/app/services/hyperloop_engine.py`):
   - Использовать имеющийся `PROCESSOR.EVENT.INJECT`/`PROCESSOR.PROCESS_ONCE`; политики через `PROCESSOR.POLICY.SET`.

5) Инспекторы/Тесты (P27/P29):
   - Проверить наличие шагов P27, отсутствие тех‑блоков в видимом ответе, инциденты при просрочках due.

6) Acceptance (smoke):
   - Инъекции `skill_signal` и `skill_session_result` → `PROCESSOR.PROCESS_ONCE` ok; данные в `user_skills/skill_practice/quant_links` актуализированы; метрики инкрементируются; трасса шагов соответствует P27.

## 29) Связь Квантов и Цели (детализация)

Цель: обеспечить управляемое приближение к целям пользователя/проекта через рождение и обработку Квантов класса `goal_progress|goal_assessment|goal_adjustment`, с фиксацией достижений/барьеров и автоматической коррекцией траекторий.

Источники активации:

- завершение задач плана, ключевые события календаря, входящие сообщения о результатах, внешние метрики (KPI) или инциденты, влияющие на достижимость цели.

Классы Квантов:

- `goal_progress` (изменение прогресса), `goal_assessment` (оценка траектории/рисков), `goal_adjustment` (коррекция цели/микроцелей/порогов).

Поведение Процессора:

- При активации создает Квант соответствующего класса, инициирует действие (обновление прогресса, проверка KPI, коррекция), формирует подтверждающий Квант.
- При недостатке данных — инициирует уточняющий Квант (запрос контекста/данных) или переиспользует ответ из прошлых Квантов.

### 29.1 Контракты данных и связи

Сущности:

- `goals(id, user_id, title, description, target_value numeric, current_value numeric, unit text, status text, due_at timestamptz, priority int, kpi jsonb, meta jsonb)`
- `goal_milestones(id, goal_id, title, target_value numeric, status text, due_at timestamptz, meta jsonb)`
- `quant_links(id, from_quant, to_entity_type, to_entity_id, relation_type, weight float, created_at)`

Связи и семантика:

- Квант→Цель: `relation_type='advances'|'assesses'|'adjusts'|'achieves'|'blocks'`.
- Прогресс: `goals.current_value += delta` (с учётом unit), проверка достижения `current_value >= target_value` или удовлетворения KPI.
- Мерилы KPI (в `kpi`): список условий/порогов; Квант‑оценка вычисляет `ok/at_risk/off_track` и пишет инцидент при отклонении.

Политики:

- Идемпотентность по `dedup_key=<goal_id>:<milestone_id|ts_bucket>`.
- Two‑Keys для опасных корректировок цели (уменьшение target_value, перенос due_at).

### 29.2 Интеграция с петлёй Процессора

- perceive: собрать состояние цели/вех, KPI/порогов, внешние сигналы; нормализовать единицы измерения.
- appraise: вычислить ожидаемый вклад (delta), срочность по due_at, риск недостижения.
- decide: выбрать тактику: `update_progress | assess_kpi | adjust_goal | spawn_plan_task` (создать задачу плана для приближения).
- act: применить действие (обновить `goals/goal_milestones`, записать `quant_links`, инициировать план/напоминания при необходимости).
- observe: ждать подтверждение (подтверждающий Квант/обновление KPI); при отсутствии — ретрай/эскалация.
- learn: обновить веса стратегий, пороги раннего предупреждения (`at_risk`), приоритеты целей.

Шаги подписи: `svc.processor.*`, при вовлечении ядра — `svc.soul.preanalysis|svc.llm_client.*|svc.parser.json_strict|svc.chat.reply_render`; действия Hyperloop — `cmd.hyperloop.*`.

### 29.3 Hyperloop (P36) — команды и сценарии

- Инъекция прогресса: `PROCESSOR.EVENT.INJECT kind=goal_signal payload={"goal_id":"g-1","delta":1.0,"unit":"points"}`
- Оценка KPI: `PROCESSOR.EVENT.INJECT kind=goal_assess payload={"goal_id":"g-1"}`
- Коррекция цели: `PROCESSOR.EVENT.INJECT kind=goal_adjust payload={"goal_id":"g-1","target_value":100,"due_at":"2025-12-31T23:59:59Z"}` (с Two‑Keys)
- Обработка одного: `PROCESSOR.PROCESS_ONCE`
- Трасса: `CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"`

Пример:

```powershell
$B=@{ commands='PROCESSOR.EVENT.INJECT kind=goal_signal payload={"goal_id":"g-1","delta":5}\nPROCESSOR.PROCESS_ONCE' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri '{API_BASE}/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B
```

### 29.4 Acceptance (Цели)

- При сигнале `goal_signal` создаётся Квант `goal_progress`, `goals.current_value` обновлён, связь `quant_links(advances)` создана.
- При достижении цели генерируется Квант `achieves`, статус `goals.status=done`, записана связь `quant_links(achieves)` и при необходимости — инициирована новая цель/следующий этап.
- При оценке KPI создаётся Квант `goal_assessment`; при `off_track` — инцидент и, опционально, Квант корректировки `goal_adjustment`.
- В `signature_steps` присутствуют шаги P27; Hyperloop сценарии возвращают `trace_id`.

### 29.5 Наблюдаемость/метрики

- `processor.goal.progress_delta_total{goal_id}`
- `processor.goal.achieved_count`, `at_risk_count`, `adjustments_count`
- `processor.goal.time_to_achieve_ms` (от постановки до достижения)
- p95 `processor.goal.decide_latency_ms`

### 29.6 Пошаговая реализация (код)

1) Схема БД (Alembic):
   - Проверить/добавить `goals`, `goal_milestones`; индексы `goals(status,due_at,priority)`; GIN по `kpi`.

2) Процессор (`backend/app/services/processor_scheduler.py`):
   - В `_process_one` добавить обработку kinds: `goal_signal`, `goal_assess`, `goal_adjust`:
     - `goal_signal`: обновить `goals.current_value`, проверить достижение, записать `quant_links(advances|achieves)`.
     - `goal_assess`: вычислить KPI‑статус (`ok|at_risk|off_track`), записать инцидент при отклонении, опционально поставить событие `goal_adjust`.
     - `goal_adjust`: при Two‑Keys разрешении обновить `target_value|due_at|priority`, записать `quant_links(adjusts)`.
   - Идемпотентность по `dedup_key`.

3) Ядро Соул (`backend/app/services/soul_core_manager.py`):
   - Stateless `generate_quants(..., db=None, signature_ctx=ctx)` для формулировки следующего шага к цели (текст/инструкция) — Квант класса `goal_progress`.

4) Hyperloop (`backend/app/services/hyperloop_engine.py`):
   - Инъекции `goal_*` через общий `PROCESSOR.EVENT.INJECT`.
   - Two‑Keys для `goal_adjust` — подтверждение через `TWO_KEYS.REQUEST/APPROVE`.

5) Инспекторы (P27/P29):
   - Проверять наличие шагов P27; добавить плагин качества `p30.goal_consistency` (в перспективе) — соответствие `current_value<=target_value`, корректность связей.

6) Acceptance (smoke):

   - Инъекция `goal_signal` и `goal_assess` → `PROCESSOR.PROCESS_ONCE` возвращает ok; `goals`/`quant_links` обновлены; трасса шагов соответствует P27.

## 28) Связь Квантов и Календарь (детализация)

Цель: детерминированно обработать календарные события/напоминания, порождая Кванты по предназначению «выполнение/коррекция расписания», с гарантией уведомления, учёта сдвигов/повторов и фиксации связей.

Источники активации:

- due‑события календаря (start, pre‑notify, end), изменения события (перенос/отмена), RRULE‑повторы, смена TZ/DST.
- напоминания (P17): ручные/автоматические, snooze/reschedule.

Классы Квантов:

- `calendar_support` (поддержка выполнения расписания), `schedule_adjustment` (сдвиг/перенос), `reminder_trigger` (уведомление), `availability_block` (бронь слотов).

Поведение Процессора:

- При активации формирует Квант класса по контексту события, инициирует действие (уведомление/бронь/сдвиг), создаёт подтверждающий Квант.
- Решает тактику: прямое действие (уведомить/сдвинуть), запрос уточнения (новый Квант), чтение ответа из ранних Квантов.

### 28.1 Контракты данных и связи

Сущности (P17/P26):

- `calendar_events(id, user_id, title, start_at, end_at, tz, rrule, status, meta jsonb)`
- `reminders(id, user_id, due_at, status, snooze_count, meta jsonb)`
- `quant_links(id, from_quant, to_entity_type, to_entity_id, relation_type, weight float, created_at)`

Связи:

- Квант→Календарь: `relation_type='triggers'|'updates'|'confirms'|'snoozes'` (due/изменение/подтверждение/отложено).
- Идемпотентность: ключ `dedup_key = <entity_id>:<due_at|start_at>` на уровне события.

Политики:

- TZ/DST: все вычисления в UTC, хранить исходный `tz` в meta; при сдвиге пересчитывать `due_at`.
- RRULE: генерировать следующий повтор при `status='done'|snoozed`.

### 28.2 Интеграция с петлёй Процессора

- perceive: собрать `event_id|reminder_id`, времена, tz, RRULE, конфликтующие слоты.
- appraise: приоритет = срочность (t_now→due) и важность события; бюджет нотификации.
- decide: `notify|reschedule|block|ignore` (по политике и контексту).
- act: выполнить действие/уведомление; создать/обновить `quant_links` и статусы `calendar_events|reminders`.
- observe: ожидать ACK (read/confirm); при отсутствии — ретрай/эскалация/snooze.
- learn: корректировать пороги срочности/окна нотификации, веса конфликтов.

Шаги подписи: `svc.processor.*` + при нотификациях ядра `svc.chat.reply_render`; Hyperloop действия — `cmd.hyperloop.*`.

### 28.3 Hyperloop (P36) — команды и сценарии

- Инъекция due: `PROCESSOR.EVENT.INJECT kind=calendar_event_due payload={"event_id":"e-1","user":{"id":468326902}}`
- Инъекция напоминания: `PROCESSOR.EVENT.INJECT kind=reminder payload={"reminder_id":"r-1","user":{"id":468326902}}`
- Обработка одного: `PROCESSOR.PROCESS_ONCE`
- Трасса: `CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"`

Пример:

```powershell
$B=@{ commands='PROCESSOR.EVENT.INJECT kind=calendar_event_due payload={"event_id":"e-1","tz":"Europe/Moscow"}\nPROCESSOR.PROCESS_ONCE' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri '{API_BASE}/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B
```

### 28.4 Acceptance (Календарь)

- При due создаётся Квант `calendar_support`, пишется `quant_links(triggers)` к `calendar_events.id` и отправляется уведомление (или бряцается обработчик эффектора).
- При snooze обновляется `reminders.due_at`, пишется `quant_links(snoozes)`; создаётся подтверждающий Квант.
- При переносе события — `schedule_adjustment`: новое время сохранено, связи обновлены, следующий RRULE рассчитан.
- В `signature_steps` присутствуют шаги P27; Hyperloop сценарии возвращают `trace_id`.

### 28.5 Наблюдаемость/метрики

- `processor.calendar.notifications_sent` / `notifications_missed`
- `processor.calendar.snoozed_count`, `rescheduled_count`
- `processor.calendar.on_time_delivery_rate`
- p95 `processor.calendar.notify_latency_ms` (due→ACK)

### 28.6 Пошаговая реализация (код)

1) Схема БД (Alembic):
   - Проверить наличие `calendar_events`, `reminders` (P17/P26) и `quant_links`.
   - Индексы: `calendar_events(start_at,end_at,status)`, `reminders(due_at,status)`; GIN по `meta`.

2) Процессор (`backend/app/services/processor_scheduler.py`):
   - В `_process_one` добавить обработку kinds: `calendar_event_due`, расширить `reminder`:
     - Создать/обновить `quant_links` с `relation_type` по действию.
     - При нотификации записать инцидент `calendar_notified` и/или обновить `reminders.status='sent'`.
     - При snooze — обновить `reminders.due_at`, `snooze_count++`, зафиксировать `svc.processor.act`.
   - Соблюдать идемпотентность по `dedup_key`.

3) Ядро Соул (`backend/app/services/soul_core_manager.py`):
   - Для сообщений‑напоминаний использовать stateless `generate_quants(..., db=None, signature_ctx=ctx)` для классификации/формирования текста нотификации, класс `reminder_trigger`.

4) Hyperloop (`backend/app/services/hyperloop_engine.py`):
   - Разрешить инъекции `calendar_event_due`/`reminder` через `PROCESSOR.EVENT.INJECT` (уже поддерживается общим хендлером);
   - Опционально: `PROCESSOR.BATCH kind=reminder count=N process=true` для генерации пачки due.

5) Инспекторы (P27):
   - Убедиться, что `signature.required_steps.single` включает шаги из P27/P30; прогон `INSPECTOR.RUN_ALL` должен быть «зелёным» при активном трафике календаря.

6) Acceptance (smoke):
   - Инъекция `calendar_event_due` и `reminder` → `PROCESSOR.PROCESS_ONCE` возвращает ok;
   - В БД: обновлены статусы `reminders`, в `quant_links` присутствуют связи `triggers|snoozes|confirms`;
   - Трасса `TRACE.STEPS` показывает обязательные шаги; метрики `processor.calendar.*` инкрементируются.
