# P36 — ТЗ: Hyperloop DSL (единая структура команд, запросов/ответов, инспекторы)

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md` — инвентарь документов каталога Soul.
- `docs/DOCS_INVENTORY_DOCS.md` — инвентарь каталога docs.
- `tmp_p_series_plan.json` — план анализа P‑серии (дубль/слияния/приоритеты).
- `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md` — политика подписи и Delivery Guard.
- `Soul/P30_TZ_Soul_Processor_v2_0.md` — интеграция событий процессора/инспекторов.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр документов.

## Индекс взаимных ссылок (P01–P46)

- P30 Processor — команды событий.
- P33 Personification — MINICHAT.REPLY и команды инспекции Mini Chat.
- P35 Processes — управление процессными цепочками.
- P45 Quant Generation Modes — использование Hyperloop для загрузки/линковки офлайн‑квантов: `QUANT.LINK`, `PROCESSOR.EVENT.INJECT plan_update|goal_assess`.
- P46 NeuroIntegrity — запуск инспекторов нейроцелостности и корректирующих команд

Версия: v1.3

Статус: Расширено DB/SCHEMA/MIGRATE/RELATION/INDEX/REINDEX, TUNNEL/DEPLOY, MACRO, LANG, GPU/Concurrency/SELFTEST; согласовано с P27/P28/P29/P30/P38; готово к реализации и тестированию

### 1) Назначение и область

- Единый язык управления системными модулями (флаги, инспекторы, процессор, судья/жандарм, пайплайн ядра).
- Поддержка внутренних вызовов (RBAC `soul.admin`) и внешних подписанных вызовов (HMAC).

### 2) Подключение и аутентификация

- Внутренний эндпоинт (RBAC): `POST /api/hyperloop/execute`
- Внешний подписанный эндпоинт: `POST /api/hyperloop/execute-signed`
  - Поля: `key`, `ts` (unixtime), `sig` = HMAC_SHA256(`${key}:${ts}:${commands}`, secret)
  - Валидация времени: |now - ts| ≤ 300 сек
  - Разрешение: флаг `hyperloop.allow_signed=true` (ENV/Settings)

### 3) Формат запроса

```json
{
  "commands": "...multi-line DSL...",
  "options": {"stop_on_error": true}
}

```

- Разделитель команд: перевод строки
- Модификаторы: `DRY_RUN`, `WITH TRACE`, `EXPECT key=value`, `TIMEOUT=ms`
- ВАЖНО: поле `commands` — строго СТРОКА, а не массив.

### 4) Базовые команды (напоминание)

- `FLAGS.SET|UNSET|APPLY_PROFILE|STATE`
- `TRACE.STEPS trace_id=<uuid>`
- `SANITIZER.PREVIEW text="..."`
- `INSPECTOR.RUN key=<key>` / `INSPECTOR.RUN_ALL [scope=*|sanitizer|signature|processor]`

#### 4.2 Быстрое подключение LLM‑агентов и зеркалирование (обновлено)

- SESSION:
  - `SESSION.CLAIM owner=<tg_id> branch=<key> [topic=<t>] [ttl_sec=<n>] [session=<id>]`
  - `SESSION.PING owner=<tg_id> session=<id> [session_ttl_sec=<n>]`
  - `SESSION.RELEASE branch=<key> [owner=<tg_id>] | SESSION.RELEASE session=<id>`
- DEV:
  - `DEV.CONNECT owner=<tg_id> branch=<key> [session=<id>] [ttl_sec=<n>] [session_ttl_sec=<n>]`
  - Шаг подписи (обязательно): `cmd.hyperloop.dev.connect`.
  - Модификаторы: допускается `WITH TRACE`/`DRY_RUN` (в DRY_RUN — только проверка параметров, без побочных эффектов).
  - Ответ:
    - Успех: `{ ok: true, data: { claim: {...}, ping: {...|null} } }`
    - Ошибка: `{ ok: false, error: "..." }`
  - Метрики (наблюдаемость):
    - `dev_connect_total{status="success|error"}` — счётчик попыток.
    - `dev_connect_latency_ms{status}` — latency одной операции; мониторим p50/p95.
  - Алерты: рост `401|404|422` и таймаутов (502/504).
  - Совместимость многопользовательских локов:
    - Рекомендуется указывать `session=<id>`: при `DEV.CONNECT` выполняется `claim_branch` c привязкой к сессии и heartbeat `SESSION.PING`.
    - Инспектор `plan.branch` поддерживает shared‑локи: для одной ветки может существовать несколько владельцев (owners) с разными `session`.
    - `INSPECTOR.RUN key=plan.branch action=list` возвращает `locks.branches[branch_key].owners{ owner_id → { owner, session, ts, topic } }` (legacy: `{ owner, session, ts }`).
- LLM:
  - `LLM.MIRROR owner=<tg_id> branch=<key> topic=<t> user_command="..." agent_reply="..." [plan_task_id=<uuid>] [success=<0|1>]`
  - `LLM.MIRROR.BATCH items=[{...}]`

Примеры (PowerShell, Windows):

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
$B=@{ commands='DEV.CONNECT owner="468326902" branch="p48r-dev"' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

```

### 5) Наблюдаемость/подпись

- Все команды фиксируют шаги `cmd.hyperloop.*` в `signature_steps`.
- Для `DEV.CONNECT` обязательно присутствует `cmd.hyperloop.dev.connect`.

### 6) Ошибки и коды (добавлено)

- `unknown command` — команда не известна парсеру/диспетчеру; сверить версию сервиса.
- `auth_forbidden|timeout|url_malformed` — причины для автосоздания инцидентов P50 (см. P50).

### 7) Примеры

```text
SESSION.CLAIM owner="468326902" branch="p48r-dev" topic="planning" session="dev-001"
DEV.CONNECT owner="468326902" branch="p48r-dev" WITH TRACE
LLM.MIRROR owner="468326902" branch="p48r-dev" topic="dev" user_command="ping" agent_reply="pong"

```

Ответы нормализуются фасадом Python в `{ ok, results:[], meta:{}, signature:{} }`. Побочные эффекты (БД) выполняются на Python‑стороне; RS остаётся read‑only.

#### 4.1 Примеры для новых инспекторов (P40/P48)

- Ветвление/блокировки задач (P40 `plan.branch`):
  - Базовые команды:
    - `INSPECTOR.RUN key=plan.branch action=list`
    - `INSPECTOR.RUN key=plan.branch action=claim_branch branch=P45/ingest/qc owner=468326902 ttl_sec=172800`
    - `INSPECTOR.RUN key=plan.branch action=release_branch branch=P45/ingest/qc owner=468326902`
  - Сессии блокировок (новое):
    - Блокировки могут быть привязаны к сессии разработчика `session=<id>`; при потере сессии блокировки освобождаются автоматически (GC) после `session_ttl_sec`.
    - Поддерживаются heartbeat и массовое освобождение:
      - `INSPECTOR.RUN key=plan.branch action=session_ping session=dev-001 owner=468326902 [session_ttl_sec=1800]`
      - `INSPECTOR.RUN key=plan.branch action=release_session session=dev-001`
    - Пример: заявка ветки с сессией и heartbeat
      - `INSPECTOR.RUN key=plan.branch action=claim_branch branch=P45/ingest/qc owner=468326902 session=dev-001 ttl_sec=172800 session_ttl_sec=1800`
      - `INSPECTOR.RUN key=plan.branch action=session_ping session=dev-001 owner=468326902`
    - Поведение при конфликте: активная ветка конфликтует только если её сессия жива; при утрате сессии или истечении `session_ttl_sec` ветка считается свободной.

- Зеркалирование действий LLM-агента (P48 `llm.mirror`):
  - `INSPECTOR.RUN key=llm.mirror owner=468326902 topic=dev.ops user_command="ping" agent_reply="pong" success=true`
  - Примечания:
    - Сервис формирует корректный массив тегов `tags` в формате `text[]` и возвращает `quant_id`.
    - При необходимости предусмотрен `dry_run=true` для диагностики без записи в БД.

Наблюдаемость:

- В ответах инспекторов статус `ok|passed|success` трактуется как успешный.
- Все вызовы фиксируют шаги `cmd.hyperloop.inspector.run` в `signature_steps`.

### 5) Новые команды P38 (NeuroTraining)

#### 5.1 BATCH.GENERATE_QUANTS

- Назначение: пакетная генерация квантов через ядро с опцией использования DB‑контекста.
- Синтаксис:
  - `BATCH.GENERATE_QUANTS n=<int> [input_text="..."] [topic="..."] [use_db_for_models=true|false] [append=true|false] [DRY_RUN] [TIMEOUT=ms]`
- Параметры:
  - `n` — количество кандидатов.
  - `input_text|topic` — текстовая постановка задачи.
  - `use_db_for_models` — подмешивать контекст из БД на этапах подстройки (по умолчанию false).
  - `DRY_RUN` — без выполнения, возврат планируемых параметров.
  - `TIMEOUT` — верхняя граница времени исполнения в миллисекундах.
- Выход:
  - `{ ok: true, data: { items: [ ... ], n, use_db_for_models } }`
- Замечания по безопасности: STRICT_JSON; в stateless ветке `desired_action=[]`.
- `append=true` — накапливает результат в `train.last_batch` вместо перезаписи (для порционной генерации).

Примеры:

- `BATCH.GENERATE_QUANTS n=2 input_text="P38 DSL smoke" DRY_RUN`
- `BATCH.GENERATE_QUANTS n=2 input_text="Целевая генерация квантов о напоминаниях на завтра" use_db_for_models=true`
- `BATCH.GENERATE_QUANTS n=2 input_text="Сгенерируй кванты напоминаний" use_db_for_models=true TIMEOUT=45000`

#### 5.2 TRAIN.EVAL.LAST_BATCH

- Назначение: оценка последнего сохранённого батча (`train.last_batch`).
- Синтаксис: `TRAIN.EVAL.LAST_BATCH`
- Выход (метрики):
  - `count`, `non_empty_thought`, `json_validity`, `avg_energy_weight`, `tags_present_count`, `avg_weighted_score`, `weights{alpha..epsilon}`
- Поведение:
  - Поддерживается хранение прошлого батча как массива либо как объекта `{ items, n, input_text, ts }`.

#### 5.3 LEARN.APPLY_FEEDBACK

- Назначение: фиксация обратной связи для цикла обучения.
- Синтаксис: `LEARN.APPLY_FEEDBACK mode={reinforce|decay} window=<dur> [DRY_RUN]`
- Пример: `LEARN.APPLY_FEEDBACK mode=reinforce window=24h`

#### 5.4 TRAIN.LAST_BATCH.NORMALIZE

- Назначение: нормализует и пересохраняет `train.last_batch` строгим JSON (устраняет исторические строки с одинарными кавычками).
- Синтаксис: `TRAIN.LAST_BATCH.NORMALIZE`
- Выход: `{ ok, data: { count, meta } }`

#### 5.5 TRAIN.METRICS.WINDOW

- Назначение: агрегированные метрики по квантам за окно.
- Синтаксис: `TRAIN.METRICS.WINDOW window=<dur>` где `<dur>`: `60m|24h|7d|<seconds>`
- Метрики: `count`, `non_empty_thought`, `avg_energy_weight`, `tags_present_count`
- Примеры:
  - `TRAIN.METRICS.WINDOW window=24h`
  - `TRAIN.METRICS.WINDOW window=7d`
  - `TRAIN.METRICS.WINDOW window=60m`

#### 5.6 TRAIN.WEIGHTS.SET / TRAIN.WEIGHTS.GET

- Назначение: установка/чтение весов формулы качества (см. П38 §Алгоритмы).
- Синтаксис:
  - `TRAIN.WEIGHTS.SET alpha=<float> beta=<float> gamma=<float> delta=<float> epsilon=<float>`
  - `TRAIN.WEIGHTS.GET`
- Примеры:
  - `TRAIN.WEIGHTS.SET alpha=1.0 beta=1.0 gamma=1.2 delta=1.5 epsilon=0.8`
  - `TRAIN.WEIGHTS.GET`

### 6) Модификаторы и поведение (включая RT)

- `DRY_RUN` — команда не исполняется, возвращаются планируемые параметры.
- `WITH TRACE` — формирует trace и обязательные шаги подписи (`cmd.hyperloop.*`, `svc.soul.*`, `svc.parser.json_strict`).
- `TIMEOUT=ms` — максимальная длительность операции (best‑effort); при таймауте допустим частичный результат или ошибка шлюза.
- `append=true|false` — для порционной генерации (`BATCH.GENERATE_QUANTS`), накапливает batсh с последующей оценкой.

Дополнения (Stage‑2 Provenance):

- При включённом флаге `provenance.enabled=true` движок фиксирует минимальные рёбра причинности даже в stateless‑сценариях: `input` и `llm:response`. При наличии `quant_id` он подставляется в рёбра (идемпотентно, `ON CONFLICT DO NOTHING`).
- Проверка наличия рёбер для трассы: `GET /api/admin/provenance/trace/{trace_id}`; экспорт: `GET /api/admin/provenance/export/openlineage/{trace_id}`.
- Для одиночного квант‑процесса проверка по `quant_id`: `GET /api/admin/provenance/quant/{quant_id}`.

### 7) Примеры сценариев P38 (сборка и RT)

- Пакетная генерация → оценка → фидбек → метрики окна:

  1) `BATCH.GENERATE_QUANTS n=10 input_text="Анализ напоминаний на завтра" use_db_for_models=true`
  2) `TRAIN.EVAL.LAST_BATCH`
  3) `LEARN.APPLY_FEEDBACK mode=reinforce window=24h`
  4) `TRAIN.METRICS.WINDOW window=24h`

- Порционная генерация с накоплением и нормализацией:
  - `BATCH.GENERATE_QUANTS n=2 input_text="..." use_db_for_models=true append=true`
  - `BATCH.GENERATE_QUANTS n=2 input_text="..." use_db_for_models=true append=true`
  - `TRAIN.LAST_BATCH.NORMALIZE`
  - `TRAIN.EVAL.LAST_BATCH`
- RT‑смоки:
  - `CORE.PIPELINE.RUN input_text="RT gap-closure smoke" WITH TRACE TIMEOUT=1200`
  - `BATCH.GENERATE_QUANTS n=3 input_text="RT micro-batch" append=true TIMEOUT=3000`
- A/B калибровка весов:
  - Профиль A: `TRAIN.WEIGHTS.SET alpha=1.0 beta=1.0 gamma=1.0 delta=1.5 epsilon=0.8` → `BATCH.GENERATE_QUANTS ...` → `TRAIN.EVAL.LAST_BATCH`
  - Профиль B: `TRAIN.WEIGHTS.SET alpha=1.0 beta=1.0 gamma=1.4 delta=1.0 epsilon=1.2` → `BATCH.GENERATE_QUANTS ...` → `TRAIN.EVAL.LAST_BATCH`

### 8) Инварианты и безопасность

- STRICT_JSON для ответов; отсутствие видимых тех‑блоков; NEGATIVE‑санитайзер.
- RBAC/Two‑Keys для потенциально рискованных TRAIN‑операций (см. P32/P29): заявка→approve→execute.

### 9) Наблюдаемость/подпись

- Примеры событий процессора:
  - `PROCESSOR.EVENT.INJECT kind=neurotrain.report payload={}` — отправка отчёта в Telegram архитектору.
  - `PROCESSOR.EVENT.INJECT kind=neurotrain.report.verify payload={}` — проверка получения отчёта (ACK) и перепланирование напоминания.
- Все команды фиксируют шаги `cmd.hyperloop.*` в `signature_steps`; ключевые стадии ядра: `svc.soul.preanalysis`, `svc.llm_client.send/recv`, `svc.parser.json_strict`, `svc.soul.router_decide`, `svc.chat.reply_render`.

INFRA/таймауты (рекомендации для стабильности внешних смоков):

- На уровне Nginx для backend‑локаций выставить `proxy_read_timeout 120; proxy_send_timeout 120;`.
- При отладке сетевого слоя использовать локальные вызовы `127.0.0.1:8000` для исключения влияния прокси.

### 4) Формат ответа (нормализованный)

```json
{
  "ok": true,
  "trace_id": "uuid|optional",
  "results": [
    { "command": "...", "ok": true, "data": {...} },
    { "command": "...", "ok": false, "error": "..." }
  ],
  "signature": {"steps": [...], "trace_id": "..."},
  "incidents": [],
  "tests": [],
  "flags": {},
  "meta": {"version": "2.9"},
  "errors": []
}

```

### 5) Грамматика команд (MVP)

- FLAGS
  - `FLAGS.SET key=<k> value=<json|scalar>`
    - Для чувствительных ключей требуется `request_id=<UUID>` (Two-Keys): `delivery_guard.enforce`, `hyperloop.allow_signed`, `processor.enabled`
  - `FLAGS.UNSET key=<k>`
  - `FLAGS.APPLY_PROFILE name=<profile>` (см. P28)
  - `FLAGS.RECONCILE policy=<p27|...>` — привести инварианты/политики к эталону (например, P27)
- ACTOR
  - `ACTOR.ROUTER.DECIDE input_text="..." context_data={<json>}`
- INSPECTOR
  - `INSPECTOR.RUN key=<id>`
  - `INSPECTOR.RUN_ALL [scope=<sanitizer|signature|processor|*>]`
- TEST
  - `TEST.RUN key=<test_key>`
- SKILL
  - `SKILL.TEST key=<skill_test_key> [context_json={<json>}]` — запуск теста цепочки навыка через Жандарма
  - `SKILL.SUITE category=<skills|skill_chain|...> [filter=<pattern>]` — запуск набора тестов по категории
- JUDGE
  - `JUDGE.CHARTER.UPSERT name=<n> version=<v> text="..." [category=<c>] [enforced=true]`
  - `JUDGE.CHECK code="..."`
- QUANT/GOAL
  - `QUANT.CREATE thought_form="..." [tags=[...]] [energy_weight=<float>]`
  - `QUANT.LINK from_quant=<uuid> to_type=<...> to_id=<id> relation=<...>`
  - `QUANT.LINK.CHECK from_quant=<uuid> [to_type=<...>] [to_id=<...>]`
  - `GOAL.CREATE quant_id=<uuid> [title="..."] [description="..."] [priority=<float>] [status=active]`
- SCHEMA
  - `SCHEMA.COLUMNS table=<name>`
  - `SCHEMA.ENSURE_QUANT_LINKS`
- PROCESSOR (P30)
  - `PROCESSOR.ENABLE|DISABLE`
  - `PROCESSOR.POLICY.SET key=<k> value=<json>` (или `value_json=<json>`)
  - `PROCESSOR.EVENT.INJECT kind=<k> payload=<json> [priority=<n>] [due_at=<ts>] [dedup_key=<id>]` (или `payload_json=<json>`)
  - `PROCESSOR.PROCESS_ONCE`
  - `PROCESSOR.PROCESS_EVENT id=<uuid>`
- CORE
  - `CORE.PIPELINE.RUN input_text="..." num_candidates=<n> [WITH TRACE]`
  - `TRACE.STEPS trace_id=<uuid>`
  - `CORE.TRACE.REQUIRE chain="a,b,c"`
  - `CORE.MSG.AUDIT event="..." meta=<json>`
- EXPERIMENTS (P04)
  - `EXPERIMENTS.REGISTER key=<str> a_json={<overridesA>} b_json={<overridesB>} [notes="..."]`
  - `EXPERIMENTS.AB.RUN key=<str> [cases_path=<path>|cases="c1|c2|..."] [case=<single>] [n=<int>] [reflect=<true|false>]`
  - `EXPERIMENTS.AB.PUBLISH key=<str> [winner=A|B] [request_id=<UUID>]`
  - Политики и дефолты:
    - По умолчанию для внешних смоков `n=1`, `reflect=false` (изменяемо параметрами)
    - Публикация требует Two‑Keys подтверждения (`request_id`) — иначе ошибка policy
    - В ответе AB.RUN возвращаются агрегированные KPI и `p95_latency_ms` по вариантам; при `reflect=false` выполняется выборочная рефлексия победителя `winner_reflect`
- DB / SCHEMA / MIGRATE / RELATION / INDEX (v1.2)
  - `DB.SEARCH table=<name> where={<json>|<sql>}`
  - `DB.INSERT table=<name> values=<json>`
  - `DB.UPSERT table=<name> key=<col|cols> values=<json>`
  - `DB.DELETE table=<name> where={<json>|<sql>}`
  - `SCHEMA.ENSURE table=<name> ddl="..."`
  - `MIGRATIONS.STATUS`
  - `MIGRATIONS.APPLY revision=<rev|head>`
  - `RELATION.CREATE from=<table>:<id> to=<table>:<id> type=<name> [weight=<float>]`
  - `RELATION.DELETE from=<...> to=<...> [type=<name>]`
  - `INDEX.REBUILD table=<name> [name=<idx>]`
  - `REINDEX.ALL`
- PROCESS (очереди процессора)
  - `PROCESS.QUEUE.STATUS`
  - `PROCESS.QUEUE.REORDER strategy=priority_first_fifo [apply=true]`
- REQUEST (Архивариус)
  - `REQUEST.CREATE type=<t> subject="..." payload={<json>}`
  - `REQUEST.STATUS id=<uuid> status=<new|done|...>`
  - `REQUEST.LIST [status=<filter>]`
- TUNNEL (v1.2)
  - `TUNNEL.OPEN name=<id> target=<host:port|unix> [lport=<n>] [ttl=<dur>]`
  - `TUNNEL.CLOSE name=<id>`
  - `TUNNEL.STATUS [name=<id>]`
- NET (v1.3)
  - Принципы: RBAC только `sysadmin`, опасные — Two‑Keys; DRY_RUN/EXPECT поддерживаются; все операции аудируются в подписи (P27).
  - `NET.FW.STATUS` — текущее состояние (enabled, profile, allow/deny lists)
  - `NET.FW.APPLY_PROFILE name=<prod_lockdown|dev_fast|diagnostics_on>` — применить профиль фаервола (Two‑Keys при смене профиля в PROD)
  - `NET.FW.ALLOW domain=<host|*.domain> [port=<n>|ports="443,80"] [ttl=<dur>]` — добавить в allow‑list (опц. TTL)
  - `NET.FW.DENY domain=<host|*.domain> [port=<n>|ports="..."]` — добавить в deny‑list (приоритетнее allow)
  - `NET.FW.TEST url=<https://...>` — быстрый HEAD/GET тест с таймаутом (best‑effort)
  - `NET.FW.KILL_SWITCH ttl=<dur>` — экстренное закрытие всего egress (кроме критически необходимых) на TTL; создаёт инцидент P29
  - `NET.ROUTE.SHOW [table=<core|dmz|tools>]` — показать маршруты
  - `NET.ROUTE.ADD dest=<cidr> via=<gw> [table=<name>]` — добавить маршрут
  - `NET.ROUTE.DEL dest=<cidr> [table=<name>]` — удалить маршрут
  - `NET.ACCESS.WINDOW OPEN tag=<purpose> [ttl=<dur>] [domains=[...]]` — открыть egress‑окно по тегу
  - `NET.ACCESS.WINDOW CLOSE tag=<purpose>` — закрыть окно
  - `NET.SERVICE.PORT.SWITCH service=<backend|worker|...> port=<n>` — перевести сервис на новый порт (Two‑Keys), синхронно обновив прокси/health
  - `NET.DARKNET.ENABLE [egress_allow=["*.onion:80","*.onion:443"]] [request_id=<UUID>]` — включить управляемый выход в Tor (Two‑Keys)
  - `NET.DARKNET.DISABLE [request_id=<UUID>]`
  - `NET.DARKNET.STATUS` — состояние darknet шлюза и разрешений
- DEPLOY (v1.2)
  - `DEPLOY.RESTART unit=soulpulse-backend.service`
  - `DEPLOY.NGINX.RELOAD`
  - `DEPLOY.CHECK`
- MACRO (v1.2)
  - `MACRO.RUN key=<name> [args=<json>]`
  - `MACRO.LIST`
- LANG (v1.2)
  - `LANG.SET key=<path> value={<json>|<scalar>}`
  - `LANG.GET key=<path>`
- GPU/CONCURRENCY/SELFTEST (v1.2)
  - `GPU.STATUS`
  - `CONCURRENCY.LIMITS set send_threads=<n> parse_threads=<m>`
  - `SELFTEST.RUN key=<id>`
- SANITIZER
  - `SANITIZER.ADD name=<n> pattern="<regex>"`
  - `SANITIZER.REMOVE name=<n>`
  - `SANITIZER.PREVIEW text="..."`
- MINICHAT
  - `MINICHAT.REPLY input_text="..." [persona=<key>] [include_context=true] [recent_ratio=0.3] [WITH TRACE]`

### 5.1) Правила процедур тестирования (P36/P29)

Примеры сценариев:

```text
INSPECTOR.RUN key=signature.required_steps.consistency
INSPECTOR.RUN_ALL scope=signature
CORE.PIPELINE.RUN input_text="health check" WITH TRACE
CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.soul.router_decide,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"
FLAGS.RECONCILE policy=p27
PROCESSOR.POLICY.SET key=block.chat_message value_json="{\"enabled\":false}"
PROCESSOR.EVENT.INJECT kind=chat_message payload_json="{\"text\":\"processor ping\"}" priority=5
ACTOR.ROUTER.DECIDE input_text="План на неделю" context_data={"user_id":468326902}
PROCESS.QUEUE.STATUS
PROCESS.QUEUE.REORDER strategy=priority_first_fifo apply=true
MINICHAT.REPLY input_text="Мини‑смок MiniChat" persona="prompt-4" include_context=true recent_ratio=0.3 WITH TRACE

```

Профили Hyperloop (через FLAGS.APPLY_PROFILE):

```text
FLAGS.APPLY_PROFILE name=prod_safe
FLAGS.APPLY_PROFILE name=diagnostics_on
FLAGS.APPLY_PROFILE name=dev_fast
FLAGS.APPLY_PROFILE name=dev_full

```

### 6) Интеграция c реестрами (P27/P28/P29/P30)

- P27 (Signature/Guard):
  - Обязательные шаги в Settings: `signature.required_steps.*`
  - Проверка цепочек: `CORE.TRACE.REQUIRE`; Guard на уровне ответов — флаг `delivery_guard.enforce`
- P28 (Feature Flags / Inspectors):
  - Флаги — через `FLAGS.*`
  - Инспекторы — зарегистрированы в БД (`feature_inspectors`) или как плагины и вызываются `INSPECTOR.RUN*`
- P29 (Gendarme/Judge):
  - Тесты запускаются `TEST.RUN key=...`
  - Судья управляется `JUDGE.*`
  - Навыки: профилированные прогоны Suite — сначала `FLAGS.APPLY_PROFILE`, затем `SKILL.SUITE category=skill_chain`
- P30 (Processor):
  - Управление флагами/политиками/очередью — через `PROCESSOR.*`

### 7) Плагины и инспекторы

- Плагины размещаются в `backend/app/gendarme_tests/*` и `backend/app/feature_plugins/*` или указываются в реестрах БД (module/callable)
- Контракт плагина:

```python
async def run(db: AsyncSession, context: dict | None = None) -> dict:
    return {"status": "passed|failed", "detail": "...", "metrics": {...}}

```

- Вызов через Hyperloop: `INSPECTOR.RUN key=<id>`

### 8) Ошибки и коды

- 400 — `stale timestamp`, `invalid payload`
- 403 — `signed access disabled`, `invalid key`, `invalid signature`
- 500 — `engine error`, `handler error`
- Внутри `results[]`: `ok=false`, `error="..."`
- Частые ошибки интеграции DSL:
  - `Field required: body.commands`
  - `string_type for body.commands`

### 9) Примеры

```text
FLAGS.SET key="delivery_guard.enforce" value=true
FLAGS.SET key=processor.enabled value=true request_id=<UUID>
PROCESSOR.POLICY.SET key="block.all" value={"enabled": true}
PROCESSOR.EVENT.INJECT kind="chat_message" payload={"text":"hi"} priority=10
PROCESSOR.PROCESS_ONCE EXPECT processor.enabled=true
INSPECTOR.RUN key="sanitizer.patterns_consistency"
TEST.RUN key="p29.pipeline_smoke"
JUDGE.CHARTER.UPSERT name="core_safety" version="v1" text="no dangerous ops" enforced=true
JUDGE.CHARTER.UPSERT name="core_safety" version="v2" text="strict" enforced=true request_id=<UUID>
JUDGE.CHECK code="no dangerous ops here"
SKILL.TEST key="skill_chain.golden_eval.demo.skill"
SKILL.SUITE category=skill_chain

```

### 9.1 Примеры DSL: PROCESSOR.EVENT.INJECT и PROCESSOR.PROCESSОНCE

Одна команда на строку, поле `commands` — строка.

```text
# Инъекция чат-события (payload встраиваем строкой)
PROCESSOR.EVENT.INJECT kind=chat_message payload={"text":"ping"} priority=10 dedup_key="chat:468326902:ts-123"

# Тот же сценарий с payload_json (удобно для сложного JSON)
PROCESSOR.EVENT.INJECT kind=chat_message payload_json="{\"text\":\"ping\",\"meta\":{\"lang\":\"ru\"}}"

# Обработка одного события из очереди
PROCESSOR.PROCESS_ONCE EXPECT processor.enabled=true

# Комбинация: due напоминание + обработка
PROCESSOR.EVENT.INJECT kind=reminder payload={"reminder_id":"r-1","user":{"id":468326902}}
PROCESSOR.PROCESS_ONCE

# WITH TRACE для ядра (связанные сценарии)
CORE.PIPELINE.RUN input_text="health check" WITH TRACE
TRACE.STEPS trace_id="<UUID>"

```

### 5.2) Секреты (SECRET.*) и защищённое хранилище

- Назначение: безопасное управление чувствительными ключами (LLM, Hyperloop HMAC) без хранения в файловой системе.
- Команды:

```text
SCHEMA.SECRETS.ENSURE
SECRET.SET key=deepseek_api_key value="sk-***" request_id=<UUID>
SECRET.GET key=deepseek_api_key

```

### 5.3) Ветвление процессов (PROCESS.FORK/NODE/NEXT)

- Команды:

```text
PROCESS.FORK name=architect_review nodes=plan|exec|observe
PROCESS.NODE branch=plan flow=architect_review
PROCESS.NODE branch=exec flow=architect_review
PROCESS.NEXT flow=architect_review

```

### Валидатор и нормализация Hyperloop DSL (Frontend)

- Общая функция нормализации: `frontend/src/utils/hyperloopDsl.ts` (`normalizeHyperloopDSL(text)`)
- Общий компонент: `frontend/src/components/HyperloopDSLValidator.tsx`
  - Используется на страницах: `RSDashboard.tsx`, `GendarmePanel.tsx`, `AdminPanel.tsx`
  - Поведение: единая нормализация кавычек/escape, переводов строк в `;`, схлопывание пробелов вне кавычек, трим вокруг `=`

### Two-Keys в RS Dashboard

- Блок управления профилями выполнения: выбор `prod_safe | dev_full | rs_canary_profile`
- Операции:
  - `TWO_KEYS.REQUEST operation=FLAGS.APPLY_PROFILE scope="rs.profile" reason="..." ttl_minutes=5`
  - `TWO_KEYS.APPROVE id="<uuid>"`
  - `FLAGS.APPLY_PROFILE name="<profile>" two_keys_request_id="<uuid>"`
- UI: поля причины, request_id, кнопки создания/одобрения заявки и применения профиля

### RS Dashboard — метрики, сырые Prometheus и тренды

- Сводка p95/p99 per op (`rsbus_latency_ms`) и per phase (`hyperloop_rs_latency_ms`)
- Сырые метрики Prometheus: `/api/admin/rs/metrics-raw` (просмотр в UI)
- Топ ошибок по классам: агрегация `rsbus_errors_total{class="..."}`
- Тренды p95/p99: секция "Тренды..." с выбором источника (op/phase) и ключа; данные из `rs_nightly_reports` (последние записи)

### Nightly отчёты (Backend)

- Эндпоинты: `/api/admin/rs/nightly/generate`, `/api/admin/rs/nightly/recent` (см. `backend/app/routers/rs_nightly_admin.py`)
- Таблица: `rs_nightly_reports(id, generated_at, window_days, summary jsonb, diff_7d jsonb, created_at)`
- Фоновая задача: `RSNightlyReportsBackgroundTask` (см. `backend/app/background_tasks.py`), автозапуск в `main.py`
- Настройки:
  - `rs.nightly.interval_sec` — интервал генерации (по умолчанию 86400)
  - `rs.nightly.window_days` — окно сбора (по умолчанию 1)
- Diff 7 дней: рассчитываются дельты p95/p99 текущего значения к средним за 7 дней по ключам

### Acceptance (обновления)

- Валидатор/нормализация DSL доступен на страницах (Admin/Gendarme/RS)
- Two-Keys операции профилей работают через Hyperloop DSL и UI RS Dashboard
- Nightly отчёты генерируются фоном, отображаются последние N записей и тренды p95/p99

Дополнительно (если включён Stage‑2 Provenance):

- `WITH TRACE` даёт непустой `trace_id`, а `GET /api/admin/provenance/trace/{trace_id}` возвращает ≥ 2 рёбер (минимум `input`, `llm:response`).
- Для процессов с сохранённым квант‑результатом `GET /api/admin/provenance/quant/{quant_id}` возвращает рёбра с привязкой к `quant_id`.
- В OpenAPI присутствуют пути `/api/admin/provenance/*`.

### 12) Новые команды P40 (Project Management)

Назначение: управление проектами/планами/задачами/рисками/изменениями и репозиториями методологий/базовых настроек ролей.

Общие принципы:

- RBAC (P32) и политики (P28); для опасных операций — Two‑Keys (P29).
- Идемпотентность по `request_id|dedup_key`.
- DRY_RUN для расчётных команд.

#### 12.1 PROJECT.*

- `PROJECT.CREATE name="..." [methodology=<waterfall|iterative|agile|kanban|hybrid>] [priority=<0..1>] [owner=<tg_id>]`
- `PROJECT.GET id=<pid>` | `PROJECT.LIST [owner=<tg_id>] [status=<active|archived>]`
- `PROJECT.UPDATE id=<pid> [name=...] [priority=...] [status=<active|archived>] [methodology=<...>]`
- `PROJECT.DELETE id=<pid> [DRY_RUN]`

#### 12.2 `PLAN.*` / `TASK.*`

- `PLAN.TASK.ADD project_id=<pid> title="..." [cpm_duration_days=<float>] [assignee=<tg_id>] [start_at=<ts>] [due_at=<ts>] [priority=<0..1>]`
- `PLAN.TASK.UPDATE id=<tid> [title=...] [status=<todo|doing|done|blocked>] [progress=<0..1>] [cpm_duration_days=<float>] [start_at=<ts>] [due_at=<ts>] [assignee=<tg_id>]`
- `PLAN.TASK.DEPEND predecessor=<tid> successor=<tid> dep_type=<FS|SS|FF|SF>`
- `PLAN.TASK.UNDEPEND predecessor=<tid> successor=<tid>`
- `PLAN.CPM.CALC project_id=<pid> [WITH TRACE] [DRY_RUN]`
- `PLAN.EVM.UPDATE project_id=<pid> [date=<ts>]`

#### 12.3 `TASK.*` (алиасы)

- `TASK.UPDATE id=<tid> status=<todo|doing|done|blocked> [progress=<0..1>]`

#### 12.4 `RISK.*`

- `RISK.ADD project_id=<pid> title="..." [severity=<low|medium|high|critical>] [probability=<unlikely|possible|likely|almost_certain>] [owner=<tg_id>]`
- `RISK.UPDATE id=<rid> [title=...] [severity=...] [probability=...] [status=<open|mitigating|closed>]`
- `RISK.SCORE.CALC id=<rid> [WITH TRACE]`

#### 12.5 `CHANGE.*`

- `CHANGE.ADD project_id=<pid> title="..." [type=<scope|schedule|budget|quality>] [reason="..."]`
- `CHANGE.APPROVE id=<cid> [approved=<true|false>] [request_id=<UUID>]`

#### 12.6 `METHODOLOGY.*`

- `METHODOLOGY.LIST`
- `METHODOLOGY.GET name=<n> [version=<v>]`
- `METHODOLOGY.SET name=<n> version=<v> tree_json=<json> [ui_config_json=<json>]`

#### 12.7 `ROLE.*`

Ссылки (интеграции и реестры):

- docs/PROJECT_STRUCTURE_v8_2_0.md — карта и RS интеграция Hyperloop
- docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md — мастер‑реестр документов
- Soul/Report_Soul_AI_Scientific.md — аналоги и сводка регресса
- Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md — подпись/TRACE/Guard
- Soul/P28_TZ_FeatureFlags_Registry_and_Policies_v1_0.md — FLAGS/инспекторы
- Soul/P30_TZ_Soul_Processor_v2_0.md — PROCESSOR.* / DLQ / лимиты

 
## Мировые аналоги и практики
- RPC/Command DSL: HashiCorp Consul/Nomad (jobspec), Kubernetes kubectl apply/CRDs
- Signed API (HMAC): AWS Signature v4 `https://docs.aws.amazon.com/general/latest/gr/signature-version-4.html`
- Idempotency и EXPECT‑паттерны: Stripe Idempotency Keys `https://stripe.com/docs/idempotency`
- Tracing/Signature steps: OpenTelemetry + детерминированный JSON контракт
- Policy/Two‑Keys: GitHub protected branches/required reviews; Google BeyondCorp policy enforcement
- DSL‑нормализация (frontend): Prettier/ESLint аналогия для текстовых протоколов
