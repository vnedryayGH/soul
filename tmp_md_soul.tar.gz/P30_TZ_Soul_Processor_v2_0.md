<!-- markdownlint-disable MD037 -->

# P30 — Техническое задание: Processor/Orchestrators v2.0 (RT, надежность, масштабируемость)

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md` — инвентарь документов каталога Soul.
- `docs/DOCS_INVENTORY_DOCS.md` — инвентарь каталога docs.
- `tmp_p_series_plan.json` — план анализа P‑серии (сверка версий/дублей/приоритетов).
- `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md` — обязательные шаги подписи и Delivery Guard.
- `Soul/P36_TZ_Hyperloop_DSL_v1_1.md` — DSL/инспекторы/DEV.CONNECT/наблюдаемость.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр документов.

## 1) Цель и границы изменений

- Обеспечить надежную, предсказуемую и быструю обработку больших потоков событий в реальном времени без коренной переработки текущего решения.
- Сохранить существующие сущности/эндпоинты и P27‑подпись; расширить свойства объектов и добавить недостающие механизмы: приоритетные очереди, многопоточность/мультипроцессность, кластерный режим, строгие квоты, карантин, справедливое планирование и бэкпрешер.
- Вписать концепцию в текущие модули: `backend/app/services/processor_scheduler.py`, админ‑роуты `/api/admin/soul/processor/*`, настройки `SoulSettingsService`, RS/UDS мост (P48R), без хардкодов адресов/портов (каноника).

## 2) Требования производительности и надежности

- p95 бюджет по виду события (DB‑ключи `processor.kind_limits.<kind>.p95_budget_ms`) — обязательный контроль и авто‑карантин при нарушении.
- Ошибки по виду события ≤ `err_rate_max` (по умолчанию 1–5%) с окном ≥ 20 обработанных событий.
- Горизонтальное масштабирование: несколько воркеров `processor-worker@N` на одном APP и кластер из APP‑нод; отсутствие дублей обработки (идемпотентность, row‑locks, дедуп).
- Предсказуемая деградация: AIMD/токен‑бакеты, карантин нарушителей, аварийный режим с дренажом top‑k очередей.

## 3) Модель очереди и приоритетов

- Таблица `processor_events(id, kind, payload jsonb, priority int, due_at timestamptz, dedup_key text, status, attempts int, created_at, dispatched_at, worker_id text)`.
- Приоритетные классы (DB‑реестр/константы): system_critical > health > rs_autotune > planner/age_sync > auto_link > aux_smokes.
- Отбор батча: ORDER BY priority DESC, COALESCE(due_at, now()) ASC, created_at ASC.
- Конкурентный отбор: `FOR UPDATE SKIP LOCKED` при переводе в `status='dispatched'`, проставление `worker_id`, `dispatched_at`.
- Дедуп и идемпотентность: UNIQUE по `(dedup_key, status in ('pending','scheduled','dispatched'))`, повторная встреча — пометка `skipped` с инцидентом.

## 4) Планирование и ограничения (QoS)

- Пер‑видовые лимиты (в БД):
  - `processor.kind_limits.<kind>.{rps,max_concurrency,timeout_ms,p95_budget_ms,err_rate_max}`
  - Новые ключи: `processor.kind_priority.<kind>` (целое, маппится на классы), `processor.kind_retry.{max_attempts,backoff_ms_max}`.
- Механизмы:
  - Глобальный лимит `processor.concurrent_tasks` и «справедливая ротация» по видам (weighted round‑robin по активным kind с учётом приоритета).
  - Токен‑бакеты RPS per‑kind (неотрицательная дробь, пополнение каждый тик; пропуск без токенов запрещён).
  - Пер‑видовые семафоры `max_concurrency` и таймауты выполнения; отмена по таймауту — инцидент, экспоненциальный backoff с джиттером.
  - Карантин вида: `processor.kind_quarantine.<kind>=true` → пропуск вида на `processor.kind_quarantine.cooldown_sec` с периодической проверкой выхода.
  - Аварийный режим: ускоренный дренаж top‑k очередей по ключам `emergency.queue_drain.*` (уже реализовано), плюс принудительное отключение фоновой генерации.

### 5) Мультипроцессность/многоядерность/кластер

- systemd‑юнит `processor-worker@.service` (N экземпляров на APP) — один и тот же код `ProcessorScheduler` в worker‑режиме; конкуренция разрешается через DB‑очередь и `SKIP LOCKED`.
- Межпроцессная синхронизация не требуется (DB — источник истины); попытки фиксируются в `attempts`.
- Кластер из APP‑серверов допускается; конфликтов не будет благодаря row‑locks и дедуп‑ключам.
- CPU‑тяжёлые участки переносить в RS‑акторы через `svc.rs.proxy` (P48R), Python — control‑plane/IO/админ/API.

### 5.1) Rust‑ядро Процессора (обязательно)

- Ядро диспетчера очередей реализуется на Rust (

  Tokio multi-thread runtime, `sqlx`/`tokio-postgres` для БД, `prometheus` экспорт метрик, `tracing`):

  - Диспетчер батчей: выборка `processor_events` с `FOR UPDATE SKIP LOCKED`, перевод в `dispatched`, таймауты и отмена задач.
  - Приоритеты и WRR: внутри Rust реализуются очереди per‑kind с весами (priority→weight), токен‑бакеты (RPS) и пер‑видовые семафоры.
  - Ретраи: экспоненциальный backoff с джиттером; `attempts/next_retry_at` уважаются; dead‑letter после `max_attempts`.
  - Плагины акторов: обработчики видов (`reminder`, `chat_message`, `auto.link_quants`, ...) вызываются через шину `rsbus` или UDS‑мост `svc.rs.proxy` в Python, сохраняя P27.
- Схема развёртывания:
  - Бинарь: `rs/processor_core`.
  - systemd: `rs-processor-core@.service` (N экземпляров на APP‑сервер), единый конфиг из БД (через Python‑фасад `SoulSettingsService` или прямой read‑only доступ ключей).
  - Режимы: `processor.rs_core.enabled=true` включает Rust‑ядро как primary; `processor.rs_core.mode={primary|python_fallback|mirror}`.
- Контракты взаимодействия с Python:
  - Все публичные вызовы идут через `svc.rs.proxy` (гарантии P48R: JSON‑контракты стабильны, шаг подписи `svc.rs.proxy` обязателен).
  - Python остаётся control‑plane: админ‑API, флаги/квоты/карантин, дашборды, fallback при деградации RS.
  - P27: добавляются шаги `svc.processor.rs.dequeue`, `svc.processor.rs.dispatch`, `svc.processor.rs.observe` (минимум один из них присутствует в цепочке).
- Ключи БД (минимум):
  - `processor.rs_core.enabled` (bool), `processor.rs_core.mode` (string),
  - `processor.rs_core.batch_max_events`, `processor.rs_core.poll_interval_ms`,
  - `processor.rs_core.max_concurrency`, `processor.rs_core.default_timeout_ms`,
  - `rs.hyperloop.addr` (UDS), `rs.hyperloop.timeout_ms` (already),
  - совместимые `processor.kind_limits.*`, `processor.kind_priority.*`, `processor.kind_quarantine.*` — применяются на RS стороне.
  - Мониторинг: экспорт `processor_rs_*` метрик и зеркалирование существующих `processor.*` (p95/e2e/incidents) в единый реестр.

### 6) Интеграция с текущими видами событий (конкретика)

- reminder:
  - Приоритет: высокий (выше auto.link, ниже system_critical/health).
  - Лимиты (дефолт): `max_concurrency=16`, `rps=128`, `timeout_ms=3000`, `p95_budget_ms=1200`, `err_rate_max=0.02`.
  - Поведение при ошибке: mark `skipped`, инцидент `reminder_error`; автоматический backoff 15s→60s; волновая отправка.
- chat_message:
  - Источник: вебхук/мини‑аппа; генерация квантов через `SoulCoreManager.generate_quants` (batch, P27 подпись).
  - Лимиты: `max_concurrency=8`, `rps=32`, `timeout_ms=8000`, `p95_budget_ms=3000`.
- auto.link_quants:
  - Политика батчей: партиями по 100 элементов для инжеста/линковки [[memory:9584631]].
  - Лимиты: `max_concurrency=8`, `rps=10`, `timeout_ms=60000`, `p95_budget_ms=5000`.
- lima.sync, neuro_integrity.run, soul.dream.rewire, soul.diamond.trigger, auto.dogenerate, neurotrain.report, outbound.text — задать классы/лимиты аналогично; дефолты описаны в §10.

### 7) Прочность к сбоям и повторная обработка

- Поля: `attempts`, `last_error`, `next_retry_at` (расчёт по backoff с джиттером).
- Dead‑letter политика: при превышении `max_attempts` → `status='dead'`, инцидент `processor_dead_event` с рекомендациями.
- Идемпотентность акторов: события вида reminder/diamond/outbound обязаны маркировать «выполнено» в профильной таблице; повтор — noop.

### 8) Наблюдаемость и алерты

- Метрики Prometheus:
  - Очереди: `processor_queue_len_total`, `processor_queue_len_by_kind{kind}`.
  - Диспетч: `processor.dispatch_latency_ms_p95`, `processor.e2e_ms{kind}` (уже есть), `processor.dispatch_errors_total{reason}`.
  - QoS: `processor.tokens{kind}`, `processor.concurrency_in_use{kind}`.
  - Карантин: `processor.quarantined_kinds`.
- Алерты (human‑readable):
  - `ProcessorQueueBacklogHigh(kind=..., severity=warn|crit)` — действия: включить карантин вида/снизить квоты; проверить БД/RS.
  - `ProcessorP95BudgetBreach(kind=..., budget_ms=..., p95=...)` — действия: снизить RPS, включить карантин, изучить трассы.
  - `DeadLetterSpike` — действия: инспектировать последние инциденты, при необходимости включить emergency‑режим.

### 9) Админ/API и диагностика

- Расширить `/api/admin/soul/processor/kind_stats` полями: текущие `max_concurrency/rps/timeout_ms/priority`, карантин, backlog minutes.
- Новый POST `/api/admin/soul/processor/limits/set` (RBAC `soul.admin`): upsert для набора видов одним вызовом.
- Новый GET `/api/admin/soul/processor/workers/status` — список активных воркеров, их прогресс (по `worker_id`).

### 10) Дефолты лимитов/приоритетов (рекомендуемые)

```json
{
  "classes": ["system_critical","health","rs_autotune","planner","auto_link","aux_smokes"],
  "priorities": {
    "reminder": 70,
    "chat_message": 60,
    "lima.sync": 55,
    "neuro_integrity.run": 50,
    "soul.dream.rewire": 40,
    "soul.diamond.trigger": 50,
    "auto.link_quants": 35,
    "auto.dogenerate": 30,
    "neurotrain.report": 30,
    "outbound.text": 45
  }
}


```

### 11) Изменения в БД и индексы

- Добавить поля: `attempts int not null default 0`, `dispatched_at timestamptz`, `worker_id text`, `next_retry_at timestamptz` в `processor_events`.
- Индексы:
  - `(status, priority DESC, COALESCE(due_at, now()) ASC, created_at)` — покрыть планировщик.
  - `(dedup_key) where status in ('pending','scheduled','dispatched')` — дедуп.
  - `(kind, status)` — быстрые сводки.

### 12) П27 / безопасность / каноника

- Обязательная цепочка подписи: `svc.processor.dequeue → svc.processor.dispatch → svc.<actor>.* → svc.processor.observe`.
- Секреты/URL/порты только из БД (`SoulSettingsService`, `SecretsService`), запрет хардкодов.
- Не логировать PII; RBAC `soul.admin|architect` для админ‑эндпоинтов.

Rust‑инварианты:

- Контракты RS акторов версионируются, запрет скрытых параметров; JSON‑схемы публикуются.
- Fail‑safe: при недоступности RS — мгновенный python_fallback и запись P50‑инцидента с reason.

### 13) Пошаговое внедрение (zero‑downtime)

1. Миграции БД (поля/индексы) — онлайн (CONCURRENTLY где возможно).
2. Собрать/развернуть `rs-processor-core@1` в mirror‑режиме (`processor.rs_core.mode=mirror`): двойное выполнение (RS считает план/решение и публикует метрики, Python исполняет).
3. Переключить на canary (`processor.rs_core.mode=primary`, share по видам через kind‑whitelist) с python fallback.
4. Эскалировать до полного охвата видов; отключить python‑ветку для покрытых видов.
5. Подтвердить алерты/панели; включить авто‑карантин и адаптивные лимиты в RS.

### 14) Сопоставление с лучшими практиками

- DB‑очередь с `SKIP LOCKED` — де‑факто стандарт для Postgres‑базированных систем с сильной консистентностью (аналог job‑систем в Rails/Sidekiq‑совместимых реализациях).
- Token‑bucket + WRR — применяется в Nginx/Envoy/Redis Streams потребителях для справедливой отдачи и предсказуемости QoS.
- Backoff+jitter — рекомендация AWS/GCP для снижения синхронных волн ретраев.
- Мультипроцесс/кластер через systemd — каноника для Python‑сервисов без GIL‑шаринга состояний.
- CPU‑тяжёлое в Rust‑акторах (P48R) — соответствие целям p95≤50ms для граф‑операций.

### 15) Acceptance

- p95 по ключевым видам ≤ бюджетов 60+ минут подряд; error_rate ≤ порога; дублей нет.
- `/api/admin/soul/processor/{events,metrics,top,kind_stats}` возвращают данные без 5xx; новые эндпоинты работают и уважают RBAC.
- Аварийный режим дренирует top‑k (ETA предсказуем); карантин работает авто и снимается при стабилизации.
- Инциденты и алерты читаемы (severity/risk + пошаговые действия).

### 16) Связанные документы и модули

- Код: `backend/app/services/processor_scheduler.py`, `backend/app/routers/processor_admin.py`, `backend/app/routers/processor_dashboard_api.py`.
- Настройки: `SoulSettingsService` — ключи `processor.*`, `comm.*`, `rs.*`.
- RS/UDS: `svc.rs.proxy` (P48R), canary/автотюн `rs.hyperloop.canary_share`.
- Проектная структура: `docs/PROJECT_STRUCTURE_v8_1_1.md`.

---

## Consolidation (merge notes)

- Источники для слияния:
  - `Soul/P30_TZ_Soul_Processor_v1_0.md` (предыдущая версия)
  - `Soul/P30R_TZ_Processor_Rust_v1_0.md` (RS‑ядро)
- Принятые решения:
  - Базовый документ — v2.0; разделы v1.0 учтены и расширены; требования P30R интегрированы в §§5.1 и смежные.
  - Ключи БД и лимиты приведены к канонике (`processor.kind_*`, `processor.rs_core.*`, `emergency.queue_drain.*`), без хардкодов URL/портов.
  - Реестр обновлён: `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` (раздел P54 нормализации).

Ссылки (интеграции и реестры):

- docs/PROJECT_STRUCTURE_v8_2_0.md — интеграции Processor/DLQ/карантин/лимиты
- docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md — мастер‑реестр документов
- Soul/Report_Soul_AI_Scientific.md — аналоги и сводка регресса
- Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md — обязательные подписи Processor
- Soul/P28_TZ_FeatureFlags_Registry_and_Policies_v1_0.md — профили/инспекторы Processor
- Soul/P36_TZ_Hyperloop_DSL_v1_1.md — команды `PROCESSOR.*` и `FLAGS.*`

 
## Мировые аналоги и практики
- Очереди с `SKIP LOCKED`: Postgres‑подход и job‑системы (Sidekiq‑совместимые)
- WRR/Token Bucket для QoS: Nginx/Envoy концепции `https://www.nginx.com/blog/rate-limiting-nginx/`
- Backoff + jitter (AWS/GCP best practice): `https://aws.amazon.com/blogs/architecture/exponential-backoff-and-jitter/`
- Dead‑letter очереди и повторная обработка: SQS/RabbitMQ паттерны `https://www.rabbitmq.com/dlx.html`
- Prometheus/Grafana мониторинг диспетчеров: exporter‑метрики, p95/p99, очереди
- Rust для hot‑path: tokio, zero‑copy, prom exporter (best practice высоконагруженных брокеров)
