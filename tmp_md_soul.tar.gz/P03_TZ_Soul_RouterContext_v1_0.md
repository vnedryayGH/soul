---

## Индекс взаимных ссылок (P01–P37)

- P01 MeaningExtraction — потребляет правила контекста.
- P02 MetaLoop — интроспекция и настройка параметров.
- P03 RouterContext — этот документ.
- P14 MultiProviderRouting — политики провайдеров в связке с объёмом контекста.
- P27 Signature/Lineage — подпись решений о выборке.
- P33 Personification — использует 30/70 в Mini Chat.
- P35 Processes Unified — применяет RouterContext в процессах.
- P36 Hyperloop DSL — команды для трасс/инспекции.

### ТЗ P03 — ROUTER_CONTEXT 2.0 и 30/70 (active_goal/current_quant/flow_summary)

Дата: 2025‑09‑14
Приоритет: P03 (влияет на релевантность)
Статус: Внедрено (MVP)

---

### 0. Executive summary

- Цель: повысить релевантность и предсказуемость маршрутизации модулей за счёт обогащённого `ROUTER_CONTEXT` (active_goal, current_quant, flow_context_summary) и гибридного ретривала.
- Интеграция: дополнить `soul_context.py` сбором полей и краткого summary, подключить `SoulQuantRouterService.decide(...)`, параметризовать recent/deep политики, вести аудит решений с reason.
- Результат: устойчивые решения роутера на multi‑turn запросах, объяснимость, управляемые политики загрузки контекста.

---

### 1. Актуальная реализация (аудит)

- Контекст 30/70 реализован: недавние и ранжированные сниппеты.
- Лёгкий квант‑роутер (`backend/app/services/soul_quant_router.py`) использует `active_goal`, `current_quant`, `flow_context_summary?` для выбора модулей/фильтров/policy; базовый `RouterV2` — эвристический.
- Аудит присутствует частично; рекомендуется расширить reason/coverage.

---

### 2. Изменения/интеграция

- `soul_context.py`:
  - из истории/БД получить `current_quant` (последний релевантный), `active_goal` (из `quantum_goals`), собрать `flow_context_summary` (LLM/summarizer ≤ 200–300 символов)
  - адаптировать `recent_ratio` по policy: recent=0.6, deep=0.2; deep=0.8; balanced=0.3
  - гибридный ретривал (если доступно): BM25 + вектор → дедуп → rerank R

- `soul_router_v2.py` / `SoulQuantRouterService`:
  - вход: `{input_text, active_goal, current_quant, flow_summary, settings}`
  - выход: `{modules, filters, goal_bias, context_load_policy}` и `reason`
  - аудит: `soul_router_decision` {policy, reason, modules}

Контракты (опционально, Pydantic):

```python
class RouterContext(BaseModel):
    input_text: str
    active_goal: Optional[Dict[str, Any]]
    current_quant: Optional[Dict[str, Any]]
    flow_summary: Optional[str]

class RouterDecision(BaseModel):
    modules: List[str]
    filters: List[str]
    goal_bias: Optional[str]
    context_load_policy: Literal["recent","deep","balanced"]
    reason: str

```

---

### 3. Настройки/метрики

- `router.recent_ratio.{recent|deep|balanced}`
- Метрики: hit‑rate ретривала, распределение policy, p95 формирование контекста.

---

### 4. Безопасность/приватность

- Удалять PII/секреты из `flow_summary` (через `privacy_sanitizer`).
- Не включать имена внутренних модулей в summary; только смысловые маркеры.

---

### 5. Acceptance

- ROUTER_CONTEXT заполняется; аудит решений содержит reason; ретривал стабильнее на multi‑turn кейсах.

---

### 6. Траблшутинг

- Переизбыточный контекст → уменьшить длину `flow_summary`/снизить recent_ratio.
- Слабая чувствительность к истории → поднять deep/balanced доли.
- Медленный ретривал → отключить векторный компонент (временное), оставить BM25.

---

### 7. Ссылки

- Роутер V2: `backend/app/services/soul_router_v2.py`
- Квант‑роутер: `backend/app/services/soul_quant_router.py`
- Оркестратор: `Soul/orchestrator_mapping_v1.json`, `Soul/modules_registry_v1.json`
- Контекст: `backend/app/services/soul_context.py`

---

### 8. Алгоритмы (подробно)

8.1 Гибридный ретривал (30/70 aware):

- Inputs: `input_text`, `canonical_terms` (если P15 включён), `recent_ratio_policy`.
- Steps:

  1) BM25 поиск по `input_text` + `expanded_terms` (если доступны) → top_k_bm25 (k=50)
  2) Векторный поиск (если индекс есть) по эмбеддингу `input_text` → top_k_vec (k=50)
  3) Объединение: `U = bm25 ∪ vec` с нормировкой скоринга (min‑max per source)
  4) Дедуп: по `quant_id`/hash; при совпадении — агрегировать баллы (`0.6*bm25 + 0.4*vec`)
  5) Rerank R: учесть `energy_weight`, `connection_strength`, свежесть, совпадение тегов/якорей
  6) Разделить на recent/deep пулы согласно policy и собрать итоговый набор для контекста

8.2 Формирование `flow_context_summary`:

- Сжать 3–5 ключевых сниппетов контекста (≤ 200–300 симв.)
- Включать только смысловые факты/якоря; не включать имена модулей/системные токены
- Санитайзер PII до аудита

8.3 Эвристика выбора policy и модулей:

- Если `active_goal` задан и тема совпадает с тегами входа → bias на модули, усиливающие цель (e.g., Ved для структурности)
- Если вопрос креативный/открытый → Flow/Klee; если аналитический/проверочный → Ved/Chekhov
- Если история длинная/важны недавние факты → `context_load_policy=recent`
- Если тема архивная/редкая → `context_load_policy=deep`
- Balanced — дефолт при неопределённости; reason фиксировать (ключевые признаки)

8.4 Примеры reason:

- "recent_policy: user_followup=true, time_gap<5m"
- "deep_policy: low_recent_overlap, anchor_hit=true"
- "modules=[Flow,Klee], rationale: creative_request+low_risk"

---

### 9. Метрики и SLO

- `router.decision_time_ms.p95 ≤ 120ms`
- `router.policy_distribution` (recent/deep/balanced)
- `router.hit_rate@5` (ретривал по золотому набору)
- `router.reason_coverage` (доля решений с reason != empty) ≥ 99%

Аудитные события:

- `soul_router_context_built` {has_goal, has_current, summary_len}
- `soul_router_decision` {policy, modules, reason}

---

### 10. Тест‑план

- Unit: построение `RouterContext` без БД (моки), проверка выбора policy при разных сигналах
- Integration: золотые кейсы multi‑turn → проверка стабильности policy и роста hit‑rate
- Perf: p95 формирования контекста ≤ 150ms при k=100 совокупно BM25+vec

---

### 11. Rollout/флаги

- `router.context.enabled=true`
- `router.hybrid_retrieval.enabled=true`
- `router.policy.default=balanced`

- Контекст: `backend/app/services/soul_context.py`
- Роутер: `backend/app/services/soul_router_v2.py`
- Настройки: `backend/app/services/soul_settings_service.py`

---

### 12. Отметка принятия (2025-09-20)

- `SoulContextService` формирует recent/ranked, поддерживает гибридный ретривал и `flow_context_summary`; политика recent/deep/balanced регулируется через настройки.
- `soul_router_v2`/`SoulQuantRouterService` используются в ядре; события `soul_router_decide` и `soul_router_context_built` пишутся; при Hyperloop RUN WITH TRACE шаг `svc.soul.router_decide` присутствует.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
