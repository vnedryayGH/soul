# P56 — Техническое задание: LLM Агент Cursor (интеграция с Ядром Соул) v1.0

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — инвентари.
- `tmp_p_series_plan.json` — план P‑серии.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр.
- `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`, `Soul/P36_TZ_Hyperloop_DSL_v1_1.md`, `Soul/P40_TZ_Project_Log_and_Methodology_Workflow_v1_0.md`, `Soul/P21_TZ_P95_Observability_and_Regulation_v1_0.md` — ключевые интеграции.

## 1. Назначение и цели

- Обеспечить устойчивое и детерминированное поведение LLM‑агента Cursor при росте истории диалога, без обнуления сессии.
- Описать полный контур формирования контекста, механизмы вызова/«форсированного» запуска агента, отложенные вызовы и наблюдаемость.
- Установить единые правила безопасности (RBAC, Delivery Guard), конфигурации через БД, и документационные опоры.

## 2. Область действия

- Взаимодействие Cursor ↔ репозиторий проекта (артефакты: `.cursorrules`, `CURSOR_AGENT_SYSTEM_PROMPT_EN.md`, `SESSION_BRIEF.md`).
- Внешнее влияние на качество ответов через обновление Session Brief, тримминг контекста, мониторинг и алерты.
- Паттерны «принудительного» запуска в рамках ограничений Cursor (закрытый стек без нативного таймера).

## 3. Определения

- Cursor Agent: LLM‑агент внутри Cursor, управляемый системным промптом и политиками репозитория.
- Session Brief: краткий стабильный контекст (≤ ~1–2k токенов) — «дальняя память».
- Tail‑first: политика формирования окна истории с приоритетом последних реплик.
- Delivery Guard (P27): подпись шагов и трассировка, инвариант проекта.

## 4. Артефакты и политики (репозиторий)

- `.cursorrules` — Cursor Agent Context Policy (tail‑first + Session Brief + системный промпт; конфликты→приоритет последних сообщений и Brief).
- `CURSOR_AGENT_SYSTEM_PROMPT_EN.md` — системный промпт (англ.) со структурой: Context Policy, Output Rules, Security, Planning, Retrieval, Failure, Procedures (plan/search/edit/test/doc/defer), Deferred Agent Policy.
- `SESSION_BRIEF.md` — выжимка контекста для стабильной «дальней памяти».
- Runbooks:
  - `docs/RUNBOOK_Cursor_Session_Brief_Refresh_v1_0.md` — обновление Brief (по требованию/по таймеру, B64‑режим, CLI команды).
  - `docs/RUNBOOK_Cursor_Deferred_Agent_v1_0.md` — отложенные действия (deferred executor через systemd).

## 5. Цепочка формирования контекста запроса (Cursor)

1) Системный слой: Cursor первично подмешивает `CURSOR_AGENT_SYSTEM_PROMPT_EN.md` и `SESSION_BRIEF.md` (Brief всегда первым).
2) Tail‑first история: берётся хвост диалога до бюджета токенов, хронология сохраняется.
3) Разрешение конфликтов: последняя реплика пользователя → Session Brief → `.cursorrules`.
4) Вывод: краткий, структурный, без «воды»; код/команды — только в fenced блоках.

Примечание: Внутренний пайплайн Cursor закрыт, но контекст управляется «снаружи» — через артефакты и краткий Brief; в проекте включён дополнительный безопасный тримминг на стороне сервиса (`backend/app/services/llm_client.py`) при серверных вызовах.

## 6. Механизмы вызова LLM‑агента Cursor

### 6.1. Интерактивный вызов

- Триггеры: новое сообщение пользователя, завершение инструмента (terminal/поиск/правка/линтер) или ошибка инструмента (тоже завершение).
- Рекомендация: для длинных операций разбивать на шаги; агент реагирует при завершении каждого шага.

### 6.2. «Принудительный» вызов в рамках Cursor (паттерн события‑якоря)

- Ограничение: у Cursor нет нативных таймеров/cron; deferred‑JSON без «якорного» события не активирует ход.
- Паттерн: запуск короткой команды‑якоря, которая завершится через Δt (например, `python -c "import time; time.sleep(10)"`). По завершении команда возвращает управление агенту, вызывая следующий ход.
- Практика: держать Δt небольшой (10–30 сек), чтобы не упереться в таймауты среды; для длительных отложенных действий — использовать инфраструктурный deferred‑executor (см. 6.3).

### 6.3. Отложенные/периодические действия (вне Cursor, влияют на качество)

- `ops/systemd/cursor-session-brief.service|.timer` (ежечасно): запускает `Soul/scripts/refresh_session_brief.py`, который читает `SESSION_BRIEF.md` и обновляет ключи в БД (`cursor.session_brief.*`) через Hyperloop CLI. Это поддерживает актуальность Brief и стабильность ответа без обнуления истории.
- `ops/systemd/cursor-deferred-agent.service|.timer` + `Soul/scripts/deferred_agent.py`: выполняет декларативные задания из JSON (тип действия: `dsl` через Hyperloop CLI, либо `shell`). Это не «принуждает» Cursor немедленно ответить, но подготавливает контекст/данные к следующему интерактивному вызову.

### 6.4. Декларативное defer() (внутри промпта)

- Системный промпт поддерживает рекомендацию формата:
  - `{ "defer": { "action": "<cmd>", "schedule": "hourly|nightly|cron|at:HH:MM" } }`
- Хост‑среда может отобразить это на systemd timers. Fallback: если хост defer() не исполняет — использовать 6.3 для инфраструктурных задач и 6.2 для коротких задержек.

## 6.5. Шина задач через FLAGS.* (Soul → Cursor → Soul)

- Ключи в БД (через Hyperloop DSL):
  - `cursor.agent.task.json` — JSON‑задание от Соул к агенту Cursor
  - `cursor.agent.task.version` — монотонная версия задания (инкремент при каждой постановке)
  - `cursor.agent.result.json` — JSON‑результат от агента Cursor к Соул
  - `cursor.agent.result.version` — монотонная версия результата
- Протокол:

  1) Soul пишет `task.json` и инкрементит `task.version`.
  2) Soul инициирует ход агента (короткое сообщение в чате: "sync" или завершение инструмента).
  3) Агент Cursor на своём ходе читает `task.json`, выполняет действие, пишет `result.json` и инкрементит `result.version`.
  4) Soul читает `result.*` и принимает решение (в т.ч. апрувы/уточнения).

- Безопасность: никакие секреты в JSON заданиях; все операции агента — через конфиги/секреты из БД.

## 6.6. Watchdog/независание

- Soul ведёт контроль прогресса по версиям (`task.version`, `result.version`) и по времени (TTL на ожидание результата).
- При отсутствии результата дольше SLA Soul отправляет повторный пинг (короткая реплика) и/или уточняет задание.
- В критических случаях — эскалация Архитектору через мини‑чат бота.

### 6.7. Cursor Chat Bridge (Slack) — «якорное» событие для холодного старта

- Проблема: внешние таймеры и FLAGS меняют состояние в БД, но не создают событие внутри Cursor. Нужен внешний мост, который программно создаёт короткое сообщение в ветке/канале, привязанной к агенту Cursor.
- Решение (минимально инвазивное): Slack‑мост, который публикует `ping` при росте `cursor.agent.task.version`.
- Реализация:
  - Скрипт: `Soul/scripts/cursor_chat_bridge_slack.py`.
  - Идемпотентность: хранит «последнюю отправленную версию» в БД ключом `cursor.chat.bridge.sent.version` через Hyperloop DSL (FLAGS.SET/GET).
  - Источники конфигурации (в порядке приоритета):

    1) ENV (prod): `SLACK_BOT_TOKEN`, `SLACK_CHANNEL_ID`, `SLACK_API_BASE` (по умолчанию `https://slack.com/api`), `SOUL_API_BASE` (prod API base), `SOUL_AUTH_TOKEN` (опционально), `X_TG_ID` (468326902 по умолчанию).
    2) БД (через Hyperloop GET): `cursor.chat.bridge.slack_channel_id`, `cursor.chat.bridge.branch`, `cursor.chat.bridge.project_code`.

  - Поведение:

    1) Читает `cursor.agent.task.version` и `cursor.chat.bridge.sent.version`.
    2) Если `task.version > sent.version` — публикует Slack‑сообщение формата: `[CursorBridge] task.version=<N> → ping (project=<code>, branch=<key>)`.
    3) При успехе — устанавливает `cursor.chat.bridge.sent.version = task.version`.

  - Безопасность: токен только из ENV (секреты не читаются через API). URLы/каналы могут приходить через БД/ENV. Логи не содержат секретов.
  - Развёртывание: systemd `ops/systemd/cursor-chat-bridge.service|.timer` (ежеминутно/каждые 2–3 мин).

Acceptance (минимальный): при `FLAGS.INCR key=cursor.agent.task.version` — в Slack‑канале появляется `ping`, Cursor стартует новый ход.

## 7. Наблюдаемость, метрики и алерты

- Метрики (LLM/контекст/ретраи): `backend/app/lib/observability/metrics.py` (пример: `llm.cb_trip`, `llm_failover_used_total`, `llm_aux_err_total`, latency/tokens).
- Prometheus правила: `ops/prometheus/rules_cursor.yml` — алерт `ContextDegradation` (рост ретраев/ошибок при падающей полезности) и `CursorBriefMissing`.
- Графана: панели из набора system/LLM; соответствующие JSON в `ops/grafana/`.

### 7.1. Контроль шины задач

- Счётчики постановок и завершений: инкрементировать `soul_cursor_tasks_total{type}` и `soul_cursor_results_total{type}` (через observability helpers) при серверных шагах.
- Алерт задержки: если `task.version` обновлялся, а `result.version` не менялся > N минут — алерт `CursorTaskStalled` (PromQL опирается на экспорт версий или proxy‑метрики).

## 8. Безопасность и инварианты

- Никаких хардкодов URL/портов/секретов в коде; все адреса/секреты читаются из БД (`SoulSettingsService`, `SecretsService`).
- RBAC/Delivery Guard неизменны; админ‑операции — только под `soul.admin`.
- systemd таймеры/юниты — только на APP серверах; локальные вечные циклы запрещены.

## 9. Инцидентный воркфлоу (пример постановки задачи)

Вход: `incident_id`, свободный промпт/инструкция, приоритет/severity.

Шаги Soul:
1) Пишем задание:

```json
{
  "type": "incident_workflow",
  "incident_id": "INC-<ID>",
  "severity": "critical|high|medium|low",
  "prompt": "...подробная инструкция...",
  "project": { "code": "SP-CURSOR-CONTEXT-2025-10", "branch": "cursor/context-tail-first" },
  "notify": { "architect": true },
  "acceptance": [
    "открыт проектный лог и ведётся детализация",
    "выполнен анализ инцидента/связанных инцидентов/доков/кода/внешних практик",
    "подготовлено и реализовано решение с тестами и обновлением документации",
    "перенос в PROD, ретест критичной смежной функциональности",
    "добавление знаний/уроков/квантов и уведомление Архитектора"
  ]
}

```
2) Инкрементируем `cursor.agent.task.version` и шлём короткий пинг в ветку чата.

Шаги Cursor‑агента:

- Читает задание, открывает/обновляет проектный лог, дальше исполняет сценарий: анализ → поиск → выработка решения → реализация → тесты → документация → деплой → ретест → знания/уроки/кванты → уведомление.
- На развилках запрашивает апрувы у Soul (через FLAGS либо репликой в чат). При отказе — откат или альтернативный план.
- По завершению пишет `result.json` (краткая сводка, ссылки на артефакты/PR/документы/отчёты).

## 9. Проектные реализации (готово в репозитории)

- Tail‑first политика: `.cursorrules`, `CURSOR_AGENT_SYSTEM_PROMPT_EN.md`, `SESSION_BRIEF.md` и тримминг на стороне сервиса `LLMClient`.
- Автообновление Brief: `ops/systemd/cursor-session-brief.*` + `Soul/scripts/refresh_session_brief.py`.
- Отложенный исполнитель: `ops/systemd/cursor-deferred-agent.*` + `Soul/scripts/deferred_agent.py` + пример `tools/examples/tmp_deferred_agent.example.json`.
- Документация и реестр: `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md`, runbooks по Brief и Deferred Agent.

## 10. Тест‑план и приемка

### 10.1. Интерактивный «форсированный» запуск через событие‑якорь

- Шаги:

  1) Запустить инструмент с небольшой задержкой (например, 15 сек). Ожидание завершения.
  2) По завершении агент должен сделать следующий ход и выдать заранее заданную реплику.

- Acceptance:
  - Агент отвечает в той же ветке.
  - Нет таймаутов среды; общее время шага ≤ 30 сек.

### 10.2. Отложенное влияние через Brief (ежечасно)

- Шаги:

  1) Обновить `SESSION_BRIEF.md`; запустить `cursor-session-brief.service` вручную и проверить ключ `cursor.session_brief.text` через CLI.
  2) Вызвать агента (короткий диалог) и убедиться в использовании обновлённого факта из Brief.

- Acceptance:
  - Ключи `cursor.session_brief.*` обновлены; длина брифа ≤ max_tokens.
  - Ответ агента опирается на новые факты Brief (мануальный тест).

### 10.3. Deferred‑executor (инфраструктурный)

- Шаги:

  1) Разместить JSON‑задание в `/var/www/soulpulse/backend/tmp_deferred_agent.json`.
  2) Запустить `cursor-deferred-agent.service` и проверить выполнение (`journalctl`, артефакт в `reports/`).

- Acceptance:
  - Команды типа `dsl` выполняются через Hyperloop CLI c P27 подписью.
  - Команды `shell` (если заданы) завершаются без интерактивного ввода.

### 10.4. Инцидентный тест (end‑to‑end)

- Вход: `INC-TEST-001`, severity=critical, промпт из описания задачи.
- Soul ставит задание (скрипт постановки), пингует чат; агент выполняет шаги и пишет `result.json`.
- Acceptance:
  - Заполнен проектный лог; приложены ссылки на анализы/коды/доки; решение внедрено и протестировано; уведомление Архитектору отправлено.
  - В БД `result.version` > `task.version` на момент завершения; SLA на ответ не нарушен; алертов `CursorTaskStalled` нет.

### 10.5. Slack Chat Bridge (холодный старт)

- Шаги:

  1) Установить ENV на APP: `SLACK_BOT_TOKEN`, `SLACK_CHANNEL_ID`.
  2) Убедиться, что таймер `cursor-chat-bridge.timer` активен.
  3) Выполнить: `python .\\Soul\\scripts\\hyperloop_cli.py --dsl "FLAGS.INCR key=cursor.agent.task.version"`.
  4) Проверить в Slack появление сообщения `CursorBridge ping` и запуск нового хода Cursor в привязанной ветке.

- Acceptance:
  - При каждом инкременте версии в БД появляется ровно одно Slack‑сообщение (идемпотентность).
  - Ход Cursor стартует без ручного ввода.

## 11. Ответ на ключевой вопрос: «Как принудительно вызывать LLM Агента Cursor?»

- Внутри Cursor (строго): 
  - Нет нативного таймера; агент начинает ход по завершению инструмента или при новом сообщении.
  - Используйте «событие‑якорь»: запустите короткую задержку (безопасный `sleep`) инструментом → по завершении агент автоматически продолжит ход и выполнит заданное действие/ответ.
- Вне Cursor (серверная подготовка):
  - Используйте автообновление Brief и инфраструктурный deferred‑executor, чтобы к моменту следующего интерактивного вызова агент имел актуальный «дальний контекст» и подготовленные данные.
- Декларативный defer():
  - Возвращайте JSON согласно Deferred Agent Policy. Если среда поддерживает маппинг на таймеры — он выполнится; иначе fallback на два пункта выше.

## 12. Риски и ограничения

- Долгие инструменты могут быть прерваны таймаутом среды Cursor; держите задержки небольшими.
- Deferred JSON не гарантирует запуск без поддерживающего хоста; поэтому необходим инфраструктурный исполнитель.
- Любые действия с внешними сервисами — только через БД/сервисы конфигурации; запрет хардкодов.

## 13. План внедрения

- Включить unit/timer `cursor-session-brief.*` и `cursor-deferred-agent.*` на APP1/APP2.
- Прописать алерты `ContextDegradation` и панели; проверить активность правил Prometheus.
- Провести тесты 10.1–10.3; зафиксировать результаты в проектном логе (P40) и `docs/PROJECT_STRUCTURE_v8_2_0.md`.

## 14. Источники/Ссылки

- Внутренние:
  - `.cursorrules`, `CURSOR_AGENT_SYSTEM_PROMPT_EN.md`, `SESSION_BRIEF.md` (repo root)
  - `docs/RUNBOOK_Cursor_Session_Brief_Refresh_v1_0.md`, `docs/RUNBOOK_Cursor_Deferred_Agent_v1_0.md`
  - `ops/systemd/cursor-session-brief.*`, `ops/systemd/cursor-deferred-agent.*`, `ops/prometheus/rules_cursor.yml`
  - `backend/app/services/llm_client.py`, `backend/app/lib/observability/metrics.py`
- Внешние (концептуальные, о бюджетировании контекста и best practices):
  - OpenAI — Context, tokens, conversation summarization: https://platform.openai.com/docs/guides
  - Anthropic — Prompting/Context windows: https://docs.anthropic.com
  - Cursor (обзор продукта/интеграции): https://www.cursor.com

---

Версия: v1.0 • Проект: SP‑CURSOR‑CONTEXT‑2025‑10 • Ветка: `cursor/context-tail-first`


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
