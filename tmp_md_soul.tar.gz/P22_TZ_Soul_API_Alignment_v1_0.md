<!-- markdownlint-disable MD041 MD022 MD032 MD031 MD040 MD047 -->
---

## Индекс взаимных ссылок (P01–P37)

- P10 SchemaGuard — проверка схем.
- P20 TelegramBots Platform — выравнивание API Mini App.
- P33 Personification — контракты `/api/chat/send`, `/threads/{id}/messages`.

# P22 — Выравнивание API под P20 и консолидация интерфейсов

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — инвентари.
- `tmp_p_series_plan.json` — план P‑серии.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр.
- `Soul/P20_TZ_Telegram_Bot_Orchestrator_and_E2E_Dataflow_v1_1.md`, `Soul/P23_TZ_UI_Spec_v2_1.md`, `Soul/P30_TZ_Soul_Processor_v2_0.md`, `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`, `Soul/P36_TZ_Hyperloop_DSL_v1_1.md` — ключевые интеграции P‑серии.

Версия: v1.0
Статус: Готово к реализации (инкрементная поставка без регресса)

Ссылки (интеграции и реестры):

- docs/PROJECT_STRUCTURE_v8_2_0.md — интеграции API/фасадов под P20/P23/P30
- docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md — мастер‑реестр
- Soul/Report_Soul_AI_Scientific.md — сводка нормализации/регресса
- Soul/P20_TZ_Telegram_Bot_Orchestrator_and_E2E_Dataflow_v1_1.md — OpenAPI/каналы
- Soul/P23_TZ_UI_Spec_v2_1.md — UI/формы/маршруты
- Soul/P30_TZ_Soul_Processor_v2_0.md — Processor API/лимиты/DLQ
- Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md — подпись/инспекторы/гвард

## 1. Цели и принципы

- Единый фасад API по P20 (`docs/openapi-p20-telegram-bots.yaml`) как источник истины.
- Совместимость: старые пути `/api/miniapp/*` сохраняются как алиасы до вывода из эксплуатации.
- Безопасность: строгие RBAC, scope‑политики, «два ключа» для чувствительных действий.
- Контракты: Pydantic Strict, `row_version` + `ETag/If-Match`, Schema Guard в CI.
- Наблюдаемость: p95/ошибки/аудит, health/инциденты.
- Согласование с задачей пересборки UI: отсутствие хардкода, конфиг‑схемы, Mini‑App/Web различия, авторизация через Telegram.

## 2. Текущее состояние (инвентаризация кода)

- Подключённые роутеры (ключевые):
  - Auth `/api/miniapp/auth`, Web‑auth `/api/web-auth`
  - Chat/Prompts/Profile/Themes/Payments/Keywords/Cache/Account/User/RBAC/Admin‑панели
  - Reminders: `/api/miniapp/reminders` (реализация есть)
  - Health: `/api/health` (snapshot/timeseries/incidents реализованы)
  - Security: `/api/security` (status/anomalies/ethics/events/settings)
  - Trace/Admin/Dashboard/Goals/Search/Advanced monitoring и пр.
- Добавлено: фасад `backend/app/routers/reminders_facade.py` → `/api/reminders/*` (алиас к текущей бизнес‑логике). Подключено в `app/main.py`.
- Архивировано как неиспользуемые: `routers/notifications.py`, `routers/feedback.py`.
- Миграции под P20 есть: tasks/events/reminders/chat_mined_facts, comments/attachments/sprints/time, row_version, two‑keys queue, health.

## 3. OpenAPI ↔ код: сопоставление и разрывы

- Покрыто кодом:
  - `/api/health/snapshot`, `/api/health/timeseries` (временный совместимый ответ), `/api/health/incidents` (GET/POST/PATCH)
  - `/api/reminders/*` (через фасад)
- Требуется реализовать фасады:
  - `/api/tasks` (GET/POST), `/api/tasks/{id}` (PATCH + If‑Match/ETag)
  - `/api/events` (GET/POST), `/api/events/{id}` (PATCH)
  - `/api/gantt` (GET), `/api/tasks/{id}/schedule` (PATCH), `/api/tasks/{id}/dependencies` (PUT)
  - `/api/chat-mining/*` (ingest/proposals/list/confirm)
  - `/api/inbox` (GET), `/api/inbox/batch` (POST)
  - `/api/tasks/{id}/comments` (GET/POST), `/api/tasks/{id}/attachments` (POST presign)
  - `/api/sprints` (GET/POST), `/api/sprints/{id}/tasks` (PUT)
  - `/api/time-entries` (GET/POST)
- Требуется реализовать инструменты и админ-политику:
  - `/api/pc/exec`, `/api/pc/fs`
  - `/api/cursor/edit`, `/api/cursor/run`
  - `/api/admin/two-keys/policies|approve|requests`

## 4. Архитектура маршрутов (целевое состояние)

- Фасадные `APIRouter` под P20 проксируют текущую бизнес‑логику/сервисы.
- Унификация фильтров/пагинации/статусов; PATCH с `If-Match` и проверкой `row_version`.
- Мягкая «мульти‑аренда»: `bot_id/team_id` в заголовках/токене; аудит контекстов.

## 5. Безопасность

- RBAC: роли → разрешения (read/write/delete/admin) по ресурсам.
- Scopes: `repo.read/write`, `workspace.read/write/exec`, `secrets.read`.
- Two‑keys: очередь заявок, TTL, причины, аудит; утверждение в `/api/admin/two-keys/*`.
- CORS/Headers согласованы с Mini‑App/Web (CSP/XFO/Permissions‑Policy).

## 6. Контракты и целостность

- Strict‑модели выровнены с OpenAPI; примеры payload/response.
- Schema Guard в pre‑commit/CI; semver на изменения.
- `row_version` + `ETag` для задач/событий/комментариев/времени.

## 7. Наблюдаемость

- Метрики: p50/p95, RPS, ошибки, таймауты, ретраи — по каждому пути.
- Аудит: two‑keys, pc/cursor, security decisions, router‑решения.
- Health‑дашборд: snapshot/timeseries/incidents, SLO/алерты.

## 8. Детализация работ по эндпоинтам

- Tasks/Events:
  - Создать сервисы `TaskService`, `EventService` (CRUD/filters/row_version).
  - Роутеры `/api/tasks`, `/api/events` с контрактами из OpenAPI.
  - ETag/If‑Match в PATCH, конфликт 409 при несовпадении `row_version`.
- Gantt:
  - `/api/gantt` агрегация задач + deps; кэш ETag/If‑None‑Match.
  - `schedule`/`dependencies` — транзакционные обновления, audit.
- Chat‑mining:
  - Ingest нормализованного события, генерация `mining_proposals`, подтверждение link→task/event.
- Inbox:
  - Сбор pending proposals/mentions/escalations; batch‑операции accept/reject/assign.
- Comments/Attachments/Sprints/Time:
  - Роутеры по OpenAPI; в attachments — presigned URL flow (S3‑совместимый провайдер).
- Tools и Two‑keys:
  - Очередь `sensitive_op_requests` + TTL; политики на действия+scopes; approve‑поток; audit.
  - pc/cursor — только после одобрения; dry‑run по умолчанию.

## 9. Последовательность реализации (инкременты)

1) Фасад Reminders (ГОТОВО) и smoke‑тесты.
2) Админ «два ключа»: `/api/admin/two-keys/*`, сервис очереди, audit; mock‑действия.
3) `/api/pc/*`, `/api/cursor/*` (dry‑run, scope‑проверки), связка с two‑keys.
4) Health выравнивание с OpenAPI (устранить DEPRECATED поведения в timeseries, добавить недостающие поля).
5) Tasks/Events/Gantt базовые (GET/POST/PATCH, schedule/deps), ETag/If‑Match.
6) Inbox/Chat‑mining; Comments/Attachments; Sprints/Time.
7) Schema Guard/Strict‑модели/CI; синхронизация OpenAPI ↔ код; Postman/Insomnia.
8) Включить `Deprecation` заголовки на `/api/miniapp/*`; план вывода.

## 10. Контроль качества и приёмка

- Покрытие Postman/Insomnia коллекцией P20 (все 2xx/4xx по сценариям).
- Нагрузочные: p95≤ целевых SLO, отсутствие утечек соединений/дескрипторов.
- Безопасность: RBAC/scopes/двухключевой поток — негативные сценарии запрещены.
- Регресс: старые пути работают и возвращают прежние ответы.

## 11. Риски/откат

- Дубли маршрутов → изолированные фасады и флаги включения.
- Несовпадение схем → Schema Guard + PR‑гейт.
- Откат: выключить фасады, вернуться к `/api/miniapp/*` (алиасы остаются).

## 12. Артефакты

- Обновленный `docs/openapi-p20-telegram-bots.yaml`.
- Фасадные роутеры и тесты.
- Коллекции Postman/Insomnia.
- Док‑страницы по UI‑конфигах.

## LLM‑параметры (таймауты и ретраи)

Источник истины: `soul_settings`.

- Ключи: `llm_timeout_ms.<function>.<model>`, `llm_retries.<function>.<model>` (int)
- Приоритеты: 1) `soul_settings`, 2) defaults LLMClient, 3) model_config.
- Backend: `SoulSettingsService.get_setting(...)`; чтение перед `LLMClient.send(...)`.
- Frontend: `/llm-params` (табличный UI, read/write через Admin Settings API).
- НФТ: без хардкода, изменения применяются без рестарта; кэш ключей (опц.) 1–5с.

## Assembly Contract (SYSTEM сборка) — консолидация

- Порядок блоков: [CORE] → [ROUTER_CONTEXT] → [MODULES] → [OUTPUT_SPEC] → [NEGATIVE].
- Анти‑подмена роли: запреты на смену identity, вывод модульных названий в user‑тексте, non‑JSON.
- Язык ответа: определяется по текущему запросу (см. LANG_POLICY).
- STRICT JSON: единый квант (single) или массив (batch).
- Источник: см. архив `backend/docs/ARCHIVE__SOUL_PROMPT_BUILDING.md`.

## 13. Примеры API для PROCESSOR (в связке с P36)

### 13.1 POST /api/hyperloop/execute — инъекция события Процессора

Пример (PowerShell):

```text
$H=@{ 'X-Telegram-User-ID'='468326902' }
$cmds='PROCESSOR.EVENT.INJECT kind=chat_message payload={"text":"processor ping"} priority=5'
$B=@{ commands=$cmds } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri '{API_BASE}/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B

```
Ожидается: 200, `ok=true`, `signature.trace_id`, шаг `cmd.hyperloop.processor.event.inject` присутствует в `signature_steps`.

### 13.2 POST /api/hyperloop/execute — единичная обработка очереди

```text
$H=@{ 'X-Telegram-User-ID'='468326902' }
$cmds='PROCESSOR.PROCESS_ONCE'
$B=@{ commands=$cmds } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri '{API_BASE}/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B

```
Ожидается: 200, `ok=true`, при наличии ожидающих событий — их часть обработана; шаг `cmd.hyperloop.processor.process_once` сохранён в подписи; при пустой очереди — `results[].data.processed=0`.

### 13.3 POST /api/hyperloop/execute — комбинированный сценарий

```text
$H=@{ 'X-Telegram-User-ID'='468326902' }
$cmds='PROCESSOR.EVENT.INJECT kind=reminder payload={"reminder_id":"r-1","user":{"id":468326902}}\nPROCESSOR.PROCESS_ONCE'
$B=@{ commands=$cmds } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri '{API_BASE}/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B

```
Ожидается: 200, `ok=true`; по `trace_id` события видны шаги инъекции и обработки; в окне 24ч инспектор подписи находит обязательные шаги P27.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
