# M06 — SAFe Portfolio Lite (v1.0)

Цель: координация поездов релизов и портфельных инициатив.

Инварианты: P27/P28/P29/P30/P36.

Процесс: PI Planning → Iterations → Inspect & Adapt.

Алгоритмы/метрики: PI Objectives, Predictability, p95.

Роли: RTE, Product Manager, System Architect.

DSL: PLAN.EPIC.ADD, PLAN.FEATURE.ADD, METHODOLOGY.SET, INSPECTOR.RUN_ALL.

Acceptance: артефакты PI в БД; панели Portfolio/PI.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
