P46_TZ: Проверка нейроцелостности и нейрополноты (NeuroIntegrity)

1. Цель
- Обеспечить автоматическую проверку целостности и полноты нейроструктур Соул при «Сне» и при пакетной загрузке данных/Квантов: связность Квантовой нейросети, навыков (Skills), нейрообучения (NeuroTraining), планирования/целей/вех, напоминаний/календаря. Аномалии фиксируются инспекторами, инициируются корректирующие действия Процессором.

2. Область и стыковки
- Точки запуска: P16 (Sleep v2), пакетные загрузки JSONL/SQL/Hyperloop (P45), массовая генерация связей (Skills/Plan/Goals — P25/P30/P40).
- Управление/вызовы: через Процессор (P30) и Hyperloop DSL (P36), с шагами подписи (P27) и RBAC/Two‑Keys (P44) при опасных операциях.
- Данные: `quants`, `quant_links`, `skills/*`, `plan_tasks`, `goals/goal_milestones`, `reminders`, `calendar_events`, `processor_*`.

3. Триггеры
- Sleep (ежедневно/по расписанию): полная проверка окна (24–168h).
- Batch ingest: после загрузки N≥500 квантов или M≥1000 связей — «ускоренная» проверка (focus=последние 24–72h, только изменённые узлы/окрестности).
- Ручной запуск через Hyperloop.

4. Алгоритм (высокий уровень)

1) Собрать срез: counts по ключевым сущностям/связям; топология графа `quant_links` (компоненты связности, диаметр/средняя длина, изолированные кластеры/листья, петли).
2) Проверить полноту:

   - Skills: наличие связей `improves|plans|assesses|adjusts|schedules`; доля `user_skills` с актуальным `next_due_at`;
   - Plan/Goals: наличие связей `supports|advances|assesses|adjusts|achieves|confirms`; непротиворечивость прогресса/статусов;
   - Reminders/Calendar: `schedules|triggers|snoozes|confirms` консистентны и не ведут к просроченным событиям без ACK.

3) Проверить целостность:

   - Схемная валидность payload (STRICT JSON) и ожидаемые ключи;
   - Идемпотентность связей (дубликаты/обращённые дубликаты);
   - Отсутствие «висячих» ссылок (to_entity не существует, owner нарушен);
   - KPI топологии: пороги связности/листьев/осиротевших узлов;
   - Шаги подписи P27 для массовых операций в окне времени (coverage≥целевого порога).

4) Выдать отчёт и рекомендации: агрегаты, нарушения, список корректирующих действий (Hyperloop/Processor).
5) (Опц.) Инициировать корректирующие действия (под контролем RBAC/Two‑Keys): восстановление недостающих связей, пересчёт прогресса/due, переиндексация, нормализация данных.

5. Метрики / KPI
- coverage_signature_percent (P27) по окну; orphan_quants_rate; invalid_links_count; skills_due_health_rate; goals_progress_consistency_rate; plan_links_density; calendar_on_time_rate.
- Граф: components_count, diameter_approx, leaves_ratio, avg_degree, isolated_nodes.

6. Инспекторы (реестр)
- `neuro.integrity.graph_topology` — связность/изолированные узлы/листья.
- `neuro.integrity.links_validity` — дубликаты/висячие/несогласованные связи.
- `neuro.integrity.skills_completeness` — доля корректных связей/показателей навыков.
- `neuro.integrity.plan_goals_consistency` — непротиворечивость план/целей, связи achieves/advances/assesses.
- `neuro.integrity.reminders_calendar` — актуальность due/ack/snooze, кросс‑ссылки.
- `signature.required_steps.consistency` — обязательные P27‑шаги за окно (повторная валидация).

7. Команды Hyperloop (P36)
- Запуск полного цикла:
  - `INSPECTOR.RUN_ALL scope=neuro_integrity`
  - `PROCESSOR.EVENT.INJECT kind=neuro_integrity.run payload={"mode":"full","window":"24h"}`
- Ускоренный режим (после batch):
  - `INSPECTOR.RUN key=neuro.integrity.links_validity`
  - `INSPECTOR.RUN key=neuro.integrity.graph_topology`
- Корректирующие действия (под Two‑Keys при опасных изменениях):
  - `QUANT.LINK from_quant=<uuid> to_type=<...> to_id=<...> relation=<...>`
  - `PROCESSOR.POLICY.SET key=skills.spaced_repetition value={...}`
  - `PROCESSOR.EVENT.INJECT kind=plan_update|goal_assess payload={...}`

8. Интеграция с Процессором (P30)
- Процессор регистрирует задачу `neuro_integrity.check` в sleep‑расписании и на batch‑триггерах.
- Шаги подписи: `svc.processor.perceive/decide/act/observe/learn` + `cmd.hyperloop.*` для инспекторов/коррекций.
- Политики: лимиты времени и batch‑размеров; Two‑Keys для изменений структуры (связи/массовые апдейты).

9. Acceptance
- Sleep: завершённый отчёт без 5xx; метрики/KPI доступны; инспекторы статус `passed|warning` без `failed` (или с оформленными корректирующими действиями/заявками Two‑Keys).
- Batch: после загрузки ≥500 квантов/≥1000 связей проходит ускоренный прогон (≤5 минут), нет критичных `failed`.
- P27: за окно 24h видны обязательные шаги по массовым операциям; Delivery Guard инцидентов нет.

10. Риски/Откаты
- Перегрузка: ограничение окна/частоты инспекций; деградация — только инспекции, без авто‑фиксов.
- Неправильные правки: Two‑Keys для корректирующих действий; dry‑run режимы.

11. Связанные документы (P‑серия)
- P16 — Sleep v2: `Soul/P16_TZ_Soul_MemoryCompaction_v1_0.md` (расписание Сна, оконные задачи)
- P25 — Skills/Routes: `Soul/P25_TZ_Soul_Skills_Routes_v1_0.md` (связи и модели навыков)
- P27 — Signature & Data Lineage: `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md` (обязательные шаги/инспекторы)
- P30 — Processor: `Soul/P30_TZ_Soul_Processor_v1_0.md` (управление задачей NeuroIntegrity)
- P36 — Hyperloop DSL: `Soul/P36_TZ_Hyperloop_DSL_v1_1.md` (INSPECTOR.RUN/PROCESSOR.EVENT/QUANT.LINK)
- P38 — NeuroTraining: `Soul/P38_TZ_Soul_NeuroTraining_v1_0.md` (оценка/батчи/RT‑микро‑батчи)
- P40 — Project Management: `Soul/P40_TZ_Project_Management_Soul_v1_0.md` (план/цели/вехи)
- P44 — Roles & Authorization: `Soul/P44_TZ_Soul_Roles_and_Authorization_v1_0.md` (RBAC/Two‑Keys)
- P45 — Quant Generation Modes: `Soul/P45_TZ_Quant_Generation_Modes_v1_0.md` (batch ingest, JSONL→SQL/Hyperloop)


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
