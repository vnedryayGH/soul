# P53 — ТЗ: Структурированный глоссарий проекта и Ядра Соул (v1.0)

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — актуальные инвентари для поиска новых терминов.
- `tmp_p_series_plan.json` — план P‑серии (подсвечивает связи/дубли для уточнения терминологии).
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — источник ссылок и статуса P‑серии.
- `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`, `Soul/P30_TZ_Soul_Processor_v2_0.md`, `Soul/P36_TZ_Hyperloop_DSL_v1_1.md` — ключевые термины для глоссария (подпись/процессор/DSL).

Назначение: единый глоссарий всех объектов/сущностей/понятий проекта и Ядра Соул, с группировкой по типам, зонами применения, кратким и подробным описанием, примерами из мировой практики и особенностями использования в проекте. Должен существовать как:

- документ в проектном каталоге (этот файл и записи в реестрах),
- сущности проектной структуры в БД (таблицы глоссария),
- отдельное окно поиска/чтения в мини‑приложении (и расширенная веб‑версия),
- отдельный Агент пополнения/целостности (алгоритм+LLM) и кнопка добавления понятия по требованию Архитектора.

## Область охвата и типы понятий

- Типы: core_object, db_entity, api_route, service, process, setting_flag, metric, alert, ui_component, prompt, role_permission, quant_concept, rs_actor, age_graph, test_suite, runbook, policy, glossary_meta.
- Каждое понятие имеет связи с другими понятиями (related, parent, child, alias, supersedes).

## Модель данных (БД)

- Таблицы (первичная версия):
  - glossary_types(id, key[uniq], title, description)
  - glossary_terms(id, key[uniq], title, type_key→glossary_types.key, short_desc, long_desc, project_notes, usages_json, tags[text[]], created_at, updated_at)
  - glossary_examples(id, term_id→glossary_terms.id, source, content, url, locale, weight)
  - glossary_links(id, from_term_id, to_term_id, relation_type)
  - Индексы: по key(title, tags), GIN(tags), полнотекстовый индекс (MVP — ILIKE).

## API (Backend FastAPI)

- Публично:
  - GET /api/glossary/search?q=&type=&limit= — поиск по title/key/tags/описаниям
  - GET /api/glossary/term/{id|key} — карточка термина (с примерами и связями)
  - GET /api/glossary/types — список типов
- Админ (RBAC: Architect/soul.admin):
  - POST /api/admin/glossary/term — создать/обновить (upsert по key)
  - PUT /api/admin/glossary/term/{id} — обновить
  - POST /api/admin/glossary/link — создать связь
  - POST /api/admin/glossary/extract — извлечь кандидаты из файла/текста (алгоритм+LLM, без автозаписи)
  - POST /api/admin/glossary/agent/run — единичный прогон агента (без фонового цикла на локали)

Метрики/наблюдаемость:

- glossary.search_latency_ms p95, glossary.search_total{status}
- glossary.upsert_total{status}, glossary.agent_suggestions_total
- Человекочитаемые аннотации для алертов (severity/risk + действия).

## UI (Mini‑App + Web)

- Страница "Глоссарий":
  - Поле поиска, фильтры по типам, список результатов, детальная карточка справа.
  - Кнопка "Добавить понятие" (видна Architect) → модальное окно upsert.
  - Секция: где используется (автоматически собранные ссылки), особенности в проекте, примеры.
- Расширенная веб‑версия: та же страница с дополнительными фильтрами/экспортом.

## Агент целостности глоссария

- Источники: docs/PROJECT_STRUCTURE*, SYSTEM_MASTER_DOCUMENTS_REGISTRY, Soul/P*-TZ, backend/app/routers/*.py, orm_models.py, ops/grafana/*, ops/prometheus/*.
- Этапы (одиночный запуск по кнопке):

  1) Сбор кандидатов (эвристики/регэкспы, ключевые секции docs, объявления классов/роутов)
  2) Нормализация/кластеризация алиасов
  3) LLM‑оценка и заполнение полей (кратко/детально/мировая практика/особенности)
  4) Формирование предложений (draft) без автозаписи
  5) Подтверждение Архитектором → upsert

Инварианты:

- Источник истины — БД; документы синхронизируются/ссылаются, но не заменяют БД.
- Без фоновых бесконечных циклов на рабочей станции; запуск агента — ручной/через Processor на APP серверах.
- Без хардкодов URL/портов — всё через SoulSettingsService/SecretsService.

## Acceptance (MVP)

- БД: таблицы созданы, индексы работают; Alembic миграция применима и обратима.
- API: публичный поиск и карточка термина; админ upsert и extract; p95 поиска ≤ 150 ms на 1k терминов.
- UI: страница доступна из меню; поиск/фильтры; карточка термина; кнопка добавления (Architect).
- Агент: ручной запуск возвращает ≥5 валидных предложений по docs/PROJECT_STRUCTURE.
- Документация: P53 добавлен в реестр, PROJECT_STRUCTURE обновлён; правила наблюдаемости перечислены.

## План релиза

1) Миграции/модели → 2) API/метрики → 3) UI → 4) Агент (extract + upsert‑flow) → 5) Документация/реестры.

## Ключи настроек (SoulSettingsService)

- glossary.search.max_results (int, default=50)
- glossary.agent.enabled (bool, default=true)
- glossary.agent.timeout_ms (int, default=4000)
- glossary.examples.max_per_term (int, default=5)

## Новые термины (P20 — оркестрация и e2e)

- term: workflow_orchestration

  type: process
  title: Оркестрация воркфлоу
  short_desc: Управление последовательностями шагов e2e‑процессов с гарантиями.
  long_desc: Оркестрация определяет и исполняет шаги процессов (машины состояний, DAG/графы) с ретраями, компенсирующими транзакциями, идемпотентностью и наблюдаемостью. Для P20 это маршрутизация событий/заданий между сервисами Telegram‑платформы/мини‑аппы/ядра.
  usages_json: ["P20","P30","P29","P27"]
  tags: ["p20","workflow","saga","retry","idempotency"]

## Новые термины (P27 — Подпись/Линейность/Anchor)

- term: merkle_anchor

  type: process
  title: Merkle‑анкор корней подписи
  short_desc: Периодическая мерклизация шагов подписи и публикация корня (root) в L2‑сети.
  long_desc: Сервис агрегирует новые трассы/шаги подписи P27, строит Merkle‑root и публикует хэш в L2 (Polygon/Base). Используется для публично‑проверяемой целостности; верификация — через Merkle‑proof.
  usages_json: ["P27"]
  tags: ["merkle","anchor","l2","integrity"]

- term: w3c_prov

  type: glossary_meta
  title: W3C PROV (происхождение данных)
  short_desc: Стандарт представления происхождения данных (PROV‑DM/PROV‑N/PROV‑O).
  long_desc: Набор спецификаций W3C для описания агентов, сущностей и активностей, формирующих происхождение данных. Поддерживает графовую модель и сериализации (PROV‑N, PROV‑XML, PROV‑O/RDF). Полезен для экспорта/обмена линий происхождения и аудита P27.
  usages_json: ["P27","P21","P30"]
  tags: ["prov","provenance","standard"]

## Новые термины (P21/P24/P30 — мировые практики)

- term: temporal

  type: service
  title: Temporal (оркестратор воркфлоу)
  short_desc: Надёжная оркестрация воркфлоу с долговечными таймерами/ретраями/сага‑паттерном.
  long_desc: Платформа для описания воркфлоу и активностей (activity/child workflows) с гарантиями доставки/ретраев и версионированием выполнения. Полезна как эталон для P20/P30.
  usages_json: ["P20","P30"]
  tags: ["temporal","workflow","orchestration"]


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
