# P47 — WebAuth MiniApp → Web (Cookie/OTP, Middleware, Security)

Назначение: надёжный и безопасный доступ к веб‑интерфейсу из Telegram Mini App без передачи токенов через URL. Основной путь — HttpOnly cookie (`sp_web`). Fallback — одноразовый OTP с установкой HttpOnly cookie `sp_token`.

Версия: v1.0 (2025‑09‑23)

Связанные ТЗ/разделы:

- P44 — Роли и Авторизация (RBAC/ABAC/ReBAC/Two‑Keys)
- P20 — Платформа Telegram
- PROJECT_STRUCTURE v8.0.4 — раздел Security/Authorization

## 1. Потоки (flows)

1) Основной (Cookie):

- MiniApp → POST `/api/web-auth/issue-web-cookie` с заголовком `X-Telegram-User-ID`.
- Backend: валидирует пользователя по БД, создаёт JWT (TTL 10 мин), устанавливает HttpOnly cookie `sp_web` c атрибутами безопасности.
- FE (TelegramHome): открывает веб на домене, браузер получает `sp_web` и автоматически аутентифицируется через middleware.

2) Fallback (OTP):

- MiniApp → POST `/api/web-auth/issue-one-time-token` (возврат OTP и `tg_id`).
- Web → POST `/api/web-auth/verify-otp` с `{ tg_id, otp }`.
- Backend: сверяет ожидаемый OTP (TOTP‑подобный, окно 300с), создаёт JWT (TTL до 12ч), устанавливает HttpOnly cookie `sp_token`.

## 2. Требования к cookie и JWT

- Имена: `sp_web` (основной, 10 мин), `sp_token` (OTP‑ветка, по умолчанию до 12ч).
- Атрибуты:
  - `HttpOnly` = true (запрет JS‑доступа)
  - `Secure` = true (только HTTPS)
  - `SameSite` = `Lax` для `sp_web`, `None` для `sp_token` (совместимость, если требуется кросс‑контекст)
  - `Domain` = `.soulpulse.art`
  - `Path` = `/`
  - `Max-Age` = 600 сек (sp_web), 43200 сек (sp_token по умолчанию)
- JWT payload (минимум): `{ user_id, web: true, tg_id, sub=tg_id, exp }`
- Подпись: общий `JWT_SECRET` проекта.

## 3. Middleware (WebSession)

Назначение: автоматическое восстановление сессии для веб‑страниц.

Алгоритм:

- Для обычных веб‑путей (исключая `/api/*`, `/ws/*`, `/webhook/*`) извлечь cookie `sp_web` или `sp_token`.
- Декодировать JWT, получить `tg_id` (`payload.tg_id` или `sub`).
- Установить заголовок `X-Telegram-User-ID` для нижележащих зависимостей/роутов.
- Не падать на ошибках (best‑effort), не логировать PII.

Безопасность:

- Только HttpOnly cookie; токены не попадают в JS/URL.
- Валидация срока действия/подписи — на уровнях, где JWT используется для принятия решений (RBAC/PEP/PDP).

Реализация:

- Файл: `backend/app/main.py` — middleware `web_session_restore_middleware`.
- Роутер: `backend/app/routers/web_auth.py` — эндпоинты `issue-web-cookie`, `issue-one-time-token`, `verify-otp`.

## 4. Требования к безопасности

- Запрет передачи токенов в URL/локальное хранилище; при необходимости — только HttpOnly cookie.
- Заголовки безопасности: `X-Frame-Options=SAMEORIGIN`, CSP, HSTS для HTTPS, `Referrer-Policy`, `Permissions-Policy`.
- Rate limiting для auth‑путей (тип `auth`).
- Синхронизация с RBAC/ABAC (P44): строгое использование `X-Telegram-User-ID` и сверка с токеном при доступе к защищённым ресурсам.

## 5. Тесты (интеграционные)

Покрыть сценарии:
1) Cookie‑путь: `issue-web-cookie` устанавливает `sp_web` с корректными атрибутами; тело `{ ok: true }`.

2) OTP‑путь: `issue-one-time-token` → `verify-otp` устанавливает `sp_token`, тело содержит `status=success` и `tg_id`.

3) Негативы: неверный/просроченный OTP → 401; поддельная cookie → middleware игнорирует, доступ по защищённым роутам не даётся.

4) Кросс‑браузер: отсутствие `localStorage` не мешает — доступ через HttpOnly cookie.

Реализация тестов:

- Директория: `backend/tests/test_webauth_integration.py`.
- Использовать `TestClient` FastAPI, dependency override для `get_db_session` (возвращать фиктивного пользователя по `tg_id`).
- Проверять флаги cookie (`HttpOnly`, `Secure`, `SameSite`, `Domain`, `Path`, `Max-Age`).

## 6. Acceptance

- Все тесты зелёные.
- На PROD: cookie устанавливается, middleware проставляет `X-Telegram-User-ID`, RBAC стабильно определяет роли.
- Метрики/логи: отсутствуют 5xx на путях web‑auth; нет утечек токенов в URL/JS; no‑store для `index.html` активен.

## 7. Следующие шаги

- Расширить негативные кейсы: просроченный `sp_web`, некорректный `SameSite` при iframe‑сценариях.
- Добавить инспекторы Hyperloop (P36) на наличие/стабильность web‑сессии (best‑effort).


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
