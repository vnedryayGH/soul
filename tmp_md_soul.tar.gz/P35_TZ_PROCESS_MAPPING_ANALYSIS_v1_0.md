# Сопоставление ТЗ 35 "Процессы" с существующими номерными ТЗ Soul

Версия: v1.0  
Цель: Детальный анализ потребности существующих объектов ЯС в ТЗ 35  
Основа: Анализ Report_Soul_AI_Scientific.md + дополнение Process_Enhancement  

## Исполнительное резюме

**Вывод**: Архитектура Soul уже содержит развитую процессную систему, распределенную по многим ТЗ. ТЗ 35 должно не дублировать, а **формализовать и унифицировать** процессы как сущности первого класса с языком Hyperloop.

**Ключевое открытие**: Персонажи ЯС (Дирижёр, Жандарм, Судья, Архивариус, Матерь флагов, Отец санитайзеров) уже являются **процессными ролями**, но нуждаются в формализации как Process Actors.

## Блок A. Матрица взаимосвязей процессов с номерными ТЗ

### A1. Ядро процессной архитектуры (уже реализовано)

| ТЗ | Роль в процессах | Статус | Потребность в ТЗ 35 |
|----|------------------|--------|---------------------|
| **P30 Процессор** | Центральный движок процессов OODA | ✅ Активен | Расширение: Process Registry, Process Analytics |
| **P36 Hyperloop DSL** | Язык управления процессами | ✅ Активен | Расширение: команды PROCESS.* |
| **P27 Подпись** | Трассировка процессов | ✅ Активен | Интеграция: process signature chains |
| **P29 Жандарм/Судья** | Контроль качества процессов | ✅ Активен | Формализация: process quality gates |
| **P28 FeatureFlags** | Управление режимами процессов | ✅ Активен | Расширение: process policy profiles |

**Вывод**: Ядро процессной архитектуры уже существует и работает. ТЗ 35 должно **формализовать** эти концепции.

### A2. Источники и триггеры процессов

| ТЗ | Роль в процессах | Реализация | Интеграция с ТЗ 35 |
|----|------------------|------------|-------------------|
| **P07 DesiredAction** | Результат процессов (что делать) | ✅ Полная | Process Output Handlers |
| **P17 Reminders** | Источник событий процессов | ✅ Полная | Event Source для Process Scheduler |
| **P20 TelegramBots** | Источник событий (чаты) | ✅ Полная | Event Source для Process Scheduler |
| **P26 Calendar** | Источник событий (календарь) | ✅ Полная | Event Source для Process Scheduler |
| **P31 Multisensory** | Источник событий (сенсоры) | ✅ Полная | Event Source для Process Scheduler |
| **P34 External Chat** | Источник событий (внешние чаты) | ✅ Полная | Event Source для Process Scheduler |

**Вывод**: Источники событий для процессов покрывают все каналы. ТЗ 35 должно **унифицировать** их как Event Sources.

### A3. Обслуживающие процессы (процессы поддержки ЯС)

| ТЗ | Процессы внутри ТЗ | Статус | Связь с ТЗ 35 |
|----|-------------------|--------|---------------|
| **P16 Sleep v2** | Этапы E0-E10: дедуп, архивация, индексы | ✅ Активен | Complex Process Example |
| **P21 Health Monitoring** | Процессы мониторинга/алертинга | ✅ Активен | Process Health Monitoring |
| **P24 Tests** | Процессы тестирования E2E | ✅ Активен | Process Testing Framework |
| **P32 RBAC** | Процессы авторизации | ✅ Активен | Process Security Gates |
| **P14 MultiProvider** | Процессы роутинга LLM | ✅ Активен | Process Provider Selection |

**Вывод**: Сложные процессы уже реализованы. ТЗ 35 должно **стандартизировать** их описание.

## Блок B. Персонажи ЯС как Process Actors (ключевое открытие)

### B1. Анализ персонажей ЯС в контексте процессов

Из P30 выявлены следующие персонажи ЯС, которые уже выполняют роли process actors:

| Персонаж ЯС | Текущая роль (P30) | Process Actor роль | Формализация в ТЗ 35 |
|-------------|-------------------|-------------------|----------------------|
| **Дирижёр** | Планировщик/оркестратор запусков | **Process Orchestrator** | Управление жизненным циклом процессов |
| **Матерь флагов** | Менеджер режимов/feature-flags | **Process Configuration Manager** | Управление конфигурацией процессов |
| **Отец санитайзеров** | NEGATIVE/санитайзеры/редактура | **Process Security Gate** | Контроль безопасности процессов |
| **Жандарм** | Оркестратор тестов качества | **Process Quality Controller** | Контроль качества процессов |
| **Судья** | Уставы/политики, инциденты | **Process Governance** | Управление политиками процессов |
| **Архивариус** | Заявки/запросы сервиса | **Process Knowledge Manager** | Управление знаниями о процессах |

**Критический инсайт**: Персонажи ЯС - это уже готовые **Process Actors**! ТЗ 35 должно формализовать их как процессные роли с четкими контрактами.

### B2. Процессные роли персонажей (детализация)

#### Дирижёр как Process Orchestrator
- **Входы**: События из processor_events, расписания, цели
- **Функции**: Планирование, приоритизация, координация выполнения
- **Выходы**: Скоординированные процессы, метрики производительности
- **Интеграция**: Hyperloop команды PROCESSOR.*

#### Жандарм как Process Quality Controller  
- **Входы**: Результаты процессов, метрики качества
- **Функции**: Запуск тестов, контроль SLA, анализ отклонений
- **Выходы**: Отчеты качества, рекомендации по улучшению
- **Интеграция**: Hyperloop команды TEST.*, INSPECTOR.*

#### Судья как Process Governance
- **Входы**: Политики, инциденты, нарушения
- **Функции**: Применение правил, разрешение конфликтов
- **Выходы**: Решения по инцидентам, обновления политик
- **Интеграция**: Hyperloop команды JUDGE.*, Two-Keys

## Блок C. Пробелы и потребности для ТЗ 35

### C1. Отсутствующие компоненты процессной архитектуры

| Компонент | Статус | Критичность | Описание |
|-----------|--------|-------------|-----------|
| **Process Registry** | ❌ Отсутствует | Высокая | Реестр всех процессов ЯС с метаданными |
| **Process Definition Language** | ❌ Отсутствует | Высокая | Формальное описание процессов |
| **Process Analytics** | ❌ Отсутствует | Средняя | Анализ эффективности процессов |
| **Process Templates** | ❌ Отсутствует | Средняя | Шаблоны типовых процессов |
| **Process Versioning** | ❌ Отсутствует | Средняя | Версионирование процессов |

### C2. Недоформализованные аспекты

| Аспект | Текущий статус | Требуется для ТЗ 35 |
|--------|----------------|-------------------|
| **Контракты персонажей** | Неформальные роли | Формальные интерфейсы Process Actors |
| **Межпроцессное взаимодействие** | Через Hyperloop DSL | Стандартизированные протоколы |
| **Обработка ошибок процессов** | Частичная (ретраи) | Comprehensive error handling |
| **Метрики процессов** | Фрагментарные | Унифицированные Process KPIs |
| **Документирование процессов** | Неструктурированное | Process Documentation Standards |

### C3. Возможности для улучшения

| Улучшение | Базовая реализация | Улучшение в ТЗ 35 |
|-----------|-------------------|-------------------|
| **Process Composition** | Отдельные команды DSL | Композиция сложных процессов |
| **Process Optimization** | Ручная оптимизация | Автоматическая оптимизация на базе метрик |
| **Process Discovery** | Неявные процессы | Process Mining из signature_steps |
| **Dynamic Process Routing** | Статическая маршрутизация | Адаптивная маршрутизация |

## Блок D. Архитектурные решения для ТЗ 35

### D1. Процессы как сущности первого класса

**Концепция**: Сделать процессы явными сущностями с собственными:
- Идентификаторами (process_id)
- Метаданными (название, описание, владелец)
- Определением (шаги, переходы, условия)
- Жизненным циклом (создание, выполнение, завершение)
- Метриками (производительность, качество)

**Структура данных процесса**:
```json
{
  "process_id": "soul_quant_birth_process",
  "name": "Рождение Кванта",
  "description": "Полный цикл создания кванта от стимула до персистенции",
  "type": "orchestration",
  "actors": ["Дирижёр", "Отец_санитайзеров", "Архивариус"],
  "definition": {
    "trigger": "chat_message|reminder|goal_update",
    "steps": [
      {"id": "perceive", "actor": "Дирижёр", "timeout_ms": 1000},
      {"id": "route", "actor": "soul_router", "timeout_ms": 500},
      {"id": "generate", "actor": "soul_core", "timeout_ms": 10000},
      {"id": "sanitize", "actor": "Отец_санитайзеров", "timeout_ms": 500},
      {"id": "persist", "actor": "Архивариус", "timeout_ms": 1000}
    ],
    "transitions": {
      "perceive->route": {"condition": "signature_valid"},
      "route->generate": {"condition": "context_loaded"},
      "generate->sanitize": {"condition": "json_parsed"},
      "sanitize->persist": {"condition": "clean_output"}
    }
  },
  "sla": {"max_duration_ms": 15000, "success_rate": 0.95},
  "monitoring": {
    "signature_chain": ["svc.processor.perceive", "svc.soul.router_decide", "svc.llm_client.send", "svc.llm_client.recv", "svc.parser.json_strict", "svc.chat.reply_render"],
    "kpis": {"latency_p95": 12000, "success_rate": 0.97}
  }
}
```

### D2. Process Actors как формальные интерфейсы

**Контракт Process Actor**:
```python
from typing import Dict, Any
from abc import ABC, abstractmethod

class ProcessActor(ABC):
    """Базовый интерфейс для персонажей ЯС как Process Actors"""
    
    @abstractmethod
    async def handle_step(self, 
                         step_id: str, 
                         context: Dict[str, Any],
                         signature_ctx: SignatureContext) -> Dict[str, Any]:
        """Обработка шага процесса"""
        pass
    
    @abstractmethod
    def get_capabilities(self) -> List[str]:
        """Список возможностей актора"""
        pass
    
    @abstractmethod
    def get_sla(self) -> Dict[str, Any]:
        """SLA актора (таймауты, ретраи)"""
        pass
```

**Реализация персонажей**:
```python
class Дирижёр(ProcessActor):
    async def handle_step(self, step_id: str, context: Dict, signature_ctx: SignatureContext):
        if step_id == "orchestrate":
            return await self._orchestrate_process(context)
        elif step_id == "prioritize":
            return await self._prioritize_queue(context)
        # ...
    
    def get_capabilities(self) -> List[str]:
        return ["orchestrate", "prioritize", "schedule", "coordinate"]
```

### D3. Расширения Hyperloop DSL для процессов

**Новые команды**:
```text
# Определение процессов
PROCESS.DEFINE name="quant_birth" definition_json="{...}"
PROCESS.LIST [filter="active|completed"]
PROCESS.DESCRIBE name="quant_birth"

# Выполнение процессов  
PROCESS.START name="quant_birth" context="{trigger:'chat_message'}"
PROCESS.STATUS process_instance_id="uuid"
PROCESS.STOP process_instance_id="uuid" reason="manual"

# Мониторинг процессов
PROCESS.MONITOR name="quant_birth" window="1h" 
PROCESS.OPTIMIZE name="quant_birth" target="latency"
PROCESS.ANALYZE name="quant_birth" period="7d"

# Управление процессными ролями
ACTOR.LIST
ACTOR.STATUS actor="Дирижёр"  
ACTOR.CONFIGURE actor="Жандарм" config="{...}"
```

### D4. Process Intelligence и аналитика

**Process Mining из signature_steps**:
- Анализ фактических путей выполнения процессов
- Выявление bottlenecks и отклонений от эталона
- Автоматическая оптимизация процессов

**Process Analytics Dashboard**:
- Метрики производительности процессов
- Анализ работы Process Actors
- Рекомендации по улучшению

## Блок E. Roadmap реализации ТЗ 35

### E1. Этап 1: Формализация существующих процессов (3 недели)
**Цель**: Описать все неявные процессы Soul как формальные Process Definitions

**Задачи**:
1. **Process Discovery** (1 неделя):
   - Анализ signature_steps за последний месяц
   - Выявление паттернов выполнения процессов  
   - Создание карты процессов Soul

2. **Process Registry** (1 неделя):
   - Создание схемы БД для процессов
   - Заполнение реестра ключевыми процессами
   - API для управления процессами

3. **Actor Formalization** (1 неделя):
   - Формализация персонажей ЯС как Process Actors
   - Определение контрактов и SLA
   - Интеграция с существующими сервисами

### E2. Этап 2: Расширение Hyperloop DSL (2 недели)  
**Цель**: Добавить команды управления процессами в DSL

**Задачи**:
1. **DSL Extensions** (1 неделя):
   - Реализация команд PROCESS.*
   - Интеграция с Process Registry
   - Тестирование команд

2. **Process Execution Engine** (1 неделя):
   - Движок выполнения процессов
   - Интеграция с Дирижёром (P30)
   - Обработка ошибок и ретраи

### E3. Этап 3: Process Intelligence (3 недели)
**Цель**: Внедрить аналитику и оптимизацию процессов

**Задачи**:
1. **Process Mining** (1 неделя):
   - Анализ signature_steps для Process Mining
   - Выявление отклонений от эталонов
   - Автоматическое обновление Process Definitions

2. **Process Analytics** (1 неделя):
   - Метрики производительности процессов
   - Анализ работы Process Actors
   - Dashboard для мониторинга

3. **Process Optimization** (1 неделя):
   - Алгоритмы оптимизации процессов
   - A/B тестирование улучшений
   - Автоматическое внедрение оптимизаций

### E4. Этап 4: Integration & Production (2 недели)
**Цель**: Внедрить процессную архитектуру в продакшен

**Задачи**:
1. **Production Integration** (1 неделя):
   - Интеграция со всеми источниками событий
   - Настройка мониторинга и алертов
   - Документация и runbook

2. **Performance & Scale** (1 неделя):
   - Оптимизация производительности
   - Тестирование под нагрузкой
   - Final acceptance testing

## Блок F. Acceptance Criteria для ТЗ 35

### F1. Functional Acceptance
✅ **Process Registry**: Все процессы Soul описаны и зарегистрированы  
✅ **Process Actors**: Персонажи ЯС работают как формальные Process Actors  
✅ **Hyperloop Integration**: Команды PROCESS.* доступны и функциональны  
✅ **Process Execution**: Процессы выполняются с соблюдением SLA  
✅ **Process Monitoring**: Метрики процессов отслеживаются в реальном времени  

### F2. Quality Acceptance  
✅ **Signature Integration**: Все процессы трассируются через P27  
✅ **Quality Gates**: Жандарм контролирует качество процессов  
✅ **Error Handling**: Процессы корректно обрабатывают ошибки  
✅ **Performance**: Process overhead < 5% от базовой производительности  
✅ **Documentation**: Процессы задокументированы с примерами  

### F3. Integration Acceptance
✅ **P30 Integration**: Процессор использует Process Registry  
✅ **P36 Integration**: Hyperloop DSL поддерживает команды процессов  
✅ **P27 Integration**: Подпись процессов интегрирована  
✅ **UI Integration**: Process Dashboard доступен в админ-панели  
✅ **Backward Compatibility**: Существующие процессы работают без изменений  

## Выводы и рекомендации

### Ключевые выводы:
1. **Процессная архитектура уже существует** в Soul, но требует формализации
2. **Персонажи ЯС являются Process Actors** и должны быть оформлены как таковые
3. **Hyperloop DSL** - идеальная основа для языка управления процессами
4. **P27 подпись** обеспечивает полную трассируемость процессов
5. **Большинство компонентов уже реализовано**, нужна интеграция

### Стратегические рекомендации:
1. **Не изобретать велосипед** - использовать существующую архитектуру
2. **Формализовать неявное** - сделать процессы явными сущностями
3. **Унифицировать управление** - через расширение Hyperloop DSL
4. **Добавить аналитику** - Process Intelligence для оптимизации
5. **Сохранить обратную совместимость** - эволюция, не революция

### Уникальные преимущества Soul:
- **Quantum-Native процессы** с дискретными единицами смысла
- **Программируемые персонажи** как Process Actors
- **Process-as-Code** через Hyperloop DSL  
- **Полная трассируемость** через P27 Signature
- **Интегрированное качество** через P29 Gendarme/Judge

**Заключение**: ТЗ 35 должно не создавать новую процессную архитектуру, а **формализовать и унифицировать** уже существующую богатую процессную систему Soul, сделав её первоклассным гражданином архитектуры.

---

**Интеграции**:  
- Базируется на: Soul/Report_Soul_AI_Scientific.md + Process_Enhancement_v1_0.md  
- Связано с: P30 (Процессор), P36 (Hyperloop), P27 (Подпись), P29 (Качество), P28 (Флаги)  
- Обновляет: docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8_1.md
