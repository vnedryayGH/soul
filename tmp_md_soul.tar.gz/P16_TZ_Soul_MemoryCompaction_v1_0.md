---

## Индекс взаимных ссылок (P01–P46)

- P01/P31 — связи с квантизованной памятью/смыслами.
- P03 — влияние на объёмы deep‑истории.
- P33 — Mini Chat: не применяется в текущем объёме.

### ТЗ Soul v1.0 — Память: компакция и архивация (Summarization/TTL)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: ЧАСТИЧНО ВЫПОЛНЕНО (MVP); ПРОВЕРКИ НЕ ЗАВЕРШЕНЫ (ожидает smoke на DEV)

---

### 0. Executive summary

- Цель: удерживать память «стройной» и полезной без потери опорных знаний: удалять дубликаты/шум, консолидировать низкополезные кванты в архивные суммари и поддерживать TTL‑политику.
- Интеграция: как подэтапы Sleep v2 (Э3 Дедуп/Канон, Э4 Якоря/Прюнинг, новый Э3.5 Архивация/Компакция), управляется через `soul_settings_service` и системный оркестратор.
- MVP без миграций (частично реализовано): мягкий декей, автоархив слабых, дедуп по одинаковому `thought_form`, создание summary‑квантов и связей; без удаления данных. Stage‑2 — расширить признаки/пороговые модели.

---

### 0.1 Консолидация Sleep v2 (E0–E10) и замена старого ТЗ

- Данное ТЗ (P16) является источником истины для «Сна v2». Документ `Soul/TZ_Soul_Sleep_v2_Full_v1_0.md` признан устаревшим и консолидирован здесь.
- Этапы Sleep v2: E0 Префлайт → E1 Health → E2 RankRefresh → E3 Дедуп/Канон → E3.5 Архивация/Компакция → E4 Якоря/Прюнинг → E5 GoalsReview → E6 Skills → E7 ResearchPlanner → E8 Индексы → E9 Maintenance → E10 Safety/Rollback.
- Интеграции с Optimize/Harvest отражены в разделах 4 и 8; наблюдаемость и алерты — в разделах 8 и 11.

Примечание: при расхождении пунктов между старым документом и данным P16 — применять спецификацию P16.

---

### 1. Архитектура и точки интеграции (Sleep v2)

- Оркестратор Sleep v2 вызывает модули по этапам (батчами по 10):
  - Э3 Дедуп/Канон → Э3.5 Архивация/Компакция → Э4 Якоря/Прюнинг → Э8 Индексы.
- Наблюдаемость: события `sleep_dedup`, `sleep_archive_compact`, `sleep_anchors`, `sleep_index_rebuild`.
- Без миграций: используем существующие `quants`/`quant_connections`/представления рангов; summary — обычный квант со связями.

---

### 2. ТЗ‑A. Дедуп и каноникализация (Э3)

Файл: `backend/app/services/system/modules/sleep/dedup_canonical.py`

Алгоритм (MVP):
1) Кластеризация по схожести (батч=10 тематических кластеров):

   - Текстовые признаки: Jaccard по токенам `thought_form/tags` + простая семантика.
   - Порог: `sleep.dedup.thresholds = { sim:0.88, jaccard:0.6 }`.

2) Выбор "канона": max(rank_score, свежесть, цитируемость).
3) Для неконанонических:

   - Создать связь `quant_connections(type='is_duplicate_of', from=dup, to=canon, connection_strength≈0.9)`.
   - Переназначить внешние связи dup → canon (если не усиливает шум), иначе ослабить.

4) Аудит `sleep_dedup {clusters, merged, kept_canon}`.

Без миграций. В MVP дубликаты не удаляем.

---

### 3. ТЗ‑B. Архивация и компакция (Э3.5)

Файлы: `sleep/archive_compaction.py`, `sleep/summarizer.py` (summarizer — планируется)

Отбор кандидатов:

- `energy_weight < sleep.archive_threshold` И низкая связность `degree ≤ K` (K из настроек), И не anchor/goal.

Алгоритм (батч=10):
1) Сгруппировать близкие кванты (по теме/тегам).
2) Сгенерировать краткое суммари (малый LLM/эвристика):

   - Создать новый квант `archive_summary` (tags += ['archive_summary']).
   - Связи `quant_connections(type='summary', from=orig, to=summary, connection_strength≈0.8)`.

3) Понизить `energy_weight` у исходных (clamp к ~0.02) и/или приоритет ранга.
4) Оставить ключевые связи (к канону/якорям/целям), прочие — ослабить ниже `connection_threshold`.
5) Аудит `sleep_archive_compact {groups, summarized, new_summaries}`.

Индексы активной памяти исключают явные архивные/дубликаты.

---

### 4. ТЗ‑C. Якоря и прюнинг (Э4) и нейропластичность/эмоциональное выравнивание

Файл: `sleep/anchors_prune.py`

Алгоритм:

- Выбирать per‑topic якоря по квоте `sleep.anchors.per_topic` (топ rank_score/связанность/цитируемость).
- Прюнинг: «листья графа» с низкой полезностью, не anchor/goal/summary → ослабить связи до порога (не удалять в MVP).
- Аудит `sleep_anchors {anchors_count, pruned_count}`.

Нейропластичность и эмоциональное выравнивание (новое):

- Этап E3.7 «EmotionCalibration» — обязательная процедура после массовых загрузок и в ночном цикле Сна.
- Детекция необходимости калибровки:
  - Триггеры:

    1) После инжеста батча JSONL (через Hyperloop) — счётчик `ingest.last_batch_external_count` > 0 (факт поступления внешних квантов).
    2) В начале Sleep — `SELECT COUNT(*) FROM quants WHERE created_at >= NOW()-INTERVAL '6 hours' AND (payload->>'source') IN ('K0','JSONL','import','topic_shards') AND (energy_weight > settings.sleep.external_energy_cap OR (payload->'composite_emotion'->>'intensity')::float > settings.sleep.external_intensity_cap)` ≥ `settings.sleep.emocalib.min_recent_external`.

  - Если ни один триггер не сработал — E3.7 пропускается.
- Классификация квантов:
  - Внешние: `(payload->>'source') IN ('K0','JSONL','import','topic_shards')` или `(payload->'source'->>'batch') IS NOT NULL`.
  - Собственные: иначе.
- Алгоритм калибровки (батчами по `settings.sleep.emocalib.batch_size`, по умолчанию 500):

  1) Для внешних: 

     - `energy_weight = LEAST(energy_weight, settings.sleep.external_energy_cap)` (def 0.25–0.55);
     - `payload.composite_emotion.intensity = LEAST(intensity, settings.sleep.external_intensity_cap)` (def 0.35–0.55) через `jsonb_set`.

  2) Для собственных (опционально, если `settings.sleep.internal_energy_floor_enabled=true`):

     - `energy_weight = GREATEST(energy_weight, settings.sleep.internal_energy_floor)` (def 0.60).

  3) Нормализация связей (опционально): ограничить силу связей внешних → собственные `connection_strength ≤ settings.sleep.external_link_cap` (если используется вес связей).
  4) Аудит: `sleep_emotion_align {adjusted_external, protected_internal, link_caps_applied}`.

- Интеграции:
  - После инжеста: оркестратор/процессор может поставить событие `sleep.emotion_align` или флаг для запуска E3.7 в ближайшем цикле.
  - Ночной цикл: этап E3.7 выполняется между E3.5 (Компакция) и E4 (Якоря/Прюнинг).
- Псевдо‑SQL (обновление внешних, одна партия):

```text
WITH cte AS (
  SELECT id
  FROM quants
  WHERE created_at >= NOW()-INTERVAL '24 hours'
    AND (payload->>'source') IN ('K0','JSONL','import','topic_shards')
    AND (energy_weight > :ew_cap OR COALESCE((payload->'composite_emotion'->>'intensity')::float,0) > :int_cap)
  LIMIT :batch
)
UPDATE quants q
SET 
  energy_weight = LEAST(q.energy_weight, :ew_cap),
  payload = jsonb_set(
    q.payload,
    '{composite_emotion,intensity}',
    to_jsonb(LEAST(:int_cap, COALESCE((q.payload->'composite_emotion'->>'intensity')::float,0))),
    true
  )
FROM cte
WHERE q.id = cte.id::uuid;

```

- Acceptance E3.7:
  - При наличии внешних квантов с превышением порогов — после E3.7 их `energy_weight` и `payload.composite_emotion.intensity` не превышают капы; собственные ≥ пола (если включено).
  - Метрика `sleep_emotion_align.adjusted_external > 0` при наличии кандидатов; отсутствуют 5xx; индексы и активный ретрив не деградируют (p95 в норме).
  - Инцидент/аудит записан; счётчики откалиброванных квантов и лимиты батчей отражены в логе.

---

### 5. ТЗ‑D. Индексы и представления (Э8)

Файл: `sleep/index_rebuild.py`

Действия:

- Обновление текстового индекса (BM25) и векторного (если есть), исключая архив/дубликаты из активного набора.
- Рефреш `quant_rank_mv`.
- Аудит `sleep_index_rebuild {bm25_rebuilt, vec_rebuilt, mv_refreshed}`.

---

### 6. Контракты (Pydantic, сервер)

```python
from typing import List
from pydantic import BaseModel

class DedupCluster(BaseModel):
    canon_id: str
    duplicates: List[str]
    score: float

class SummaryPlan(BaseModel):
    group_ids: List[str]
    summary_hint: str

class SummaryResult(BaseModel):
    summary_quant_id: str
    covered_ids: List[str]

```

---

### 7. Конфигурация (soul_settings) и ENV

- Уже есть: `energy_decay_rate`, `connection_threshold`, `sleep_interval_hours`, `archive_threshold`.
- Добавить:
  - `sleep.dedup.thresholds = { sim:0.88, jaccard:0.6 }`
  - `sleep.anchors.per_topic = 5`
  - `sleep.compaction.batch_size = 10`
  - `sleep.safe_mode = true`
  - `sleep.emocalib.min_recent_external = 100`
  - `sleep.external_energy_cap = 0.35`
  - `sleep.external_intensity_cap = 0.45`
  - `sleep.internal_energy_floor_enabled = false`
  - `sleep.internal_energy_floor = 0.60`
  - `sleep.external_link_cap = 0.6`
  - `sleep.ttl.days_by_topic = { default: 365 }` (Stage‑2)

ENV — только как дефолты; источником истины служит БД настроек.

---

### 8. Наблюдаемость и алерты

- События: `sleep_dedup`, `sleep_archive_compact`, `sleep_anchors`, `sleep_index_rebuild`, `sleep_done`.
- Эндпойнты админа: `POST /api/soul/sleep/dry_run` (предпросмотр), `POST /api/soul/optimization/run`.
- Метрики:
  - Объём активной памяти (до/после), доля дубликатов, доля архивных.
  - Retrieval accuracy (golden‑set) до/после, p95 латентности ретрива.
  - Количество/длина суммари; средний размер контекста.
- Алерты:
  - `retrieval.accuracy_delta < -2%`
  - `retrieval.p95_ms_delta > +10%`
  - `sleep.run_time > sleep.max_runtime_sec`

---

### 9. Acceptance

- После Sleep v2 (ожидается, проверка не завершена):
  - Активная память снижена без падения accuracy ретрива (допуск ≤ −2%).
  - Есть summary‑кванты и связи `summary`/`is_duplicate_of`.
  - Якоря сохранены; связи к целям не ухудшились.
  - Индексы обновлены; p95 ретрива не вырос > 10%.

---

### 10. Тест‑план

- Unit: корректность связей `is_duplicate_of/summary`, сохранение канона/якорей.
- Integration: прогон Sleep v2 на DEV, сравнение метрик до/после.
- Perf: ограничение batch‑размеров, время этапов.

---

### 11. Метрики, SLO, алерты

- Метрики:
  - `sleep.dedup.clusters`, `sleep.dedup.merged`, `sleep.dedup.kept_canon`
  - `sleep.archive.groups`, `sleep.archive.summaries`
  - `retrieval.accuracy_delta` до/после Sleep, `retrieval.p95_ms_delta`
- SLO: снижение объёма активной памяти ≥ 10–30% без падения accuracy более 2%
- Алерты: `accuracy_delta < -2%`, `retrieval.p95_ms_delta > +10%`, `sleep.run_time > max_runtime`

---

### 12. Rollout

- Unit: корректность связей `is_duplicate_of`/`summary`, сохранение канона/якорей
- Integration: полная прогонка Sleep v2 на DEV, сопоставление метрик до/после
- Perf: ограничение batch‑размеров, проверка времени этапов

---

— Флаг `sleep.safe_mode=true` на старте (без удалений) — только ослабление/суммари
— Постепенно расширять охват тем/кластеров; мониторить accuracy и p95 ретрива

---

### 13. Траблшутинг

- Агрессивная компакция → поднять `archive_threshold`, уменьшить `anchors.per_topic`, включить safe‑mode.
- Дубликаты не ловятся → ослабить пороги sim/jaccard, нормализовать текст.
- Деградация ретрива → увеличить квоту якорей, исключить summary из активного индекса, точечно разархивировать.

---

### 14. Быстрая реализация (≤ 1–2 дня)

1) (сделано) `sleep_service.py`: декей/архив/дедуп/summary, dry_run.
2) (сделано) Эндпойнт dry_run.
3) (план) `summarizer.py` (LLM/эвристика для тематического summary).
4) (план) `anchors_prune.py` и `index_rebuild.py` — наполнить реализацией.
5) (в процессе) Аудит/метрики и smoke на DEV.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
