# План работ: PROD DB Inventory → P26 Import → P25 Skills DDL → PR feat/fe-build-hygiene

## Цели
- Проверить и зафиксировать структуры БД на PROD (таблицы/колонки/матвью) без деградаций.
- Довести «недоехавшие» миграции операционно (IF NOT EXISTS), не ломая историю Alembic.
- Провести ручной импорт P26 (задачи/события → цели) и подтвердить маппинги labels→tags и статусов задач→целей.
- Подготовить PR feat/fe-build-hygiene с меткой build-hygiene.

## Инварианты
- Не трогаем Nginx/сервис; работаем только с приложением и БД.
- Все SSH-команды оформляем как bash -lc с корректным экранированием для PowerShell.
- При дрейфе PROD используем операционные DDL с IF NOT EXISTS + ленивое создание матвью.

## Шаблоны устойчивых команд (PowerShell)
- Проверка заголовка ассетов (без правок сервера):
```
powershell -NoProfile -Command "curl.exe -sI https://mini.soulpulse.art/assets/ | findstr /I Content-Type"
```
- SSH c bash -lc (удвоение одинарных кавычек и экранирование $):
```
powershell -NoProfile -Command 'ssh -i "deploy/ssh_keys/app_server_key" -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc ''echo OK''"'
```

## 1) Инвентаризация PROD БД
- Список ключевых таблиц/матвью/колонок:
```
powershell -NoProfile -Command 'ssh -i "deploy/ssh_keys/app_server_key" -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc ''set -e; set -a; [ -f /etc/soulpulse/miniapp_backend.env ] && . /etc/soulpulse/miniapp_backend.env; set +a; DBURL=$(echo \"$DATABASE_URL\" | sed -E s/^postgresql\+[^:]+:/postgresql:/); if [ -z \"$DBURL\" ]; then echo DBURL_EMPTY; exit 0; fi; echo ===TABLES===; psql \"$DBURL\" -At -c \"SELECT table_schema||''.''||table_name FROM information_schema.tables WHERE table_schema=''public'' AND table_name IN (''quantum_goals'',''skills'',''skill_steps'',''skill_links'',''skill_assets'',''activity_schedules'',''activities'',''sensation_settings'') ORDER BY 1;\"; echo ===MATVIEWS===; psql \"$DBURL\" -At -c \"SELECT schemaname||''.''||matviewname FROM pg_matviews WHERE matviewname IN (''energy_balance_mv'',''activity_effectiveness_mv'') ORDER BY 1;\"; echo ===QG_COLS===; psql \"$DBURL\" -At -c \"SELECT column_name FROM information_schema.columns WHERE table_schema=''public'' AND table_name=''quantum_goals'' ORDER BY 1;\"; echo ===AS_COLS===; psql \"$DBURL\" -At -c \"SELECT column_name FROM information_schema.columns WHERE table_schema=''public'' AND table_name=''activity_schedules'' ORDER BY 1;\"; echo ===ACT_COLS===; psql \"$DBURL\" -At -c \"SELECT column_name FROM information_schema.columns WHERE table_schema=''public'' AND table_name=''activities'' ORDER BY 1;\"; echo ===SENS_COLS===; psql \"$DBURL\" -At -c \"SELECT column_name FROM information_schema.columns WHERE table_schema=''public'' AND table_name=''sensation_settings'' ORDER BY 1;\";''"'
```
- Интерпретация: если чего-то нет — применяем DDL из раздела 2.

## 2) Операционные DDL (идемпотентные)
- quantum_goals:
```
ALTER TABLE IF EXISTS public.quantum_goals ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.quantum_goals ADD COLUMN IF NOT EXISTS external_id text;
ALTER TABLE IF EXISTS public.quantum_goals ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.quantum_goals ADD COLUMN IF NOT EXISTS deadline_at timestamptz;
ALTER TABLE IF EXISTS public.quantum_goals ADD COLUMN IF NOT EXISTS tags text[];
```
- activity_schedules:
```
ALTER TABLE IF EXISTS public.activity_schedules ADD COLUMN IF NOT EXISTS timezone text;
ALTER TABLE IF EXISTS public.activity_schedules ADD COLUMN IF NOT EXISTS enabled boolean DEFAULT true;
ALTER TABLE IF EXISTS public.activity_schedules ADD COLUMN IF NOT EXISTS window int4range;
```
- row_version:
```
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS row_version bigint;
ALTER TABLE IF EXISTS public.sensation_settings ADD COLUMN IF NOT EXISTS row_version bigint;
```
- P25 таблицы:
```
CREATE TABLE IF NOT EXISTS public.skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  version text NOT NULL,
  description text,
  tags text[] DEFAULT '{}',
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_skills_name_version ON public.skills(name, version);
CREATE TABLE IF NOT EXISTS public.skill_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_id uuid NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
  step_order integer NOT NULL,
  name text NOT NULL,
  step_type text NOT NULL,
  dsl jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_skill_steps_skill_id ON public.skill_steps(skill_id);
CREATE INDEX IF NOT EXISTS ix_skill_steps_order ON public.skill_steps(skill_id, step_order);
CREATE TABLE IF NOT EXISTS public.skill_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_id uuid NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
  from_step_id uuid NOT NULL REFERENCES public.skill_steps(id) ON DELETE CASCADE,
  to_step_id uuid NOT NULL REFERENCES public.skill_steps(id) ON DELETE CASCADE,
  relation_type text NOT NULL DEFAULT 'next',
  metadata jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_skill_links_skill_id ON public.skill_links(skill_id);
CREATE INDEX IF NOT EXISTS ix_skill_links_from_to ON public.skill_links(from_step_id, to_step_id);
CREATE TABLE IF NOT EXISTS public.skill_assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_id uuid NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
  step_id uuid REFERENCES public.skill_steps(id) ON DELETE CASCADE,
  asset_type text NOT NULL,
  uri text,
  content jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_skill_assets_skill_id ON public.skill_assets(skill_id);
CREATE INDEX IF NOT EXISTS ix_skill_assets_step_id ON public.skill_assets(step_id);
```
- Матвью (лениво):
```
CREATE MATERIALIZED VIEW IF NOT EXISTS public.energy_balance_mv AS SELECT 1 AS placeholder;
CREATE MATERIALIZED VIEW IF NOT EXISTS public.activity_effectiveness_mv AS SELECT 1 AS placeholder;
```
- Запуск DDL на PROD одним пакетом:
```
powershell -NoProfile -Command 'ssh -i "deploy/ssh_keys/app_server_key" -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc ''set -e; set -a; [ -f /etc/soulpulse/miniapp_backend.env ] && . /etc/soulpulse/miniapp_backend.env; set +a; DBURL=$(echo \"$DATABASE_URL\" | sed -E s/^postgresql\+[^:]+:/postgresql:/); [ -z \"$DBURL\" ] && { echo DBURL_EMPTY; exit 0; }; psql \"$DBURL\" -v ON_ERROR_STOP=1 -c \"ALTER TABLE IF EXISTS public.quantum_goals ADD COLUMN IF NOT EXISTS source text; ALTER TABLE IF EXISTS public.quantum_goals ADD COLUMN IF NOT EXISTS external_id text; ALTER TABLE IF EXISTS public.quantum_goals ADD COLUMN IF NOT EXISTS status text; ALTER TABLE IF EXISTS public.quantum_goals ADD COLUMN IF NOT EXISTS deadline_at timestamptz; ALTER TABLE IF EXISTS public.quantum_goals ADD COLUMN IF NOT EXISTS tags text[]; ALTER TABLE IF EXISTS public.activity_schedules ADD COLUMN IF NOT EXISTS timezone text; ALTER TABLE IF EXISTS public.activity_schedules ADD COLUMN IF NOT EXISTS enabled boolean DEFAULT true; ALTER TABLE IF EXISTS public.activity_schedules ADD COLUMN IF NOT EXISTS window int4range; ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS row_version bigint; ALTER TABLE IF EXISTS public.sensation_settings ADD COLUMN IF NOT EXISTS row_version bigint; CREATE TABLE IF NOT EXISTS public.skills (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, version text NOT NULL, description text, tags text[] DEFAULT ''{}'', enabled boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()); CREATE UNIQUE INDEX IF NOT EXISTS ux_skills_name_version ON public.skills(name, version); CREATE TABLE IF NOT EXISTS public.skill_steps (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), skill_id uuid NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE, step_order integer NOT NULL, name text NOT NULL, step_type text NOT NULL, dsl jsonb, created_at timestamptz NOT NULL DEFAULT now()); CREATE INDEX IF NOT EXISTS ix_skill_steps_skill_id ON public.skill_steps(skill_id); CREATE INDEX IF NOT EXISTS ix_skill_steps_order ON public.skill_steps(skill_id, step_order); CREATE TABLE IF NOT EXISTS public.skill_links (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), skill_id uuid NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE, from_step_id uuid NOT NULL REFERENCES public.skill_steps(id) ON DELETE CASCADE, to_step_id uuid NOT NULL REFERENCES public.skill_steps(id) ON DELETE CASCADE, relation_type text NOT NULL DEFAULT ''next'', metadata jsonb, created_at timestamptz NOT NULL DEFAULT now()); CREATE INDEX IF NOT EXISTS ix_skill_links_skill_id ON public.skill_links(skill_id); CREATE INDEX IF NOT EXISTS ix_skill_links_from_to ON public.skill_links(from_step_id, to_step_id); CREATE TABLE IF NOT EXISTS public.skill_assets (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), skill_id uuid NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE, step_id uuid REFERENCES public.skill_steps(id) ON DELETE CASCADE, asset_type text NOT NULL, uri text, content jsonb, created_at timestamptz NOT NULL DEFAULT now()); CREATE INDEX IF NOT EXISTS ix_skill_assets_skill_id ON public.skill_assets(skill_id); CREATE INDEX IF NOT EXISTS ix_skill_assets_step_id ON public.skill_assets(step_id); CREATE MATERIALIZED VIEW IF NOT EXISTS public.energy_balance_mv AS SELECT 1 AS placeholder; CREATE MATERIALIZED VIEW IF NOT EXISTS public.activity_effectiveness_mv AS SELECT 1 AS placeholder;\"''"'
```

## 3) Ручной импорт P26
- Триггер админ-роутов (пример, с нужной авторизацией):
```
curl -sS -X POST https://mini.soulpulse.art/api/admin/calendar-transport/import/tasks -H "Content-Type: application/json" -H "Authorization: Bearer <TOKEN>" -d '{"dry_run": false}'

curl -sS -X POST https://mini.soulpulse.art/api/admin/calendar-transport/import/events -H "Content-Type: application/json" -H "Authorization: Bearer <TOKEN>" -d '{"dry_run": false}'
```
- Верификация наполнения:
```
powershell -NoProfile -Command 'ssh -i "deploy/ssh_keys/app_server_key" -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc ''set -e; set -a; [ -f /etc/soulpulse/miniapp_backend.env ] && . /etc/soulpulse/miniapp_backend.env; set +a; DBURL=$(echo \"$DATABASE_URL\" | sed -E s/^postgresql\+[^:]+:/postgresql:/); [ -z \"$DBURL\" ] && { echo DBURL_EMPTY; exit 0; }; echo QG_TAGS:; psql \"$DBURL\" -At -c \"select count(*) filter (where tags is not null) as with_tags, count(*) as total from quantum_goals;\"; echo QG_SRC_STATUS:; psql \"$DBURL\" -At -c \"select coalesce(source,''unknown'') as source, coalesce(status,''unknown'') as status, count(*) from quantum_goals group by 1,2 order by 1,2;\"''"'
```

## 4) Health/фоновые роботы
- Локальный health:
```
powershell -NoProfile -Command 'ssh -i "deploy/ssh_keys/app_server_key" -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc ''curl -sS -o /dev/null -w \"%{http_code} %{time_total}\\n\" http://127.0.0.1:8000/api/health''"'
```
- Хвост логов:
```
powershell -NoProfile -Command 'ssh -i "deploy/ssh_keys/app_server_key" -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc ''tail -n 200 /var/log/soulpulse/backend.log''"'
```

## 5) PR feat/fe-build-hygiene (без серверных правок)
- Локально:
```
git checkout -b feat/fe-build-hygiene
npm ci --prefix frontend
npm run build --prefix frontend --silent
# внести правки по гигиене сборки (sourcemaps, стабильные хэши, base)
git add -A
git commit -m "chore(frontend): build hygiene (sourcemaps, stable assets)"
# git push -u origin feat/fe-build-hygiene
# gh pr create -B main -t "Build hygiene" -b "Гигиена сборки фронта" -l build-hygiene
```

## Acceptance Criteria
- Все ключевые объекты БД присутствуют.
- Импорт P26 выполнен; `tags` и статусы целей заполняются корректно.
- Health 200 OK стабильно; фоновые роботы не зависают.
- Подготовлен PR feat/fe-build-hygiene с меткой build-hygiene.

## Чек‑лист
- [ ] Инвентаризация PROD БД
- [ ] Применены DDL при необходимости
- [ ] Импорт P26 (tasks/events → goals)
- [ ] Сводка `with_tags/total`, `source/status`
- [ ] Health и фоновые задачи проверены
- [ ] PR feat/fe-build-hygiene подготовлен
