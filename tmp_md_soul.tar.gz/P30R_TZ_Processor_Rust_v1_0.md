# P30R — ТЗ: Processor (Rust hot‑path) v1.0

Версия: v1.0
Статус: к внедрению (этап 4)

## 1) Назначение

Чистые функции планирования/тиков/таймаутов без БД: быстрые очереди, квоты, таймауты.

## 2) Контракты

Вход/выход — JSON снапшот `agenda`/`policies`.

```json
{ "agenda": [{"id":"e1","prio":10,"due_at":"..."}], "policies": {"max_qps": 50} }

```
Выход:

```json
{ "next": [{"id":"e1","action":"process"}], "backpressure": false }

```

## 3) SLA

`tick` ≤ 2 ms p95 при очереди до 5k событий/мин.

## 4) Наблюдаемость

Метрики: `processor_rs_tick_latency_ms{stage}`, `processor_rs_backpressure_on`, `processor_rs_queue_len`.

## 5) Интеграция

Через Python мост (UDS/HTTP); P27 Delivery Guard перед публикацией ответа неизменен.

## 6) Тесты

Golden‑кейс (детерминированные), property (идемпотентность/стабильность), soak 24h без утечек.

## 7) Acceptance

Стабильность при 1–5k событий/мин; детерминизм выбора; отсутствие регресса.

## Dual-language инварианты Processor

- RS.tick детерминируем; решения совпадают с Python‑эталоном на golden‑наборах.

- Guard на публикацию остаётся Python (P27) до полного закрытия RS; RS не ходит в БД.

- Откат: при `backpressure_on` или p95 > цели — немедленный fallback на Python.

- Метрики: `processor_rs_tick_latency_ms{stage}`, `processor_rs_backpressure_on`, `processor_rs_queue_len`.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
