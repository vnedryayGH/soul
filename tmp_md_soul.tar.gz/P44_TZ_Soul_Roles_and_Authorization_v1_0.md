# P44 — ТЗ: Система ролей и полномочий Ядра Соул (RBAC/ABAC/Two‑Keys)

Версия: v1.0

API_BASE: `https://mini.soulpulse.art/api`

ADMIN_TG_ID: `468326902`

## Назначение

Сформировать каноническую спецификацию системы ролей и полномочий для мини‑приложения и Ядра Соул с гарантией защиты данных и устойчивости UI. Модель покрывает: API (PEP), сервисный слой (PDP), LLM‑пайплайн (автопубликация/лимиты), Hyperloop DSL (Two‑Keys), UI‑гварды и кэш ролей.

## Область (стыковки)

- P32 (RBAC & Subscriptions) — база данных и лимиты LLM; P44 поднимает это до целостной модели, включая Two‑Keys/Hyperloop/LLM‑пайплайн.
- P27 (Signature & Guard), P28 (FeatureFlags), P29 (Quality), P30 (Processor), P36 (Hyperloop DSL), P23 (UI), P20 (Telegram Platform), P22 (API Alignment), P09/P08 (Security/Privacy).
- P45 (Quant Generation Modes) — офлайн/пакетная генерация квантов требует RBAC (Architect/Admin) и, при массовых загрузках/линковках, Two‑Keys подтверждений (QUANT.LINK batch, DB.*).

---

## Задание на реализацию (для LLM‑инженера)

Ты выполняешь роль высококлассного LLM‑инженера (Deep‑Dive Start Template).

- Роль: Ведущий LLM‑инженер полного цикла (анализ → проектирование → реализация → тесты → документирование → отчёт). Ответственность: комплексное выполнение P44 и связанных P‑ТЗ без заглушек и без регресса функциональности/требований.
- Цель: Реализовать P44 end‑to‑end.

Артефакты проекта (обязательная актуализация):

- `docs/PROJECT_STRUCTURE_v...`: архитектура, точки интеграции, данные, потоки.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v...`: реестр документов/версий/статусов.
- `docs/PERSONA_REGISTRY_v1_0.md`: роли/полномочия персонажей (обязательно в актуальном состоянии).
- Рабочий лог: `docs/_tmp/TZ_44_EXECUTION_LOG.md` (пошаговая фиксация решений/ссылок/результатов).

LLM‑маршрутизация (правило проекта, P14/P28):

- DeepSeek — для сложных пользовательских запросов, генерации Квантов и диалогов.
- GigaChat — для сервисных/утилитарных задач (планер/консистентность/судья/оценки).
- Отражение: в `docs/PERSONA_REGISTRY_v1_0.md` для `soul`, `processor`, `bot_orchestrator`; в `Soul/P14_TZ_Soul_MultiProviderRouting_v...` (профили функций) и профилях фич‑флагов (P28).
- Acceptance: при включённой маршрутизации фактические маршруты и метрики соответствуют политике (см. P14).

Принципы выполнения:

- Без заглушек: только реальная логика, без TODO/фиктивных ответов.
- Без регресса: расширяем тесты/спеки; подтверждаем зелёный прогон.
- Комплексность: согласование интерфейсов/данных между затронутыми модулями.
- Чистый код сразу: корректный нейминг/формат, явные инварианты и обработка ошибок.
- Трассируемость: каждая задача — ссылки на ТЗ/коммиты/PR/тесты/обновлённые docs.

Модули и ответственность (уровень ожиданий/DoD):

- Гиперлуп (P36): конвейеры событий; очереди, ретраи, back‑pressure, наблюдаемость.
- Подписи (P27): сквозная «Подпись», required‑шаги, Delivery Guard, реестр функций.
- Процессор (P30): жизненный цикл Perceive→…→Learn; идемпотентность, инциденты.
- Дирижёр: оркестрация/панели подписи/инспекторов; покрытие, инциденты, RCA.
- Судья (P29): уставы/политики, Two‑Keys для опасных операций, инциденты.
- Жандарм (P29): тест‑реестр/запуск/аналитика, регрессионные наборы.
- Архивариус: поддержка реестров (docs/OpenAPI/Project Structure/Personas).
- Мать флагов (P28): профили фич‑флагов, инспекторы, reconcile инвариантов P27.
- Отец санитайзеров (P28/P27): валидность паттернов, охват PII, отсутствие конфликтов.
- Для каждого: интерфейсы, сценарии, инварианты, метрики SLO/SLA, тест‑наборы, обновлённая документация.

Проекция на ключевые процессы:

- Рождение Квантов: валидные источники, санитайзинг, роутинг LLM по P14, сохранность, метрики.
- Достижение Целей: план/оркестрация/контроль, оценка успеха, аудит и подпись шагов (P27).
- Напоминания: триггеры, дедуп, SLA доставки, пользовательские политики, инспекторы.
- Навыки: инвентарь, RBAC/политика вызова, безопасное исполнение, контроль побочных эффектов.

Цикл по каждому подпункту:
1) Анализ: связи с P14/P27/P28/P29/P30/P36, контракты данных, интеграции, риски.
2) Детализация ТЗ: требования, I/O‑примеры, политики ошибок, критерии приёмки.
3) Реализация: без заглушек, идемпотентность, наблюдаемость (логи/метрики/трейсы).
4) Тестирование: unit + интеграционные + e2e; негативные/деградационные кейсы.
5) Документация: `docs/PROJECT_STRUCTURE_v...`, `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v...`, `docs/PERSONA_REGISTRY_v1_0.md`, рабочий лог.
6) Отчёт: что и где изменено, на основании каких требований; ссылки на тесты/доки/коммиты.

Критерии приёмки (Definition of Done):

- Выполнены требования P44 и связанных P‑ТЗ; полная трассировка (P27).
- Тесты зелёные; добавлены кейсы на новые/изменённые сценарии (включая Hyperloop‑инспекторы).
- Обновлены `docs/PROJECT_STRUCTURE_v...`, `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v...`, `docs/PERSONA_REGISTRY_v1_0.md`.
- Маршрутизация LLM по умолчанию соответствует политике (P14); флаги/инспекторы P28 синхронизированы.
- Рабочий лог `docs/_tmp/TZ_44_EXECUTION_LOG.md` содержит шаги/решения/ссылки.
- Метрики/трейсы подтверждают инварианты (required‑steps, Delivery Guard, p95 SLA по P14).

Требования к качеству:

- Нулевые линтер‑ошибки; понятные имена; явная обработка ошибок; без скрытых глобальных сайд‑эффектов.
- Стабильные типы и валидация контрактов на границах модулей.
- Производительность подтверждена нагрузочными сценариями на критических путях.
- Безопасность: санитайзеры/энкодинг/RBAC — в соответствии с Жандармом/Отцом санитайзеров; Two‑Keys для опасных операций.

Формат отчёта по завершении:

- Краткое резюме по каждому модулю и процессу.
- Список изменений с путями, ссылками на коммиты/PR и тесты.
- Сводка метрик до/после; выявленные и исправленные дефекты.
- Перечень обновлённых разделов `docs/PROJECT_STRUCTURE_v...`, записей реестров и персоны/LLM‑профилей (P14/P28).

Прочее:

- При обнаружении пробелов в ТЗ — дополнять и сразу реализовывать/покрывать тестами и документацией по правилам выше.
- Обязательная актуализация: `docs/PROJECT_STRUCTURE_v...`, `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v...`, `docs/PERSONA_REGISTRY_v...`.

## Шаг 1 — Критический анализ Report_Soul_AI_Scientific.md (отметка)

- Единая сборка промпта, NEGATIVE, STRICT_JSON и batch/stateless уже заданы; требуется явный слой гувернанса доступа: PEP на HTTP/DSL/операциях LLM и Two‑Keys для опасных команд.  
- Риски из отчёта: утечки подсказок, смена роли, статлесс‑ветка без БД. Митигируем: централизованный RBAC/ABAC, аудит `_audit_direct`, отказ по умолчанию (default‑deny).

Итог: дополняем архитектуру ядра слоем Authorization с инвариантами: default‑deny, PoLP, explicit grants, audit‑by‑default, idempotency.

## Шаг 2 — Мировая практика (свод)

- RBAC/ABAC (NIST/OWASP ASVS V2): роли + атрибуты (контекст/временные окна/канал).  
- Zanzibar/ReBAC: отношения «кто‑к чему» полезны для графа квантов; применяем точечно (admin‑панель/ownership), но не как базовый механизм.  
- Policy‑as‑Code: PDP (policy decision point) через сервис `RBACService` + конфиг‑матрица эндпоинтов; расширение до ABAC предикатов.  
- PDP/PEP/Central audit: обязательные события отказов/разрешений; трассировка `signature_steps` (P27).  
- Two‑Keys (dual control) — для опасных DSL/NET/DEPLOY команд (P36), подтверждение 2 субъектами из разных ролей/контуров.

Решение P44: RBAC как база, ABAC‑предикаты для контекста, ReBAC для владения, Two‑Keys для опасных операций; централизованный PDP и кэш ролей.

---

## Шаг 3 — Общее ТЗ системы полномочий

### 3.1 Модель данных (расширение P32)

- Таблицы (подтверждено P32): `roles`, `permissions`, `role_permissions`, `user_roles`, `subscription_plans`, `user_subscriptions`, `llm_limits`, `user_llm_usage_stats`.  
- Дополнения P44: `two_keys_policies(id, key, scope, ttl_s, required_roles[], comment)`, `two_keys_approvals(id, policy_key, request_id, approver_user_id, created_at)`.  
- Ownership (ReBAC‑узел): `resource_acl(resource_type, resource_id, owner_user_id, scope, policy_key?)` — для точечных «own‑resource» проверок.

### 3.2 Политика принятия решений (PDP)

Порядок проверки:  
1) Аутентификация: Mini‑App — обязательный заголовок `X‑Telegram‑User‑ID`; Web — JWT + совпадение `tg_id` в токене и заголовке (см. backend `get_authenticated_user`).  
2) Feature Flags (P28): аварийные байпасы допускаются только через флаги окружения (dev/test), в PROD — запрещены.  
3) Endpoint Matrix (PEP): матрица ролей/прав/лимитов для маршрута (см. `rbac_middleware`).  
4) ABAC предикаты: канал (Mini‑App/Web), временные окна, статус подписки, региональные ограничения.  
5) ReBAC/Ownership: операции вида `*.self` или доступ к своим ресурсам.  
6) Two‑Keys: если маршрут/команда помечены как опасные — требуется заявка + второе подтверждение (см. §3.5).  
7) Лимиты LLM: `check_llm_quota(function_name[, llm_model_id])` (P32).  
8) Аудит: логировать и разрешения, и отказы.

### 3.3 Матрица API (PEP, консолидировано)

- Базовые (Mini‑App): `profile.read.self`, `api.keywords.read`, `api.dates.read`.  
- Напоминания: `api.reminders.read`, `api.reminders.write`, `api.reminders.update.self`, `api.reminders.delete.self` (premium+).  
- LLM: `llm.chat.use`, `llm.functions.read`, `llm.models.read`.  
- Админ/Архитектор: `soul.admin`, `registration.*`, `promo.*`, панели/настройки.  
- Hyperloop (P36): группы `CORE.*`, `FLAGS.*`, `TRACE.*` — только `architect`; `NET.*`, `DEPLOY.*`, `SCHEMA.*`, `DB.*` — `Two‑Keys` (см. §3.5).

### 3.4 UI‑правила (Mini‑App/Web)

- RoleGuard: страницы `architect/*`, `security/*`, `admin/*`, `rbac-admin`, `trace`, `llm-params` — жёстко скрывать контент до загрузки ролей даже в Mini‑App; позволён skeleton без данных.  
- RegistrationGuard: роль `start` всегда ведёт на `/register` (без байпаса в PROD).  
- Кэш ролей: хранить в памяти + `sessionStorage` с TTL≤60s; инвалидация по событию логина/смены пользователя.  
- Заголовки: всегда отправлять `X‑Telegram‑User‑ID`; в Web — добавлять JWT.

### 3.5 Two‑Keys Workflow (опасные операции)

- Политики: ключи `net.firewall.*`, `net.route.*`, `deploy.*`, `code.change.force`, `hyperloop.sys.*`, `db.migrate.*`.  
- Заявка: инициатор создаёт `approval_request(policy_key, payload_hash)` → запись в БД → выдаётся `request_id`.  
- Подтверждение: второй участник (роль из `required_roles` и не равен инициатору) утверждает `request_id` в окне `ttl_s`.  
- Выполнение: команда исполняется только при валидной паре ключей; аудит содержит инициатора, подтверждающего, хэш запроса и результат.  
- DSL (P36): команды с Two‑Keys исполняются только при наличии `request_id` и статуса approved.

### 3.6 Ошибки/коды

- 401 — аутентификация; 403 — недостаточно прав; 402 — исчерпана квота/нужен апгрейд; 409 — Two‑Keys: нет подтверждения/просрочено; 429 — лимиты LLM.  
- Сообщения без утечки внутренних деталей; `trace_id` и `audit_id` доступны в ответе для авторизованных ролей.

### 3.7 Наблюдаемость/метрики

- Счётчики отказов/разрешений по ключам прав/ролям; p95 задержки PDP; события Two‑Keys; LLM‑квоты/отказы.  
- Интеграция с P27: обязательные шаги `svc.rbac.check`, `svc.rbac.limits`, `cmd.hyperloop.authz.*` в `signature_steps`.

### 3.8 Миграции/seed (совместимо с P32)

- Идемпотентный seed: роли `architect|admin|vip|premium|basic|start|soul`; права из матрицы; базовые лимиты LLM; роль `basic` назначать всем без ролей.  
- Добавить таблицы Two‑Keys (§3.1), индексы по `policy_key`, `request_id`, `created_at`.

---

## Шаг 4 — Проверка целостности vs Ядро Соул

- SoulCore/LLM: автопубликация действий (`desired_action.autopublish`) допускается только при наличии прав (`actions.autopublish.*`) и зелёной цепочке P27 (Delivery Guard).  
- Processor (P30): все `act`‑исполнители идут через PDP; при нарушении — блок и инцидент.  
- Hyperloop DSL (P36): RBAC на уровне команд, Two‑Keys для опасных; `TRACE.REQUIRE` доступен архитектору.  
- UI (P23): жёсткие гварды, отказ от «показывать до загрузки ролей» для защищённых страниц.  
- ENV (prod/dev): байпас RBAC/DB допускается только в тест‑окружениях.

### Минимальное влияние внутри ядра Соул (роль `soul`)

- Системные контуры (Processor/Hyperloop/служебные задачи) работают под ролью `soul` с полным набором прав.  
- PDP выполняет ранний short‑circuit для роли `soul` (разрешение + запись аудита) без дополнительных проверок; бизнес‑пайплайны и контракты не меняются.  
- Все изменения локализованы в авторизационных слоях (PEP/PDP), не затрагивая сборку промптов, JSON‑схемы и последовательности шагов ядра.

---

## Шаг 5 — Сопоставление P01…P42 (влияния и риски)

- P01 MeaningExtraction: нет прямых привилегий; аудит вызовов; запрет экспонировать внутренние роли.  
- P02 MetaLoop: доступ к introspection только `architect`.  
- P03 RouterContext: конфиги роутера только `architect`; чтение — `admin+`.  
- P04 Hypothesis A/B: публикация победителя — `architect`; запуск экспериментов — `admin+`.  
- P05 Och: без спец‑прав; логика тональных смещений не влияет на RBAC.  
- P06 SelfConsistency: настройки — `architect`.  
- P07 DesiredAction: enforce `autopublish` через право `actions.autopublish.*`.  
- P08 Privacy: маскирование PII до логирования; доступ к сырым данным — `architect`/`admin` по спец‑правам.  
- P09 Security: интеграция алертов о неудачных авторизациях/эскалациях.  
- P10 Schema Guard: команды миграций — Two‑Keys.  
- P11 Provenance: экспорт/очистка — `architect`; чтение агрегатов — `admin+`.  
- P12 TraceViewer: доступ — `architect`; анонимизированные срезы — `admin`.  
- P13 Eval: запуск/публикация — `architect`; чтение метрик — `admin+`.  
- P14 Multi‑provider: изменение профилей — `architect`; чтение — `admin+`.  
- P15 Multilingual: изменение языковых политик — `architect`.  
- P16 Memory/Sleep v2: запуск фаз — `architect`; dry‑run — `admin+`.  
- P17 Reminders/Search: CRUD — `premium+`; актёр — по правам, без Telegram‑удалений (архитектурное правило).  
- P18/19 Voice: провайдеры/ключи — `architect`; использование — по ролям.  
- P20 TG Platform: Webhook/бот‑режимы — `architect`; пользовательский доступ — через `X‑Telegram‑User‑ID`.  
- P21 Health: панели — `admin+`; full‑metrics — `architect`.  
- P22 API Alignment: изменение контрактов — `architect`; соответствие прав отражать в OpenAPI.  
- P23 UI: гварды/навигация — по ролям; админ‑меню скрыто без ролей.  
- P24 Tests: тесты не поднимают серверы; использовать реальные TG‑ID; проверки RBAC обязательны.  
- P25 Skills/Routes: публикация/изменение навыков — `architect`; использование — по правам домена.  
- P26 Calendar/Transport: доступ к своим событиям — ownership; админ‑операции — `admin+`.  
- P27 Signature: обязательные шаги `svc.rbac.*`/`cmd.hyperloop.authz.*`.  
- P28 FeatureFlags: критичные флаги — Two‑Keys; чтение — `admin+`.  
- P29 Quality (Gendarme/Judge): правила — `architect`; апелляции — `admin+`.  
- P30 Processor: все стадии через PDP; Delivery Guard блокирует ответы без цепочки P27.  
- P31 Multisensory: доступ к сенсорным данным — `admin+`/`architect`; PRIVACY фильтры.  
- P32 RBAC & Subscriptions: источник истины по БД/лимитам; P44 добавляет Two‑Keys и целостные правила.  
- P33 Personification: редактирование — `architect`; чтение активной персоны — все роли.  
- P34 External Proxy/Mobile: ключи/маршруты — `architect`; клиентские операции — по ролям.  
- P35 Processes: Processor/Hyperloop шаги включают авторизационные события.  
- P36 Hyperloop DSL: команды авторизуются по матрице; Two‑Keys для `NET/DEPLOY/DB/SCHEMA`.  
- P38 NeuroTraining: TRAIN/EVAL/LEARN — `architect`; метрики — `admin+`.  
- P39 Sensory Memory: доступ ограничен; индексы — `architect`.  
- P40 Project Management: изменения уставов/профилей — Two‑Keys.

---

## Шаг 6 — Acceptance и реализация (без заглушек)

### Acceptance (минимум)

- PROD/DEV смоки возвращают 200: Health/DB/LLM/Dispatcher/Sleep/Sanity/Refresh.  
- Stateless batch — массив квантов; `desired_action=[]`; greenlet_spawn=0.  
- RBAC: запрет без ролей/прав; страницы `architect/*` не рендерят контент до загрузки ролей.  
- Hyperloop: `INSPECTOR.RUN_ALL` зелёный; `CORE.PIPELINE.RUN ... WITH TRACE` пишет шаги, видны `cmd.hyperloop.authz.*`.  
- Two‑Keys: попытка `NET.*` без подтверждения даёт 409; с подтверждением — 200 и аудит.  
- OpenAPI (P22): описаны заголовки/коды ошибок/требуемые роли.

### Быстрые проверки

PowerShell (Windows):

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/health
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/rbac/roles' -Headers $H -Method Get | ConvertTo-Json -Compress
# Ожидаемо 403 для non-architect; 200 для архитектора
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body (@{ commands='INSPECTOR.RUN_ALL' }|ConvertTo-Json -Compress) | ConvertTo-Json -Compress

```

### Порядок внедрения (создаётся всё целиком)

1) DB: миграции Two‑Keys; идемпотентный seed ролей/прав/лимитов.  
2) Backend: расширение `rbac_middleware` матрицей DSL/опасных зон; PDP: ABAC предикаты; Two‑Keys сервис/эндпоинты.  
3) P36: маркировка команд, требующих Two‑Keys; возврат `request_id`; инспекторы authz.  
4) UI: строгий RoleGuard/RegistrationGuard; кэш ролей (TTL≤60s); скрытие контента до загрузки ролей.  
5) Observability: метрики/логи отказов/разрешений; отчёты.  
6) OpenAPI: описать заголовки/коды/требуемые роли.

---

## План реализации (детализация)

Эпик A — Бэкенд (PEP/PDP/Two‑Keys)

- A1 PEP матрица маршрутов: владелец Страж; вход: список роутов; выход: JSON‑матрица; acceptance: 100% покрытие /admin/*, Hyperloop, LLM.
- A2 PDP предикаты ABAC/Ownership: владелец Страж; вход: контексты; выход: предикаты; acceptance: p95 PDP ≤ 10мс, корректные deny‑причины.
- A3 Two‑Keys сервис/DDL: владелец Страж; вход: политики; выход: таблицы/эндпоинты; acceptance: 409 без аппрува, 200 с аппрувом; аудит полон.
- A4 Лимиты LLM (P32): владелец Страж; вход: профили провайдеров; выход: проверки; acceptance: 402/429 корректны; отчёты по отказам.

Эпик B — UI/Гварды

- B1 RoleGuard/RegistrationGuard: владелец Фронт; вход: текущие страницы; выход: обёртки/спиннеры; acceptance: 0 показа без ролей.
- B2 Меню/навигация: владелец Фронт; вход: конфиги; выход: скрытие админ‑пунктов до ролей; acceptance: смоки UI зелёные.

Эпик C — OpenAPI/Docs

- C1 SecuritySchemes/security: владелец Фронтмен; вход: список админ‑роутов; выход: секции security; acceptance: spectral‑линт зелёный.
- C2 Project Structure/Report: владелец Архивариус; вход: обновлённые файлы; выход: ссылки и краткий свод; acceptance: инспектор ссылок зелёный.

Эпик D — Жандарм/Инспекторы/Метрики

- D1 Жандарм API/UI/DSL наборы: владелец Страж; вход: PEP/DSL; выход: тест‑сценарии; acceptance: 100% ключевых кейсов зелёные.
- D2 Инспекторы P27: владелец Страж; вход: `signature_steps`; выход: правила наличия `svc.rbac.*`/`cmd.hyperloop.authz.*`; acceptance: 24h окно зелёное.
- D3 Метрики/алерты P21: владелец Фронтмен; вход: series; выход: дешборд/алерты; acceptance: алерты срабатывают на синтетике.

Эпик E — Процессор/Hyperloop/Two‑Keys интеграция

- E1 Processor pre‑act guard: владелец Процессор; вход: акты; выход: вызов Стража; acceptance: deny блокирует акт + инцидент.
- E2 Hyperloop GUARD/TWO_KEYS команды: владелец Страж; вход: DSL; выход: команды; acceptance: `GUARD.TEST`/`TWO_KEYS.*` работают.

Ресурсы/сроки

- Владелец эпика: указаны выше; срок: 1–2 недели на эпик при параллельной работе; приёмка — по соответствующим разделам Acceptance.

Матрица полноты

- PEP матрица — готово; PDP/ABAC — готово; Two‑Keys — готово; UI‑гварды — готово; OpenAPI — готово; Жандарм — готово; Инспекторы — готово; Метрики — готово; Processor guard — готово; Hyperloop — готово.

## Траблшутинг (корни проблем и фиксы)

- «Слетание» ролей в UI: запрет показа защищённых страниц до загрузки ролей; кэш с TTL; повторная загрузка ролей при ошибке API; строгий путь авторизации в Web (`/webauth`).  
- Конфликт TEST_NO_DB/PROD: в PROD отключить любые байпасы; флаги включать только в dev/test.  
- Отсутствие Two‑Keys подтверждений: предоставлять ссылку/команду на создание/аппрув заявки; чёткие коды 409/403.

---

## Согласованность и безопасность

- Default‑deny; PoLP; audit‑by‑default; неизменность личности (NEGATIVE); Zero‑Trust к каналам.  
- Секреты — только из PROD `.env`; не логировать PII; хэшировать без PII; Two‑Keys для изменений уставов/сетей/деплоя.  
- Документационная дисциплина: любые изменения → обновить P32/P23/P36/P27/P22 и реестр.

---

## Каталог экранов/форм и точечные правки (минимальные)

- ArchitectPanel (`/#/architect`) — RoleGuard(['architect']), спиннер до ролей, 403‑экран.  
- SoulDashboard/SoulGoals/SoulOptimization/SoulVisualization/SoulLogs/SoulQuants (`/#/soul/*`) — RoleGuard(['architect']), спиннер до ролей.  
- SecurityDashboard/SecurityEvents/SecurityRedTeam (`/#/security*`) — RoleGuard(['architect']), спиннер, 403‑экран.  
- RBACAdmin (`/#/rbac-admin`) — RoleGuard(['architect']), спиннер, 403‑экран.  
- AdminPanel/SystemSettings/ResilienceAdmin/VoiceAdmin/BotControl/UIFormsRegistry (`/#/admin*`) — RoleGuard(['admin','architect']), спиннер, 403; при 402 — CTA апгрейда.  
- Trace (`/#/trace`), LLMParams (`/#/llm-params`) — RoleGuard(['architect']), спиннер.  
- MiniAppChat/TelegramChat — общедоступны; спиннер до `tg_id`; 401 → WebAuth.  
- Prompts/Settings — без Guard; спиннер до ролей.  
- DatesReminders/DatesRemindersV2/RemindersHistory — RoleGuard(['premium','vip','admin','architect']), 402 → CTA апгрейда.  
- Keywords/Help — без Guard; спиннер до ролей.  
- Payments — без изменений; отображать статус плана; обрабатывать 402.  
- WebLanding/WebAuth/TelegramHome — гарантировать запись `tg_id`/единый экран при отсутствии данных.  
- AllPages — оставить как есть; защищённые карточки скрываются RoleGuard на рендере.  
- PermissionBasedMenu — до ролей/конфига: «Главная/Чат/Напоминания»; админ/арх пункты не рисовать до подтверждённых ролей.

Единые правила UI: до загрузки ролей — спиннер (skeleton); все запросы с заголовком `X‑Telegram‑User‑ID` и (в Web) Bearer‑JWT; обработка кодов: 401→WebAuth, 403→«Недостаточно прав», 402→CTA апгрейда, 409(Two‑Keys)→«Требуется подтверждение операции». Формы/контракты не меняем — лишь обёртки‑гварды и обработка статусов.

---

## Реестр персонажей и авто‑поддержка Архивариуса

Цель

- Единый машинно‑читаемый реестр системных персонажей с описанием функций, ролей, полномочий, управляемых объектов и зон ответственности. Используется для документации, инспекторов и Жандарма.

Персонажи (первичный состав)

- Соул (ядро): генерация Квантов, инварианты STRICT_JSON, NEGATIVE; роль `soul`.  
- Архитектор: дизайн систем/политик; полномочия `soul.admin`, Hyperloop `CORE/TRACE`, Two‑Keys подтверждающий.  
- Фронтмен: целостность бэкенда/окружения; гейт миграций/OpenAPI/флагов; блок сборки при расхождении.  
- Страж (RBAC Guardian): матрица прав/ABAC/Two‑Keys/делегирование, Жандарм‑наборы, аудит.  
- Процессор: Orchestrator `Perceive→…→Learn`; вызывает Стража перед `act`, поднимает инциденты.  
- Тренер (P38): обучение по агрегированным событиям; рекомендации PoLP/риска (без влияния на итог авторизации).  
- Архивариус (или Библиотекарь): поддержка реестров/структур, авто‑актуализация персон/политик/ссылок в документах.

Структура записи реестра

- `id`, `name`, `purpose`, `roles[]`, `permissions[]`, `managed_objects[]`, `responsibilities[]`, `interfaces[]`, `observability{metrics,inspectors}`, `acceptance`, `security_notes`.

Авто‑поддержка (Архивариус)

- Скан исходников/документов на новые персонажи/функции; MR с обновлением `docs/PERSONA_REGISTRY_v1_0.md` и ссылок в `docs/PROJECT_STRUCTURE_*`.  
- Инспектор соответствия: отсутствие карточки персонажа → предупреждение; рассинхронизация ролей/прав → флаг.

Acceptance

- Реестр существует, валиден по схеме; ссылки в Project Structure/Report добавлены; инспекторы не находят рассинхронизаций.

## Проверка согласованности и сбалансированности (финальный чек)

- Контракты API/форм не меняются: добавлены только `securitySchemes`/`security` и обработка кодов 401/403/402/409; тела request/response стабильны.  
- Разделение ответственности: PEP на границах HTTP/DSL/UI; PDP централизован; ядро/пайплайны неизменны.  
- Принцип минимальных UI‑правок: применены Guard‑обёртки/спиннеры без рефакторинга страниц/компонентов.  
- OS‑уровень: доступы и секреты вынесены в окружение/права файлов; разграничение сервисных юзеров; сетевые ограничения через systemd/Nginx.  
- Two‑Keys интегрирован только для опасных команд; бизнес‑потоки не зависят от него.  
- Наблюдаемость полная: шаги `svc.rbac.*`/`cmd.hyperloop.authz.*`, метрики отказов/latency PDP; алерты на всплески/пропуски.  
- Acceptance/смоки подтверждены; регресс‑риски низкие благодаря локализации изменений и инвариантам P27/P28/P29.  
- Документация синхронизирована: P44, OpenAPI, Project Structure; влияние на P‑серии описано точечно (интерфейсы и минимальные правки).

Финальные баланс‑коррекции

- Роль `soul`: только короткий обход + аудит; любые небезопасные зоны (NET/DEPLOY/DB/SCHEMA) — всё равно через Two‑Keys.  
- UI: подтверждена стратегия «минимальные правки»: только Guard‑обёртки/спиннеры/обработка статусов; формы/контракты не меняем.  
- OpenAPI: для всех админ‑роутов присутствует `security` (TgHeaderAuth+Bearer) и коды 401/403/402/409/429.  
- PEP‑матрица: покрывает все /admin/*, Hyperloop, LLM‑операции; ownership для `*.self` включён в PDP.  
- Flags: `prod_safe` активен; `DISABLE_RBAC/TEST_NO_DB` заблокированы в PROD; опасные фич‑флаги под Two‑Keys.  
- Наблюдаемость: p95 PDP в бюджете; алерт на отсутствие инспекторов `svc.rbac.*`/`cmd.hyperloop.authz.*`.

Синхронизация P44↔P01–P42 (контрольные точки)

- P20/P22/P23 — проверены (заголовок/JWT, securitySchemes, UI‑гварды).  
- P27/P28/P29/P30 — проверены (подпись шагов/флаги/правила качества/инциденты).  
- P32/P36 — проверены (лимиты/Two‑Keys/DSL‑крючки).  
- P14/P17/P21 — проверены (провайдеры/ownership/дешборды).  
- P38 — проверен рекомендательный контур без влияния на итог авторизации.

Вывод: модель согласована; финальные риски — низкие, изменения локализованы.

---

## Отметки выполнения шагов P44

- [x] Шаг 1: проанализирован научный отчёт (сформулированы инварианты авторизации).  
- [x] Шаг 2: учтены лучшие практики (RBAC/ABAC/ReBAC/Two‑Keys/Policy‑as‑Code).  
- [x] Шаг 3: сформировано общее ТЗ (модель/PEP/PDP/UI/Two‑Keys/метрики).  
- [x] Шаг 4: проверена совместимость с ядром и инвариантами P‑серии.  
- [x] Шаг 5: добавлено сопоставление P01–P42 (влияния/риски).  
- [x] Шаг 6: задана приёмка, быстрые проверки и порядок внедрения.

---

## Примечания к внедрению

- Протестировать UI‑гварды в Mini‑App с реальным Telegram ID.  
- Отразить права/ролей в `docs/openapi-p20-telegram-bots.yaml`.  
- Обновить `docs/PROJECT_STRUCTURE_v8_0_4.md` (раздел Security/Authorization) и мастер‑реестр.

## Чек‑лист внедрения (Runbook)

1) DB: применить миграции P44 (Two‑Keys таблицы); убедиться в индексации.  
2) Seed: выполнить идемпотентный `RBACService.seed_defaults()`; проверить назначение `basic` для пользователей без ролей.  
3) Backend: включить `rbac_middleware` на административных/LLM/Hyperloop маршрутах; подключить PDP проверки и ABAC предикаты.  
4) Hyperloop: пометить опасные команды как Two‑Keys; включить выдачу/проверку `request_id`.  
5) UI: усилить `RoleGuard/RegistrationGuard`; скрывать защищённые страницы до загрузки ролей; добавить skeleton.  
6) OpenAPI: обновить securitySchemes, заголовки/коды и аннотации требований ролей/прав.  
7) Observability: включить метрики/логи отказов/разрешений; инспекторы P27 на `svc.rbac.*` и `cmd.hyperloop.authz.*`.  
8) Flags: активировать профиль P28 `prod_safe`; запретить `DISABLE_RBAC`/`TEST_NO_DB` в PROD.  
9) Смоки: выполнить «Быстрые проверки» и Acceptance; зафиксировать вывод.

## Примеры OpenAPI/PEP

### OpenAPI — securitySchemes и маршрут

```yaml
components:
  securitySchemes:
    TgHeaderAuth:
      type: apiKey
      in: header
      name: X-Telegram-User-ID
    BearerAuth:
      type: http
      scheme: bearer

paths:
  /api/admin/rbac/roles:
    get:
      security:
        - TgHeaderAuth: []
        - BearerAuth: []
      summary: List roles (architect only)
      responses:
        '200': { description: OK }
        '401': { description: Unauthorized }
        '403': { description: Forbidden }

```

### PEP — матрица эндпоинтов (фрагмент)

```json
{
  "/api/admin/rbac": { "admin_only": true },
  "/api/llm/functions": { "permissions": ["llm.functions.read"], "roles": ["premium","vip","admin","architect"] },
  "/api/hyperloop/execute": { "roles": ["architect"], "two_keys": ["NET.*","DEPLOY.*","DB.*","SCHEMA.*"] }
}

```

## Подзадачи с конкретными I/O‑примерами (RBAC/ABAC/Two‑Keys)

### A1 — PEP матрица маршрутов (RBAC)

- Вход (генерация матрицы): список маршрутов/методов с доменными тегами → PEP JSON.

```json
[
  { "path": "/api/admin/rbac/roles", "method": "GET", "tags": ["admin", "rbac"] },
  { "path": "/api/llm/functions", "method": "GET", "tags": ["llm", "catalog"] },
  { "path": "/api/hyperloop/execute", "method": "POST", "tags": ["hyperloop", "dsl"] },
  { "path": "/api/reminders", "method": "POST", "tags": ["reminders", "write"] }
]

```

- Выход (PEP JSON):

```json
{
  "/api/admin/rbac/roles": { "roles": ["architect"], "permissions": [], "two_keys": [] },
  "/api/llm/functions": { "roles": ["premium","vip","admin","architect"], "permissions": ["llm.functions.read"], "two_keys": [] },
  "/api/hyperloop/execute": { "roles": ["architect"], "permissions": [], "two_keys": ["NET.*","DEPLOY.*","DB.*","SCHEMA.*"] },
  "/api/reminders": { "roles": ["premium","vip","admin","architect"], "permissions": ["api.reminders.write"], "two_keys": [] }
}

```

- Пример рантайм‑запроса (ожидаемые статусы):
  - GET `/api/admin/rbac/roles` без роли `architect` → 403 Forbidden.
  - GET `/api/llm/functions` с планом `basic` → 402 Payment Required (апгрейд).
  - POST `/api/reminders` с ролью `premium` → 200 OK.

Пример тела ошибки (единый формат):

```json
{ "error": "forbidden", "code": 403, "reason": "role_mismatch", "trace_id": "c01a..." }

```

### A2 — PDP ABAC/Ownership (решение и причины)

- Вход (контекст PDP):

```json
{
  "route": "/api/reminders",
  "method": "POST",
  "headers": { "X-Telegram-User-ID": "468326902" },
  "jwt": { "tg_id": "468326902" },
  "abac_ctx": { "channel": "web", "time": "2025-09-23T11:00:00Z", "plan": "basic", "region": "RU" },
  "resource": { "type": "reminder", "id": null, "owner_user_id": 468326902 },
  "function_name": null
}

```

- Выход (deny по плану):

```json
{ "decision": "deny", "code": 402, "reason": "plan_not_allowed", "audit_id": "a-12f..." }

```

- Пример deny по JWT/заголовку (Web):

Вход: `jwt.tg_id = 111`, заголовок `X-Telegram-User-ID = 222` →

```json
{ "decision": "deny", "code": 401, "reason": "jwt_mismatch", "audit_id": "a-773..." }

```

- Пример deny по ownership:

Вход: `resource.owner_user_id = 999` при `header.tg_id = 468326902` и операции `*.self` →

```json
{ "decision": "deny", "code": 403, "reason": "ownership_mismatch", "audit_id": "a-9bf..." }

```

- Пример allow:

```json
{ "decision": "allow", "code": 200, "reason": "ok", "audit_id": "a-2aa..." }

```

### A3 — Two‑Keys (REST и DSL)

1) Создание заявки (REST):

```http
POST /api/two-keys/requests
Content-Type: application/json

{ "policy_key": "deploy.migrate", "payload_hash": "cafe...beef" }

```

Ответ:

```json
{ "request_id": "7c9e6679-7425-40de-944b-e07fc1f90ae7", "status": "pending", "expires_at": "2025-09-23T11:15:00Z" }

```

2) Подтверждение заявки (REST):

```http
POST /api/two-keys/requests/7c9e6679-7425-40de-944b-e07fc1f90ae7/approve

```

Ответ:

```json
{ "request_id": "7c9e6679-7425-40de-944b-e07fc1f90ae7", "status": "approved", "approved_at": "2025-09-23T11:05:12Z" }

```

3) Выполнение опасной команды (Hyperloop DSL):

```json
{
  "commands": "NET.RELOAD route=\\"/api\\"",
  "request_id": "7c9e6679-7425-40de-944b-e07fc1f90ae7"
}

```

Ожидаемо: 200 OK + шаги `cmd.hyperloop.authz.*` в `signature_steps`.

Негативы Two‑Keys:

- Без заявки/аппрува → 409 Conflict `{ "error":"two_keys_required" }`.
- Инициатор = подтверждающий → 403 Forbidden `{ "reason":"same_subject" }`.
- Просрочено `expires_at` → 409 Conflict `{ "reason":"expired" }`.

4) Аналоги в DSL:

- `TWO_KEYS.REQUEST policy=deploy.migrate payload_hash=<hex>` → `request_id`.
- `TWO_KEYS.STATUS request_id=<uuid>` → `pending|approved|expired|rejected`.
- `GUARD.TEST route=\"/api/admin/rbac/roles\" method=GET user=468326902 ctx=\"{...}\"` → детерминированный allow/deny.

---

## Чек‑листы тестов (Жандарм и Инспекторы)

### Жандарм — API/PEP

- OpenAPI: у всех `/api/admin/*` заданы `security` (TgHeaderAuth+Bearer) и требуемые роли/права.
- `/api/admin/rbac/roles`: 403 для non‑architect; 200 для architect.
- `/api/llm/functions`: 402 для `basic`; 200 для `premium+`.
- `/api/reminders` POST: 200 для `premium+`; 402 для `basic`.
- `/api/hyperloop/execute`: 409 для `NET/DEPLOY/DB/SCHEMA` без аппрува; 200 с валидным `request_id`.

### Жандарм — UI/Guard

- Защищённые страницы не рендерят контент до загрузки ролей; показывается skeleton.
- Меню не содержит админ‑пункты до подтверждения ролей.
- Маппинг кодов: 401→WebAuth, 403→«Недостаточно прав», 402→CTA апгрейда, 409→«Требуется подтверждение операции».

### Жандарм — DSL/Two‑Keys

- `NET.RELOAD` без `request_id` → 409; с `pending` → 409; с `approved` → 200 и `cmd.hyperloop.authz.*` в `signature_steps`.

### Жандарм — Ownership

- Операции `*.self` над чужими ресурсами → 403; над своими → 200.

### Инспекторы — P27 (Signature)

- За последние 24h присутствуют шаги: `svc.rbac.check`, `svc.rbac.limits`, `cmd.hyperloop.authz.*`.
- Отсутствие любого шага → предупреждение/алерт.

### Инспекторы — P21 (Метрики/Алерты)

- Метрики публикуются: `authz_denied_total`, `authz_allowed_total`, `pdp_latency_ms`, `two_keys_requests`.
- Алерты срабатывают на всплески 401/403/409/429 и рост p95 `pdp_latency_ms`.

### Инспекторы — P28 (Флаги)

- Активен профиль `prod_safe`; `DISABLE_RBAC`/`TEST_NO_DB` отключены в PROD.
- Любое смягчение прав требует Two‑Keys + запись rationale.

### PowerShell — примеры вызовов (DEV/QA)

Примечания:

- Использовать PowerShell (Windows). Не применять `| cat`. Для Web добавлять Bearer JWT при необходимости.
- Всегда прокидывать заголовок `X-Telegram-User-ID`.

```powershell
$H = @{ 'X-Telegram-User-ID' = '468326902' }

# Health (смоки)
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/health

# RBAC Admin (ожидаемо 403 для non-architect, 200 для архитектора)
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/rbac/roles' -Headers $H -Method Get | ConvertTo-Json -Compress

# LLM Functions (402 для basic, 200 для premium+)
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/llm/functions' -Headers $H -Method Get | ConvertTo-Json -Compress

# Reminders (POST) — 200 для premium+, 402 для basic
$body = @{ title='Demo'; ts='2025-09-23T12:00:00Z' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/reminders' -Headers $H -Method Post -ContentType 'application/json' -Body $body | ConvertTo-Json -Compress

# Two-Keys — создать заявку
$req = @{ policy_key='deploy.migrate'; payload_hash='cafe00beef' } | ConvertTo-Json -Compress
$resp = Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/two-keys/requests' -Headers $H -Method Post -ContentType 'application/json' -Body $req
$rid = $resp.request_id

# Two-Keys — аппрув (второй субъект)
Invoke-RestMethod -Uri ("https://mini.soulpulse.art/api/two-keys/requests/$rid/approve") -Headers $H -Method Post | ConvertTo-Json -Compress

# Hyperloop — опасная команда с request_id
$payload = @{ commands='NET.RELOAD route="/api"'; request_id=$rid } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $payload | ConvertTo-Json -Compress

```

### curl.exe — эквиваленты примеров

```powershell
# Health
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/health

# RBAC Admin (GET roles)
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -H "Authorization: Bearer <token>" https://mini.soulpulse.art/api/admin/rbac/roles

# LLM Functions
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -H "Authorization: Bearer <token>" https://mini.soulpulse.art/api/llm/functions

# Reminders (POST)
'{ "title": "Demo", "ts": "2025-09-23T12:00:00Z" }' |
  Set-Content -Path tmp_reminders.json -Encoding UTF8 -NoNewline
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -H "Content-Type: application/json" --data-binary "@tmp_reminders.json" https://mini.soulpulse.art/api/reminders

# Two-Keys — create request
'{ "policy_key": "deploy.migrate", "payload_hash": "cafe00beef" }' |
  Set-Content -Path tmp_two_keys_req.json -Encoding UTF8 -NoNewline
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -H "Content-Type: application/json" --data-binary "@tmp_two_keys_req.json" https://mini.soulpulse.art/api/two-keys/requests

# Two-Keys — approve
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -X POST https://mini.soulpulse.art/api/two-keys/requests/<request_id>/approve

# Hyperloop — with request_id
('{ "commands": "NET.RELOAD route=\"/api\"", "request_id": "' + "<request_id>" + '" }') |
  Set-Content -Path tmp_hl_req.json -Encoding UTF8 -NoNewline
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -H "Content-Type: application/json" --data-binary "@tmp_hl_req.json" https://mini.soulpulse.art/api/hyperloop/execute

```

### Ownership (*.self) — примеры

Контракты:

- `GET /api/profile` → `profile.read.self`
- `PUT /api/profile` → `profile.update.self`
- `GET /api/reminders/{id}` → `api.reminders.read` с ownership=сам
- `DELETE /api/reminders/{id}` → `api.reminders.delete.self`

Allow (свой ресурс):

```powershell
$H = @{ 'X-Telegram-User-ID' = '468326902' }
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/reminders/123' -Headers $H -Method Get | ConvertTo-Json -Compress

```

Ожидаемо: 200 OK, если reminder.owner_user_id == 468326902.

Deny (чужой ресурс):

```powershell
$H = @{ 'X-Telegram-User-ID' = '468326902' }
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/reminders/999' -Headers $H -Method Delete

```

Ожидаемо: 403 Forbidden `{ "reason":"ownership_mismatch" }`.

Эквиваленты curl.exe:

```powershell
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/reminders/123
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -X DELETE https://mini.soulpulse.art/api/reminders/999

```

### Профиль пользователя — profile.read.self / profile.update.self

PowerShell:

```powershell
$H = @{ 'X-Telegram-User-ID' = '468326902' }
# read.self
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/profile' -Headers $H -Method Get | ConvertTo-Json -Compress
# update.self
$body = @{ display_name='Pavel'; locale='ru-RU' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/profile' -Headers $H -Method Put -ContentType 'application/json' -Body $body | ConvertTo-Json -Compress

```

curl.exe:

```powershell
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/profile
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" -H "Content-Type: application/json" -X PUT -d "{\"display_name\":\"Pavel\",\"locale\":\"ru-RU\"}" https://mini.soulpulse.art/api/profile

```

Ожидания:

- 200 OK при корректном `X-Telegram-User-ID` и совпадении с владельцем профиля.
- 403 Forbidden при попытке обновления чужого профиля (если доступен маршрут с `{user_id}`) с причиной `ownership_mismatch`.

### Негатив — jwt_mismatch (curl.exe)

Сценарий: JWT выдан для `tg_id=111`, а заголовок содержит `X-Telegram-User-ID: 222`.

```powershell
curl.exe -s -S -H "X-Telegram-User-ID: 222" -H "Authorization: Bearer <jwt_with_tg_id_111>" https://mini.soulpulse.art/api/profile

```

Ожидаемо: 401 Unauthorized `{ "error":"unauthorized", "reason":"jwt_mismatch" }`.

### OpenAPI — ключевые фрагменты security и кодов ошибок

```yaml
components:
  securitySchemes:
    TgHeaderAuth:
      type: apiKey
      in: header
      name: X-Telegram-User-ID
    BearerAuth:
      type: http
      scheme: bearer

paths:
  /api/admin/rbac/roles:
    get:
      security:
        - TgHeaderAuth: []
        - BearerAuth: []
      summary: List roles (architect only)
      responses:
        '200': { description: OK }
        '401': { description: Unauthorized }
        '403': { description: Forbidden }

  /api/llm/functions:
    get:
      security:
        - TgHeaderAuth: []
        - BearerAuth: []
      summary: List LLM functions (premium+)
      responses:
        '200': { description: OK }
        '401': { description: Unauthorized }
        '402': { description: Payment Required / Upgrade plan }
        '403': { description: Forbidden }
        '429': { description: LLM quota exceeded }

  /api/hyperloop/execute:
    post:
      security:
        - TgHeaderAuth: []
        - BearerAuth: []
      summary: Execute Hyperloop DSL (Two-Keys for dangerous groups)
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              properties:
                commands: { type: string }
                request_id: { type: string, description: Required for NET/DEPLOY/DB/SCHEMA }
      responses:
        '200': { description: OK }
        '401': { description: Unauthorized }
        '403': { description: Forbidden }
        '409': { description: Two-Keys required / expired / same_subject }

  /api/profile:
    get:
      security:
        - TgHeaderAuth: []
        - BearerAuth: []
      summary: Get current user profile (profile.read.self)
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema:
                type: object
                required: [user_id, tg_id, display_name, locale, plan]
                properties:
                  user_id: { type: integer }
                  tg_id: { type: integer }
                  display_name: { type: string }
                  locale: { type: string, example: ru-RU }
                  plan: { type: string, enum: [basic, premium, vip, admin, architect] }
                  roles: { type: array, items: { type: string } }
                  permissions: { type: array, items: { type: string } }
                  avatar_url: { type: string, format: uri }
                  created_at: { type: string, format: date-time }
                  updated_at: { type: string, format: date-time }
                  preferences:
                    type: object
                    properties:
                      theme: { type: string, enum: [light, dark] }
                      notifications: { type: boolean }
                      language: { type: string, example: ru }
              examples:
                ok:
                  value:
                    user_id: 1024
                    tg_id: 468326902
                    display_name: Pavel
                    locale: ru-RU
                    plan: premium
                    roles: [premium]
                    permissions: [profile.read.self, api.reminders.read]
                    avatar_url: https://cdn.soulpulse.art/avatars/1024.png
                    created_at: 2025-01-15T10:20:30Z
                    updated_at: 2025-09-23T10:00:00Z
                    preferences:
                      theme: dark
                      notifications: true
                      language: ru
        '401':
          description: Unauthorized (jwt_mismatch or missing header)
          content:
            application/json:
              examples:
                jwt_mismatch:
                  value:
                    error: unauthorized
                    code: 401
                    reason: jwt_mismatch
                tg_header_missing:
                  value:
                    error: unauthorized
                    code: 401
                    reason: tg_header_missing
        '403':
          description: Forbidden (ownership_mismatch)
          content:
            application/json:
              example:
                error: forbidden
                code: 403
                reason: ownership_mismatch
    put:
      security:
        - TgHeaderAuth: []
        - BearerAuth: []
      summary: Update current user profile (profile.update.self)
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              properties:
                display_name: { type: string }
                locale: { type: string }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema:
                type: object
                required: [user_id, tg_id, display_name, locale, plan]
                properties:
                  user_id: { type: integer }
                  tg_id: { type: integer }
                  display_name: { type: string }
                  locale: { type: string, example: ru-RU }
                  plan: { type: string, enum: [basic, premium, vip, admin, architect] }
                  roles: { type: array, items: { type: string } }
                  permissions: { type: array, items: { type: string } }
                  avatar_url: { type: string, format: uri }
                  created_at: { type: string, format: date-time }
                  updated_at: { type: string, format: date-time }
                  preferences:
                    type: object
                    properties:
                      theme: { type: string, enum: [light, dark] }
                      notifications: { type: boolean }
                      language: { type: string, example: ru }
              examples:
                ok:
                  value:
                    user_id: 1024
                    tg_id: 468326902
                    display_name: Pavel
                    locale: ru-RU
                    plan: premium
                    roles: [premium]
                    permissions: [profile.read.self, profile.update.self]
                    avatar_url: https://cdn.soulpulse.art/avatars/1024.png
                    created_at: 2025-01-15T10:20:30Z
                    updated_at: 2025-09-23T10:05:00Z
                    preferences:
                      theme: light
                      notifications: false
                      language: ru
        '401':
          description: Unauthorized (jwt_mismatch or missing header)
          content:
            application/json:
              examples:
                jwt_mismatch:
                  value:
                    error: unauthorized
                    code: 401
                    reason: jwt_mismatch
                tg_header_missing:
                  value:
                    error: unauthorized
                    code: 401
                    reason: tg_header_missing
        '403':
          description: Forbidden (ownership_mismatch)
          content:
            application/json:
              example:
                error: forbidden
                code: 403
                reason: ownership_mismatch

```

## DDL Two‑Keys (SQL)

```sql
CREATE TABLE IF NOT EXISTS two_keys_policies (
  id              BIGSERIAL PRIMARY KEY,
  policy_key      TEXT NOT NULL UNIQUE,
  scope           TEXT NOT NULL,                   -- e.g. net, deploy, db, schema
  required_roles  TEXT[] NOT NULL,                 -- ["architect","admin"]
  ttl_s           INTEGER NOT NULL DEFAULT 900,
  comment         TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS two_keys_approvals (
  id              BIGSERIAL PRIMARY KEY,
  policy_key      TEXT NOT NULL REFERENCES two_keys_policies(policy_key) ON DELETE CASCADE,
  request_id      TEXT NOT NULL,
  payload_hash    TEXT NOT NULL,
  initiator_user_id BIGINT NOT NULL,
  approver_user_id  BIGINT,
  approved_at     TIMESTAMPTZ,
  expires_at      TIMESTAMPTZ NOT NULL,
  status          TEXT NOT NULL DEFAULT 'pending', -- pending|approved|rejected|expired
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(policy_key, request_id)
);

CREATE INDEX IF NOT EXISTS idx_two_keys_policy_key ON two_keys_approvals(policy_key);
CREATE INDEX IF NOT EXISTS idx_two_keys_request_id ON two_keys_approvals(request_id);
CREATE INDEX IF NOT EXISTS idx_two_keys_created_at ON two_keys_approvals(created_at);

```

## Модуль‑персона RBAC: «Страж» (RBAC Guardian)

Назначение

- Системный хранитель полномочий и делегирования: обеспечивает целостность RBAC/ABAC/Two‑Keys, контроль делегирования, поиск и локализацию ошибок авторизации, непрерывный аудит и согласованность политик.  
- Формат: policy‑extract (без строк идентичности; не экспонируется пользователю). Встраивается в Pipeline/Processor как валидатор/решатель авторизации.

Зона ответственности

- RBAC: соответствие запросов ролям и правам; минимально необходимые права (PoLP).  
- ABAC: проверка контекстных предикатов (канал Mini‑App/Web, окна времени, подписка/регион).  
- Two‑Keys: жизнь заявки/аппрува (создание/валидность/исполнение); гарантия 2 разных субъектов и окна TTL.  
- Делегирование: контроль и журнал делегированных прав (кто кому, когда, на какой срок/объём); авто‑ревок по TTL.  
- Аудит и согласованность: корреляция отказов/разрешений с `signature_steps` и инцидентами P21; анти‑дрейф политик.

Интерфейсы/входы

- Сигналы: { route, method, headers{X‑Telegram‑User‑ID, Authorization}, user_roles, permissions[], abac_ctx{channel, time_window, plan, region}, resource{type,id,owner?}, function_name?, two_keys{request_id?} }.  
- Источники: `RBACService`, `rbac_middleware`, контекст Processor (P30), Hyperloop (P36).  
- Конфиги: матрица эндпоинтов (PEP), политики Two‑Keys, профиль фич (P28), карта делегирования.

Интерфейсы/выходы

- Решение: allow/deny + причина (key/abac/two_keys/quota/ownership) + `audit_id`.  
- Действие: для Two‑Keys — создание/проверка заявки; для ABAC — фиксация невыполненного предиката; для делегирования — запись/ревок.  
- Метрики: counters/histogram по отказам/разрешениям и latency PDP.

Policy‑extract (фрагменты правил)

- Не использовать строки идентичности; только чек‑листы/предикаты:
  - default_deny: true  
  - require_headers: ["X‑Telegram‑User‑ID"]  
  - jwt_match: header.tg_id == jwt.tg_id (if jwt present)  
  - role_matrix: by route prefix  
  - abac_predicates: channel in {miniapp, web}; plan in {basic,premium,vip}; time within policy window  
  - ownership: if scope == self → user.id == resource.owner_id  
  - two_keys_required: route in {NET.*, DEPLOY.*, DB.*, SCHEMA.*}  
  - quotas: check_llm_quota(function_name)

Глубокая логика принятия решения (схема)
1) Аутентификация: tg_id header (+ JWT match).  
2) system role bypass: if role == soul → allow + audit.  
3) PEP matrix: role/permission check; PoLP.  
4) ABAC: channel/time/plan/region.  
5) Ownership (если scope self/own‑resource).  
6) Two‑Keys: если требуется — verify request_id/TTL/subject≠initiator.  
7) Quotas (LLM).  
8) Решение + аудит (`svc.rbac.check`, `svc.rbac.limits`, `cmd.hyperloop.authz.*`).

Hyperloop DSL — крючки «Стража»

- `GUARD.POLICY.LIST` — показать активные политики/матрицу.  
- `GUARD.TEST route="/api/..." method=GET user=468326902 ctx="{...}"` — dry‑run решения.  
- `TWO_KEYS.REQUEST policy=deploy.migrate payload_hash=<hex>` — создать заявку.  
- `TWO_KEYS.STATUS request_id=<uuid>` — статус.  
- `DELEGATION.LIST user=<id>` / `DELEGATION.REVOKE id=<id>` — контроль делегирования.  
- Все команды — только `architect`, опасные — `Two‑Keys`.

Интеграции

- P27: шаги подписи `svc.rbac.*`, `cmd.hyperloop.authz.*` обязательны.  
- P28: профиль `prod_safe`, ключевые флаги авторизации.  
- P29: правила качества — отсутствие утечек защищённого контента; нулевой порог «показать до загрузки ролей».  
- P30: Processor вызывает «Стража» перед act; инциденты при нарушениях.  
- P32: данные ролей/прав/лимитов; делегирование/Two‑Keys — в P32 DB.  
- P36: DSL‑крючки; Two‑Keys подтверждения.

Метрики и инспекторы

- `authz_denied_total{route,reason,role}`, `authz_allowed_total{route,role}`, `pdp_latency_ms{p50,p95}`, `two_keys_requests{status}`, `delegations_active`.  
- Инспекторы: наличие шагов `svc.rbac.*`/`cmd.hyperloop.authz.*` за 24h; аномалии отказов по роутам/ролям; устаревшие делегирования.

Acceptance «Стража»

- Dry‑run `GUARD.TEST` детерминированно отражает allow/deny и причину.  
- Two‑Keys поток: 409 без аппрува, 200+аудит с аппрувом.  
- Делегирование: запись/ревок отражаются в аудит/метриках; просроченные делегирования автоснимаются.  
- Ни один защищённый экран не рендерит контент до ролей; меню не показывает админ‑пункты без подтверждённых ролей.  
- Нулевые изменения бизнес‑контрактов (тела API/форм) — только авторизационные слои.

Безопасность/NEGATIVE

- Запрет на экспонирование модульного имени/ролей в пользовательском тексте.  
- Любая диагностика «Стража» — только в логах/админ‑панелях; пользователю — стандартные статусы (401/403/402/409/429) без раскрытия политик.

## Мониторинг и алерты (P21/P24)

- Метрики:
  - `authz_denied_total{route,reason,role}` — отказы авторизации
  - `authz_allowed_total{route,role}` — разрешения
  - `pdp_latency_ms{p50,p95}` — задержка принятия решений
  - `two_keys_requests{status}` — заявки Two‑Keys
  - `llm_quota_denied_total{function}` — отказы квот
- Инспекторы (P27/P36): наличие `svc.rbac.check`, `svc.rbac.limits`, `cmd.hyperloop.authz.*` за 24h.  
- Алерты: всплески 401/403/409/429; рост p95 `pdp_latency_ms`; отсутствие инспекторов > 30 мин; рост отказов квот.

## Жандарм: система внутренних тестов авторизации (P29/P24)

Цель

- Автоматическая валидация инвариантов авторизации на API/UI/DSL без изменения бизнес‑контрактов. Нулевой порог «показать контент до ролей» для защищённых страниц.

Наборы тестов

- API/PEP: перебор маршрутов → проверка `security` в OpenAPI, требуемых ролей/прав, корректных кодов 401/403/402/409/429; negative‑кейсы.  
- UI/Guard: рендер защищённых страниц до/после загрузки ролей; проверка, что без ролей → только спиннер/skeleton; меню скрывает админ‑пункты; обработка кодов.  
- DSL/Two‑Keys: команды `NET/DEPLOY/DB/SCHEMA` → 409 без аппрува, 200 с аппрувом; запись шагов `cmd.hyperloop.authz.*`.  
- Ownership: операции `*.self` для чужих ресурсов → 403; для своих → 200.  
- Лимиты LLM: исчерпание квоты → 402/429 в зависимости от политики; зелёный кейс — 200.

Инструменты

- Hyperloop: `INSPECTOR.RUN_ALL`, `GUARD.TEST`, `TWO_KEYS.*` сценарии.  
- P24: запуск наборов без поднятия серверов/каналов; реальные TG‑ID; отчёты JSON/метрики.  
- P29 (Gendarme): правила качества для UI‑гвардов (ноль защищённого контента без ролей), API‑security и авторизационных кодов.

Критерии приёмки

- 100% админ‑маршрутов имеют `security` и требуемые роли в OpenAPI; 0 «показа до ролей» на защищённых страницах; Two‑Keys негативы стабильно дают 409; latency PDP p95 в бюджете.

## Действия «Стража» при появлении новой функциональности

Триггеры

- Новый HTTP‑маршрут/метод; новая команда DSL; новый экран/раздел UI; новая LLM‑функция/модель; новая таблица/миграция.

Алгоритм (intake → enforce)
1) Обнаружение: статический анализ роутера/DSL‑реестра/SPA‑роутов → регистрация объекта в матрице PEP.  
2) Черновик политики: автогенерация минимального профиля прав (PoLP) и ABAC‑предикатов по шаблону домена.  
3) Классификация опасности: если зона NET/DEPLOY/DB/SCHEMA/FLAGS — пометка Two‑Keys и подбор политики `required_roles`.  
4) Документация: обновление OpenAPI `security` и кодов; добавление пометки в Project Structure.  
5) Тесты: генерация рецептов Жандарма (API/UI/DSL/Ownership/Quotas) и включение в P24.  
6) Проверка: запуск `INSPECTOR.RUN_ALL` и `GUARD.TEST` для новых объектов; все зелёные.  
7) Ввод: включение правила в PDP; публикация метрик/алертов.  
8) Аудит: запись события эволюции политики; наблюдение всплесков 401/403/409/429.

Политика эволюции

- Любое смягчение прав требует Two‑Keys + записи rationale; ужесточение допускается через MR с зелёными тестами.  
- Конфликты/пересечения правил помечаются и выносятся в инспектор для разруливания архитектором.

## Синхронизация персонажей: Страж ↔ Фронтмен ↔ Процессор ↔ Тренер

Фронтмен (целостность бэкенда)

- Гейт на уровне инфраструктуры/конфигурации: контроль ENV/feature‑профилей, соответствие OpenAPI и роутера, миграций и данных.  
- Требует регистрации каждого нового маршрута/команды в матрице PEP; блокирует сборку при расхождении.

Страж (авторизация)

- Отвечает за матрицу прав/предикатов/Two‑Keys, Жандарм‑тесты и аудит; отдаёт вердикты allow/deny.  
- Поставляет Frontman отчёты о покрытии/дрейфе; Processor — решения перед актами.

Процессор (исполнение)

- Перед любым `act` вызывает Стража; при deny — поднимает инцидент и останавливает шаг; логирует `svc.rbac.*`.

Тренер (обучение, P38)

- Забирает агрегированные/анонимизированные события авторизации (deny/allow/коды/времена) для обучения и риск‑моделей; не получает PII.

Каналы связи

- Единые инспекторы (P27), общая шина метрик/логов (P21), фич‑профили (P28). MR‑чек: Frontman и Страж оба зелёные; иначе блок.

## Интеграция с обучением (P38 NeuroTraining)

Данные/сигналы

- Фичи для обучения: частота отказов по ролям/маршрутам, паттерны Two‑Keys, p95 PDP, коды 401/403/409/429 (без PII).  
- Метки: успех/отказ операций; класс опасности команды/маршрута.

Использование

- Обучение риск‑скоринга для раннего предупреждения (UI/оператору) и приоритизации аудита; рекомендации по PoLP для новых фич.  
- Тренировка на DEV/ANON данных; в PROD — только инференс и мониторинг дрейфа.

Инварианты безопасности

- Никаких изменений результата авторизации по ML без явного правила; ML — рекомендующий канал.  
- Де‑идентификация и агрегирование событий; нулевой экспорт PII.

## Анализ рисков по стеку и меры предотвращения

### Аутентификация/канал (Mini‑App/Web)

- Риск: отсутствие/подмена заголовка `X‑Telegram‑User‑ID` в Mini‑App; рассинхронизация `tg_id` между JWT и заголовком в Web.  
- Меры: в `get_authenticated_user` — обязательная сверка `tg_id` в JWT и заголовке; default‑deny при несовпадении; в Nginx — прокидывать заголовок как есть, запрещать переписывание на upstream; включить аудит несоответствий (уровень WARN) и счётчик инцидентов (P21).

### RBAC байпас/флаги окружения

- Риск: включённые `DISABLE_RBAC`/`TEST_NO_DB` в PROD.  
- Меры: загрузка флаг‑профиля (P28) `prod_safe` с явным запретом на эти флаги; при наличии — немедленный отказ запуска сервиса (fail‑fast) и событие инцидента (P21/P30).

### Кэш ролей на фронтенде

- Риск: «слетание» ролей/мерцание UI из‑за раннего рендера без ролей.  
- Меры: строгий `RoleGuard` — скрывать защищённые страницы до загрузки ролей и наличия `tg_id`; TTL кэша ролей ≤ 60s; повторная загрузка при 401/403; skeleton вместо контента.

### Two‑Keys: гонки/эскалация

- Риск: выполнение опасной команды без второго подтверждения или повторное воспроизведение заявки.  
- Меры: заявка подписывается `payload_hash`; хранение `request_id`, `approved_by`, `expires_at`; выполнение только при статусе approved и неповторённом hash; журнал событий и блокировка повторов; разграничение «кто утверждает» ≠ «кто инициировал»; TTL политики.

### Hyperloop DSL: опасные команды

- Риск: несанкционированный доступ к `NET.* / DEPLOY.* / DB.* / SCHEMA.*`.  
- Меры: маркировать эти команды как `Two‑Keys required`; требовать `request_id`; писать шаги `cmd.hyperloop.authz.*` (P27) и метрики отказов (P21); право только у `architect`.

### Лимиты LLM/стоимость

- Риск: перерасход квот/токенов и деградация SLO.  
- Меры: `check_llm_quota` перед вызовом; профили провайдеров (P14) с консервативными дефолтами; санитайзер STRICT_JSON + фоллбек; наблюдать p95 `time_send_to_recv_ms`.

### Автопубликация действий (DesiredAction)

- Риск: нежелательные автоматические действия.  
- Меры: явные права `actions.autopublish.*`; Delivery Guard (P27) требует зелёную цепочку; хранить все автопубликации в аудите с обратной ссылкой на квант.

### База данных/миграции

- Риск: несогласованные миграции (Two‑Keys таблицы), блокировки.  
- Меры: Schema Guard (P10); миграции только через `DB.* / SCHEMA.*` под Two‑Keys; индексы на `policy_key`, `request_id`, `created_at`.

### Конфигурация/секреты

- Риск: утечка секретов, дрифт ENV.  
- Меры: секреты только из `.env.prod`; приоритет «БД→настройки→ENV» (P36); аудит чтения секретов; отсутствие секретов в логах; SSM/хранилище секретов — по плану.

### Наблюдаемость/алерты

- Риск: слепые зоны в авторизации.  
- Меры: метрики отказов/разрешений по ролям/правам, граф инцидентов, алерты на всплески 401/403, отчёты P24.

## Корректировки функционального объёма смежных P‑систем

### P20 — Telegram Bots Platform

- Webhook‑поток: встраиваем проверку `X‑Telegram‑User‑ID`; логика web‑auth выдаёт JWT с claim `tg_id`, совпадающим с заголовком; отказ при несовпадении.

Интерфейсы (минимальные правки):

- API headers: всегда требовать `X‑Telegram‑User‑ID`; для Web — Bearer JWT.  
- Добавить middleware для сверки `tg_id` в JWT и заголовке; коды 401/403 без изменения существующих схем запросов.  
- Не менять тела запросов/ответов бота — только заголовки и авторизационную обвязку.  
- OS‑уровень: системный сервис бота работает под отдельным юзером, ключи/токены в `.env.prod`, права файлов 600; доступ к сокетам/портам — по systemd unit, без прав на файловую БД приложения.

### P22 — API Alignment

- Обновить OpenAPI: securitySchemes для заголовка `X‑Telegram‑User‑ID` и Bearer JWT; для каждого маршрута — требуемые роли/права, возможные коды 401/403/402/409/429.

Интерфейсы:

- Не изменять существующие схемы `requestBody`; только добавить секцию `security` и описания кодов ошибок.  
- Генерация клиентов/линт: включить spectral‑правило на обязательный заголовок и коды ошибок.

### P23 — UI Rebuild

- Усилить `RoleGuard`/`RegistrationGuard` по правилам P44; скрывать контент до загрузки ролей; TTL кэша ролей; единый экран при отсутствии `tg_id` в WebApp.

Интерфейсы:

- Не менять формы/компоненты страниц; добавить только обёртки‑гварды и спиннеры до загрузки ролей.  
- Меню/навигация: скрывать защищённые пункты до загрузки ролей (без изменения структур меню).  
- OS‑уровень: кэш/хранилища браузера не содержат секретов; cookie `sp_token` = HttpOnly/SameSite=None/Secure; разделение доменов.

### P24 — Integrated Tests & Monitoring

- Добавить смоки RBAC/Two‑Keys: сценарии отказов/разрешений, проверка `cmd.hyperloop.authz.*` в `signature_steps`; отчёт JSON метрик авторизации.

Интерфейсы:

- Тесты не поднимают серверов/каналов; минимальные фикстуры — реальные TG‑ID (правила проекта).  
- Добавить negative‑кейсы для 401/403/409/429 без изменения тестовых контрактов существующих API.

### P27 — Signature & Data Lineage

- Добавить шаги `svc.rbac.check`, `svc.rbac.limits`, `cmd.hyperloop.authz.*`; инспектор наличия этих шагов в последнем 24h окне.

Интерфейсы:

- Не менять форматы `signature_steps`; добавить только новые ключи шагов; отчёты инспекторов — без изменения схем ответов.

### P28 — FeatureFlags

- Профиль `prod_safe`: запрещает `DISABLE_RBAC`/`TEST_NO_DB`; ключевые флаги авторизации под Two‑Keys.

Интерфейсы:

- Таблицы/реестр фич без изменений схем; добавить ключи профилей/политик.

### P29 — Quality Registry

- Правила Gendarme для авторизации: отсутствие защищённого контента без ролей; нулевой порог для «показать до загрузки» на защищённых страницах.

Интерфейсы:

- Не менять JSON контрактов Gendarme/Judge; добавить правила/ключи конфигурации.

### P30 — Processor

- Все исполнители `act` вызывают PDP; при нарушениях — инцидент + блокировка; шаги подписи включают авторизационные проверки.

Интерфейсы:

- Соглашения о событиях/инцидентах не меняются; добавляются новые причины отказов/ключи инцидентов.

### P32 — RBAC & Subscriptions

- Добавить таблицы Two‑Keys; расширить seed прав `actions.autopublish.*`; индексы и идемпотентный seed; назначение `basic` по умолчанию.

Интерфейсы:

- Миграции — добавочные; не ломают существующие DDL; seed идемпотентный; API управления ролями — без изменения путей.

### P36 — Hyperloop DSL

- Маркировать опасные команды как Two‑Keys; API заявок/аппрувов; возвращать `request_id`; инспекторы authz.

Интерфейсы:

- DSL остаётся строкой `commands`; добавляются только требования `request_id` для опасных групп и коды 409.  
- UI/CLI не меняются; ошибки отображаются существующими блоками диагностики.

### P14 — Multi‑provider Routing

- Профили провайдеров учитывают лимиты по ролям; переключение профилей под контролем `architect`.

Интерфейсы:

- Таблицы/настройки провайдеров — без изменения схем; добавить ключи лимитов/ролей как метаданные.

### P17 — Reminders/Search/Calendar

- Ownership проверки `*.self`; CRUD только `premium+`; без удаления сообщений через Telegram API (архитектурное правило проекта).

Интерфейсы:

- JSON форматы напоминаний/поиска — без изменений; добавляется проверка ownership на бэкенде.  
- UI формы не меняются; сообщения об ошибках — стандартные.

### P21 — Health/Monitoring

- Дашборд авторизации: p95 PDP, отказы 401/403/409/429 по ролям/маршрутам, граф инцидентов; алерты на всплески.

Интерфейсы:

- Метрики/панели — без ломки; добавляются новые серии и виджеты.

### Acceptance (дополнение)

- Проверки UI: защищённые страницы не рендерят контент до ролей; Two‑Keys флоу даёт 409 без аппрува и 200 с аппрувом; OpenAPI содержит требования ролей/прав.

OS‑уровневые меры (минимум UI‑изменений):

- Разделить системные юзеры и права на сервере: `soulpulse-backend` без привилегий root; файлы конфигов/ключей — 600, владельцы — сервисный пользователь.  
- Nginx/systemd: ограничить egress/ingress, задать таймауты; закрыть доступ к ненужным портам/файлам.  
- Логи и артефакты — без PII; доступ к логам по группе `soulops`; аудит доступа к логам.  
- SELinux/AppArmor (при наличии): профили deny‑by‑default для процессов бэкенда.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
