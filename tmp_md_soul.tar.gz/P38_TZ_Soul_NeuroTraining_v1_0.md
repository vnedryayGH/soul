# P38 — ТЗ: Обучение Нейросети Соул (NeuroTraining) — v1.1

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — инвентари.
- `tmp_p_series_plan.json` — план P‑серии.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр.
- `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`, `Soul/P28_TZ_FeatureFlags_Registry_and_Policies_v1_0.md`, `Soul/P29_TZ_Background_Supervision_v1_0.md`, `Soul/P30_TZ_Soul_Processor_v2_0.md`, `Soul/P36_TZ_Hyperloop_DSL_v1_1.md` — ключевые интеграции.

Аннотированная цель: создать универсальную, производительную систему нейрообучения для «Соул», в которой небольшая по ресурсам собственная многомерная нейросеть автономно генерирует Кванты, строит нейросетевые цепочки и достигает целей. Большие LLM используются как «бустеры»: для пакетной генерации целевых Квантов/связей, для дообучения и для адаптивного планирования. Система интегрируется с ядром «Соул» по инвариантам P27/P28/P29/P30/P36 и не допускает регресса функциональности.

## 0) Контекст и инварианты

- Инварианты: STRICT_JSON_QUANT; stateless batch с desired_action=[]; единая сборка промпта (CORE/ROUTER_CONTEXT/MODULES/OUTPUT_SPEC/NEGATIVE); Delivery Guard (P27) перед отдачей ответа; RBAC/Two-Keys (P32); наблюдаемость (события/метрики/трейсы).
- Среда: отдельные апп-сервер и сервер БД; реляционная СУБД с графовой надстройкой; ядро объектно организовано, имеет программный «процессор» (P30) и Hyperloop DSL (P36). Ресурсы ограничены, масштабирование возможно.
- Роль LLM: внешние провайдеры подключаются многопоточно через P14; ответы строго парсятся и валидируются; модели — источники «ускорений», а не «истины».

### RT-инварианты (реального времени)

- SLO по латентности: p50≤1200 мс, p95≤3000 мс для «обычных» интентов; для критичных уведомлений p95≤1500 мс (без LLM, шаблон/эвристика).
- Идемпотентность и прерываемость: длительные операции дробятся на микро‑батчи (1–3 ответа) с ранним возвратом и донабором (`append=true`).
- Бюджет выполнения: токены/таймауты/провайдеры выбираются планировщиком в рантайме по политике P28 с учётом очереди (P30) и текущей загрузки.
- Stateless по умолчанию для обучения/батчей; любые вызовы LLM в stateless — `db=None`, `desired_action=[]`, greenlet_spawn=0.
- «Gap-closure» по событию: при отсутствии необходимых знаний инициируется немедленная генерация недостающих Квантов (микро‑батч) с жёсткими таймаутами.

## 1) Обзор лучшей практики и связь с проектом

- Структурированный вывод: OpenAI Structured Outputs/JSON mode; соответствие — STRICT_JSON_QUANT (`backend/app/services/soul_quant_schema.py`).
- Память: RAG+MemGPT подходы; соответствие — 30/70_v2 (`soul_context.py`) + связи/веса (DB).
- Агентные циклы: ReAct/Reflexion/agenda; соответствие — P30 (processor) + P27 (подпись) + P29 (гейты качества).
- Hybrid retrieval: BM25+vector; соответствие — вспомогательный ретривер без нарушения STRICT_JSON.

## 2) Цели и результаты

- Обучить «внутреннюю» нейросеть Соул на реальных кейсах, снижая токен/латентность за счёт самоорганизующихся алгоритмов и графа связей.
- Организовать пакетную генерацию Квантов/связей внешними LLM, их валидацию и селекцию (probe→persist), а также автономное до-обучение по циклу P30.
- Гарантировать отсутствие регресса по поведению и контрактам, полную наблюдаемость и управляемость через Hyperloop DSL.

## 3) Архитектура обучения (высокий уровень)

- Слои:

  1) Data Plane (Кванты/связи/цели) — DB + графовая надстройка; индексы и матпредставления.
  2) Control Plane (Policies/Flags) — P28; профили провайдеров и тактики.
  3) Learning Loop (P30 расширение) — петля Observe→Appraise→Agenda→Plan→Act→Learn с учётом метрик качества.
  4) Booster Plane (LLM) — мультипровайдерный генератор батчей Квантов/связей, резонно распараллеленный.
  5) Evaluation/Guard Plane — P27/P29: подпись шагов, гейты, A/B, метрики качества.

### 3.1 Реального времени (RT): архитектура и SLO

- Планировщик RT (RT Scheduler): выбирает профили провайдера/таймауты/размер микро‑батча по приоритетам очереди (P30) и политикам P28.
- Шардирование провайдеров (P14): параллельные «шарды» на разных LLM для снижения p95; координация ответов с дедупликацией.
- Бюджет токенов/времени: `budget{tokens,time_ms}` распределяется на этапы `send→recv→parse→rank`; превышение бюджета — ранний возврат с частичным результатом.
- Предсказуемые деградации: при риске таймаута — упрощённая тактика (шаблоны/эвристики без LLM), сохранение RT‑инвариантов.

## 4) Потоки данных (E2E)

- Ingest: реальные диалоги/напоминания/цели → генерация/уточнение Квантов → связи (semantic/emotional/temporal/entanglement).
- Batch NeuroTraining: задания на пакетную генерацию (по 10) через P14 провайдеров → STRICT JSON массив → парсинг и автопочинка → селекция (coverage/consistency/actionability) → probe‑persist окно.
- Persistent Single: транзакция message→quant→связи/цели → строгая валидация desired_action.
- Feedback: Delivery Guard блокирует выпуск при нарушениях; метрики и инциденты пишутся в аудит.

## 5) Компоненты и изменения

- Processor (P30): добавить стадии Learn и сигнал «reinforce/decay» для весов связей; события `svc.processor.learn.*`.
- Memory 30/70_v2 (P16): ввести адаптивный recent_ratio и приоритеты типов связей; добавить safe probe для редких кластеров.
- RouterV2: явно логировать журнал конфликтов модулей; расширить goal_bias на кластеры.
- DB: добавить вспомогательные индексы для гибридного ретрива; хранить оценки качества батчей.
- Hyperloop DSL (P36): команды `TRAIN.*`, `BATCH.GENERATE_QUANTS`, `LEARN.APPLY_FEEDBACK`, `TRACE.REQUIRE`.
- Hyperloop DSL (P36): команды `TRAIN.*`, `BATCH.GENERATE_QUANTS`, `LEARN.APPLY_FEEDBACK`, `TRACE.REQUIRE`.
- RT Scheduler: планировщик микро‑батчей и профилей провайдеров по очередям/приоритетам; политика budget/timeouts (P28).
- Shard Coordinator (P14): координация параллельных вызовов к разным LLM с дедупликацией и объединением результатов.
- Realtime Guard: быстрые эвристики/шаблоны для критичных уведомлений (без LLM) при угрозе таймаута, с обязательной подписью шагов.

## 6) Алгоритмы обучения

- Ранжирование кандидатов: `score = α*coverage + β*consistency + γ*actionability + δ*energy_weight + ε*connection_strength`;

  пороги и веса конфигурируемы (P28). Калибровка — через A/B (P13/P29).

- Рекомендуемый профиль весов (по первичному A/B на PROD): `α=1.0, β=1.0, γ=1.4, δ=1.0, ε=1.2` (см. §11.4).
- Усиление/ослабление связей: экспоненциальное сглаживание по подтверждённым успехам/откликам пользователя.
- Автогенерация недостающих цепочек: задачи вида «connect gaps» для LLM бустеров с контролем отрицательных образцов.
- Автогенерация недостающих цепочек: задачи вида «connect gaps» для LLM бустеров с контролем отрицательных образцов.
- Планирование микро‑батча (RT): `n = min(3, ceil(queue_urgency*2))`, `TIMEOUT = clamp(SLO_target - safety_margin, 800, 3000)`; `append=true` до достижения целевого размера набора.

## 7) Контракты ввода/вывода

- Batch/stateless: STRICT JSON массив объектов; `desired_action=[]`; `db=None`; greenlet_spawn=0.
- Single/persistent: жёсткая валидация `QuantStrict`; desired_action — только типизированные подсхемы; транзакция сохранения атомарна.

## 8) Наблюдаемость и метрики

- Сигнатуры: `svc.soul.preanalysis`, `svc.soul.router_decide`, `svc.llm_client.send/recv`, `svc.parser.json_strict`, `svc.chat.reply_render`, `svc.processor.learn.*`.
- Метрики: coverage/consistency/actionability/json_validity/latency; доля фоллбеков batch→single; learn_success_rate.
- Трейс: `CORE.PIPELINE.RUN ... WITH TRACE`, инспекторы `INSPECTOR.RUN_ALL` фиксируют обязательные шаги.
- Трейс: `CORE.PIPELINE.RUN ... WITH TRACE`, инспекторы `INSPECTOR.RUN_ALL` фиксируют обязательные шаги.
- RT‑метрики: `time_send_to_recv_ms{p50,p95}`, `queue_len`, `events_processed_per_min`, `rt_gap_closures_count`, `rt_time_to_first_result_ms`.

## 9) Безопасность/этика

- NEGATIVE-инвариант и санитизация; RBAC/Two-Keys для опасных `TRAIN.*`; запрет видимых тех-маркеров.
- Приватность: обучение только на данных пользователя/разрешённых наборах; отложенная публикация (autopublish_rules).

### 9.1 RBAC/Two-Keys для TRAIN.*

- Политика: команды обучения (`BATCH.GENERATE_QUANTS`, `LEARN.APPLY_FEEDBACK`, `TRAIN.EVAL.*`) доступны только ролям `Architect`/`Admin` и исполняются по схеме Two-Keys (заявка→approve→execute).
- Сценарий:

  1) Создание заявки: `SECRET.REQUEST action="TRAIN.BATCH" payload="{ n:10, provider:'deepseek', topic:'connect gaps' }"`.
  2) Подтверждение: второй участник (роль с правом approve) выполняет `SECRET.APPROVE request_id=<id>`.
  3) Исполнение: `BATCH.GENERATE_QUANTS n=10 provider=deepseek topic="connect gaps" STRICT`.

- Логи/аудит: все шаги пишутся в `_audit_direct` с полями `user_id`, `request_id`, `approved_by`, `trace_id`.

## 10) Acceptance

- Batch(stateless): валидный массив квантов; desired_action=[]; greenlet_spawn=0; JSON Validity ≥99%.
- Single: корректная персистенция кванта/связей/целей; Delivery Guard проходит; аудит шагов присутствует.
- Инспекторы: `INSPECTOR.RUN_ALL` зелёный; шаги P27 за 24h в подписях.
- Отчёт NeuroTraining: по завершении 24h сбора — отправлен отчёт архитектору в Telegram и получено подтверждение (ACK) кнопкой. Критерий завершения: `train.report.last.status=acknowledged`.
- Отчёт NeuroTraining: по завершении 24h сбора — отправлен отчёт архитектору в Telegram и получено подтверждение (ACK) кнопкой. Критерий завершения: `train.report.last.status=acknowledged`.
- RT: при «Gap‑Closure» p95 `time_send_to_recv_ms ≤ 3000` и `rt_time_to_first_result_ms ≤ 1200`; при перегреве очереди — бэк‑прешер и приоритизация критичных событий активны; доля принудительных деградаций ≤ 5%.

## 11) Диагностика и Hyperloop DSL (минимум)

- `FLAGS.APPLY_PROFILE name=prod_safe`
- `CORE.PIPELINE.RUN input_text="health check" WITH TRACE`
- `PROCESSOR.ENABLE on=1`
- `BATCH.GENERATE_QUANTS n=10 provider=deepseek topic="connect gaps" STRICT`
- `TRAIN.EVAL.LAST_BATCH`
- `LEARN.APPLY_FEEDBACK mode=reinforce window=24h`
- `TRACE.STEPS trace_id="<id>"`

### 11.1 Быстрые проверки (PowerShell / PROD)

```powershell
$OutputEncoding = [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$H=@{ 'X-Telegram-User-ID'='468326902' }

# Health/DB/LLM
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/health
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/admin/soul/db/check
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/soul/llm/test?provider=deepseek&prompt=ping' -Headers $H -Method Get
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/soul/llm/test?provider=gigachat&prompt=ping' -Headers $H -Method Get | ConvertTo-Json -Compress

# Stateless batch sanity
$B=@{ input_text='batch stateless'; num_quants=2; persist_all=$false } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/soul/process_batch' -Method Post -Headers $H -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress

# Single sanity
$S=@{ input_text='single test'; num_candidates=1 } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/soul/process' -Method Post -Headers $H -ContentType 'application/json' -Body $S | ConvertTo-Json -Compress

# Hyperloop traces
$B1=@{ commands='CORE.PIPELINE.RUN input_text="health check" WITH TRACE' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B1 | ConvertTo-Json -Compress

# NeuroTraining: batch generate quants (DRY_RUN)
$B2=@{ commands='BATCH.GENERATE_QUANTS n=2 input_text="P38 DSL smoke" DRY_RUN' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B2 | ConvertTo-Json -Compress

# NeuroTraining: batch generate quants with DB context
$B3=@{ commands='BATCH.GENERATE_QUANTS n=2 input_text="Целевая генерация квантов о напоминаниях на завтра" use_db_for_models=true' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B3 | ConvertTo-Json -Depth 12 -Compress

# Evaluate last batch and apply feedback
$E=@{ commands='TRAIN.EVAL.LAST_BATCH' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $E | ConvertTo-Json -Compress
$F=@{ commands='LEARN.APPLY_FEEDBACK mode=reinforce window=24h' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $F | ConvertTo-Json -Compress


```

### 11.2 Примеры Hyperloop (P38)

- `BATCH.GENERATE_QUANTS n=2 input_text="P38 DSL smoke" DRY_RUN`
- `BATCH.GENERATE_QUANTS n=2 input_text="Целевая генерация квантов о напоминаниях на завтра" use_db_for_models=true`  

  (поддерживается параметр `use_db_for_models=true|false`)

- `BATCH.GENERATE_QUANTS n=2 input_text="..." use_db_for_models=true append=true`  

  (использовать `append=true` для накопления порциями перед оценкой)

- `TRAIN.EVAL.LAST_BATCH`
- `TRAIN.LAST_BATCH.NORMALIZE`  

  (нормализует и пересохраняет последний батч строгим JSON)

- `LEARN.APPLY_FEEDBACK mode=reinforce window=24h`
- `TRAIN.METRICS.WINDOW window=24h`
- `TRAIN.METRICS.WINDOW window=7d`
- `TRAIN.METRICS.WINDOW window=60m`

### 11.5 RT смоки (Hyperloop)

- `FLAGS.APPLY_PROFILE name=rt_low_latency`
- `BATCH.GENERATE_QUANTS n=1 input_text="RT gap-closure smoke" DRY_RUN TIMEOUT=1200`
- `BATCH.GENERATE_QUANTS n=3 input_text="RT micro-batch" append=true TIMEOUT=3000`
- `TRAIN.METRICS.WINDOW window=60m`

### 11.3.1 Расширенные сценарии (доменные группы)

- Напоминания (reminders): встречи/звонки/дела; уточнение времени/места/участников; actionability≥0.8.
- Цели (goals): формулировка SMART‑задач; связи с кластерами квантов; приоритет и статус.
- Календарь (calendar): конверсия диалога→события; дедупликация/сдвиг; транспорт.
- Личностные нормы (persona): тональность/маскировка PII; контроль NEGATIVE; видимость тех‑маркеров=0.
- Поиск/контент (retrieval): уточняющие кванты для контекстуализации; без персистенции.

Шаблоны команд (порционно, с накоплением):

```text
BATCH.GENERATE_QUANTS n=2 input_text="Сгенерируй 2 кванта [reminders|goals|calendar|persona|retrieval] ..." use_db_for_models=true append=true TIMEOUT=90000
TRAIN.EVAL.LAST_BATCH


```

Критерии приёмки батча: json_validity=1; non_empty_thought=count; tags_present_count≈count; avg_energy_weight≥0.7.

### 11.4 Результаты первичного прогона (PROD) и рекомендации

- Методика:
  - Генерация малыми порциями (`n=1..2`) с `append=true` до целевого размера батча (≈10–12).
  - Нормализация `train.last_batch` перед оценкой (`TRAIN.LAST_BATCH.NORMALIZE`).
  - Оценка `TRAIN.EVAL.LAST_BATCH` по метрикам: `count`, `non_empty_thought`, `json_validity`, `avg_energy_weight`, `tags_present_count`, `avg_weighted_score`.

- Итоги A/B (напоминания на завтра):
  - Профиль B (γ=1.4, ε=1.2; α=β=δ=1.0):  

    `count=12`, `json_validity=1`, `non_empty_thought=12`, `tags_present_count=12`, `avg_energy_weight≈0.825`, `avg_weighted_score≈4.1417`.

  - Профиль A (δ=1.5, ε=0.8; α=β=γ=1.0):  

    `count=5`, `json_validity=1`, `non_empty_thought=5`, `tags_present_count=5`, `avg_energy_weight≈0.86`, `avg_weighted_score≈4.06`.

- Выводы:
  - Профиль B даёт больший итоговый `avg_weighted_score` при сопоставимой валидности JSON и покрытии; профиль A подчёркивает энергию, но суммарный скор ниже.
  - Генерация порциями с `append=true` стабильно проходит под сетевыми ограничениями и снижает риск 504 при длинных LLM-вызовах.

- Рекомендации (к внедрению):
  - Зафиксировать рабочий профиль весов по умолчанию: `α=1.0, β=1.0, γ=1.4, δ=1.0, ε=1.2` (обновить `train.weights`).
  - Использовать стратегию порционной генерации (`n=1..3`, `append=true`) с последующей оценкой, пока длительные запросы `/api` ограничены таймаутами.
  - Включить в публичную спекацию DSL команды `TRAIN.LAST_BATCH.NORMALIZE` и параметр `append=true` для `BATCH.GENERATE_QUANTS` (см. §11.2).
  - Настроить регулярные окна метрик: `TRAIN.METRICS.WINDOW window=60m|24h|7d` и сохранять результаты A/B в аудит (P29) с привязкой к профилям весов.
  - Расширить датасет задач (помимо «напоминаний») и ввести фильтры при оценке (например, `actionability≥0.8`, `|tags|≥2`) для повышения требовательности теста.

### 11.3 A/B калибровка весов ранга (α..ε)

Цель: подобрать веса формулы `score = α*coverage + β*consistency + γ*actionability + δ*energy_weight + ε*tags_present` под реальные данные.

- Профиль A (более «энергетичный»):
  - `TRAIN.WEIGHTS.SET alpha=1.0 beta=1.0 gamma=1.0 delta=1.5 epsilon=0.8`
  - `BATCH.GENERATE_QUANTS n=10 input_text="Анализ напоминаний и целей на завтра" use_db_for_models=true`
  - `TRAIN.EVAL.LAST_BATCH`
  - `TRAIN.METRICS.WINDOW window=24h`

- Профиль B (более «действия/теги»):
  - `TRAIN.WEIGHTS.SET alpha=1.0 beta=1.0 gamma=1.4 delta=1.0 epsilon=1.2`
  - `BATCH.GENERATE_QUANTS n=10 input_text="Анализ напоминаний и целей на завтра" use_db_for_models=true`
  - `TRAIN.EVAL.LAST_BATCH`
  - `TRAIN.METRICS.WINDOW window=24h`

- Сравнение:
  - Сопоставить `avg_weighted_score`, `non_empty_thought`, `tags_present_count`, `avg_energy_weight`.
  - Зафиксировать выигрышный профиль в `TRAIN.WEIGHTS.SET` и сохранить метрики в отчёт.

## 12) План внедрения (без регресса)

1) Метрики качества/инспекторы; 2) DSL-команды TRAIN/BATCH/LEARN; 3) Processor: Learn‑стадия; 4) DB индексы/оценки; 5) Адаптивный recent_ratio; 6) Hybrid retriever вспомогательно; 7) A/B и калибровка весов.

## 13) Сопоставление с P01–P37 (начало цикла)

- P01–P07: контракты STRICT_JSON, DesiredAction подсхемы, self-consistency — учтены.
- P08–P12: privacy/security/provenance/trace — учтены; расширены подписи.
- P13–P16: eval/многоязычие/память — добавлены A/B и адаптивные политики.
- P17–P23: напоминания/календарь/UI — обучение учитывает реальные события; диагностика в панели.
- P24–P30: тесты/процессор — интеграция инспекторов и стадий Learn.
- P31–P37: мультисенсорность/RBAC/персоны/мобильный/процессы/DSL/промпты — совместимость сохранена.

## 14) Артефакты и обновления реестров

- Обновить `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8_2.md`: добавить P38.
- Обновить `docs/PROJECT_STRUCTURE_v8_0_4.md`: отразить TRAIN/BATCH/LEARN, метрики качества, индексы.
- Привязки: `backend/app/services/soul_core_manager.py`, `soul_router_v2.py`, `soul_context.py`, `soul_settings_service.py`, `soul_quant_schema.py`.
- Ссылки: P45 Quant Generation Modes — офлайн‑режимы, JSONL→SQL, связка с планом/целями (использовать для подготовки обучающих партий вне API).
- Ссылки: P46 NeuroIntegrity — запуск инспекторов полноты/целостности после крупных батчей обучения

## 15) Цикл сопоставления P01–P37 — Подразделы

- P01 MeaningExtraction: уточнить извлечение смыслов под задачи TRAIN/BATCH; добавить фичефлаг на усиление ключей для обучения.
- P02 MetaLoop/Introspection: включить пост‑оценку батчей и рефлексию планов обучения; журнал самокоррекции.
- P03 RouterContext: расширить контекст признаками «learning_task», «gap_connect» для bias и фильтров.
- P04 Hypothesis A/B: формальные эксперименты весов `α..ε` ранга; сравнение тактик провайдеров.
- P05 Och: тональные коррекции для снижения когнитивной нагрузки при обучающих диалогах.
- P06 SelfConsistency: проверки согласованности батч‑квантов; авто‑ретрай с поправками.
- P07 DesiredAction: типизированные подсхемы действий `train/eval/reinforce/decay`; политика autopublish.
- P08 Privacy: ограничение обучающих выборок по consent/скоупам; маскирование PII.
- P09 Security: Two‑Keys на `TRAIN.*`; анти‑злоупотребление LLM генерацией.
- P10 SchemaGuard: снепшоты подсхем действий и метрик качества; гейт несовместимых изменений.
- P11 Provenance: хранение источников батч‑квантов, провайдера, параметров.
- P12 TraceViewer: обязательные шаги обучения в `signature_steps`; инспекторы покрывают TRAIN/LEARN.
- P13 Eval: метрики качества; golden‑сеты для сценариев обучения.
- P14 MultiProviderRouting: профили провайдеров по задачам `connect_gaps`, `augment_context`.
- P15 Multilingual: языковые политики обучения; унификация на базовый язык для индексов.
- P16 MemoryCompaction: исключение дубликатов из активной витрины; якоря для частых паттернов.
- P17 Reminders/Search: обучение на фактических напоминаниях; проверка actionability.
- P18 Voice ASR: извлечение обучающих примеров из голосовых; нормализация эмоций.
- P19 Voice TTS: генерация кратких подтверждений обучения; UX‑сигналы.
- P20 TelegramBots: фасады TRAIN/LEARN в админ‑панели; логирование с RBAC.
- P21 Health: p95 стадий TRAIN/EVAL/LEARN; алерты на падение JSON Validity.
- P22 API Alignment: OpenAPI фасады для обучения; Pydantic схемы метрик.
- P23 UI Rebuild: виджеты батч‑обучения/метрик/трассы в ArchitectPanel.
- P24 Integrated Tests: сценарии статлесс батчей, фоллбеки, инспекторы.
- P25 Skills/Routes: загрузка «навыков» как цепочек квантов; интеграция в обучение.
- P26 Calendar/Transport: обучение на календарных целях; транспорт задач обучения в очередь.
- P27 Signature/Data Lineage: обязательные сигнатуры `svc.processor.learn.*` и TRAIN DSL.
- P28 FeatureFlags: профили обучения; безопасные дефолты; kill‑switch.
- P29 Quality Registry: гейты обучения и апелляции; человек‑в‑контуре при спорных случаях.
- P30 Processor: добавление Learn‑стадии и обратных связей; планировщик обучающих задач.
- P31 Multisensory Quants: мультимодальные признаки в ранге; веса по типу сигнала.
- P32 RBAC/Subscriptions: лимиты на обучение per‑user; платные профили провайдеров.
- P33 Personification/Profile: персонные предпочтения обучения; стили подачи.
- P34 External Chat/Mobile: прокси для обучения через внешние каналы; безопасные заголовки.
- P35 Processes (UNIFIED): место TRAIN/BATCH/LEARN в цепочках; совместимость с ядром.
- P36 Hyperloop DSL: команды TRAIN.*; REQUIRE цепочки шагов в трассах.
- P37 Prompts TD: описать модульные правила обучения в промптах; санитизация.

### 15.1 RT‑заметки (по P01–P37)

- P01: ускорить извлечение смыслов микро‑подзапросом к малой LLM при высоком приоритете; таймаут 300–600 мс.
- P03: ввести `router.rt_policy` (эвристика vs LLM) по критичности события; предикат «критичное уведомление → без LLM».
- P14: разделить поставщиков на low‑latency и high‑quality; RT Scheduler предпочитает low‑latency для микро‑батча.
- P16: недавние якоря памяти повышают шанс попадания в контекст для RT‑запросов (recency boost↑).
- P27: обязательные шаги подписи без исключений даже при деградациях; RT‑кейс покрывается инспектором.
- P28: профиль `rt_low_latency` (timeouts/token_budget/temperature) и kill‑switch деградаций.
- P29: гейт «rt_latency_budget» — блокировать длинные пути при критичных уведомлениях.
- P30: планировщик очередей учитывает p95 по классам событий; `processor.queue_len` и бэк‑прешер обязательны.
- P35: в цепочках процессов добавить «RT Gap‑Closure» узел перед обычным обучением.
- P36: DSL параметр `TIMEOUT=<ms>` обязателен для RT‑команд; `CORE.TRACE.REQUIRE` в смоках.

### 15.2 Перечень RT‑улучшений по P01–P37 (миниконспект)

- P01 MeaningExtraction: малая LLM для смысла (timeout 300–600 мс), не блокировать ядро.
- P02 MetaLoop: микро‑рефлексия после батчей (окна 60м/24ч), без влияния на RT‑путь ответа.
- P03 RouterContext: `router.rt_policy` (critical→evristic/no‑LLM), контекст урезан до «якорей».
- P04 Hypothesis A/B: профили `rt_low_latency` vs `hq_quality`, метрика p95 и доля деградаций.
- P05 Och: снижение когнитнагрузки при RT‑ответах (короче текст, без сложных структур).
- P06 SelfConsistency: лёгкие проверки (структура/диапазоны), тяжёлые — оффлайн.
- P07 DesiredAction: в stateless `[]`; автопубликация только по RT‑политикам (Two‑Keys при опасных типах).
- P08 Privacy: маскирование PII на входе/выходе RT‑ветки.
- P09 Security: Two‑Keys для `TRAIN.*`; лимиты частоты RT‑обучения.
- P10 SchemaGuard: снимки подсхем метрик/действий; гейт несовместимых RT‑изменений.
- P11 Provenance: фиксировать `provider, model, timeout_ms, shard_id` у батчей.
- P12 TraceViewer: RT‑метрики в `signature_steps` и в инспекторах.
- P13 Eval: окна метрик 60м/24ч включают latency/rt_gap_closures.
- P14 MultiProvider: теги провайдеров `low_latency|high_quality`, шардирование.
- P15 Multilingual: не выполнять переводы в RT; нормализация только при явной нужде.
- P16 MemoryCompaction: recency‑boost↑ и якоря для RT; батчи компактны.
- P17 Reminders/Search: при due/critical — RT gap‑closure (n≤3, TIMEOUT≤1500–3000 мс).
- P18 Voice ASR: стриминг парциалов; дешёвые модели в RT.
- P19 Voice TTS: кэш шаблонов подтверждений; цель p95≤800 мс.
- P20 TelegramBots: заголовок `X-Telegram-User-ID` обязателен; без поднятия локсерверов в тестах.
- P21 Health: алерты на `time_send_to_recv_ms p95` и `queue_len`.
- P22 API Alignment: параметр `TIMEOUT` в DSL/OpenAPI; единые типы метрик RT.
- P23 UI Rebuild: индикаторы RT‑режима, скрыта диагностика по умолчанию.
- P24 Integrated Tests: RT‑смоки через Hyperloop; тесты не стартуют сервера.
- P25 Skills/Routes: RT‑квоты/бюджеты на сессии навыков.
- P26 Calendar/Transport: приоритизация событий; быстрая `snooze/reschedule` без LLM.
- P27 Signature/Data Lineage: обязательные шаги и Guard для RT‑ответов.
- P28 FeatureFlags: профиль `rt_low_latency`, kill‑switch деградаций.
- P29 Quality: гейт `rt_latency_budget` и апелляции при блокировке.
- P30 Processor: back‑pressure по очередям; цели throughput и p95 по стадиям.
- P31 Multisensory: лёгкие предобработки; тяжёлые — оффлайн.
- P32 RBAC/Subscriptions: лимиты на RT‑обучение/провайдеров по ролям/планам.
- P33 Personification: не усиливать стилистические модули в RT; имя персоны отображается (UI).
- P34 External Chat/Mobile: безопасные заголовки; мобильный low‑latency профиль.
- P35 Processes: узел «RT Gap‑Closure» перед обычным обучением; `TRACE.REQUIRE` обязателен.
- P36 Hyperloop DSL: `TIMEOUT=<ms>` обязателен для RT‑команд; смоки в §11.5.
- P37 Prompts TD: OUTPUT_SPEC инвариант; RT‑сноски только как динамические указания, базовые промпты неизменны.

## Приложение A — Метрики качества (формулы)

- Coverage ∈ [0,1] (экспертная/эвристическая оценка)
- Consistency ∈ [0,1] (валидация схем/логики)
- Actionability ∈ [0,1] (типизированные действия пригодны к исполнению)
- JSON Validity = валидные/все
- Итоговый ранг: `score = αC + βK + γA + δE + εS` (см. §6)

## Приложение B — Команды DSL (спека)

- `BATCH.GENERATE_QUANTS n=<int> provider=<key> topic="..." STRICT`
- `TRAIN.EVAL.LAST_BATCH`
- `LEARN.APPLY_FEEDBACK mode={reinforce|decay} window=<dur>`
- `TRAIN.METRICS.WINDOW window=<dur>`

## 16) Операции (эксплуатация)

- Запуск 24h‑сбора (профиль B): cron‑джоб с порционной генерацией (`append=true`), периодической оценкой (`TRAIN.EVAL.LAST_BATCH`) и метриками окна (`TRAIN.METRICS.WINDOW window=60m`).
- Отправка отчёта: по завершении суток инжектируется событие `PROCESSOR.EVENT.INJECT kind=neurotrain.report`, процессор отправляет отчёт в Telegram с кнопкой «Подтверждаю получение».
- Подтверждение получения: обработчик callback `ack_nt_*` меняет `train.report.last.status` на `acknowledged`. Планировщик процессора (`neurotrain.report.verify`) напоминает до получения ACK.
- Ручные операции:
  - Инжект отчёта: `PROCESSOR.EVENT.INJECT kind=neurotrain.report payload={}`
  - Проверка ACK: `GET /api/admin/soul/settings/all` → `train.report.last` содержит `status=acknowledged`
  - Аварийная нормализация батча: `TRAIN.LAST_BATCH.NORMALIZE`

## 17) Изменения v1.1 (RT‑инкремент)

- Добавлены RT‑инварианты и SLO (p50/p95), микро‑батчи и gap‑closure по событию.
- Расширена архитектура: RT Scheduler, шардирование провайдеров, бюджет времени/токенов.
- Дополнены потоки данных, алгоритмы и Acceptance с RT‑метриками.
- Добавлены RT смоки и RT‑заметки по P01–P37.

## 18) RT‑аудит соответствия (чек‑лист и смоки)

- Инварианты (обязательные):
  - Stateless batch: `db=None`, `desired_action=[]`, STRICT JSON массив; greenlet_spawn=0.
  - Guard: наличие цепочки шагов P27 перед любым видимым ответом; при отсутствии — блок.
  - RT‑метрики экспортируются: `time_send_to_recv_ms{p50,p95}`, `queue_len`, `events_processed_per_min`.
- Пороговые значения (acceptance):
  - p95 `time_send_to_recv_ms ≤ 3000` в RT gap‑closure; `rt_time_to_first_result_ms ≤ 1200`.
  - Доля принудительных деградаций ≤ 5% за 24ч; JSON Validity ≥ 99%.
- Инспекторы/тесты (Hyperloop):
  - `INSPECTOR.RUN_ALL scope=signature`
  - `CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"`
  - `BATCH.GENERATE_QUANTS n=1 input_text="RT gap-closure smoke" DRY_RUN TIMEOUT=1200`
  - `BATCH.GENERATE_QUANTS n=3 input_text="RT micro-batch" append=true TIMEOUT=3000`
  - `TRAIN.METRICS.WINDOW window=60m`

## 19) Согласованность и отсутствие регресса

- Контракты и инварианты: STRICT_JSON_QUANT, stateless batch c `desired_action=[]`, Delivery Guard (P27) — соблюдены.
- Совместимость: P01–P37 — учтены (см. §15.1–15.2); Hyperloop DSL (P36) расширен только безопасными RT‑параметрами.
- Без регресса: функциональный объём P38 увеличен (RT SLO/смоки/метрики) без удаления разделов/требований.
- Реестр документов: обновлён `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8_2.md` (P38 v1.1, RT).

## 20) Догенерация данных, мягкий QC и автозагрузчик (расширение P38)

Цель: непрерывное пополнение базы Соул новыми Квантами/Навыками/Планами из подготовленных наборов и внешних источников (интернет) с автоматической догенерацией и мягко настраиваемым QC; гарантировать стабильный инжест без 5xx/429, нулевые SKIP по каноническим good и ≥95% покрытия QUANT.LINK.

Область: каталоги `Soul/data/**` (raw) и производные `Soul/out/qc/**` (`*.refine.jsonl`, `*.good.jsonl`, `*.good.gen.jsonl`, `*.qc_report.json`). Запуски — по glob или весь проект.

Компоненты:

- Нормализация/рефайн/валидация: `normalize_jsonl_recursive.py`, `refine_jsonl_recursive.py`, `pre_ingest_validate.py`.
- Обогащение: `enrich_quants_jsonl.py`.
- Регенерация/инжест: `regen_empty_goods_and_ingest.py`, `llm_generate_missing_and_ingest.py` (расширить web‑добычей).
- Слияние/QC‑синхронизация: `merge_gen_into_base_goods.py`, `recompute_qc_metrics_from_gen.py`.
- Инжест/отчёты: `ingest_all_goods.py`, `aggregate_ingest_report.py`, `verify_quants_links_coverage.py`.
- DSL‑отправщик: `send_hyperloop_dsl.py` (батчи/ретраи/паузы/резюмирование).

Догенерация с интернет‑добычей (RAG):

- В `llm_generate_missing_and_ingest.py` добавить флаги: `--with-web --search-provider <env> --max-urls 20 --per-url-max-chars 12000 --diversity-lines 28..32 --retry 2 --timeout 90 --rpm 120`.
- Вставлять источники в поля provenance; секреты — только из PROD ENV.

Смягчённый QC (адресный):

- Базовые пороги: `min_len=60, max_len=320, min_tags=2, uniq≥0.80, char_gram=3, max_char_jaccard=0.92`.
- Оверрайды (пример `Soul/config/qc_overrides.yaml`):

```yaml
overrides:
  - glob: "Soul/out/qc/exchange_shard_*.good.jsonl"
    uniq_min: 0.75
    max_char_jaccard: 0.94
  - glob: "Soul/out/qc/*prog_langs*.good.jsonl"
    uniq_min: 0.76


```

- `pre_ingest_validate.py` читать оверрайды и применять на лету.

Автозагрузчик (непрерывный цикл):

- Оркестратор `auto_dogenerate_and_ingest.py` (каждые 10–15 минут):

  1) Находит пустые/низко‑уникальные good либо отсутствующие good при наличии refine.
  2) Запускает догенерацию (`--with-web`) с QC‑оверрайдами.
  3) `pre_ingest_validate` → `enrich_quants_jsonl` → `merge_gen_into_base_goods` → `recompute_qc_metrics_from_gen`.
  4) `ingest_all_goods.py` (адаптивно, батчи 50–80, ретраи).
  5) `link_quants_from_goods.py` + `neuro_link_from_goods.py`.
  6) `verify_quants_links_coverage.py` (≥95% по выборке).
  7) Логи JSON в `Soul/out/logs/auto_dogenerate_YYYYMMDD.jsonl`; инциденты P27 в БД.

- Интеграция в ProcessorScheduler (флаг `auto_dogenerate_enabled=true`), мониторинг p95/err_rate.

План/связи (P40):

- Проекты: `PROJECT.CREATE|LIST`.
- Цели/задачи: `PLAN.GOAL.ADD external_id=...`, `PLAN.TASK.ADD project_name=... external_id=...`.
- FIND/линковка (новое): `PLAN.GOAL.FIND|PLAN.TASK.FIND` + `QUANT.LINK.AUTO from_quant=<uuid> to=<goal|task|project> [external_id|title] [project_id] relation=supports`.
- Батч‑скрипт (новое): `Soul/scripts/generate_find_and_auto_link_dsl.py` — формирует единый DSL‑файл на основе `payload.plan.goal_id|task_id` из `*.good.jsonl`:
  - добавляет префиксные `PLAN.GOAL.FIND`/`PLAN.TASK.FIND` (дедуп);
  - строит `QUANT.LINK.AUTO from_quant=... to=goal|task external_id=... relation=supports`;
  - по умолчанию пишет в `Soul/out/qc/hyperloop_find_and_auto_link.dsl`.
- Отправка батча: через `send_hyperloop_dsl.py` или прямые POST в `/api/hyperloop/execute`.

Метрики/Acceptance:

- Инжест: 0 ошибок 5xx/429, `SKIP=0` по каноническим good.
- QUANT.LINK покрытие: ≥95% по выборке 25–30 записей/файл.
- Рост базы: +N% уникальных `id` vs последний срез; без деградации уникальности.

Операции (PS):

```powershell
python .\Soul\scripts\llm_generate_missing_and_ingest.py --root Soul/out/qc --with-web --diversity-lines 30 --retry 2 --timeout 90 --rpm 120
python .\Soul\scripts\pre_ingest_validate.py --root Soul/out/qc --overrides Soul/config/qc_overrides.yaml
python .\Soul\scripts\merge_gen_into_base_goods.py --qc-dir Soul/out/qc
python .\Soul\scripts\recompute_qc_metrics_from_gen.py --qc-dir Soul/out/qc
python .\Soul\scripts\ingest_all_goods.py --api https://mini.soulpulse.art --user-id 468326902 --batch-size 60 --sleep-ms 200 --threads 12 --adaptive
python .\Soul\scripts\link_quants_from_goods.py --batch 60 --api https://mini.soulpulse.art --user-id 468326902
python .\Soul\scripts\neuro_link_from_goods.py
python .\Soul\scripts\verify_quants_links_coverage.py
python .\Soul\scripts\qc_overrides_validate.py --config Soul\config\qc_overrides.yaml --qc-dir Soul\out\qc --sample 10 --report Soul\out\qc\qc_overrides_dry_run.json


```

Безопасность: ключи только из PROD ENV; PII не логировать; веб‑добыча — троттлинг/таймауты/robots.txt (если включено).


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
