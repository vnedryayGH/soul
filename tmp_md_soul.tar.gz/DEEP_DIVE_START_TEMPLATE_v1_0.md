# Soul — Deep‑Dive Start Template v1.0

Версия: v1.0  
Назначение: быстрый старт и глубокая работа в проекте Soul. Самодостаточный документ: содержит доступы/секреты, SSH/деплой‑рунбуки, реестры документов, правила разработки, чек‑листы актуализации, направления исследования и контроль качества.  
Источник требований: `Soul/P23_TZ_Soul_UI_Rebuild_v1_0.md`, `Soul/P23_TZ_UI_Spec_v2_1.md`, `Soul/P22_TZ_Soul_API_Alignment_v1_0.md`, `Plan/FRONTEND_CLEAN_REBUILD_PLAYBOOK_v1_0.md`.

Плейсхолдеры (подставлены по умолчанию):
- {API_BASE} = https://mini.soulpulse.art/api
- {ADMIN_TG_ID} = 468326902

Внимание: Не удаляйте секреты в этом документе при локальном использовании. Не коммитьте заполненные секреты в публичные ветки.

---

## 0) Контекст ветки

- Ветка: {BRANCH_NAME}, версия: {BRANCH_VERSION}, дата: {DATE}
- Цели инкремента (пример):
  - Чистый ребилд фронтенда в новых каталогах без мусора (PROD/DEV)
  - Включение Stage 0→1 (Header‑only, TelegramHome, MiniAppChat)
  - Включение фасадов P22 (Reminders ГОТОВО; подготовка Two‑Keys/Admin)
- Ограничения: SAFE_BOOT, ROUTES_STAGE, VITE_DEBUG_LOGS=0; TTI ≤ 1.5s (Mini‑App), ≤ 2.0s (Web)

## 1) PROD/DEV окружение (канонично)

- API: {API_BASE}
- Обязательный заголовок: `X-Telegram-User-ID: {ADMIN_TG_ID}`
- PROD пути: ENV `/etc/soulpulse/miniapp_backend.env`; systemd: `soulpulse-backend.service`; Nginx: `/etc/nginx/sites-enabled/03-mini_soulpulse.conf`
- PowerShell (Windows):

```powershell
$OutputEncoding = [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
```

## 2) Доступы, ключи и секреты (консолидация)

Внимание: раздел для закрытого использования. Хранить локально, не коммитить с заполненными значениями. Источники: `docs/SECRETS_INVENTORY_2025-09-15.md`, Guardian `Plan/guardian/storage/data/servers.json`.

### 2.1 Переменные окружения (prod)

- Хранятся в: `/etc/soulpulse/miniapp_backend.env`
- Ключевые переменные: `DATABASE_URL`, `BOT_TOKEN`, `BOT_TOKENS`, `JWT_SECRET`, `DEEPSEEK_API_KEY`, `CORS_ORIGINS`, `SOUL_DISABLE_QUANT_PERSIST_BATCH`, `TEST_NO_DB`
- Получение (SSH):

```bash
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art \
  "grep -E '^(DATABASE_URL|BOT_TOKEN|BOT_TOKENS|JWT_SECRET|DEEPSEEK_API_KEY)=' /etc/soulpulse/miniapp_backend.env"
```

Локальные значения (пример — хранить вне репозитория):

- `DATABASE_URL=postgresql+asyncpg://miniapp_user:miniapp_pwd@46.173.24.4:5432/miniapp_db`
- `BOT_TOKEN=8236996666:AAFdY2uSqoNIxFibTXolnrLBYjTTK_DWF-E`
- `BOT_TOKENS=8236996666:AAFdY2uSqoNIxFibTXolnrLBYjTTK_DWF-E`
- `JWT_SECRET=15Z9NIaD2LRfmVHaTt96T3pOiHu1fWnI9HwhAjj9mJVoh0Pq`
- `DEEPSEEK_API_KEY=sk-32a76a58a2384977b8d05fb9bee194bb`
- `CORS_ORIGINS=https://mini.soulpulse.art`
- `LLM_PROVIDER=deepseek`
- `DEEPSEEK_MODEL=deepseek-chat`

### 2.2 Telegram/боты (локальные примеры)

- BOT_TOKENS (local test): `8260946317:AAGkYKYWD8WNnEIgFXghqk_pToYKJRcN2FM` (локальные стенды; в проде не использовать)
- TELEGRAM_BOT_TOKEN (example): `your_bot_token_here`

### 2.3 База данных

- PROD host: `46.173.24.4`; DB: `miniapp_db`; User: `miniapp_user` (пароль в `DATABASE_URL`)
- Тестовый DSN (пример): `postgresql+asyncpg://miniapp_user:miniapp_pwd@127.0.0.1:5432/miniapp_db`

### 2.4 SSH доступы

- Приложение (prod): `root@mini.soulpulse.art:22` (ключ: `deploy/ssh_keys/app_server_key`)
- Пользователь приложения: `soulpulse@mini.soulpulse.art:22`
- Сервер БД: `root@46.173.24.4:22` (ключ: `deploy/ssh_keys/db_server_key`)

Проверка:

```bash
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "hostname"
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new soulpulse@mini.soulpulse.art "whoami"
ssh -i deploy/ssh_keys/db_server_key  -o StrictHostKeyChecking=accept-new root@46.173.24.4 "hostname"
```

### 2.5 SSL/домены

- Домен PROD: `mini.soulpulse.art`
- Сертификаты: `/etc/letsencrypt/live/mini.soulpulse.art/fullchain.pem`, `privkey.pem`

Проверка срока:

```bash
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art \
  'openssl x509 -in /etc/letsencrypt/live/mini.soulpulse.art/fullchain.pem -noout -enddate'
```

## 3) Реестры и документы (must‑read)

- Индекс: `docs/DOCUMENTATION_INDEX_v4_2.md`
- Структура проекта: `docs/PROJECT_STRUCTURE_v8_0_4.md`
- Конвейер Soul: `docs/SOUL_PIPELINE_v1_1.md`
- Структура БД: `docs/DATABASE_STRUCTURE_v8_0_2.md`
- OpenAPI (P20): `docs/openapi-p20-telegram-bots.yaml`
- P‑серия: папка `Soul/` (источник истины)
- Научный отчёт: `Soul/Report_Soul_AI_Scientific.md`
- Project AI Autopilot: `Soul/PROJECT_AI_AUTOPILOT_v2_26.md`
- Регистры: `docs/REGISTRIES_INDEX.md`, `docs/DOCS_REGISTRY_v8_0_4.md`
- CI/Метрики: `scripts/ci_generate_metrics.py`, артефакты `Soul/CI/*`

Чек‑лист актуализации после изменений:
- Обновить соответствующий P‑документ
- Синхронизировать OpenAPI ↔ Pydantic ↔ БД (Alembic)
- Обновить `PROJECT_STRUCTURE_v8_0_4.md` и индексы
- Прогнать `scripts/ci_generate_metrics.py` и приложить отчёт
- Обновить гайды (тесты/системный обзор/SSH)

## 4) Правила разработки (жёсткие)

- Stateless batch вначале: LLM‑вызовы с `db=None`; STRICT JSON — массив объектов; в stateless `desired_action=[]`
- Фоллбек: batch→single; persistent включать после стабилизации
- Никаких заглушек; фиксировать корневую причину
- Модули — «policy‑extract», NEGATIVE‑санитизация обязательна
- Единая сборка SYSTEM/USER: `[CORE][ROUTER_CONTEXT][MODULES][OUTPUT_SPEC][NEGATIVE]` + история + `input_text`
- Контракты: Pydantic Strict; `row_version` + `ETag/If-Match`
- Schema Guard: снимок JSON‑схем; semver; CI‑гейт
- RBAC/Scopes: `repo.read/write`, `workspace.read/write/exec`, `secrets.read`; two‑keys
- Observability by default: события/метрики/трейсинг; SLO/алерты

## 5) Быстрые проверки PROD (после деплоя)

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
# Health/DB/LLM
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/health
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/admin/soul/db/check
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/soul/llm/test?provider=deepseek&prompt=ping' -Headers $H -Method Get
# Dispatcher
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/dispatcher/run_for?minutes=1' -Headers $H -Method Post | ConvertTo-Json -Compress
Start-Sleep -Seconds 2
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/dispatcher/metrics' -Headers $H -Method Get | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/dispatcher/stop' -Headers $H -Method Post | ConvertTo-Json -Compress
# DesiredAction sanity (пример)
$Q='P07: desired_action: [{"type":"reminder","text":"Позвонить маме","when":"2025-09-15T10:00:00Z"}]'
$B=@{ input_text=$Q } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/soul/process' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Depth 12 -Compress
# Sleep v2 (dry_run)
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/soul/sleep?dry_run=true' -Headers $H -Method Post | ConvertTo-Json -Depth 8 -Compress
# Sanity последних квантов
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/soul/qa/quants_sanity?limit=10' -Headers $H -Method Get | ConvertTo-Json -Compress
# Обновление рангов (MV)
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/soul/refresh-rank' -Headers $H -Method Post | ConvertTo-Json -Compress
```

## 6) Режимы исполнения

- Batch/stateless: STRICT JSON массив, `desired_action=[]`, `LLMClient.send(..., db=None)`
- Single/persistent: транзакция message→quant→связи/цели; строгая валидация `desired_action: List[dict]`

## 7) Acceptance (принятие инкремента)

- Batch(stateless) — валидный массив квантов; `desired_action=[]`
- Single — корректная персистенция кванта/связей/целей
- Health/DB/LLM/Dispatcher/Sanity/Refresh/Sleep — 200; логи чистые; 5xx нет

## 8) Траблшутинг

- ImportError `system_api`: защитить импорт флагом; деактивация через ENV; корректный фикс в `app/main.py`
- 504/таймауты: понизить `num_quants` до 1–3; проверить Nginx timeouts; systemd `Restart=always`
- STRICT JSON: верхний уровень — массив/объект без markdown; числа → float; `tags: List[str]`
- `desired_action`: в stateless всегда `[]`
- `greenlet_spawn`: все LLM‑вызовы в stateless — с `db=None`

## 9) Rollback (без простоя)

```powershell
scp -i .\Arh\spbd_ed25519 -o StrictHostKeyChecking=accept-new backend/app/services/soul_core_manager.py `
  root@217.12.38.238:/opt/soulpulse/app/Telegram_Bot/backend/app/services/
ssh -i .\Arh\spbd_ed25519 -o StrictHostKeyChecking=accept-new root@217.12.38.238 `
  "systemctl restart soulpulse-backend.service ; systemctl is-active soulpulse-backend.service ; journalctl -u soulpulse-backend.service -n 50 --no-pager"
```

## 10) Nginx/Backend sanity (SSH)

```bash
# Nginx проверка и reload
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art \
  'nginx -t && systemctl reload nginx && echo RELOADED'
# Порты/сервисы
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art \
  'ss -ltnp | egrep ":(22|80|443|8000)" ; systemctl is-active soulpulse-backend.service'
# Логи ошибок Nginx
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art \
  'tail -n 120 /var/log/nginx/error.log'
```

## 11) Два ключа и чувствительные операции (Admin API)

- Политики/очередь: `/api/admin/two-keys/policies`, `/api/admin/two-keys/requests`, `/api/admin/two-keys/approve`
- Скоупы: `repo.read/write`, `workspace.read/write/exec`, `secrets.read`
- Требование: любые `pc.*`/`cursor.*` — только с одобрением и аудитом

## 12) Guardian (проверки PROD)

- Конфиг/хранилище: `Plan/guardian/storage/data/servers.json`
- Типовые проверки: домен/SSL, Nginx, backend service, ENV, DB host, пути фронтенда
- Выполнение (пример):

```bash
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art \
  "hostname && nginx -t && systemctl is-active soulpulse-backend.service"
```

## 13) Направления погружения (knowledge map)

- Структурированный вывод LLM: JSON‑контракты, Pydantic Strict, Schema Guard
- Память/контекст 30/70_v2: ранжирование, гибридный ретривер (BM25+vector)
- Роутинг/политики: RouterV2, policy‑extract, NEGATIVE‑санитизация
- DesiredAction/Router: подсхемы, allow‑list, ethics‑gate, autopublish
- Multi‑provider routing: стоимость/латентность, failover, rate‑limit
- Безопасность: Red‑Team/Jailbreak‑guard, PII‑санитайзер, RBAC/scopes
- Миграции/ABI: Alembic, `row_version`, `ETag/If-Match`, snapshot схем
- Observability: качество квантов, HealthScore (P21), дешборды/алерты
- Многоязычие/память: язык/леммы/теги/синонимы
- Голос (ASR/TTS): ffmpeg, Telegram voice, приватность
- Тестирование: Golden‑Set, Eval Harness, A/B, интеграционные цепочки (P24)

## 14) План чтения и соответствия (быстрый старт)

1) `docs/PROJECT_STRUCTURE_v8_0_4.md` — карта системы
2) `docs/SOUL_PIPELINE_v1_1.md` — batch/single и сборка промпта
3) `Soul/PROJECT_AI_AUTOPILOT_v2_26.md` — авторизация, UI, RBAC
4) `Soul/Report_Soul_AI_Scientific.md` — STRICT JSON, память 30/70, роутинг
5) P‑документы по активной задаче (P01–P24)
6) `docs/openapi-p20-telegram-bots.yaml` — контракты API
7) `docs/DATABASE_STRUCTURE_v8_0_2.md` — сущности/связи/row_version

## 15) Чек‑лист изменений (обязательный порядок)

- Контракты: Pydantic → OpenAPI синхронизированы
- Миграции Alembic написаны и применены
- Schema Guard: обновлён снимок/версия схем
- Обновлены индексы/реестры (индекс документации, структура проекта)
- Тесты: целевые + общий прогон; интеграционные цепочки
- Мониторинг: метрики/дашборды обновились, алертов нет
- Безопасность: RBAC/Scopes, two‑keys покрывают новые операции

## 16) Команды Dev/CI

- Генерация health‑метрик CI:

```powershell
$env:SOUL_CI_HEALTH_STRICT="1" ; python .\scripts\ci_generate_metrics.py
```

- Быстрый прогон фасадов P22 (если включены):

```powershell
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/two-keys/policies' -Headers @{ 'X-Telegram-User-ID'='468326902' } -Method Get
```

---

## A) Чистый ребилд фронтенда (по Playbook, PROD/DEV)

Артефакты Playbook: `Plan/FRONTEND_CLEAN_REBUILD_PLAYBOOK_v1_0.md`. Ниже — встроенные шаги с командами.

### A.1 Аварийная форма `/frontend/minimal/`

Файлы (PROD):
- `/var/www/soulpulse/frontend/minimal/index.html`
- `/var/www/soulpulse/frontend/minimal/Soul6.png`

Загрузка (PowerShell → SSH):

```powershell
$f = "$PWD/tmp/sp_minimal_index.html"; New-Item -Force -ItemType Directory tmp | Out-Null; Set-Content -Path $f -Value (Get-Content -Raw Plan/FRONTEND_CLEAN_REBUILD_PLAYBOOK_v1_0.md | Select-String -Pattern '<!doctype html>' -Context 0,0).Matches[0].Value -Encoding utf8
scp -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new $f root@mini.soulpulse.art:/var/www/soulpulse/frontend/minimal/index.html
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc 'nginx -t && systemctl reload nginx && echo READY && curl -sI https://mini.soulpulse.art/minimal/ | head -n 1'"
```

### A.2 Чистый старт фронта в корне `/frontend`

```powershell
# 1) Бэкап текущего каталога (или создать если нет)
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc 'set -e; BASE=/var/www/soulpulse; ts=`$(date +%Y%m%d_%H%M%S); [ -d "`$BASE/frontend" ] && cp -a "`$BASE/frontend" "`$BASE/frontend_backup_`$ts" || mkdir -p "`$BASE/frontend"; echo BACKUP:frontend_backup_`$ts'"
# 2) Залить минимальный index.html в корень
$h='<!doctype html><html lang="ru"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/><title>SoulPulse — аварийный старт</title><meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/><meta http-equiv="Pragma" content="no-cache"/><meta http-equiv="Expires" content="0"/><style>:root{--bg:#0f172a;--card:#111827;--text:#e5e7eb;--muted:#93c5fd}*{box-sizing:border-box}html,body{height:100%;margin:0}body{display:flex;align-items:center;justify-content:center;background:var(--bg);color:var(--text);font:14px ui-monospace,monospace}.card{background:var(--card);border:1px solid #1f2937;border-radius:14px;padding:20px;min-width:300px;max-width:680px;box-shadow:0 10px 30px rgba(0,0,0,.35)}h1{margin:.2rem 0 1rem 0;font-size:18px}.muted{color:var(--muted)}.err{color:#fca5a5}img{max-width:160px;border-radius:12px;border:1px solid #1f2937;display:block;margin:0 auto 10px auto}</style></head><body><div class="card"><img src="./Soul6.png" alt="Soul" onerror="this.style.display=\"none\""/><h1>SoulPulse — аварийный старт</h1><div class="muted">PROD · mini.soulpulse.art · <span id="ts"></span></div><div class="err" id="errmsg">Основной интерфейс временно недоступен. Попробуйте обновить мини‑апп позже.</div></div><script>(function(){try{document.getElementById("ts").textContent=new Date().toISOString();var u=new URL(window.location.href);var m=u.searchParams.get("err");if(m){document.getElementById("errmsg").textContent=m;}}catch(e){}})();</script></body></html>'
New-Item -Force -ItemType Directory tmp | Out-Null; Set-Content -Path .\tmp\sp_index.html -Value $h -Encoding utf8
scp -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new .\tmp\sp_index.html root@mini.soulpulse.art:/var/www/soulpulse/frontend/index.html
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc 'nginx -t && systemctl reload nginx && echo READY && curl -sI https://mini.soulpulse.art/ | head -n 1'"
```

### A.3 Минимальные требования Nginx

```nginx
root /var/www/soulpulse/frontend;
location / { try_files $uri /index.html; }
location /assets/ { try_files $uri =404; expires 30d; add_header Cache-Control "public, max-age=2592000, immutable"; types { application/javascript js; text/css css; } }
add_header Cache-Control "no-store" always;
```

### A.4 Минимальный UI‑скелет (Stage 0→1)

- Router: `MemoryRouter`
- Флаги: `window.__SP_FLAGS__` (SAFE_BOOT, NOREDIRECT, DIAG)
- Детект Mini‑App: по `Telegram.WebApp`/UA, не по `tg_id`
- Никаких авто‑редиректов в Mini‑App; `WebAuth` только для Web
- Логи: в проде `VITE_DEBUG_LOGS=0`; warn/error остаются

### A.5 CI/сборка/аудит

- `frontend/vite.config.ts`: sourcemap(prod), drop console.debug/info/log
- `frontend/.env.production`: `VITE_DEBUG_LOGS=0`
- Pre‑commit (husky): build + `scripts/gate_dist.ps1`
- Smoke preview: `scripts/smoke_frontend_preview.ps1` (/, /webauth, /chat, /dates-reminders, /minimal)

### A.6 Rollback фронтенда без простоя

```powershell
ssh -i deploy/ssh_keys/app_server_key -o StrictHostKeyChecking=accept-new root@mini.soulpulse.art "bash -lc 'set -e; BASE=/var/www/soulpulse; L=`$(ls -1dt `$BASE/frontend_backup_* 2>/dev/null | head -n1); if [ -n "`$L" ]; then cp -a "`$L" "`$BASE/frontend"; fi; nginx -t && systemctl reload nginx && echo ROLLED'"
```

---

## B) Выравнивание API под P20 (P22)

Минимальные фасады (из `Soul/P22_TZ_Soul_API_Alignment_v1_0.md`):
- Уже подключено: `/api/reminders/*` через фасад
- Далее по инкрементам: Two‑Keys Admin → PC/Cursor (dry‑run) → Health выравнивание → Tasks/Events/Gantt → Inbox/Mining → Comments/Attachments/Sprints/Time

Требования безопасности:
- RBAC роли→разрешения; Scopes (`repo.*`, `workspace.*`, `secrets.read`)
- Two‑Keys очередь/TTL/аудит; pc/cursor — только после approve

Контракты:
- Strict‑модели, ETag/If‑Match, пагинация/фильтры унифицированы

---

## C) UI пересборка (P23)

Слои UI:
- Core, Layout, Navigation, Pages, Widgets, Styles, Guards
- Платформенные классы: `telegram-mini-app`, `sp-platform-telegram`, `sp-platform-web`
- Сессия: Mini‑App — `tg_id` в `sessionStorage` (pre‑init); Web — токен

Безопасность UI:
- CSP/XFO/Referrer‑Policy/Permissions‑Policy; CORS — доверенные origin
- Заголовок `X-Telegram-User-ID` из Mini‑App; RBAC/Scopes в UI (видимость)

Конфиг‑схемы (источник истины):
- `design-tokens.json`, `themes.json`, `layout.json`, `nav.menu.json`, `features.json`, `forms/*.json`

Реестр страниц (без регресса):
- Core: TelegramHome, WebAuth, Home, Help, Settings, LLMSettings, LLMParams, Keywords, Payments
- Chat: MiniAppChat, TelegramChat, ChatManagement
- Soul: SoulDashboard, SoulGoals, SoulOptimization, SoulVisualization, SoulLogs
- Admin: AdminPanel, SecurityDashboard, SecurityEvents, RBACAdmin, ArchitectPanel, Trace, ActivityGoalsIntegration, DatesReminders, DatesRemindersV2, SoulQuants, Register, Prompts

Производительность и UX:
- Budgets: TTI ≤ 1.5s/2.0s; lazy routes, code‑split; метрики: LCP/CLS/INP + свои

Этапы раскатки:
- 1) Каркас + Header; platform classes; pre‑init Mini‑App; метрики старта
- 2) PermissionsProvider; загрузка ролей; безопасная отрисовка
- 3) Маршруты партиями; ленивые страницы
- 4) Меню/Sider; responsive; темы/токены
- 5) Отладка UI‑конфигов; i18n/a11y; UX polishing

---

Ответственный: владелец текущей ветки. Обновляйте этот документ при каждом изменении процесса; держите его единственным источником истины для запуска PROD/DEV, UI‑ребилда и проверки качества.


