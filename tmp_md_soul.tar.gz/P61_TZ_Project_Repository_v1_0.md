# P61 — ТЗ: Проектный репозитарий (Project Repository)

Версия: v1.0  
Статус: draft → ready for implementation  
Интеграции: P27/P28/P29/P30/P36/P40/P42/P45/P50/P53/P58  
RBAC: soul.admin (изменения), repo.read (чтение)  

## 1) Назначение и цели

- Обеспечить единый проектный репозитарий в БД для хранения номерных P‑ТЗ, их разметки «смыслами», тегами, связями и артефактами, с гарантией паритета между файлами в репозитории (Git) и копией в БД.
- Интегрировать репозитарий с планированием (P40), квантами (P45), уроками/рисками/изменениями (P40), а также с методологиями (каталог P40.Methodology).
- Обеспечить цикл работы LLM‑агента: на старте — анализ релевантных «смыслов» и примеров; на завершении — «работа над ошибками» и обновление структурированных сущностей в репозитарии.

## 2) Область действия

- БД (DDL): новые таблицы `project_repo_*` и индексы; расширения связности через `quant_links` (to_entity_type=repo_*).
- Hyperloop DSL (P36): новые команды `REPO.*` для upsert/получения документов, смыслов, тегов, ссылок и синхронизации локальных файлов.
- Инспекторы: `repo.enforce` (паритет файлов↔БД, покрытие связей P40/P45/P53), `repo.best_practices` (карта бенчмарков по смыслам).
- Наблюдаемость/алерты (P21/P50): метрики паритета, задержек синхронизации, покрытий связей; человекочитаемые алерты с рекомендациями.

## 3) Текущее состояние (анализ)

- PM‑сущности (факт): `projects`, `plan_tasks`, `plan_task_dependencies`, `risks`, `changes` (см. P40). В `projects.meta` используется `project_log` (см. P40 Project Log & Methodology Workflow).  
- Hyperloop DSL (реализовано): `PROJECT.CREATE|LIST`, `PLAN.TASK.ADD|DEPEND`, `PLAN.CPM.CALC`, `TASK.UPDATE`, `PROJECT.LOG.SET/GET`, `PROJECT.FILES.ENSURE` (см. P36/P58/P40‑Log).  
- Пробел: отсутствует нормализованная БД‑структура для хранения P‑ТЗ и их «смыслов»/тегов/связей, обеспечивающая паритет с файлами и интеграции с задачами/квантами/рисками/уроками.  
- Lessons Learned: обработчики/инспекторы упоминают `lessons` (автовыбор методологии), DDL в кодовой базе не зафиксирован; требуется консолидация.

## 4) Проектируемая модель данных (DDL)

```sql
-- 4.1 Документы ТЗ (номерные серии Pxx)
create table if not exists project_repo_documents (
  id uuid primary key default gen_random_uuid(),
  tz_key text not null,              -- ключ серии/документа, напр. "P61"
  title text not null,
  version text not null,             -- семвер/метка, напр. "v1_0"
  status text not null default 'active',
  path_repo text not null,           -- относительный путь файла в Git
  storage text not null default 'db',-- где хранится актуальная копия: 'db'|'file'|'hybrid'
  content_md text not null,          -- актуальная Markdown-копия
  checksum text not null,            -- sha256 контента (для паритета)
  tags jsonb not null default '[]',  -- плоские теги документа
  meta jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists ix_repo_docs_tz_key on project_repo_documents(tz_key);
create index if not exists ix_repo_docs_updated_at on project_repo_documents(updated_at desc);

-- 4.2 «Смыслы» (структурированные смысловые блоки документа ТЗ)
create table if not exists project_repo_meanings (
  id uuid primary key default gen_random_uuid(),
  document_id uuid not null references project_repo_documents(id) on delete cascade,
  slug text not null,                -- stable id в пределах документа
  title text not null,
  summary text,
  body_md text not null,
  order_idx int not null default 0,
  tags jsonb not null default '[]',  -- тонкие теги на уровне смысла
  meta jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(document_id, slug)
);
create index if not exists ix_repo_meanings_doc on project_repo_meanings(document_id);

-- 4.3 Теги/таксономия (опционально; базовые теги также inline в jsonb)
create table if not exists project_repo_tags (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text,
  created_at timestamptz not null default now()
);

-- 4.4 Связи репозитария с проектными сущностями и знаниями
-- Унифицированная модель ссылок (doc/meaning ↔ quant/task/goal/risk/change/lesson/skill/other)
create table if not exists project_repo_links (
  id uuid primary key default gen_random_uuid(),
  from_entity_type text not null,    -- 'repo_doc' | 'repo_meaning'
  from_entity_id uuid not null,      -- id из соответствующей таблицы
  to_entity_type text not null,      -- 'plan_task'|'project'|'risk'|'change'|'lesson'|'skill'|'quant'|'goal'|'example'
  to_entity_id text not null,        -- uuid/текстовый ключ (в т.ч. внешние справочники)
  relation_type text not null,       -- 'defines'|'implements'|'assesses'|'best_practice'|'related'|'derives'
  weight numeric(6,3) default 1.0,
  meta jsonb not null default '{}',
  created_at timestamptz not null default now()
);
create index if not exists ix_repo_links_from on project_repo_links(from_entity_type, from_entity_id);
create index if not exists ix_repo_links_to on project_repo_links(to_entity_type, to_entity_id);

-- 4.5 Lessons (нормализация, если таблицы отсутствуют)
-- (идемпотентно; если lessons уже есть — пропустить)
--
-- create table if not exists lessons (
--   id uuid primary key default gen_random_uuid(),
--   project_id uuid,
--   title text not null,
--   summary text,
--   methodology text,
--   tags jsonb not null default '[]',
--   meta jsonb not null default '{}',
--   created_at timestamptz not null default now(),
--   updated_at timestamptz not null default now()
-- );
```

Инварианты:

- «Актуальная копия» ТЗ хранится в `project_repo_documents.content_md` и синхронизируется с файлом `path_repo`; контроль паритета через `checksum` и инспектор.
- Каждый `plan_task` категории «Документация/ТЗ» должен иметь связь к минимум одному `repo_doc` или `repo_meaning` (coverage‑гейт инспектора).
- `quant_links` допускает `to_entity_type in ('repo_doc','repo_meaning')` (бэкэнд — алиасы/валидация; миграция — только документация/инспектор).

## 5) Hyperloop DSL (P36) — новые команды `REPO.*`

- `REPO.DOC.UPSERT tz_key="P61" title="..." version="v1_0" path_repo="Soul/P61_TZ_...md" content_md=<B64|INLINE> [tags_json=...]`
- `REPO.DOC.GET id=<uuid>|tz_key="P61" [with_meanings=true]`
- `REPO.DOC.LIST [tz_key_prefix="P"] [tag="..."] [updated_since=<ts>]`
- `REPO.MEANING.UPSERT document_id=<uuid> slug="purpose" title="Назначение" body_md=<B64|INLINE> [order_idx=1] [tags_json=...]`
- `REPO.MEANING.LIST document_id=<uuid>`
- `REPO.TAG.SET name="best_practice" description="..."`
- `REPO.LINK.ADD from_type=repo_meaning from_id=<uuid> to_type=plan_task to_id=<uuid> relation_type=defines`
- `REPO.SYNC.LOCAL path="Soul/P61_TZ_...md"` — сверка и запись в БД (`checksum`); режимы: DRY_RUN/STRICT.
- `INSPECTOR.RUN key=repo.enforce` — паритет файл↔БД, coverage связей, валидность тегов; отчёт со списком расхождений.
- `INSPECTOR.RUN key=repo.best_practices` — сопоставление «смыслов» с каталогом лучших практик (см. §7).

Требования к ответам: детерминированный JSON, UTF‑8, шаги подписи P27 присутствуют. Изменяющие операции — `soul.admin`.

## 5.1) Системные реестры в БД (STRUCTURED) и DSL `REGISTRY.*`

Требование: реестры `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` и `docs/PROJECT_STRUCTURE.md` хранятся и используются в структурированном виде в БД. Локальная копия — документальная (Markdown), источник истины — БД.

### 5.1.1 DDL (реестры)

```sql
-- Унифицированная таблица записей реестров
create table if not exists project_registry_entries (
  id uuid primary key default gen_random_uuid(),
  registry_key text not null,            -- 'system_master_docs' | 'project_structure'
  entry_key text not null,               -- стабильный ключ записи (например, 'P61' или путь раздела)
  title text not null,
  content_md text,                       -- человекочитаемая копия
  content_json jsonb,                    -- структурированный вид (основной источник)
  path_repo text,                        -- путь локального файла-источника
  checksum text,                         -- sha256 markdown/сгенерированного json
  tags jsonb not null default '[]',
  meta jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(registry_key, entry_key)
);
create index if not exists ix_registry_key on project_registry_entries(registry_key);
create index if not exists ix_registry_updated_at on project_registry_entries(updated_at desc);
```

### 5.1.2 DSL

- `REGISTRY.UPSERT registry=system_master_docs entry_key="P61" title="..." content_json=<B64|INLINE> [content_md=<B64|INLINE>] [path_repo="docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md"]`  
- `REGISTRY.GET registry=project_structure entry_key="root"`  
- `REGISTRY.LIST registry=system_master_docs [tag="..."]`  
- `REGISTRY.SYNC.LOCAL registry=project_structure path="docs/PROJECT_STRUCTURE.md" [DRY_RUN|STRICT]` — импортирует локальный Markdown, парсит в структуру (заголовки/секции/ссылки), обновляет `content_json`; хранит `content_md` как документальную копию.  
- `INSPECTOR.RUN key=registry.enforce` — проверка паритета файл↔БД, валидности структуры (обязательные поля), ссылок на P‑серии, непротиворечивости.

Инварианты:

- При наличии обеих копий (`content_md` и `content_json`) операции чтения по умолчанию возвращают `content_json` как источник истины; Markdown используется для отображения/экспорта.
- Любые изменения через DSL отражаются в БД; локальные файлы — только синхронизация через `REGISTRY.SYNC.LOCAL`.

### 5.1.3 Комплексные команды (макросы)

- `PROJECT.REPO.SYNC id=<PID> [update_registry=true]` — выполняет: `PROJECT.GET` → `REPO.DOC.LIST(tags include project:<PID>)` → upsert смыслов/линков → при `update_registry=true` запускает `REGISTRY.SYNC.LOCAL` для обоих реестров и фиксирует `PROJECT.LOG.SET` ссылку на агрегат.
- `REPO.SEARCH query="..." [tags_any=[...]] [entity_types=[repo_doc,repo_meaning,plan_task,skill]]` — комплексный поиск по БД (фуллтекст по title/summary/body_md, теги, связи).

## 6) Интеграции

- P40 Planning:
  - На старте задач LLM‑агент выполняет `PROJECT.LIST/GET` и `REPO.DOC.LIST` по релевантным тегам/сериям, подмешивает «смыслы» в контекст.
  - По завершении — `REPO.MEANING.UPSERT` обновления/правки, `REPO.LINK.ADD` к `plan_task`/`project`/`risk`, `PROJECT.LOG.SET` ссылка на артефакт.
- P45 Quants:
  - `quant_links` дополняются связями к `repo_doc|repo_meaning` (implements|assesses|best_practice).
  - Авто‑линковки при батче (batch=100) — поддерживаются скриптом ingest (см. P45 §16), инспектор coverage.
- P53 Глоссарий:
  - Ссылки `repo_meaning → glossary.*` (relation: defines|related).
  - Инспектор непротиворечивости терминов.
- P40 Methodology:
  - `repo.best_practices` использует каталог методологий для рекомендаций/линковки (см. §7).

- Реестры/индексы:
  - `REGISTRY.UPSERT/GET/LIST/SYNC.LOCAL` для `system_master_docs` и `project_structure`; инспектор `registry.enforce` в составе `INSPECTOR.RUN_ALL`.

## 7) Лучшие практики (аналоги) — карта покрытия

- ADR (Architecture Decision Records): привязка «Решение/Контекст/Последствия» к «смыслу» ТЗ (relation: best_practice|defines).  
- PMBOK/ISO 21500/21502: области знаний → теги и «смыслы» (Scope/Time/Cost/Quality/Resource/Comm/Risk/Procurement/Stakeholder).  
- PRINCE2: продукты управления (PID, Stage Plan, Exception Report) → «смыслы» «Артефакты/Логи/Контроль».  
- Scrum/Agile: DoR/DoD, Sprint Goal, Backlog refinement → «смыслы» реализации/приёмки.  
- GitOps (Repo as SOI): декларативные изменения, запрос‑намерение, аудит — как инварианты синхронизации «файл↔БД».

Результат инспектора: список рекомендаций с приоритетами; для каждого «смысла» — подобранный набор best practices и ссылки `repo_link(best_practice)`.

## 8) Наблюдаемость и алерты (P21/P50)

- Метрики:
  - `repo_sync_latency_ms_p95`, `repo_sync_error_rate`, `repo_parity_drift_total`, `repo_links_coverage_ratio`.
- Алерты (пример аннотаций):
  - `RepoParityDriftHigh` — severity=medium; риск: несоответствие БД файлам; действия: REPO.SYNC.LOCAL (DRY_RUN), проверить checksum, выполнить SYNC (strict), эскалировать при повторении.
  - `RepoCoverageLow` — severity=low; риск: неполное покрытие связей; действия: запустить `repo.enforce`, добавить связи `REPO.LINK.ADD`.
  - `RepoSyncErrorsSpike` — severity=high; риск: сбои записи в БД; действия: проверить транзакции/блокировки Postgres, уменьшить нагрузку, создать инцидент P50.

## 9) Политики/безопасность

- Все пути/URL/порты — из БД настроек (SoulSettingsService).  
- Изменяющие `REPO.*` — только `soul.admin`; логи шагов подписи обязательны.  
- Идемпотентность `UPSERT` по `(tz_key, version)` и `(document_id, slug)`.

## 10) Acceptance

1) Alembic‑миграция создаёт `project_repo_*` таблицы; индексы присутствуют.  
2) `REPO.DOC.UPSERT` сохраняет актуальную копию файла и ставит корректный `checksum`; `REPO.SYNC.LOCAL` подтверждает паритет.  
3) `REPO.MEANING.UPSERT/LIST` работают; минимум 6 «смыслов» для P61 (purpose/scope/current_state/data_model/dsl/observability).  
4) Инспектор `repo.enforce` — зелёный: паритет файлов/БД, покрытие связей с `plan_tasks`/`quant_links` по ключевым задачам.  
5) Реестры `SYSTEM_MASTER_DOCUMENTS_REGISTRY` и `PROJECT_STRUCTURE` доступны из БД через `REGISTRY.GET/LIST`; `REGISTRY.SYNC.LOCAL STRICT` подтверждает паритет.  
6) Обновлены `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` и `docs/PROJECT_STRUCTURE.md` с ссылками на P61 (локальные документальные копии).  
7) LLM‑агент при старте задач считывает релевантные «смыслы» и реестровые записи (через `REPO.DOC.LIST`/`REGISTRY.LIST`), по завершении выполняет upsert/post‑mortem.

## 11) План работ / миграции

- Миграция Alembic: `20251013_000093_project_repository_core.py` (идемпотентные CREATE IF NOT EXISTS).  
- Бэкоф/DRY‑RUN синхронизации: начать с `REPO.SYNC.LOCAL DRY_RUN`, затем применить `STRICT`.  
- Best‑effort нормализация исторических P‑ТЗ: «вытяжка» смыслов минимальным парсером (заголовки/подзаголовки), ручная верификация.

## 12) Пример смок‑контур (Windows PowerShell)

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
python .\Soul\scripts\hyperloop_cli.py --dsl "DEV.CONNECT owner=\"468326902\" branch=\"p61-project-repository\""

# 1. Upsert документа (P61)
python .\Soul\scripts\hyperloop_cli.py --dsl "REPO.DOC.UPSERT tz_key=\"P61\" title=\"Project Repository\" version=\"v1_0\" path_repo=\"Soul/P61_TZ_Project_Repository_v1_0.md\""

# 2. Добавить смысл
python .\Soul\scripts\hyperloop_cli.py --dsl "REPO.MEANING.UPSERT document_id=<DOC_ID> slug=\"purpose\" title=\"Назначение\" body_md=\"...\" order_idx=1"

# 3. Линки к задаче плана
python .\Soul\scripts\hyperloop_cli.py --dsl "REPO.LINK.ADD from_type=repo_meaning from_id=<MEANING_ID> to_type=plan_task to_id=<TASK_ID> relation_type=defines"

# 4. Паритет
python .\Soul\scripts\hyperloop_cli.py --dsl "INSPECTOR.RUN key=repo.enforce"
```

## 13) Риски и меры

- Дубли/дрейф версий — решаются checksum+инспектором, запретом перезаписи без UPSERT.  
- Отсутствие Lessons DDL — временно использовать `project_repo_links(to_entity_type='lesson')`; зафиксировать консолидацию lessons в отдельной миграции.  
- Производительность — индексы по updated_at/to/from; batch‑операции и бэкоф через Hyperloop.

## 14) Приложения

- Карта тегов: `best_practice`, `acceptance`, `observability`, `dsl`, `ddl`, `migration`, `integration:p40`, `integration:p45`, `integration:p53`.
- Минимальный обязательный набор «смыслов» для каждого P‑ТЗ: назначение, область, текущее состояние, модель данных/контракты, интеграции/DSL, наблюдаемость/acceptance.

## 15) Подсказки и поиск Hyperloop команд (LLM‑friendly)

Требование: все команды Hyperloop должны иметь интуитивные подсказки для LLM‑агентов и поддерживать поиск необходимых команд с описанием, параметрами и характеристиками (RBAC, побочные эффекты, DRY_RUN, WITH TRACE, идемпотентность, сложности кавычек и т.п.). Системный промпт Cursor должен включать команду быстрого поиска, чтобы агенты преимущественно использовали Hyperloop команды, снижая ошибки и транзакции поиска.

### 15.1 DDL каталога команд

```sql
create table if not exists hyperloop_commands_catalog (
  id uuid primary key default gen_random_uuid(),
  group_key text not null,            -- например, REPO, REGISTRY, PROJECT, PLAN, TASK, INSPECTOR, FLAGS
  command_key text not null,          -- например, REPO.DOC.UPSERT
  title text not null,
  description text not null,
  params jsonb not null default '[]', -- [{ name, type, required, default, description }]
  modifiers jsonb not null default '[]', -- ["DRY_RUN","WITH TRACE","EXPECT","TIMEOUT_MS"]
  rbac jsonb not null default '[]',   -- [{ role:"soul.admin"|"user", scope:"repo.read"|... }]
  side_effects boolean not null default false,
  idempotent boolean not null default true,
  examples jsonb not null default '[]', -- [{ shell:"powershell", dsl:"..." }]
  tags jsonb not null default '[]',
  meta jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(command_key)
);
create index if not exists ix_hl_cmd_group on hyperloop_commands_catalog(group_key);
create index if not exists ix_hl_cmd_tags on hyperloop_commands_catalog using gin(tags);
```

### 15.2 DSL `COMMANDS.*`

- `COMMANDS.SEARCH query="repo upsert" [tags_any=["REPO","UPSERT"]] [side_effects=false] [role="user"]` — полнотекстовый/теговый поиск, фильтры по побочным эффектам и RBAC.
- `COMMANDS.DETAIL key="REPO.DOC.UPSERT"` — возвращает описание, параметры, модификаторы, RBAC, примеры, отметки «опасности»/кавычек.
- `COMMANDS.HINTS topic="project_repository"` — отдаёт curated‑подсказки по сценарию (микро‑гайд с готовыми DSL‑шаблонами и рекомендуемыми модификаторами).
- `COMMANDS.CATALOG.UPSERT key="REPO.DOC.UPSERT" title="..." description="..." params_json=...` — админ‑обновление каталога (P27 шаги, RBAC: soul.admin).

Ответы — детерминированный JSON, UTF‑8; включают поле `llm_hint` — краткую фразу‑подсказку для встраивания в промпт.

### 15.3 Интеграция с системным промптом Cursor

- В системном промпте Cursor добавить инструкцию: «Для поиска и использования команд Hyperloop сначала вызывай `COMMANDS.SEARCH` (или `COMMANDS.HINTS`), затем используй найденные команды; избегай прямых догадок по синтаксису».
- Добавить быстрые примеры для REPO/REGISTRY/PROJECT/PLAN/TASK/INSPECTOR.
- Указать рубрики тонких подсказок: кавычки PowerShell, `--commands + --options-json-file`, DRY_RUN для опасных операций, обязательный заголовок `X-Telegram-User-ID`.

### 15.4 Acceptance (подсказки)

1) Заполнен каталог гиперлуп‑команд для REPO/REGISTRY/PROJECT/PLAN/TASK/INSPECTOR (минимум по 1 примеру на команду).  
2) `COMMANDS.SEARCH` на запрос «repo upsert» возвращает ключ `REPO.DOC.UPSERT` с `llm_hint` и примером PowerShell.  
3) `COMMANDS.DETAIL key="REGISTRY.SYNC.LOCAL"` содержит модификаторы DRY_RUN/STRICT и подсказку про парсинг Markdown в structured JSON.  
4) Системный промпт Cursor обновлён и содержит явную инструкцию про `COMMANDS.SEARCH|HINTS` и гиперлуп‑команды приоритетно.  
5) Инспектор `repo.enforce`/`registry.enforce` зелёные после использования подсказок: команды вызываются корректно, без избыточных проб.
