# P44R — ТЗ: Политики PDP (Rust, чистая функция) v1.0

Версия: v1.0
Статус: к внедрению (этап 3)

## 1) Назначение

Чистая функция принятия решений по авторизации на основе предоставленного контекста (без БД/секретов).

## 2) Контракты

Вход:

```json
{ "route":"/api/...","method":"GET","headers":{"X-Telegram-User-ID":"468326902"},"roles":["architect"],"permissions":["soul.admin"],"abac_ctx":{"channel":"mini","time":"2025-09-23T11:00:00Z","plan":"premium","region":"RU"},"resource":null,"function_name":null,"two_keys":null }

```
Выход:

```json
{ "decision":"allow","code":200,"reason":"ok" }

```
Deny причины: `role_mismatch|plan_not_allowed|jwt_mismatch|ownership_mismatch|two_keys_required|quota_exceeded`.

## 3) SLA

Решение ≤ 1 ms p95.

## 4) Интеграция

PEP в Python формирует контекст и вызывает RS PDP; шаги `svc.rbac.*`/`cmd.hyperloop.authz.*` фиксируются P27.

## 5) Тесты

Golden (allow/deny, ≥100), property (композиции предикатов), fuzz (заголовки/Unicode).

## 6) Безопасность

Без `unsafe`; лимиты на размеры входа; чёткие коды ошибок; нулевой PII.

## 7) Acceptance

Совпадение решений Python↔Rust на golden; p95 в бюджете; инспекторы authz зелёные.

## Dual-language правила PDP

- PEP/PDP на фасаде Python; RS выдаёт чистое решение без доступа к БД/секретам.

- Маппинг ошибок RS→фасад: `role_mismatch→403`, `plan_not_allowed→402`, `jwt_mismatch→401`, `ownership_mismatch→403`, `two_keys_required→409`, `quota_exceeded→429`.

- Гейты Жандарма: golden‑наборы allow/deny; p95 решения ≤ 1 ms; отсутствие дрейфа причин deny.

## Аудит решений (P44)

- Таблица `p44_pdp_audit`: `id`, `decided_at`, `decision`, `subject` (user_id, tg_id, roles, permissions), `scope` (path, method, function_name), `reason`, `headers` (безопасный поднабор).
- Сервис: `backend/app/services/pdp_audit_service.py` — best‑effort запись аудита.
- Точки записи: `RBACProtection.check_endpoint_access` (allow/deny) с минимальным набором заголовков.
- Админ‑эндпоинты:
  - `GET /api/admin/pdp-audit/recent?limit=50` — последние записи аудита.
  - `GET /api/admin/pdp-audit/stats` — суммарные allow/deny за 24 часа.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
