---

## Индекс взаимных ссылок (P01–P37)

- P01 MeaningExtraction — объект интроспекции (качество/стратегии извлечения).
- P03 RouterContext — параметры контекстной подачи для экспериментов.
- P13 Eval — метрики в экспериментах; P24 интегрированные тесты.
- P14 MultiProviderRouting — переключение профилей провайдеров.
- P21 Health/Monitoring — наблюдаемость метапетли.
- P27 Signature/Lineage — подпись экспериментов/шагов.
- P28 FeatureFlags — флаги стратегий/профилей.
- P33 Personification — влияние персон на поведение; Mini Chat (опционально).
- P35 Processes Unified / P36 Hyperloop DSL — orchestration/команды.

### ТЗ P02 — Метапетля мышления (Plan → Act → Reflect → Revise) + IntrospectionQuant

Дата: 2025‑09‑14
Приоритет: P02 (критично для саморазвития)
Статус: Внедрено (MVP; управляется флагами через SettingsService)

---

### 0. Executive summary

- Цель: ввести устойчивую метапетлю мышления вокруг каждого ответа: Plan → Act → Reflect → Revise, не меняя пользовательский «голос» и JSON‑контракт вывода.
- Новое: тип `IntrospectionQuant` (служебный квант‑рефлексия), mini‑LLM‑оценка качества (clarity/consistency/actionability/ethics), confidence, improvement_plan, политика revise.
- Интеграция: после рождения основного кванта (Act) — короткая рефлексия (Reflect) → запись `IntrospectionQuant` → при низких метриках — фоновая регенерация кандидата/уточнение (Revise) за флагом.
- Без миграций: `IntrospectionQuant` сохраняется как обычный квант с `tags+=['introspection']` и мягкой связью на `for_quant_id` через `quant_connections(type='introspects')` либо через мета‑поле.

---

### 1. Актуальная реализация (аудит)

- Пайплайн ядра: `backend/app/services/soul_core_manager.py: generate_quant_enhanced` (KeywordAnalysis → ContextEnrichment → SoulCore → AttributeEnrichment).
- Контекст/30‑70: `backend/app/services/soul_context.py` — выборка recent/ranked.
- Настройки: `backend/app/services/soul_settings_service.py` — есть базовые флаги, добавим `meta.*`.
- LLMManager: профили для быстрых моделей доступны (используем для mini‑LLM).
- Аудит: события `soul_*` уже пишутся (добавим `soul_meta_*`).

---

### 2. Архитектура и точки интеграции

- Этапы петли:

  1) Plan — сформировать краткий служебный план ответа (скрытый `_debug`, не попадает к пользователю).
  2) Act — родить основной квант (как сейчас), выполнить строгую валидацию.
  3) Reflect — mini‑LLM оценивает ответ и порождает `IntrospectionQuant`.
  4) Revise — при низких метриках: фоновая регенерация варианта или постановка `desired_action=clarify` (persistent), без изменения уже отданного ответа.

- Инъекция в код:
- `soul_core_manager.py` — после успешной генерации основного кванта вызвать `MetaLoopService.reflect_and_maybe_revise(...)`.
  - `docs/SOUL_PIPELINE.md` — отразить шаг «4c. Meta‑Loop (Reflect/Revise)».
  - `SOUL_PROMPT_BUILDING.md` — не добавлять ничего в пользовательский промпт; план хранить в `_debug`/аудите.

---

### 3. Контракты (Pydantic)

```python
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

class IntrospectionEval(BaseModel):
    clarity: float = Field(ge=0.0, le=1.0)
    consistency: float = Field(ge=0.0, le=1.0)
    actionability: float = Field(ge=0.0, le=1.0)
    ethics: float = Field(ge=0.0, le=1.0)

class IntrospectionQuant(BaseModel):
    for_quant_id: str
    eval: IntrospectionEval
    confidence: float
    improvement_plan: str
    tags: List[str] = []

class MetaPlan(BaseModel):
    outline: str  # краткий план ответа (1-3 пункта), скрытный
    risks: List[str] = []

```

События аудита: `soul_meta_plan`, `soul_meta_reflect`, `soul_meta_revise`.

---

### 4. Алгоритм (подробно)

1) Plan (скрыто):

   - На вход: `input_text`, ключевые признаки контекста, вывод роутера.
   - Сформировать `MetaPlan.outline` («Как отвечу: 1) …; 2) …; 3) …») без CoT и подробностей.
   - Записать в аудит `soul_meta_plan {outline}`.

2) Act:

   - Сгенерировать основной квант (как сейчас), убедиться в STRICT JSON, нормализовать.

3) Reflect:

   - Mini‑LLM (быстрый профиль через `LLMManager.get_model_for_function('meta_reflect')`) получает краткий контекст: выжимку вопроса, `thought_form`, ключевые теги, краткие метки модулей (без раскрытия системных имён).
   - Модель возвращает JSON: `eval.clarity|consistency|actionability|ethics`, `confidence`, `improvement_plan` (≤ 300 символов), `tags`.
   - Создать `IntrospectionQuant` и сохранить как обычный квант с `tags+=['introspection']`; добавить мягкую связь `quant_connections(type='introspects', from=introspect, to=for_quant)` либо хранить `for_quant_id` в служебном поле.
   - Аудит `soul_meta_reflect {scores, confidence}`.

4) Revise (за флагом):

   - Порог: если `eval.clarity < T_clarity` или `eval.consistency < T_consistency` или `confidence < T_confidence` → запланировать ревизию.
   - В persistent:
     - вариант A: создать задачу фоновой регенерации альтернативного кандидата (без автоподмены ответа; результат анализируется в Sleep/Optimize);
     - вариант B: добавить `desired_action=clarify` (через безопасный ActionRouter) с мягкой подсказкой к пользователю.
   - В stateless: только сигнал в метрики.
   - Аудит `soul_meta_revise {reason, action}`.

Примечание: связь с P06 (Self‑Consistency) — использовать её `confidence` как дополнительный сигнал при пороге Revise (см. настройки ниже).

---

### 5. Интеграция в код

- `backend/app/services/meta_loop_service.py` (новый):
  - `plan(input_text, context) -> MetaPlan`
  - `reflect(draft_quant, context) -> IntrospectionQuant`
  - `maybe_revise(introspection, mode, self_consistency_confidence?) -> Optional[ReviseAction]`
- `soul_core_manager.py`: точка вызова после сохранения основного кванта.
- `soul_settings_service.py`: секция `meta.*`.

---

### 6. Настройки/флаги (SoulSettingsService)

- `meta.enabled=false`
- `meta.model_profile="meta_reflect_fast"`
- `meta.thresholds = { clarity:0.6, consistency:0.6, confidence:0.5 }`
- `meta.auto_revise=false`  # выполнять Revise‑действия автоматически
- `meta.revise_policy = "clarify_only|regen_only|both"`
- `meta.max_tokens=256`
- `meta.timeout_ms=1200`

ENV (опц.): `SOUL_META_ENABLED`, `SOUL_META_THRESHOLDS`, `SOUL_META_MODEL`.

---

### 7. Наблюдаемость и метрики

- Аудит: `soul_meta_plan`, `soul_meta_reflect`, `soul_meta_revise`.
- Метрики:
  - `meta.reflect.p95_ms`, `meta.reflect.error_rate`
  - `meta.eval.clarity_mean`, `meta.eval.consistency_mean`, `meta.eval.actionability_mean`, `meta.eval.ethics_mean`
  - `meta.confidence_hist`
  - `meta.revise.rate` (доля случаев ниже порога)

---

### 8. Acceptance

- При `meta.enabled=false` поведение неизменно, JSON‑контракт ответов не меняется.
- При включении: создаётся `IntrospectionQuant` на каждый ответ; пишутся события `soul_meta_*`.
- На golden‑наборе: рост средней `clarity`/`consistency` ≥ +3–5% за счёт сигналов Revise (в ручном режиме подтверждения), без падения JSON‑валидности.
- Латентность шага Reflect p95 ≤ 1.2–1.5 с.

---

### 9. Траблшутинг

- Высокая латентность: снизить `meta.max_tokens`, упростить контекст для mini‑LLM, выбрать более быстрый профиль.
- Чрезмерный шум Revise: поднять пороги, использовать совместный порог с Self‑Consistency (`min(meta.confidence, sc.confidence)`).
- Утечка служебного плана: убедиться, что `MetaPlan` не попадает в пользовательский вывод/память, только в аудит/trace.

---

### 10. Безопасность/приватность

- ПИИ‑санитайзер: отражаемые тексты проходят через `privacy_sanitizer` перед аудитом/сохранением.
- Guard: метапетля не меняет «голос» и не исполняет действий напрямую; любые действия — только через безопасный ActionRouter.
- NEGATIVE‑гейт: усилить при признаках role‑switch в Reflect‑контексте.

---

### 11. Связи с другими модулями

- P01 MeaningExtraction — улучшает входные смыслы, косвенно повышая clarity.
- P03 RouterContext — лучшее заполнение `flow_context_summary` улучшает оценку Reflect.
- P06 Self‑Consistency — `confidence` может влиять на политику Revise.
- P07 DesiredAction — формализованный `clarify`/`research` как действия Revise.

---

### 12. Ссылки на исходники/документы

- Ядро: `backend/app/services/soul_core_manager.py`
- Контекст: `backend/app/services/soul_context.py`
- Настройки: `backend/app/services/soul_settings_service.py`
- Безопасность/приватность: `Soul/P09_TZ_Soul_Security_v1_0.md`, `Soul/P08_TZ_Soul_Privacy_v1_0.md`
- Self‑Consistency: `Soul/P06_TZ_Soul_SelfConsistency_v1_0.md`

---

### 13. Отметка принятия (2025-09-20)

- Интеграция MetaLoop в `soul_core_manager.py` активна: `plan(...)` и `reflect_and_maybe_revise(...)` вызываются после рождения основного кванта; события `soul_meta_plan` и `soul_meta_reflect` пишутся.
- Инспектор `INSPECTOR.RUN_ALL` — зелёный; обязательные шаги P27 при Hyperloop RUN WITH TRACE присутствуют за 24h.
- Поведение без `meta.enabled=true` неизменно; JSON‑контракт не нарушен.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
