# M03 — Scrum Disciplined (v1.0)

Цель: итеративная поставка с сильной дисциплиной спринтов и Definition of Done.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Sprint Planning → Daily → Review → Retro; Backlog Refinement по расписанию.

Алгоритмы/метрики: Velocity, CFD, Lead/Cycle Time, p95 e2e.

Роли: PO, SM, Dev Team, QA.

DSL: PLAN.TASK.ADD, PLAN.TASK.DEPEND, METHODOLOGY.SET, QUANT.LINK.AUTO, INSPECTOR.RUN_ALL.

Acceptance: флаги в БД; инспекторы зелёные; панели Scrum/CFD.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
