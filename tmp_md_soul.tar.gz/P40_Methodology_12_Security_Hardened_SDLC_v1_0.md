# M12 — Security-Hardened SDLC (v1.0)

Цель: безопасная разработка с ранним выявлением уязвимостей и контролем поставки.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Threat Modeling → Secure Design → SAST/DAST → Supply Chain → Hardening → Monitoring.

Алгоритмы/метрики: CVE exposure, MTTR vulns, p95, err_rate.

Роли: Security Lead, Dev Lead, QA, SRE.

DSL: SECURITY.SCAN, SBOM.GENERATE, METHODOLOGY.SET, INSPECTOR.RUN_ALL.

Acceptance: политика/сканы в БД; алерты; панели Security.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
