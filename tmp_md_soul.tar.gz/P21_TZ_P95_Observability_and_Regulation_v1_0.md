<!-- markdownlint-disable MD022 MD032 MD012 MD031 MD040 MD047 MD041 -->

# P21 — ТЗ: P95 Observability & Regulation (v1.0)

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — актуальные инвентари.
- `tmp_p_series_plan.json` — план P‑серии.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр.
- `Soul/P30_TZ_Soul_Processor_v2_0.md`, `Soul/P36_TZ_Hyperloop_DSL_v1_1.md`, `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md` — интеграции процессора/DSL/подписи.

Версия: 1.0 (2025‑10‑06)
Статус: draft → ready for implementation
Ответственные: Архитектор / Процессор (P30) / Жандарм (P50) / SRE

---

## 1. Назначение и цели

- Выровнять p95‑контур наблюдаемости и реакции по всем слоям:
  - Источник истины p95 — Prometheus гистограмма `processor_e2e_ms_bucket`.
  - Единая формула PromQL на p95 для: правил Prometheus, панелей Grafana, Регулятора (Python) и RS‑ядра (Rust).
  - Единый путь доступа к Prometheus API из БД (`metrics.prometheus_path`) без хардкодов.
- Обеспечить предсказуемую и объяснимую автоматику: AIMD‑реакции на превышение бюджетов p95 per‑kind, burn‑rate алерты, визуализация per‑kind в Grafana, инцидентирование с рекомендациями.
- Минимизировать шум/флаппинг: кэш PromQL, гистерезис/cooldown в Регуляторе, recording rules для тяжёлых запросов.

Критерий успеха (высокий уровень): при наличии трафика значения p95 per‑kind совпадают между PromQL/правилом/панелью/регулятором в допуске ±2%, а реакции RS/Регулятора согласованы и логируются.

---

## 2. Область (Scope)

- Prometheus (локальный APP1 `127.0.0.1:9090`): конфиги/правила/перезапуск через systemd.
- Nginx: внешний путь `/api/metrics/prometheus` остаётся экспортёром бэкенда (не API Prometheus).
- Backend (Python):
  - Регулятор `backend/app/services/emergency_regulator.py` — чтение p95 per‑kind из Prometheus по DB‑ключу; добавление гистерезиса/охраны.
  - Фасад «PromQL‑кэш» (новый модуль) — централизованные вызовы PromQL с TTL.
  - Админ‑роуты настроек уже есть (`/api/admin/soul/settings/*`).
- RS ядро (Rust): `rs/processor_core/src/main.rs` — чтение `metrics.prometheus_path`, p95 per‑kind, AIMD‑реакции.
- Grafana: `ops/grafana/rs_age_dashboard.json` — панели per‑kind p95/err_rate/queue и переменная `kind`.
- Alerting: Prometheus rules + Alertmanager формат сообщений (единый шаблон).
- Документы: обновление регистров/рукбуков, ссылка в `docs/PROJECT_STRUCTURE_v8_0_4.md`.

Вне области: перенос Prometheus/Alertmanager на иные хосты, смена модели хранения метрик.

---

## 3. Источники и ссылки

- Внутренние файлы:
  - Правила: `ops/prometheus/rules_processor.yml`, `ops/prometheus/rules_processor_autoscale.yml`.
  - Панели: `ops/grafana/rs_age_dashboard.json`.
  - RS ядро: `rs/processor_core/src/main.rs`.
  - Регулятор: `backend/app/services/emergency_regulator.py`.
  - Экспортёр метрик: `GET /api/metrics/prometheus` (бэкенд; не Prometheus API).
  - Админ‑настройки: `backend/app/routers/soul_settings_admin.py`.
  - Документ структуры: `docs/PROJECT_STRUCTURE_v8_0_4.md`.
- Ключи БД (через `SoulSettingsService`):
  - `metrics.prometheus_path` — базовый URL Prometheus API (строка, без хвостового `/`).
  - `processor.kind_limits.<kind>.{p95_budget_ms,err_rate_max,rps,max_concurrency,timeout_ms}`.
  - Регулятор: `emergency.mode.enabled`, `emergency.queue_drain.*`.
- Внешние источники:
  - Prometheus Query API — [официальная документация](https://prometheus.io/docs/prometheus/latest/querying/api/).
  - PromQL `histogram_quantile` — [справка функции](https://prometheus.io/docs/prometheus/latest/querying/functions/#histogram_quantile).
  - Grafana — [панели/запросы](https://grafana.com/docs/grafana/latest/panels-visualizations/).
  - Alertmanager — [конфигурация](https://prometheus.io/docs/alerting/latest/configuration/).
  - systemd timers — [мануал](https://www.freedesktop.org/software/systemd/man/latest/systemd.timer.html).

---

## 4. Требования (функциональные)

4.1. Единая формула p95

- Пер‑kind p95: `histogram_quantile(0.95, sum(rate(processor_e2e_ms_bucket[5m])) by (le,kind))`.
- Агрегат p95 (все виды): `histogram_quantile(0.95, sum(rate(processor_e2e_ms_bucket[5m])) by (le))`.

4.2. Единый доступ к Prometheus API

- Все сервисы и утилиты получают базовый URL из БД `metrics.prometheus_path`.
- Запрещены хардкоды `http(s)://`/порты в исходниках (кроме документации/примеров под whitelist).

4.3. Recording rules

- В правилах Prometheus должны быть записи:
  - `processor:p95_e2e_ms` — пер‑kind p95 (см. формулу).
  - `processor:p95_e2e_ms_all` — агрегат p95.
- Интервалы и агрегаторы согласованы с панелями/регулятором.

4.4. Backend «PromQL‑кэш»

- Новый модуль: централизованный клиент PromQL (httpx/async), TTL 5–15 c, пула соединений, backoff на ошибки.
- Предоставляет методы:
  - `get_p95_by_kind(window='5m') -> Dict[str,float]`;
  - `get_p95_all(window='5m') -> float | None`.
- Источник URL — `metrics.prometheus_path` из БД; fallback таймаут конфигурируем через БД (`prometheus.http_timeout_ms`).

4.5. Регулятор: гистерезис/anti‑noise/cooldown

- Настройки в БД:
  - `regulator.cooldown_sec` (int, по умолчанию 60);
  - `regulator.min_breach_windows` (int, по умолчанию 2);
  - `regulator.smoothing_alpha` (float 0..1, по умолчанию 0.3).
- Поведение: изменения лимитов не чаще 1 раза в `cooldown_sec`; превышение считается «устойчивым», если `min_breach_windows` последовательных окон нарушены; p95 сглаживается EMA (`alpha`).

4.6. RS ядро: AIMD 2.0 (динамический шаг)

- Снижение `rps/max_concurrency` пропорционально величине/длительности превышения (bounded), повышение — медленнее.
- Настройки в БД: `aimd.alpha_up`, `aimd.alpha_down`, `aimd.prediction_weight`, граничные `aimd.min_rps`, `aimd.min_max_concurrency`.

4.7. Grafana панели

- Переменная `kind` (multi, includeAll) над `label_values(processor_e2e_ms_bucket, kind)`.
- Новые панели:
  - p95 per‑kind (формула из 4.1);
  - error_rate per‑kind (`skipped/(processed+skipped)` за окно);
  - queue per‑kind и total (`processor_queue_len_total` и по видам, если есть);
  - корреляция queue vs p95.
- Аннотации инцидентов (Prometheus alert annotations) на графах p95/очереди.

4.8. Алерты (SRE burn‑rate/диагностика)

- Дополнить группу правил:
  - Burn‑rate p95 (5m/1h) по `processor:p95_e2e_ms_all`;
  - Per‑kind error_rate (существует, усилить аннотации/действия);
  - Flapping/cooldown (диагностика частых изменений лимитов) — экспорт счётчиков из Регулятора.
- Сообщения Alertmanager единообразные, человекочитаемые (severity/risk/шаги действий).

4.9. История лимитов/наблюдений (аудит)

- Новая таблица (или расширение существующей): `processor_limit_changes` (ts, kind, p95_ms, budget_ms, rps, max_concurrency, action, reason, actor{regulator|rs_core}, user?).
- Админ‑панель/эндпоинт для выгрузки истории.

4.10. Canary авто‑эскалация

- Политика: при стабильном SLA (p95≤budget, err_rate≤thr, backpressure=0) ≥10–15 мин — повышать `rs.hyperloop.canary_share` ступенями 0.05→0.10→0.20 (границы/шаги из БД), с гистерезисом.

---

## 5. Требования (нефункциональные)

- Производительность: p95 запросов PromQL не должен создавать заметного RPS к Prometheus — за счёт кэша и recording rules.
- Надёжность: при недоступности Prometheus — best‑effort поведение (сигнал N/A), отсутствие падений Регулятора/RS.
- Безопасность: адреса/порты/токены — только из БД/SecretsService; запрет хардкодов.
- Наблюдаемость: метрики самого кэша (hits/misses/latency), счётчики изменений лимитов, статистика cooldown.

---

## 6. Дизайн/Архитектура

- Источник p95: Prometheus API (`/api/v1/query`), базовый URL в БД `metrics.prometheus_path`.
- Запросы p95 идут через Backend «PromQL‑кэш» (TTL), откуда читают Регулятор и RS‑ядро (для RS — опционально поверх прямого чтения).
- Prometheus Recording Rules материализуют p95 (пер‑kind и all) для панелей и алертов.
- Регулятор/RS‑ядро используют согласованные p95 и бюджеты per‑kind из БД; решения логируются.

---

## 7. Пошаговая реализация (низкоуровнево, минимизация ошибок)

7.1. Префлайт (SSH/health)
1) PowerShell (Windows):

   - `curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/health`

2) SSH на APP1:

   - `ssh -i .\Arh\spbd_ed25519 -o StrictHostKeyChecking=accept-new root@217.12.38.238 'curl -s http://127.0.0.1:9090/-/ready; echo; systemctl is-active prometheus || true'`

7.2. Установить `metrics.prometheus_path` в БД (если отличается)

- `curl.exe -s -S -X POST -H "X-Telegram-User-ID: 468326902" "https://mini.soulpulse.art/api/admin/soul/settings/set_kv?key=metrics.prometheus_path&value=http://127.0.0.1:9090"`

7.3. Recording rules (Prometheus)
1) Проверить активные файлы на APP1:

   - `ssh ... 'grep -n "processor:p95_e2e_ms" /etc/prometheus/rules/*.yml || true'`

2) При необходимости обновить `rules_processor.yml`/`rules_processor_autoscale.yml` (в репо `ops/prometheus/*.yml`) и деплойнуть на сервер.
3) Перезапуск Prometheus:

   - `ssh ... 'systemctl restart prometheus; sleep 2; systemctl status prometheus --no-pager -n 30'`

7.4. Backend «PromQL‑кэш»
1) Добавить модуль, например: `backend/app/services/promql_cache.py`:

   - Async httpx клиент (пул), методы `get_p95_by_kind`/`get_p95_all`, TTL кэша, метрики hits/misses.
   - Чтение `metrics.prometheus_path` и `prometheus.http_timeout_ms` из БД (`SoulSettingsService`).

2) Внедрить в `emergency_regulator.py` использование фасада вместо прямого запроса.
3) Экспортировать технические метрики кэша в `/api/metrics/prometheus`.

7.5. Регулятор: гистерезис/cooldown/EMA
1) Ключи БД: создать/задать значения (`regulator.cooldown_sec`, `regulator.min_breach_windows`, `regulator.smoothing_alpha`).
2) В `emergency_regulator.py`:

   - Добавить сохранение времени последнего изменения лимитов; блокировать изменения, если прошло < cooldown.
   - Для каждого kind вести счётчик последовательных «breach» окон, применять изменение при достижении порога.
   - Сглаживать p95 EMA перед сравнением с бюджетом.

3) Логировать действия и причины (вставка в `processor_incidents`/новую таблицу истории).

7.6. RS ядро: AIMD 2.0
1) В `rs/processor_core/src/main.rs`:

   - В блоке `adaptive_tick` скорректировать снижение/повышение `rps/max_concurrency` по динамическому правилу, параметризованному из БД.
   - Добавить метрики: `regulator_limit_changes_total{action,kind}`, `regulator_cooldown_blocks_total`.

2) Подключить чтение новых настроек (`aimd.*`).

7.7. Grafana
1) В `ops/grafana/rs_age_dashboard.json` добавить панели:

   - p95 per‑kind, error_rate per‑kind, queue per‑kind/total, корреляция queue vs p95.

2) Убедиться, что переменная `kind` читает актуальные label_values.
3) Включить аннотации инцидентов (по alert‑labels `kind`).

7.8. Алерты (Prometheus/Alertmanager)
1) Добавить burn‑rate p95 алерты (5m/1h) и диагностические алерты флаппинга.
2) Проверить маршрут Alertmanager и шаблоны (единый формат).

7.9. История лимитов/наблюдений
1) Создать таблицу `processor_limit_changes` (DDL в alembic ревизии) — atomically.
2) Внедрить запись событий из Регулятора и RS ядра.
3) Админ‑эндпоинт выгрузки (RBAC `soul.admin`).

7.10. Canary авто‑эскалация
1) Добавить ключи: `rs.canary.share_steps=[0.05,0.10,0.20]`, `rs.canary.escalation_window_sec`, `rs.canary.hysteresis_sec`.
2) Реализация шагов с проверкой SLA метрик (p95/err_rate/backpressure) и логированием решения.

7.11. Документация
1) Обновить `docs/PROJECT_STRUCTURE_v8_0_4.md` (ссылки и раздел уже добавлены — расширить при необходимости).
2) Внести запись в `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` о настоящем ТЗ.

---

## 8. Acceptance‑критерии

- Промежуточные:
  - `metrics.prometheus_path` задан и читается из всех потребителей.
  - Recording rules активны, `processor:p95_e2e_ms(_all)` доступны.
  - Кэш PromQL показывает метрики hits/misses; ошибки не приводят к падению Регулятора/RS.
- Итоговые (при наличии трафика):
  - p95 per‑kind из PromQL = p95 из recording rule = значения панели Grafana = значения Регулятора/RS (±2%).
  - Регулятор/RS снижают `rps/max_concurrency` при устойчивом превышении, с cooldown и логами.
  - Алерты burn‑rate доставляются, формат сообщений соответствует шаблону.
  - Панели Grafana показывают per‑kind p95/err/queue, аннотации инцидентов присутствуют.
  - История лимитов доступна через админ‑API.

---

## 9. Риски и смягчение

- Перегруз Prometheus — использовать кэш и recording rules.
- Флаппинг лимитов — cooldown/EMA/минимальная длительность.
- Кардинальность label `kind` — нормализация, опциональная группировка.
- Отсутствие трафика — acceptance откладывается до генерации сэмплов.

---

## 10. Эксплуатация и низкоуровневые операции (OS level)

- systemd:
  - Перезапуск Prometheus: `systemctl restart prometheus`; проверка: `systemctl status prometheus`.
  - Просмотр логов: `journalctl -u prometheus -n 200 --no-pager`.
  - Таймеры (будущие): `soul-auto-drain.service|.timer`, `soul-report.service|.timer` — создать юниты в `/etc/systemd/system/`, `systemctl daemon-reload && systemctl enable --now <timer>`.
- Nginx:
  - Проверка конфигурации: `nginx -t && systemctl reload nginx`.
  - Убедиться, что `/api/metrics/prometheus` проксирует на backend (это не API Prometheus).
- Prometheus API локально:
  - `curl -G 'http://127.0.0.1:9090/api/v1/query' --data-urlencode "query=histogram_quantile(0.95, sum(rate(processor_e2e_ms_bucket[5m])) by (le,kind))"`.

---

## 11. План работ и ориентиры (дорожная карта)

Этап 1 (Quick wins, 1–2 недели):

- Ввести «PromQL‑кэш», проверить `metrics.prometheus_path`, дописать recording rules, включить cooldown/EMA в Регуляторе, добавить панели Grafana per‑kind и burn‑rate алерты.

Этап 2 (2–6 недель):

- AIMD 2.0 в RS, история лимитов/наблюдений, Canary авто‑эскалация, аннотации инцидентов, нормализация label‑пространства.

Этап 3 (6+ недель):

- Профили SLO per‑kind, exemplars/trace, агрегации видов, HA/Federation Prometheus.

---

## 12. Изменения в кодовой базе (target locations)

- Prometheus rules: `ops/prometheus/*.yml` → PROD `/etc/prometheus/rules/*.yml`.
- Backend cache: `backend/app/services/promql_cache.py` (новый), интеграция в `emergency_regulator.py`.
- RS ядро: `rs/processor_core/src/main.rs` (AIMD 2.0, метрики, чтение настроек).
- Grafana: `ops/grafana/rs_age_dashboard.json` (панели и переменные).
- Admin API: `backend/app/routers/soul_settings_admin.py` (безопасные операции настроек).
- Документы: `docs/PROJECT_STRUCTURE_v8_0_4.md`, `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` (запись о данном ТЗ).

---

## 13. Политики/Инварианты (из Soul/Cursor правил)

- Все адреса/порты/секреты — из БД (`SoulSettingsService`/`SecretsService`).
- Без фоновых локальных лупов на рабочей станции; долгие процессы — только на APP серверах под systemd.
- Наблюдаемость: метрики p95/error_rate/очередей, счётчики изменений, алерты с понятными рекомендациями.
- PR-допуск: инспектор не должен находить запрещённые хардкоды URL/портов вне whitelist’ов.

---

## 14. Приложение: пример Alertmanager шаблона (единый формат)

```text
{{ .CommonLabels.alertname }} ({{ .Status | toUpper }})
Severity: {{ .CommonLabels.severity }}
{{- range .Alerts }}- {{ .Annotations.summary }}{{ if .Annotations.description }} — {{ .Annotations.description }}{{ end }}
{{- end }}

```

---

## 15. Приложение: контрольный лист перед приёмкой

- [ ] `metrics.prometheus_path` установлен и читается.
- [ ] Recording rules активны, вижу `processor:p95_e2e_ms(_all)`.
- [ ] Кэш PromQL отдаёт p95 per‑kind, метрики hits/misses отображаются.
- [ ] Регулятор применяет cooldown/EMA, изменения лимитов логируются.
- [ ] RS ядро снижает/повышает лимиты по AIMD 2.0.
- [ ] Панели Grafana: p95/err/queue per‑kind + аннотации инцидентов.
- [ ] Burn‑rate алерты доставляются; формат соответствует шаблону.
- [ ] История лимитов доступна через админ‑API.
- [ ] Сверка p95 между PromQL/recording/панелью/регулятором в допуске ±2%.

Ссылки (интеграции и реестры):

- docs/PROJECT_STRUCTURE_v8_2_0.md — интеграции наблюдаемости p95, RS/Регулятор
- docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md — записи о ТЗ и правилах
- Soul/Report_Soul_AI_Scientific.md — сводка нормализации/регресса
- Soul/P30_TZ_Soul_Processor_v2_0.md — источники метрик/лимитов per‑kind
- Soul/P36_TZ_Hyperloop_DSL_v1_1.md — запуск инспекторов/смоков


## Мировые аналоги и практики
- Prometheus — Query API/Histogram Quantiles: `histogram_quantile` и recording rules (`https://prometheus.io/docs/prometheus/latest/querying/functions/#histogram_quantile`)
- Grafana — панели и аннотации алертов: `https://grafana.com/docs/grafana/latest/`
- SRE Burn‑rate алерты (Google SRE): `https://sre.google/sre-book/alerting-on-slos/`
- AIMD регулирование нагрузки: [Additive‑Increase/Multiplicative‑Decrease](https://en.wikipedia.org/wiki/Additive_increase/multiplicative_decrease)
- Exponential backoff with jitter (AWS): `https://aws.amazon.com/blogs/architecture/exponential-backoff-and-jitter/`
- Systemd timers/units для фоновых задач: `https://www.freedesktop.org/software/systemd/man/latest/systemd.timer.html`
