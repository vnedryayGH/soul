---

## Индекс взаимных ссылок (P01–P37)

- P01 MeaningExtraction — этот документ.
- P02 MetaLoop — связанное (интроспекция над извлечением смыслов).
- P03 RouterContext — контекстные правила (30/70) для подачи истории в смыслы.
- P04 Hypothesis A/B — эксперименты над стратегиями извлечения.
- P05 Och — методология формализации.
- P06 SelfConsistency — верификация гипотез извлечения.
- P07 DesiredAction — мэппинг смыслов в действия.
- P08 Privacy — требования приватности/ретеншн.
- P09 Security — безопасная обработка текста.
- P10 SchemaGuard — валидация STRICT JSON схем.
- P11 Provenance — происхождение данных/подпись шагов.
- P12 TraceViewer — просмотр трасс извлечения.
- P13 Eval — метрики качества извлечения.
- P14 MultiProviderRouting — политика провайдеров LLM.
- P15 Multilingual — многоязычность смыслов.
- P16 MemoryCompaction — компактификация памяти смыслов.
- P17 Reminders Search — поиск дат/событий из смыслов.
- P18 Voice ASR — голосовой ввод.
- P19 Voice TTS — голосовой вывод.
- P20 TelegramBots Platform — интеграция каналов.
- P21 Health/Monitoring — мониторинг пайплайна.
- P22 API Alignment — согласование API.
- P23 UI Spec — UI отображение смыслов.
- P24 Integrated Tests — интеграционные тесты.
- P25 Skills Routes — маршруты навыков на основе смыслов.
- P26 Calendar Transport — календарные события.
- P27 Signature/Lineage — подпись шагов пайплайна.
- P28 FeatureFlags — фичефлаги стратегий.
- P29 Quality Registry — регистр качества.
- P30 Processor — события и исполнение действий.
- P31 Multisensory Quants — связь со смыслами.
- P32 RBAC/Subscriptions — права доступа.
- P33 Personification — персонализация контекста.
- P34 External Chat Proxy/Mobile — каналы доставки.
- P35 Processes Unified — процессные цепочки.
- P36 Hyperloop DSL — команды ядра.
- P37 Prompts Technical — §svc, каталоги персон.

### ТЗ P01 — MeaningExtraction: «Ключевые слова → Смыслы → Квант»

Дата: 2025‑09‑14
Приоритет: P01 (критично для качества ядра)
Статус: Внедрено (MVP)

---

### 0. Цель и рамки

- Объединить текущие шаги анализа в единый сервис MeaningExtractionService и встроить в `SoulCoreManager.generate_quant(...)` перед сборкой промпта.
- На вход: `input_text`, выдержки истории/контекста (30/70). На выход: кандидаты квантов (0..N) строгой схемы. В stateless `desired_action=[]`.
- Ввести «двойной фильтр» для отсечения бытового шума.

Безопасность/инварианты:

- Строгий JSON: кандидаты приводятся к строгой схеме перед передачей в промпт.
- Stateless: принудительно `desired_action=[]` в кандидате.
- PII‑санитизация: входы/сниппеты очищаются перед логированием/LLM.

---

### 1. Файлы/компоненты

- Новый: `backend/app/services/meaning_extraction_service.py`
- Обновить: `backend/app/services/soul_core_manager.py` (вызов перед сборкой промпта; fallback на уточнение при 0 кандидатов)
- Задействовать: `soul_context.py` (30/70), `soul_quant_schema.py` (STRICT JSON), строгий парсинг в `soul_core_manager.py`

---

### 2. Контракты (Pydantic)

```python
class Keyword(BaseModel):
    token: str
    kind: Literal["entity","topic","temporal","action","affect","goal_hint"]

class Meaning(BaseModel):
    title: str
    gist: str
    reason: str
    tags: List[str] = []
    evidence: List[str] = []
    confidence: float
    emotion_hint: Optional[str] = None
    value_type: Literal["core","growth","noise"]
    recommended_action: Optional[str] = None

class QuantCandidate(BaseModel):
    thought_form: str
    composite_emotion: Dict[str, Any]
    desired_action: List[Dict[str, Any]]
    energy_weight: float
    tags: List[str]

```

---

### 3. Алгоритм

1) `extract_keywords(input_text, history_snippets) -> ≤15 Keyword`

   - простая NER/ключевые фразы (быстрый LLM/эвристики), нормализация языком `LanguageService` (если включен)

2) `plan_meanings(keywords, context) -> ≤3 Meaning`

   - малый LLM (быстрый) формирует «смыслы» с полями; отбрасывает «noise»

3) `to_quant_candidates(meanings, mode) -> List[QuantCandidate]`

   - формирование STRICT‑подобных кандидатов; в stateless `desired_action=[]`

Сигналы качества (логировать):

- coverage (охват ключевых смыслов исходного `input_text`),
- novelty (новизна тегов относительно текущей темы),
- ambiguity (эвристика неоднозначности для последующей `clarify`).

Двойной фильтр:

- Meaning рождается если `score(confidence) ≥ 0.6` и `value_type ∈ {core,growth}`
- Квант рождается если `len(gist) ≥ 20` и ( `len(tags)>0` или `confidence ≥ 0.65`) и `energy_weight ≥ 0.2`

---

### 4. Встройка в пайплайн

- В `generate_quant(...)` до сборки промпта:
  - вызвать MeaningExtraction; если кандидаты есть → выбрать 1–3 лучших (по confidence/coverage) и подать в промпт как ориентиры
  - если 0 → мягкий fallback: квант‑уточнение («уточните цель/условия»)

---

### 5. Настройки/флаги

- `meaning.enabled=true`
- `meaning.max_keywords=15`
- `meaning.max_meanings=3`
- `meaning.confidence_threshold=0.6`
- `meaning.quant_energy_min=0.2`

---

### 6. Метрики/аудит

- `meaning_keywords_extracted` {n}
- `meaning_meanings_planned` {n}
- `meaning_quant_candidates` {n}
- p95 по этапам; доля 0‑кандидатов

Аудит:

- `meaning_keywords_extracted` {n}
- `meaning_meanings_planned` {n}
- `meaning_candidates_born` {n, passed_filters}

---

### 7. Acceptance

- На бытовых фразах кандидатов 0; на ценных — ≤3 смысла, ≥1 валидный квант.
- В stateless `desired_action=[]`.

---

### 8. Отметка принятия (2025-09-20)

- Проверки PROD: batch/stateless и single выполнены успешно; в stateless ответы возвращаются с `desired_action=[]` (валидный массив объектов).
- Hyperloop RUN WITH TRACE зафиксировал обязательные шаги P27: `svc.soul.preanalysis`, `svc.llm_client.send/recv`, `svc.parser.json_strict`, `svc.soul.router_decide`, `svc.chat.reply_render`.
- Исправлена запись аудита в модуле `backend/app/services/meaning_extraction_service.py`: события `soul_meaning_filter_stats` и `soul_quant_filter_stats` теперь пишутся через именованный параметр `extra_meta` (без попытки передать `dict` в `quant_id`).
- Наблюдаемость: ошибки аудита исчезли, инспектор `signature.required_steps.consistency` — passed.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
