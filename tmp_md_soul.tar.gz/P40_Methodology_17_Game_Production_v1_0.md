# M17 — Game Production (v1.0)

Цель: производственный цикл игры с итерациями по геймдизайну и качеству.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Prototype → Vertical Slice → Alpha → Beta → Release → LiveOps.

Алгоритмы/метрики: Retention, DAU/MAU, p95, crash rate.

Роли: Producer, GD, Tech Lead, QA.

DSL: BUILD.ADD, PLAYTEST.ADD, TELEMETRY.SET, METHODOLOGY.SET.

Acceptance: метрики/телеметрия в БД; панели LiveOps.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
