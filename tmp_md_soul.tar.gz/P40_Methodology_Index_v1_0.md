# P40 — Methodology Index (v1.0)

Сводный реестр 18 методологий управления проектами для Soul Core.

## Список методологий (ключ → название)

- M01_HYBRID_AUTOPILOT → Hybrid Autopilot
- M02_WATERFALL_CONTROLLED → Waterfall Controlled
- M03_SCRUM_DISCIPLINED → Scrum Disciplined
- M04_KANBAN_FLOW → Kanban Flow
- M05_LEAN_DELIVERY → Lean Delivery
- M06_SAFE_PORTFOLIO → SAFe Portfolio Lite
- M07_PRINCE2_CORE → PRINCE2 Core
- M08_PMBOK_GUIDED → PMBOK Guided
- M09_DEVOPS_RELEASE → DevOps Release Train
- M10_RESEARCH_EXPLORATION → Research/Exploration
- M11_DATA_ML_PIPELINE → Data/ML Pipeline
- M12_SECURITY_HARDED → Security-Hardened SDLC
- M13_MIGRATION_ROLLOUT → Migration/Rollout
- M14_GOV_COMPLIANCE → Governance/Compliance
- M15_OPEN_SOURCE → Open‑Source Maintainer
- M16_EMBEDDED_SYSTEMS → Embedded/Hardware
- M17_GAME_PRODUCTION → Game Production
- M18_SUPPORT_SRE → Support/SRE Continuous

Примечание: единые инварианты P27/P28/P29/P30/P36; параметры/алгоритмы фиксируются в профильных документах Mxx.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
