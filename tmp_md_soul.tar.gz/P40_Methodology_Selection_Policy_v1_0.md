# P40 — Methodology Selection Policy (v1.0)

Цель: детерминированная и объяснимая выборка методологии (M01..M18) для проектов/задач ядра Soul.

## Входные признаки (features)

- Тип инициативы: delivery|research|migration|security|portfolio|support
- Жизненный цикл: каскадный|итеративный|потоковый|экспериментальный
- Требования: compliance|security|hardware|oss|ml
- Ограничения: срок (deadline), риск (risk_level), стабильность (stability_req)
- Контекст: наличие PI/epics/features, RS/AGE SLA, требуемые артефакты

## Правила выбора (упрощённые примеры)

- Если research|эксперимент → M10 Research/Exploration
- Если DevOps релизы, частые деплои → M09 DevOps Release Train
- Если строжайший контроль стадий и артефактов → M02 Waterfall Controlled|M07 PRINCE2 Core (по risk_level)
- Если потоковая работа и WIP‑лимиты → M04 Kanban Flow
- Если compliance/security первично → M14 Governance/Compliance|M12 Security‑Hardened SDLC
- Если данные/ML конвейер → M11 Data/ML Pipeline
- Если миграция/раскатка фазами → M13 Migration/Rollout
- Если поддержка/SRE → M18 Support/SRE Continuous
- Иначе гибридная автопилотная → M01 Hybrid Autopilot

## LLM‑шаблон классификации (STRICT JSON)

Ожидаемый ответ:

```json
{
  "methodology_key": "M09_DevOps_Release_Train",
  "confidence": 0.82,
  "reasons": ["frequent releases", "canary required", "DORA targets"],
  "profile_overrides": { "p95_budget_ms": 50, "err_rate_max": 0.01 }
}

```

## Интеграция

- Backend: функция `select_methodology(features) -> key, profile` и валидация инспектором
- DSL: `METHODOLOGY.SET project_id=<uuid> value="<key>"`
- Наблюдаемость: метрика `methodology.selected_total{key}`; панели выбора и эффективности (KPI)

Acceptance: выбор методологии повторяемый, покрыт тестами инспектора, параметры профиля применяются в планировании.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
