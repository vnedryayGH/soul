---

## Индекс взаимных ссылок (P01–P46)

- P30 Processor — инициаторы/действия (plan_session), события напоминаний.
- P33 Personification — Mini Chat сигналы для практик (при включении).
- P36 Hyperloop DSL — команды для запуска сценариев навыков.
- P46 NeuroIntegrity — полнота/согласованность связей навыков (проверка в Sleep и при batch‑ingest)

# P25 — ТЗ: Навыки/Маршруты (Skill Routes) для Квантового Сознания Soul

Дата: 2025-09-15
Статус: ТЗ-MVP к внедрению

## 1. Цель

Быстрое «подгружение» и использование сложных знаний (навыков) как маршрутов к Цели из Квантов, с органичным встраиванием в память Soul.

## 1.1 Словарь профессий/специализаций и маппинг задач

- Вводится системный словарь (taxonomy) профессий/специализаций/функций:
  - Профессии: `llm_engineer`, `data_engineer`, `ml_engineer`, `security_engineer`, `devops_engineer`, `frontend_engineer`, `backend_engineer`, `db_engineer`, `product_manager`, `qa_engineer` и др.
  - Специализации: `planning_systems`, `skills_systems`, `quant_graph`, `rbac_policies`, `hyperloop_dsl`, `reminders_p30`, `neuro_training`, `neuro_integrity`, `observability_p21`, `postgres_tuning_p41` и др.
  - Функции: `analysis`, `design`, `implementation`, `testing`, `documentation`, `deployment`, `monitoring`.

- Правила маппинга задач (из P40 Реестра) на навыки:
  - Каждая задача `plan_task` должна быть привязана минимум к одному `skill.key` (уровень специалиста), выбранному из профиля профессии/специализации.
  - Для задач архитектуры/ТЗ обязательна привязка к `skills.*.planning_systems|rbac_policies|hyperloop_dsl` по контексту.
  - Для задач массовой загрузки знаний обязательна привязка к `skills.*.quant_graph|neuro_training|postgres_tuning_p41`.
  - В `quant_links` используется `relation_type in ('plans','implements','assesses','improves')`.

- Контроль связности (вместе с `planning.enforce`):
  - Для каждого `plan_task` проверяется наличие связей к `skills` и к минимум одному Кванту выполнения/оценки.
  - Для каждого `skill` проверяется наличие обратных связей на план/цели при активности в окне 24h.

## 1.2 Правила семантических/квантовых связей

- Навык→Квант: `improves|guides|assesses` — усиление/оценка выполнения.
- План‑задача→Навык: `implements|plans` — применение навыка для реализации задачи.
- Квант→План/Цель: `supports|closes|assesses|advances` — подтверждение прогресса/закрытие/оценка влияния.
- Для внешних шардов/ingest (см. P45): связи к профессиональным навыкам обязательны для «производственных» тем.

## 3.1 Расширение DDL (таксономия)

Добавить таблицу `skill_taxonomy` и связи к навыкам:

```sql
create table if not exists skill_taxonomy (
  key text primary key,
  kind text not null check (kind in ('profession','specialization','function')),
  title text not null,
  parent_key text null references skill_taxonomy(key) on delete set null,
  meta jsonb not null default '{}'
);
alter table skills add column if not exists taxonomy text[];
create index if not exists ix_skill_taxonomy on skills using gin(taxonomy);

```sql

Пример привязки:

```json
{
  "skill": {"key": "llm_engineer.planning_systems", "name": "LLM инженер — Планирование", "version": "1.0.0"},
  "taxonomy": ["llm_engineer","planning_systems","implementation"],
  "graph": {"steps": []}
}

```

## 2. Область

- Модель Навыка и шагов/графа
- Хранение/версионирование/провенанс
- Импорт DSL (Strict JSON/YAML) и валидация
- Применение в Планировщике/Роутере
- Оптимизация во «Сне» (P16)
- Метрики/дашборды (P21)
- Безопасность/PII/Red-Team (P08/P09)

## 3. Модели (DDL, кратко)

- skills(id uuid pk, key text unique, name text, description text, target_goal_id uuid null, tags text[] gin, assets jsonb, version text, enabled bool, owner_id bigint, created_at, updated_at, row_version int)
- skill_steps(id uuid pk, skill_id uuid fk, order_no int, from_quant_id uuid null, to_quant_id uuid null, preconditions jsonb, postconditions jsonb, tool_hints jsonb, notes text, is_optional bool, branch_key text null, weight numeric, created_at)
- skill_links(skill_id uuid, related_skill_id uuid, relation_type text, weight numeric, primary key(skill_id, related_skill_id))
- skill_assets(id uuid pk, skill_id uuid fk, kind text, url_or_ref text, hash text, meta jsonb)

Индексы: (key), (skill_id, order_no), GIN(tags), GIN(assets), (relation_type)

## 4. DSL (Strict)

```json
{
  "skill": {"key": "helicopter.basic", "name": "Пилотирование вертолёта", "version": "1.0.0", "tags": ["aviation"]},
  "goals": [{"id": "<uuid>", "name": "Взлёт и посадка"}],
  "assets": [{"kind": "doc", "url_or_ref": "https://.../manual.pdf", "hash": "sha256:..."}],
  "graph": {
    "steps": [
      {"order_no": 1, "from_quant_id": "<uuid>", "to_quant_id": "<uuid>", "tool_hints": {"checklists": ["preflight"]}},
      {"order_no": 2, "from_quant_id": "<uuid>", "to_quant_id": "<uuid>", "branch_key": "good_weather"}
    ]
  },
  "evals": {"golden": [{"scenario": "calm wind", "expect": "success"}]}
}

```

Правила: Strict JSON, Pydantic Strict, Schema Guard snapshot; семантическая проверка ссылок/квантов; провенанс-хэши.

## 5. API (сводно)

- GET /api/skills?tag=&goal=&q=
- POST /api/skills (Strict; ETag)
- PUT /api/skills/{id} (If-Match)
- POST /api/skills/import?dry_run=true|false
- POST /api/skills/{id}/activate
- POST /api/skills/{id}/apply?goal=
- GET /api/skills/{id}/trace

## 6. Применение и Планировщик

- Навык → план выполнения (tool_hints, expected_cost/value)
- Fallback: обычная маршрутизация
- Трасс: успех/ошибки, latency, coverage

## 7. Сон (P16)

- Упрощение графа, объединение дублей
- Перерасстановка весов/веток, сокращение латентности
- Инкрементальная переоценка по наблюдениям

## 8. Метрики (P21)

- skill_apply_success_rate, avg_skill_latency_ms
- skill_route_depth/width, fallback_rate, assets_hit_rate

## 9. Безопасность

- NEGATIVE/PII санитайзер
- Red-Team gate на импорт/активацию
- RBAC: Architect/Admin

## 10. Приёмка

- Импорт/валидация/активация — 200; применение снижает среднюю латентность и повышает success (Golden-Set)

### 10.1 Тесты цепочек навыков (интеграция с P29/P36)

- Типы тестов:
  - `apply_and_trace` — применение навыка с обязательной трассировкой подписи P27
  - `golden_eval` — сравнение результатов навыка с эталонными (golden) кейсами
  - `sleep_optimize_then_apply` — оптимизация навыка во сне (P16) и повторное применение, сравнение метрик до/после
- Реализация: плагины `backend/app/gendarme_tests/*` и/или записи в `tests_registry`.
- Запуск через Hyperloop (см. P36):
  - `SKILL.TEST key=skill_chain.apply_and_trace.<skill_key>`
  - `SKILL.TEST key=skill_chain.golden_eval.<skill_key>`
  - `SKILL.TEST key=skill_chain.sleep_optimize_then_apply.<skill_key>`
  - `SKILL.SUITE category=skill_chain`
- Expected outcome (для `demo.skill`, пример):

```json
{
  "skill_key": "demo.skill",
  "status": "passed",
  "metrics": {
    "json_valid": true,
    "signature_steps_present": [
      "svc.soul.preanalysis",
      "svc.soul.router_decide",
      "svc.llm_client.send",
      "svc.llm_client.recv",
      "svc.parser.json_strict",
      "svc.chat.reply_render"
    ]
  }
}

```

## 11. Роллаут

- Этап 1: CRUD+импорт (disabled)
- Этап 2: Применение в Планировщике и частях роутера
- Этап 3: Сон-оптимизация + дашборд

## 12. Мировой опыт (обзор)

- HRL: Options Framework, Skills, Hierarchical Planning
- Behavior Trees/HTN в играх/робототехнике
- ReAct/ToT/Program-of-Thoughts; LangGraph/GraphRAG
- Skill Libraries/LLM Compiler (компиляция тактик в графы)
- Наилучшая практика: явные графы + Strict контракты + телеметрия

## 13. Риски/Митигирование

- Грязный импорт → Strict/Schema Guard/dry-run
- Деградация маршрутизации → feature flags, fallback
- Несогласованность квантов → проверки связей/целей

## 14. План работ (MVP)

1) DDL+Pydantic+контракты API
2) Импорт DSL (dry_run), активатор
3) Применение в Планировщике
4) Метрики/дашборды
5) Сон-оптимизация

## 15. Конкретные процессы навыков (стыковка P30/P35)

### 15.1 Процесс формирования практики (skill_signal → plan_session)

- Триггер: событие `skill_signal` (источник: чат/цель/план/напоминание).
- Шаги:

  1) perceive/appraise (P30): извлечь `skill_key`, проверить `user_skills`, due/status.
  2) decide: выбрать действие `plan_session`.
  3) act: создать Квант `skill_plan`, записать/обновить `user_skills.next_due_at`.
  4) observe/learn: подтвердить создание задачи/напоминания; обновить политику интервалов.

- Hyperloop:

```text
PROCESSOR.EVENT.INJECT kind=skill_signal payload={"user":{"id":468326902},"skill_key":"typing_speed"}
PROCESSOR.PROCESS_ONCE

```

- Acceptance: создана запись в `user_skills`/обновлён `next_due_at`, связь `quant_links(plans|schedules)`; `signature_steps` включает `svc.processor.*`.

### 15.2 Процесс оценки практики (skill_session_result → feedback)

- Триггер: событие `skill_session_result` (итог сессии).
- Шаги:

  1) perceive/appraise: прочитать результат и текущий уровень/стрик.
  2) decide: обновить прогресс/уровень/стрик; рассчитать новый due (spaced repetition).
  3) act: обновить `user_skills`, создать запись `skill_practice`, Квант `skill_feedback`, связи `quant_links`.
  4) observe/learn: зафиксировать метрики, скорректировать политику интервалов.

- Hyperloop:

```text
PROCESSOR.EVENT.INJECT kind=skill_session_result payload={"user":{"id":468326902},"skill_key":"typing_speed","score":0.82,"duration_sec":600}
PROCESSOR.PROCESS_ONCE

```

- Acceptance: обновлён `user_skills`/`skill_practice`, рассчитан новый `next_due_at`, связи `quant_links(assesses|improves)`.

### 15.3 Процесс корректировки уровня (adjustment)

- Триггер: KPI/инцидент (off_track) или быстрая динамика прогресса.
- Шаги: decide→act корректировка `level/proficiency`, запись `skill_adjustment`, Two‑Keys для массовых изменений.
- Hyperloop:

```text
TWO_KEYS.REQUEST operation=skills.adjust scope=user reason="mass level up"

```

- Acceptance: изменения по Two‑Keys, следы в аудите, шаги `cmd.hyperloop.*` в подписи.

### 15.4 Метрики/Наблюдаемость (дополнительно к §8)

- `processor.skill.sessions_count`, `on_time_practice_rate`, `proficiency_delta_avg`, p95 `session_to_feedback_ms`.

### 15.5 Безопасность

- RBAC на инъекции/массовые операции; privacy‑маскирование PII в payload; анти‑спам частоты практик.

## Приложение A. Alembic draft для P25 сущностей (DDL эскиз)

```sql
-- skills
CREATE TABLE IF NOT EXISTS skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  name text NOT NULL,
  description text,
  target_goal_id uuid,
  tags text[],
  assets jsonb DEFAULT '{}',
  version text NOT NULL,
  enabled boolean DEFAULT false,
  owner_id bigint,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  row_version int DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_skills_tags ON skills USING gin(tags);
CREATE INDEX IF NOT EXISTS ix_skills_assets ON skills USING gin(assets);

-- skill_steps
CREATE TABLE IF NOT EXISTS skill_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  order_no int NOT NULL,
  from_quant_id uuid,
  to_quant_id uuid,
  preconditions jsonb DEFAULT '{}',
  postconditions jsonb DEFAULT '{}',
  tool_hints jsonb DEFAULT '{}',
  notes text,
  is_optional boolean DEFAULT false,
  branch_key text,
  weight numeric,
  created_at timestamptz DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_skill_steps_order ON skill_steps(skill_id, order_no);

-- skill_links
CREATE TABLE IF NOT EXISTS skill_links (
  skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  related_skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  relation_type text NOT NULL,
  weight numeric,
  PRIMARY KEY (skill_id, related_skill_id)
);

-- skill_assets
CREATE TABLE IF NOT EXISTS skill_assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  kind text NOT NULL,
  url_or_ref text NOT NULL,
  hash text,
  meta jsonb DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS ix_skill_assets_kind ON skill_assets(kind);

-- user_skills
CREATE TABLE IF NOT EXISTS user_skills (
  user_id bigint NOT NULL,
  skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  level int DEFAULT 1,
  streak int DEFAULT 0,
  last_practiced_at timestamptz,
  next_due_at timestamptz,
  proficiency float DEFAULT 0,
  meta jsonb DEFAULT '{}',
  PRIMARY KEY (user_id, skill_id)
);
CREATE INDEX IF NOT EXISTS ix_user_skills_due ON user_skills(next_due_at);

-- skill_practice
CREATE TABLE IF NOT EXISTS skill_practice (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id bigint NOT NULL,
  skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  session_at timestamptz DEFAULT now(),
  duration_sec int,
  outcome text,
  score float,
  notes text,
  meta jsonb DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS ix_skill_practice_session ON skill_practice(session_at);
CREATE INDEX IF NOT EXISTS ix_skill_practice_outcome ON skill_practice(outcome);
```


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
