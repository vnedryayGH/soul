# M11 — Data/ML Pipeline (v1.0)

Цель: надёжный конвейер данных и ML‑моделей c SLA.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Ingest → Validate → Transform → Train → Evaluate → Deploy → Monitor.

Алгоритмы/метрики: Data Drift, Model Drift, p95 latency, err_rate.

Роли: Data Engineer, MLE, QA.

DSL: PIPELINE.ADD, MODEL.DEPLOY, METHODOLOGY.SET, INSPECTOR.RUN_ALL.

Acceptance: метрики/алерты в БД; панели Data/Model.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
