---

## Индекс взаимных ссылок (P01–P37)

- P17 Reminders Search — источники напоминаний.
- P20 TelegramBots Platform — интеграция Mini App.
- P30 Processor — доставка/планирование.
- P33 Personification — Mini Chat сценарии напоминаний.

# P26 — ТЗ: Планы/Календарь/Транспорт для интеграции с Квантовым Ядром

Дата: 2025-09-15
Статус: ТЗ-MVP к внедрению

## 1. Цель

Обеспечить двунаправленный транспорт задач и событий между бот‑платформой (Tasks/Events/Reminders) и Ядром Soul (Goals/Quants), чтобы Соул:

- знал о планах/календаре и мог использовать их для достижения целей;
- рождал Кванты и Цели на основе календарных сигналов;
- оптимизировал планирование (оконность/энергобюджеты/сон‑алгоритмы) без деградации.

## 2. Область

- Импорт Tasks/Events → Goals (источники, провенанс).
- Экспорт Goals → Tasks (при необходимости публикации наружу).
- Фоновая синхронизация (CalendarSync) с флагом окружения.
- Наблюдаемость/метрики/трассировка, безопасные DDL.

## 3. Модели и схема

- Платформа:
  - tasks(id uuid, title, description?, status, due_at?, start_at?, priority?, labels jsonb?, created_at)
  - events(id uuid, title, start_at, end_at?, location?, description?, created_at)
- Soul:
  - quantum_goals: добавить колонки
    - source text (e.g., 'task'|'event')
    - external_id text (id из внешней таблицы)
    - индексы по (source, external_id)
- Расписания (ActivitySchedules): `cron/window/timezone/enabled` валидируются и учитываются в планировании (см. TZ_Activity_09 v9).

## 4. Транспорт (CalendarTransport)

- Импорт задач → цели: upsert по (source='task', external_id), имя цели = title.
- Импорт событий → цели: upsert по (source='event', external_id), имя цели = title.
- Экспорт целей → задачи: создаёт задачи из активных целей, у которых нет привязки (source null).
- Без заглушек: если таблиц нет — возвращает 200 с note:"... missing" (реализовано).

## 5. Фоновые задачи

- CalendarSyncBackgroundTask (включение `ENABLE_CALENDAR_SYNC=1`):
  - периодичность 5 минут (конфигурируемо);
  - import tasks/events и export goals→tasks с безопасными проверками;
  - логи в audit/health.

## 6. Метрики/Наблюдаемость (P21)

- calendar_imported_tasks, calendar_imported_events, calendar_exported_goals.
- Ошибки/пропуски в audit с деталями (source, external_id, причина).
- Дашборды: тренды импорта/экспорта, попадание в окна расписаний.

## 7. Безопасность/Приватность

- Strict JSON, Pydantic Strict в админ‑API.
- RBAC: только Admin/Architect может запускать ручной импорт/экспорт.
- ПИI: скрывать частные поля в логах; внешние источники — через two‑keys при необходимости.

## 8. API (админ)

- POST `/api/admin/calendar-transport/import/tasks?limit=200`
- POST `/api/admin/calendar-transport/import/events?limit=200`
- POST `/api/admin/calendar-transport/export/goals-to-tasks?limit=100`

Все ответы 200 с полями `{imported|exported, skipped, note?}`.

## 9. Связь с рождением Квантов/Целей

- Импортированные цели участвуют в планировании (FlowDispatcher, ActivityPlanner окна) и в цепочке рождения Квантов.
- Цели, сформированные из календаря, транслируют контекст в Кванты; при сопоставлении с Навыками (P25) получают маршруты (SkillRoutes).
- Во «Сне» (P16) — оптимизация расписаний, дедупликация целей, укрепление связей с Навыками.

## 10. Мировой опыт

- RFC 5545 (iCalendar), CalDAV, ICS; Google Calendar API best‑practices.
- GTD/OKR/time‑blocking: блоки времени ↔ цели.
- Event‑sourcing: аудит изменений планов.

## 11. Приемка

- Админ‑эндпоинты работают (200), CalendarSync запускается по флагу.
- Цели отражаются в планировании; окна учитываются; дашборды обновлены.
- Health 200; 5xx=0; latency в SLO.

## 12. Роллаут

- Этап 1: ручной импорт/экспорт + логирование.
- Этап 2: включение CalendarSync в непиковое время.
- Этап 3: расширение маппинга полей/приоритетов и интеграция с P25.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
