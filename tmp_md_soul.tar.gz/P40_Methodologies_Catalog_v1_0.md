# P40 — Каталог проектных методологий v1.0

Дата: 2025-10-04
Назначение: единый реестр 18 методологий управления проектами для Ядра Соул; каждая — с целями, инвариантами (P27/P28/P29/P30/P36), ролями, базовыми процессами, KPI/SLA и интеграциями (Кванты/Планы/Навыки/RS/AGE/Grafana/Alerts). Все параметры/политики — через БД `soul_settings`.

## Список методологий (реестр 18)

1. Hybrid Autopilot (гибридная методология с автопланированием)
2. Waterfall Baseline Control
3. Iterative PDCA (Plan‑Do‑Check‑Act)
4. Agile Scrum Minimal (Lite)
5. Kanban WIP‑Governance
6. Lean Value Stream (VSM)
7. PRINCE2 Tailored for Small Teams
8. PMBOK Knowledge‑Areas Mapping
9. Critical Chain (CCPM) with Buffers
10. Risk‑Driven Delivery (RDM)
11. Quality‑First (Gendarme/Judge‑centric)
12. Incident‑Resilient (P50‑centric)
13. Data‑Ops/ML‑Ops Integrated
14. Security‑by‑Design (Key Master)
15. Compliance‑as‑Code
16. Documentation‑as‑Product
17. Autonomy‑Driven LLM Planner
18. Marketplace/Integration‑First (External Interfaces)

## Шаблон описания методологии (для каждой из 18)

- Цели/Контексты применения
- Инварианты и политики: P27/P28/P29/P30/P36 (+ P42/P48/P51 при необходимости)
- Роли/Ответственности (RBAC)
- Базовые процессы и этапы (дерево процессов per‑role)
- План/Задачи/Связи (PLAN.TASK.*, QUANT.LINK, SKILL.LINK)
- KPI/SLA и метрики (Prometheus), алерты (Alertmanager), панели (Grafana)
- Автономия LLM и гейты (LLM‑gate/Two‑Keys)
- Acceptance (смоки/инспекторы/трейсы)

## 1) Hybrid Autopilot (контур)

- Цели: гибкое планирование с детерминированной расчётной частью (CPM/EVM), автодекомпозиция и автоэскалации AGE/RS.
- Инварианты: Delivery Guard; идемпотентные расчёты CPM/EVM; справедливое планирование в Processor; каноника URL/портов; STRICT JSON.
- Роли: manager/operator/developer/tester/analyst/integrator/riskman.
- Процессы: init→wbs→schedule→cpm→evm; auto‑replan при алертах/инцидентах; periodic `neurotrain.report(+verify)`.
- KPI: p95 e2e по видам ≤ бюджетов; CPI/SPI в допусках; incidents rate низкий; RS p95≤50ms, AGE lag≤60s.
- Acceptance: `INSPECTOR.RUN_ALL` зелёный; `PLAN.TASK.ADD`/`PLAN.CPM.CALC` работают; панели обновляются.

— Полная детализация методологии 1 будет добавлена в `Soul/P40_Methodology_01_Hybrid_Autopilot_v1_0.md`.



## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
