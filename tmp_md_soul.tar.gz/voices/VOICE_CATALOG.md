# Каталог голосов (samples) и привязки к персонам

- Базовая директория: `Soul/voices/`
- Файлы лежат в подпапках по семействам и дублируются в `latest/` для удобного доступа.

Таблица выбранных голосов (используются в проекте)

| Персона/Режим | Провайдер/Voice ID | Скорость | Эмоция | Аудио-файл | Относительный путь |
|---|---|---:|---|---|---|
| Soul (бархатный мужской) | yandex_speechkit / ermil | 0.90 | neutral | voice_soul_velvet_ermil.ogg | Soul/voices/latest/voice_soul_velvet_ermil.ogg |
| Фаина Раневская (фикс) | yandex_speechkit / jane | 0.72 | evil | ranevskaya_jane_s072_evil.ogg | Soul/voices/Ranevskaya/latest/ranevskaya_jane_s072_evil.ogg |
| Поток | yandex_speechkit / ermil | 1.06 | good | zh_sharp_ermil_s106_good.ogg | Soul/voices/Zhvanetsky/latest/zh_sharp_ermil_s106_good.ogg |
| Дядя Миша (Жванецкий) | yandex_speechkit / filipp | 1.00 | neutral | zh_sharp_filipp_s100_neutral.ogg | Soul/voices/Zhvanetsky/latest/zh_sharp_filipp_s100_neutral.ogg |
| Вед (космич. реверб) | yandex_speechkit / ermil | 0.88 | neutral | ved_ermil_cosmic_reverb.ogg | Soul/voices/Ved/latest/ved_ermil_cosmic_reverb.ogg |
| Каббала | yandex_speechkit / ermil | 0.92 | neutral | oldj_ermil_s092_neutral.ogg | Soul/voices/OldJewish/latest/oldj_ermil_s092_neutral.ogg |
| Female Resonance | yandex_speechkit / oksana | 0.80 | evil | ranevskaya_oksana_s080.ogg | Soul/voices/Ranevskaya/latest/ranevskaya_oksana_s080.ogg |
| Language Trainer | yandex_speechkit / oksana | 0.85 | neutral | ranevskaya_oksana_s085.ogg | Soul/voices/Ranevskaya/latest/ranevskaya_oksana_s085.ogg |

Подборочные варианты (для сравнения)

- Ranevskaya:
  - Soul/voices/Ranevskaya/latest/ranevskaya_oksana_s080_evil.ogg
  - Soul/voices/Ranevskaya/latest/ranevskaya_oksana_s085_neutral.ogg
  - Soul/voices/Ranevskaya/latest/ranevskaya_jane_s080_evil.ogg
  - Soul/voices/Ranevskaya/latest/ranevskaya_jane_s082_neutral.ogg
  - Soul/voices/Ranevskaya/latest/ranevskaya_oksana_s073_neutral.ogg
- Zhvanetsky:
  - Soul/voices/Zhvanetsky/latest/zhvanetsky_ermil_s098_neutral.ogg
  - Soul/voices/Zhvanetsky/latest/zhvanetsky_ermil_s108_good.ogg
  - Soul/voices/Zhvanetsky/latest/zhvanetsky_ermil_s112_good.ogg
  - Soul/voices/Zhvanetsky/latest/zhvanetsky_zahar_s104_neutral.ogg
  - Soul/voices/Zhvanetsky/latest/zh_sharp_ermil_s102_neutral.ogg
  - Soul/voices/Zhvanetsky/latest/zh_sharp_zahar_s104_neutral.ogg
  - Soul/voices/Zhvanetsky/latest/zh_sharp_filipp_s100_neutral.ogg
- OldJewish:
  - Soul/voices/OldJewish/latest/oldj_filipp_s088_neutral.ogg
  - Soul/voices/OldJewish/latest/oldj_ermil_s090_good.ogg
- Ved:
  - Soul/voices/Ved/latest/ved_ermil_s088_neutral_raw.ogg (до реверба, если присутствует)

Примечания

- Все пути относительные к корню репозитория; для отдачи в UI/боте используйте публичный статик‑хостинг или внутренний файловый сервер.
- Для Telegram голосовых сообщений предпочтителен Ogg Opus mono 48 kHz (libopus). Подборочные файлы уже в этом формате.
