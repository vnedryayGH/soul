---

## Индекс взаимных ссылок (P01–P37)

- P20 TelegramBots Platform — голосовой канал Mini App.
- P23 UI Spec — голосовые UI состояния.
- P33 Personification — влияния на язык/персону (опционально).

### ТЗ Soul v1.0 — Голосовые сообщения боту (ASR: Speech‑to‑Text перед обработкой)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: К реализации (MVP без миграций; Stage‑2 — вложения/хранилище)

---

### 0. Executive summary

- Цель: при получении голосового/аудио‑сообщения распознавать речь (ASR) и отправлять текст в стандартный пайплайн; в чате показывать текст.
- Интеграция: «нулевой» этап перед `chat_service.send_message`. По умолчанию OFF; включение флагом и настройкой провайдера. Без миграций.

---

### 1. Архитектура и точки интеграции

- Новые сервисы:
  - `backend/app/services/asr/asr_service.py` — маршрутизация провайдера, нормализация.
  - `backend/app/services/asr/audio_convert.py` — конвертация в WAV/16k/mono (ffmpeg).
  - (опц.) `backend/app/services/asr/voice_handler.py` — download→convert→asr для Telegram.
- Обновления:
  - В месте приёма апдейтов/`chat_service.send_message` — детект «voice/audio» → ASR → подмена `message_text`.
  - `SoulSettingsService` — секция `asr.*`.
  - Admin UI — вкладка «Голос/ASR».

---

### 2. Поддерживаемые форматы/источники

- Вход: Telegram `voice` (OGG/Opus), `audio` (MP3/M4A/WAV/OGG), длит. ≤ `asr.max_duration_sec`, размер ≤ `asr.max_size_mb`.
- Конвертация: `WAV PCM 16kHz mono` (ffmpeg).

---

### 3. Провайдеры ASR (плагин)

Интерфейс `ASRProvider`:

- `transcribe(wav_bytes: bytes, *, lang_hint: Optional[str]) -> { text: str, lang: str, duration_sec: float, confidence?: float }`

Реализации (переключаемые): `whisper_openai`, `yandex_speechkit`, `google_speech`, `vosk_local` (DEV), `gigachat_asr` (если доступно).

---

### 4. Алгоритм обработки голосового сообщения

1) Детект `voice|audio`.
2) Download → `audio_convert.to_wav16_mono` (проверки длит./размера).
3) `ASRService.transcribe(wav_bytes, lang_hint)` (язык: профиль/last message/`asr.lang_default`).
4) Нормализация текста: trim/пунктуация (если доступна), пустые — отбрасывать.
5) PII‑санитизация до логов/аудита.
6) Передать как `message_text = transcript.text` в стандартный путь.
7) Очистить временные файлы.

Фоллбек: при ошибке скачать/конвертировать/ASR — отправить пользователю «Не удалось распознать аудио…», не вызывать ядро.

---

### 5. Настройки/флаги (SoulSettingsService)

- `asr.enabled=false`
- `asr.provider="gigachat_asr"`
- `asr.lang_default="ru"`
- `asr.max_duration_sec=180`
- `asr.max_size_mb=15`
- `asr.timeout_ms=15000`
- `asr.auto_punct=true`
- `asr.keep_temp_files=false`

ENV: ключи провайдеров; путь к `ffmpeg`.

---

### 6. Безопасность/приватность

- Все тексты транскриптов через `privacy_sanitizer`; без PII в логах/трассах.
- Guard: текст из аудио — обычный пользовательский ввод; не исполняем команды.
- Временные файлы удалять; при `keep_temp_files=true` — TTL‑очистка (Stage‑2).

---

### 7. Наблюдаемость и аудит

События: `asr_voice_received`, `asr_download_ok|fail`, `asr_convert_ok|fail`, `asr_transcribe_ok|fail`, `asr_text_forwarded`.
Метрики: `asr.p95_ms_total`, `asr.err_rate`, `asr.provider_usage`, `asr.mean_text_len`, `asr.lang_dist`.

---

### 8. Acceptance

- При `asr.enabled=true` голос → текст → стандартный пайплайн; в чате показывается текст.
- p95 ≤ 5–8с с сетевыми провайдерами на тестовом наборе (ru/en); точность приемлема (ручная проверка).
- При ошибке ASR — корректный фоллбек-сообщение, без проброса в ядро.
- При `asr.enabled=false` поведение неизменно.

---

### 9. Stage‑2 (опционально)

- Хранилище вложений: `attachments`/`message_attachments` (meta: duration/format/lang/confidence, file_path), TTL‑сборщик.
- VAD/Chunking для длинных аудио, параллельная транскрипция, слияние сегментов.
- Диаризация (многоголосие) для звонков.
- Адаптивный выбор провайдера по лимитам/стоимости (связь с Multi‑Provider Routing).

---

### 10. Метрики, SLO, алерты

- Метрики: `asr.p95_ms_total`, `asr.err_rate`, `asr.provider_usage`, `asr.mean_text_len`, `asr.lang_dist`
- SLO: `p95_ms_total ≤ 8000ms`, ErrRate ≤ 3%
- Алерты: `err_rate > 5%` (10мин), `p95_ms_total > 10s` (10мин)

---

### 2. Тест‑план

- Unit: конвертация ffmpeg (разные форматы), ограничение длительности/размера
- Integration: end‑to‑end голос→текст→пайплайн; точность на RU/EN примерах
- Perf: батчи аудио с 30–60 сек — удержать SLO

---

### 3. Rollout

- DEV: два провайдера (Yandex/Whisper), сравнение метрик
- STAGE: ограниченный процент пользователей, алерты
- PROD: gradual rollout с fallback на текстовый ввод при деградациях


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
