# P48R — ТЗ: Этапная миграция Hyperloop/крит‑зон ядра на Rust (v1.0)

## Изменения v1.1 — надёжные «ворота» напоминаний и эмпатических фоллоу‑апов (до LLM)

Цель обновления: исключить прохождение любых пользовательских сообщений «мимо» парсинга дат/событий и неявных намерений, гарантировать постановку событий/напоминаний (P30) до обращения к генеративной модели, а также добавить живую эмпатическую логику (пост‑диалоговые check‑in/спросить позже) на базе LLM‑аналитики с накоплением знаний.

### 1) Обязательный Gate перед LLM (Pre‑LLM Reminder/Intent Gate)

- Все входящие сообщения проходят пред‑обработку «до» основного LLM:
  - Gate A: Извлечение времени/дат/событий (Event/Time Extraction) — нормализация when → datetime; создание напоминаний (persist) и немедленное планирование `processor_events(kind='reminder', status='scheduled', due_at)`.
  - Gate B: Интент‑оценка эмпатии/заботы (health/weather/condition intent) — выявление неявных follow‑up намерений (напр., «болит голова», «попал под дождь», «устал/плохо»), постановка «мягких» check‑in событий на будущее окно (через P30 scheduler) с учётом персонажа/промпта.
- Функции Gate фиксируются в подписи (P27) до шагов LLM:
  - `gate.event_time.parse` (scope: `soul_gate`, status: ok/fail, input: text, output: parsed_when)
  - `gate.intent.empathy.detect` (scope: `soul_gate`, output: intents: [health_check, mood_check, weather_check, etc.])
- Любые ошибки Gate не блокируют чат, но записывают инциденты `gate_parse_error` / `gate_empathy_error` (P21/P27).

### 2) Интент‑слой «живой души»: эмпатические follow‑ups (обновлено)

- LLM‑аналитика (служебный профиль, GigaChat при наличии кредов → fallback DeepSeek) выделяет эмпатические смыслы. Ворота работают ВСЕГДА для любых входящих сообщений (даже без явного «напомни»), обеспечивая 100% перехват для анализа:
  - Примеры интентов: `health_check_later`, `weather_check_later`, `mood_followup`, `safety_check`.
  - Для каждого интента формируются «мягкие» напоминания/события с окном (например, через 2 часа/завтра утром), которые в due генерируют контекстно‑персонифицированное сообщение (ReminderActor) с учётом активной персоны/промпта.
- Поведение не жёсткое: параметры окна/тональности/персонификации задаются в настройках (P28), а тексты — на уровне ReminderActor + текущей персоны. Ошибки не блокируют чат; фиксируются инциденты `gate_empathy_error`.

### 2.1) Детали реализации гейтов (новое)

- Gate A `gate.event_time.parse`: синхронный вызов `ReminderService.analyze_message_for_events` в `ChatService` до основного LLM, с немедленным созданием напоминаний и инъекцией `processor_events` с `due_at`.
- Gate B `gate.intent.empathy.detect`: в `ChatService` до LLM — лёгкие эвристики + сервисный LLM‑классификатор (GigaChat→DeepSeek). На основе интентов создаются «мягкие» follow-up напоминания (здоровье, настроение, погода, безопасность). Результат фиксируется в подписи P27.

### 2.2) Надёжность перехвата (новое)

- Гарантия 100% охвата: гейты выполняются синхронно в коде `ChatService` до любых веток LLM/персоны/оркестрации.
- При создании напоминаний — обязательная запись события в `processor_events` (даже при деградации фонового инжектора). Схемные различия учитываются (наличие `dedup_key`).
- Инспекторы обновлены: обязательная цепочка включает `gate.event_time.parse` и `gate.intent.empathy.detect`.

### 2.3) Смоки и инспекторы (новое)

- Смоки Hyperloop DSL:
  - `CORE.PIPELINE.RUN input_text="болит голова, проверим позже" WITH TRACE` → в подписи есть `gate.intent.empathy.detect`; создан follow-up.
  - `P30.EXTRACT_AND_PLAN text="через 15 минут позвонить"` → `gate.event_time.parse` присутствует; напоминание запланировано.
- Инспекторы:
  - `signature.required_steps.consistency` включает `gate.*` шаги в список обязательных.
  - `processor.feedback_invariant` отражает `reminder_sent`/ошибки доставки.
  - `diamond.pipeline.health` — наличие `svc.diamond.*` шагов и успехов `diamond_*` за 24h (см. backend/app/gendarme_tests/diamond_pipeline_health.py).
  - `rs.actor.budgets` — p95/error_rate RS‑шины/актеров в бюджете (см. backend/app/gendarme_tests/rs_actor_budgets.py).

### 3) Интеграция с P27/P30/P36

- P27 Подпись: добавлены обязательные шаги `gate.*` перед `svc.soul.preanalysis`:
  - Минимальная требуемая цепочка (обновить инспектора): `gate.event_time.parse, gate.intent.empathy.detect, svc.soul.preanalysis, svc.llm_client.send, svc.llm_client.recv, svc.parser.json_strict, svc.chat.reply_render`.
- P30 Processor: при создании любого напоминания/интента создаётся событие `processor_events` со статусом `scheduled` и корректным `due_at` (UTC) + `dedup_key=reminder:<id>:<due_at>`.
- Rust‑связь: команды Hyperloop и операторы процессора проксируются через `svc.rs.proxy` (rsbus). Для событий `dialog.followup` и `reminder` предусмотрен детерминированный обработчик в Python с записью подписи; на следующих итерациях перенос в Rust‑акторы.

### 4) Нейронная петля обратной связи (новое)

- Определение: автоматическое планирование follow‑up проверки, если пользователь не нажал подтверждение (ACK) в течение окна `dialog.followup.no_ack_minutes` (по умолчанию 60 минут).
- Реализация: после `svc.reminder.deliver`, если доставка `ok`, планируется событие `processor_events(kind='dialog.followup', due_at=now()+Δ)`.
- Обработка: `dialog.followup` инициирует диалог‑вопрос к пользователю (контекстно‑эмпатичный), учитывая активную персону и историю. Ответ приводит к продолжению цепочки (SequenceEngine) или отмене.
- Подпись: `svc.dialog.followup.plan` и `svc.dialog.followup.deliver` фиксируются в P27;
- Инспекторы: smoke на пополнение очереди `dialog.followup` и последующую доставку вопроса без 5xx.
  - При due ReminderActor выполняет: prefetch (если включён), персонализированную генерацию, доставку, ack/snooze/cancel; для эмпатических событий — «мягкие» формулировки.
- P36 Hyperloop DSL: тестовые сценарии Gate и эмпатии (см. §7 ниже).

### 4) Роутинг LLM и производительность (RS‑миграция)

- Чат/персоны/ядро — DeepSeek; сервисные задачи (keyword/empathy/reminder/planner/judge) — GigaChat при наличии кредов, иначе DeepSeek.
- В рамках RS (Rust) реализовать «горячий путь» для Gate:
  - Быстрая нормализация относительных форм (regex + шаблонные правила) и подготовка контракта для P30 (ISO8601, user_tz→UTC).
  - LLM‑эмпатия остаётся на Python‑стороне (служебный вызов) с дальнейшей RS‑миграцией по результатам профилирования.

### 5) UX/Telegram / Chat UX

- После ACK показывать расширенные snooze‑кнопки (+5/+15/+30/+60 и меню вариантов). Snooze обновляет `reminder_date`, сбрасывает `is_sent=false`, планирует `processor_events` на новый `due_at` и пишет инцидент `reminder_snooze`.
- Эмпатические due‑сообщения формируются с учётом активной персоны/промпта; при включённом prefetch (напр., `weather`, `currency`) подмешиваются выдержки и ссылка.
- Видимое подтверждение в ответе (чтобы ЛЛМ «знала» о системе напоминаний и не отвечала невпопад): если в рамках текущего сообщения созданы напоминания, перед репликой персоны добавляется краткий префикс‑квитирование:
   - Формат: `✅ Напоминание поставлено:\n• <title> — <YYYY‑MM‑DD HH:MM>\n\n`
   - Пример: `✅ Напоминание поставлено:\n• посмотреть погоду в Москве — 2025‑09‑24 19:06\n\n`
   - Префикс добавляется только при фактическом создании due‑напоминаний в этом сообщении; не влияет на инспекторы/подпись, но улучшает понятность ответа для пользователя и снижает вероятность «несуразных» ответов.

### 6) Наблюдаемость/инциденты/метрики

- Подпись: `gate.event_time.parse`, `gate.intent.empathy.detect`, далее стандартная цепочка.
- Инциденты: `reminder_created`, `reminder_sent`, `reminder_ack`, `reminder_snooze`, `reminder_cancelled`, `reminder_prefetch_ok/fail`, `gate_parse_error`, `gate_empathy_error`.
- Метрики (P21): покрытие gate, p95 Gate, p95 Processor, доля сообщений с detected intents, reminder.delivery_success_rate.

### 7) Тесты/Acceptance (Hyperloop DSL)

- Gate smoke:
  - `CORE.PIPELINE.RUN input_text="через 15 минут проверить почту" WITH TRACE`
  - Проверить шаги `gate.event_time.parse` и наличие `processor_events(kind='reminder', status='scheduled')`.
- Empathy smoke:
  - `CORE.PIPELINE.RUN input_text="весь день шел дождь, промок и замёрз" WITH TRACE`
  - Ожидается интент `health_check_later` → событие на +2 часа.
- Prefetch smoke (напоминание с поиском): создать через API/DSL напоминание с `search_query` на +6 минут; за 5 минут до due фиксируется `reminder_prefetch_ok`.
- Инспекторы P27: покрытие шагов gate ≥ p95‑порог.

### 8) Миграция и риски

- Python‑сторона: включить Gate до LLM (синхронный быстрый разбор + фоновый анализ), автопланирование `processor_events` при создании напоминаний/интентов.
- RS‑сторона (этап 1): вынести быстрые эвристики when‑нормализации в RS для p95 ≤ 2 ms; сохранить единый контракт JSON для Python‑планировщика.
- Риск: двойная постановка событий — предотвращается `dedup_key` и дедуп‑окном ±2 мин.
- Риск: «чрезмерная забота» — лимиты интентов/сутки и тональность на уровне настроек P28.

---

Данный апдейт закрепляет инвариант: «Ни одно сообщение не проходит мимо ворот парсинга напоминаний и эмпатических интентов». Это повышает надёжность подсистемы напоминаний и качество живого диалогового поведения без деградации производительности (за счёт RS‑горячих путей и отложенных сервисных вызовов).

Версия: v1.0

Статус: к внедрению (этапы 1–4)

Область: Hyperloop DSL (парсер/исполнитель), P27 Delivery Guard (валидатор цепочек), P29 Инспекторы (горячий путь), P30 Processor (тик/планирование), P44 PDP (чистая проверка политик), Two‑Keys verify.

## 0) Цель и инварианты

- Поэтапный перевод горячих узлов на Rust без регресса функциональности, с фича‑флагами и мгновенным откатом.
- Контракты I/O стабильны: JSON (или Protobuf по согласованию). Нулевой PII в логах.
- Rust — stateless; секреты — только из Python. Никаких исходящих сетевых запросов из Rust.

Флаги зон: `HYPERLOOP_RS_ENABLED`, `P27_RS_ENABLED`, `P29_RS_ENABLED`, `P30_RS_ENABLED`, `P44_PDP_RS_ENABLED`, `TWOKEYS_RS_ENABLED`, `WEBAUTH_RS_ENABLED`.

## 1) Архитектура интеграции

- Модель: микросервисы `Axum/Hyper` на UDS/localhost (mTLS/UDS ACL) ИЛИ `PyO3` для точек нулевого overhead (после отдельного аудита).
- Транспорт: JSON. Маркеры трасс: `X-Request-ID|trace_id`.
- Python↔Rust мосты: адаптеры `*_bridge_rs.py` в `backend/app/services/`.

### 1.1) RS System Bus (UDS) — низкоуровневая шина взаимодействия

- Цель: минимальный overhead и максимальная пропускная способность обмена Python↔RS в реальном времени.
- Транспорт: Unix Domain Socket (UDS, stream) с бинарным фреймингом `len(4 bytes BE) + json_utf8_bytes`.
- Сокет: `/run/soul/rsbus.sock` (prod), dev — `/run/soul/rsbus.dev.sock`; владелец `root:soulops`, права `0660`.
- Протокол сообщений (envelope, JSON):
  - `id: string` — идентификатор запроса (uuid4)
  - `ts: string` — ISO8601
  - `op: string` — операция (`hyperloop.execute | p27.guard.verify | p29.inspector.run | p44.pdp.decide | health`)
  - `trace_id: string?`
  - `payload: object` — контракт конкретной операции (см. разделы 5–9)
  - Ответ: `{ ok: bool, id, trace_id?, result?:object, error?:{ code:int, class:string, reason:string } }`
- Параллелизм/очереди:
  - Tokio runtime, multi-worker; входящий поток — через length-delimited codec.
  - Обработка: lock‑free каналы (`tokio::mpsc`) по `op`, work‑stealing пул воркеров.
  - Пулы памяти/буферов: `bytes::BytesMut` pre‑alloc; минимум копирований.
- Backpressure:
  - Водяные метки очередей → возврат `429 backpressure_on` и телеметрия.
- Телеметрия:
  - Prometheus: `rsbus_inflight`, `rsbus_backpressure_on`, `rsbus_frame_bytes`, `rsbus_latency_ms{op}`.
  - OpenTelemetry: спаны `bus.recv`, `bus.dispatch`, `op.*` (link к trace Python).
- Безопасность:
  - Только UDS, без TCP. `RestrictAddressFamilies=AF_UNIX` в systemd. Нулевой egress (nftables cgroup).
  - Валидация длины фрейма (≤256 KiB), тайм‑аут чтения, лимит глубины JSON.
- Readiness/health:
  - `health`: короткий путь без аллокаций, `{ ok:true, service:"rsbus", version }`.
  - readiness = open(sock) + round‑trip `health` ≤ 1 ms p95.

Примеры UDS/HTTP:

- UDS: `/run/soul/hyperloop_rs.sock` (Axum)
- Dev HTTP: `127.0.0.1:7071` (hyperloop_rs), `:7072` (p27_rs), `:7073` (p29_rs), `:7074` (p30_rs), `:7075` (p44_pdp_rs)

## 2) Наблюдаемость

- OpenTelemetry: спаны `parse`, `exec`, `proxy`.
- Prometheus:
  - `hyperloop_rs_latency_ms{phase=parse|exec|total}` (histogram)
  - `hyperloop_rs_errors_total{class}` (counter)
  - `hyperloop_rs_backpressure_on` (gauge)
  - `processor_rs_queue_len` (gauge)
- RS Bus:
  - `rsbus_latency_ms{op}` (histogram), `rsbus_inflight`, `rsbus_backpressure_on`, `rsbus_frame_bytes`.
  - Лейблы: `op`, `worker`, `error_class`.
- P27 инварианты: шаги подписи не деградируют; Delivery Guard проходит.

## 3) Производительность (SLA)

- Hyperloop: overhead ≤ 1 ms p50 / ≤ 3 ms p95 / ≤ 6 ms p99 при ≥200 rps; ≥2k rps для лёгких команд.
- P27 RS: ≤ 0.5 ms p50 / ≤ 2 ms p95; zero‑alloc горячий путь.
- P29 RS инспектор: ≤ 2 ms p95 на единичный; потоковый батч.
- P30 RS: тик/планирование ≤ 2 ms p95; 1–5k событий/мин устойчиво.
- P44 PDP RS: решение ≤ 1 ms p95 (матрицы/кэш вне Rust; Rust — чистая функция).
- Two‑Keys verify: крипто‑проверка ≤ 3 ms p95; корректные ошибки TTL/подмены.

— RS Bus: overhead кадра ≤ 0.3 ms p50 / ≤ 0.8 ms p95; ≥ 50k rps суммарно на лёгких `op` при ≥ 4 воркерах.

## 4) Безопасность

- Без `unsafe` (или изолированно/аудировано). Лимиты: длина входа, глубина парсинга, время, общий таймаут; отмена по сигналу.
- Никаких исходящих сетевых запросов из Rust. Все опасные действия — через Python PEP/Two‑Keys.

## 5) Hyperloop DSL (RS)

Зоны:

1) Парсер DSL (EBNF, лимиты, Unicode/quoting)

2) Исполнитель простых команд (чистые трансформации)

3) Прокси эффектов в Python

Запрос:

```json
{ "commands": "CORE.PIPELINE.RUN input_text=\"...\" WITH TRACE", "options": {"stop_on_error": true} }

```

Ответ:

```json
{ "ok": true, "trace_id": "...", "results": [{"command":"...","ok":true,"data":{}}], "errors": [], "signature": {"steps":[], "trace_id":"..."} }

```

### 5.1 Быстрые команды подключения LLM‑агентов (новое)

- SESSION.CLAIM owner=<tg_id> branch=<key> [topic=<t>] [ttl_sec=<n>] [session=<id>]
- SESSION.PING owner=<tg_id> session=<id> [session_ttl_sec=<n>]
- SESSION.RELEASE branch=<key> [owner=<tg_id>] | SESSION.RELEASE session=<id>
- DEV.CONNECT owner=<tg_id> branch=<key> [topic=<t>] [session=<id>]
- LLM.MIRROR owner=<tg_id> branch=<key> topic=<t> user_command="..." agent_reply="..." [plan_task_id=<uuid>] [success=<0|1>]
- LLM.MIRROR.BATCH items=[{...}]

Контракты: фасад Python нормализует в единый формат ответов Hyperloop `{ ok, results:[], meta:{}, signature:{} }`. RS‑ядро возвращает read‑only core; побочные эффекты выполняет Python‑фасад (запись в БД/линки/аудит).

SLA: п95 ≤ 1–2 мс на сессио‑команды; batch mirror ≤ 10 мс на 10 элементов.

EBNF (фрагмент):

```text
program = { command, ["\n"] } ;
command = ident, {".", ident}, {" ", arg}, [modifier] ;
ident   = ALPHA, { ALPHA | DIGIT | "_" } ;
arg     = key, "=", value ;
key     = ident ;
value   = quoted | number | boolean | json ;
quoted  = '"', { char | escape }, '"' ;
modifier= { " WITH TRACE" | " DRY_RUN" | " EXPECT ", key, "=", value | " TIMEOUT=", number } ;

```

Квотинг: `"..."`, эскейпы `\"`, `\\`, `\n`. JSON‑литералы допустимы как строка.
Интеграция через RS Bus: `op="hyperloop.execute"`, `payload={ commands, options, trace_id }`.

## 6) P27 Delivery Guard (RS)

Чистый валидатор обязательных шагов.

Вход:

```json
{ "required": ["svc.soul.preanalysis", "svc.llm_client.send", "svc.llm_client.recv", "svc.parser.json_strict", "svc.chat.reply_render"], "steps": ["..."] }

```

Выход:

```json
{ "ok": true, "missing": [] }

```

Горячий путь: сравнение на массивах/бит‑масках, zero‑alloc; p95 ≤ 2 ms.
Интеграция через RS Bus: `op="p27.guard.verify"`, `payload={ required, steps }`.

## 7) P29 Инспекторы (RS)

- `rs.parity` — сверка Python↔Rust по результату/подписи.
- `rs.performance_sla` — контроль `p95/p99` по метрикам.
- `rs.security_limits` — соблюдение лимитов глубины/длины/таймаутов/отмен.

Единый контракт: `run(key, payload) -> {status, detail, metrics}`; потоковый режим для батчей.
Интеграция через RS Bus: `op="p29.inspector.run"`, `payload={ key, context? }`.

## 8) P30 Processor (RS)

Горячие функции без БД: тик/планирование/квоты/таймауты. I/O — JSON снапшоты `agenda`/`policy`.

Метрики: `processor_rs_tick_latency_ms{stage}`, `processor_rs_backpressure_on`.

## 9) P44 PDP (RS)

Чистая функция решения политик над контекстом (без БД):

Вход: `{ route, method, headers{X-Telegram-User-ID}, roles[], perms[], abac_ctx{channel,time,plan,region}, resource?, function_name?, two_keys? }`

Выход: `{ decision: "allow|deny", code, reason }` (классы: `role_mismatch|plan_not_allowed|jwt_mismatch|ownership_mismatch|two_keys_required|quota_exceeded`).
Интеграция через RS Bus: `op="p44.pdp.decide"`, `payload={ ... }`.

## 10) Тестирование/приёмка

- Golden‑паритет (≥50 позитивных, ≥50 негативных кейсов на зону).
- Property‑tests + fuzzing входа (DSL/политики/подписи), отсутствие `panic/UB`.
- Интеграция: Python↔Rust прокси, инспекторы, TRACE/STEPS, Two‑Keys verify, WebAuth cookie.
- Нагрузка: latency/throughput/soak 24h; отсутствие утечек; предсказуемый backpressure.
- Безопасность: `clippy`, `cargo-audit`, `cargo-deny`, SBOM; pin зависимостей.

— RS Bus acceptance:

  - `health` round‑trip ≤ 0.8 ms p95; `inflight` не растёт без ограничений при 10k rps.
  - Дропа нет при окне нагрузки 60с; при backpressure возвращается 429 и восстанавливается ≤ 5с.
  - Property/fuzz на фрейминг: произвольные длины/escape/несовпадение `len`.

Acceptance (минимум):

- `INSPECTOR.RUN_ALL` — зелёный (signature/processor/rs.*).

- `CORE.PIPELINE.RUN ... WITH TRACE` — шаги сохраняются; `cmd.hyperloop.*` видны.

- P27/P28/P29/P30 инварианты зелёные; 5xx нет.

## 11) Поставка/флаги/откат

- Флаги: включение зон по отдельности; профиль `prod_safe` откатывает RS при аномалиях.
- Canary 5–10%: сравнение метрик/ошибок/результатов Python↔Rust; быстрый откат флагом.
- systemd: `NoNewPrivileges`, `CapabilityBoundingSet`, лимиты ресурсов; health/readiness.

— RS Bus unit: `rsbus.service` с `RestrictAddressFamilies=AF_UNIX`, `PrivateTmp=yes`, `ProtectSystem=strict`, `UMask=007`, лимитами `MemoryMax`/`TasksMax`.

## 12) План миграции (вехи)

- Этап 1 (нед. 1–2): RS Bus (UDS, health/фрейминг/метрики) + Hyperloop (parser/exec), golden‑наборы, инспекторы parity/perf/security.
- Этап 2 (нед. 3–4): P27 Guard (валидатор цепочек), P29 горячие инспекторы.
- Этап 3 (нед. 5–6): P44 PDP (read‑only решения), Two‑Keys verify.
- Этап 4 (нед. 7–8): P30 Processor (планировщик/таймеры), WebAuth горячие точки.
- Каждый этап — canary 24–48h, отчёт метрик/дефектов, обновление документации.

## 13) CI/CD

`cargo fmt` → `clippy -D warnings` → `cargo test` → `cargo audit` → (опц.) `cargo fuzz`.

SBOM: CycloneDX; отчёт в PR: p50/p95/p99, ошибки, покрытие, audit/deny, список зависимостей.

## 14) Threat‑model / fuzz

Поверхности: парсер DSL, лимитеры/таймауты, PDP парсинг.

Атаки: переполнения, JSON‑billion laughs, Unicode edge‑cases, path traversal UDS.

Митигаторы: лимиты, timeouts, отказ сети/исходящих, чёткие коды ошибок.

## 15) Документы/реестры

- Этот документ + приложения: `P27R_TZ_Signature_Guard_Rust_v1_0.md`, `P29R_TZ_Gendarme_Rust_v1_0.md`, `P30R_TZ_Processor_Rust_v1_0.md`, `P44R_TZ_Policies_PDP_Rust_v1_0.md`.

- Обновить `docs/PROJECT_STRUCTURE_v8_0_4.md`, `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8_2.md`.

## 16) Бесшовная миграция и режим canary (без простоя)

- Режимы прогрева/замещения:

  - `python_only` → базовый режим (эталон, метрики/трейсы каноничны).

  - `rs_shadow` → Rust выполняет те же вызовы «в тени», результат сверяется, ответ клиенту даёт Python.

  - `rs_canary` (5–10% трафика) → реальный ответ может прийти из Rust; несоответствия фиксируются инспектором `rs.parity` (P29R) и уходят в инциденты/дашборд.
  - Профиль включения через Hyperloop: `FLAGS.APPLY_PROFILE name="rs_canary_profile"` (включает `rs.hyperloop.enabled=true`, `rs.hyperloop.mode=rs_primary_python_fallback`, `rs.hyperloop.canary_share=0.1`).

  - `rs_primary_python_fallback` → Rust по умолчанию, при сбоях — мгновенный fallback на Python, возврат 200/корректный ответ.

  - `rs_primary_no_fallback` → финальный режим (после soak 24–48h).

- Здоровье/готовность: отдельные `health/readiness` для каждого RS‑сайдкара; переключение по фичефлагу только при `readiness=ok` и стабильном SLA (p95).

— RS Bus readiness — обязательный гейт перед `rs_canary`.

- Backpressure: при деградации метрик RS включается `backpressure_on`, API мост переключает на Python, RS остаётся в `shadow`.

- Наблюдаемость: отчёт canary по p50/p95/p99, error‑rate, parity‑mismatch‑rate, guard‑pass‑rate.

## 17) Реестр преемственности (Registry of Succession)

- Назначение: фиксировать предсказуемый переход функций/модулей от Python к Rust.

- Модель (канонично в БД/реестре P27 Function Registry):

  - `module_id`, `function_id`, `owner`, `lang_state` ∈ {`python_only`,`rs_shadow`,`rs_canary`,`rs_primary_python_fallback`,`rs_primary_no_fallback`}, `since_ts`, `canary_share`, `sla_targets`, `notes`.

- Интеграции:

  - P27: шаги подписи дополняются `svc.rs.proxy`/`cmd.hyperloop.*` при RS.

  - P29: инспектор `rs.parity` и `rs.performance_sla` потребляют реестр и проверяют соответствие режимов.

  - P28: профили `prod_safe/canary_on/diagnostics_on` управляют переключением.

- Acceptance: любая смена `lang_state` требует зелёных инспекторов P29R, стабильного SLA и отчёта canary.

## 18) Двухязычная архитектура: целесообразность и правила

- Критерии оставить Python (временно):

  - отсутствуют зрелые/аудированные аналоги в Rust (библиотеки/драйверы),

  - бизнес‑логика тесно связана с ORM/БД/экосистемой Python,

  - накладные расходы на PyO3/FFI ниже сетевой прокси и оправданы горячим путём.

- Правила безопасности/надёжности/скорости при двух языках:

  - RS‑компоненты — stateless; секреты не читают; только чистые вычисления.

  - Все опасные действия (мутирующие БД/сеть) — через Python PEP/Two‑Keys.

  - Контракты строго JSON; версионирование через `version`/`schema` поля; совместимость назад не ломаем.

  - Измеряем overhead: p95 моста ≤ 0.8 ms; при превышении — PyO3 локальный модуль (с изолированным `unsafe` и аудитом) или ре‑дизайн.

- Стратегия закрытия ядра на Rust:

  - Этап 1–2: выделение горячих путей в RS‑сайдкары.

  - Этап 3: перенос PDP/Guard/инспекторов (read‑only) в RS для мс‑латентности.

  - Этап 4: «ядро на Rust, Python как обёртка» — Python экспортирует прежние интерфейсы API/UI/DSL, делегируя в Rust; для внешнего мира сохранён контракт Python, внутри — RS выполняет вычисления.

  - Условие финального перевода: `rs_primary_no_fallback` ≥ 30 суток без инцидентов класса A, SLA стабилен.

## 19) Риски и митигации

- Семантические расхождения Python↔Rust:

  - Митигатор: golden‑наборы (≥100/зона), инспектор `rs.parity`, отчёты diff, блокировка режима `primary` при рассинхронизации.

- Дрейф схем I/O:

  - Митигатор: версионирование контрактов, CI‑снапшоты, `SchemaGuard` на ответы RS.

- Перегрев/утечки в RS:

  - Митигатор: soak‑тесты 24–48h, `memory_max`, leak‑детекторы, авто‑переключение на Python.

- Таймауты/Backpressure:

  - Митигатор: явные таймауты, прерывание по сигналу, `backpressure_on` и деградация до Python.

- Безопасность/секреты:

  - Митигатор: нулевой доступ RS к секретам; Two‑Keys на опасные пути; аудит шагов `svc.rbac.*`/`cmd.hyperloop.authz.*` присутствует.

## 20) Жандарм (P29) — внутренние тесты и гейты

- Наборы: `rs.parity`, `rs.performance_sla`, `rs.security_limits` (см. P29R).

- Гейты переключения `lang_state`:

  - `shadow→canary`: p95 в бюджете, parity mismatches ≤ 0.5% за окно 24h.

  - `canary→primary_fallback`: p95 в бюджете, mismatches ~ 0, ошибок < порога; отчёт инспектора.

  - `primary_fallback→primary`: 24–48h soak без фоллбэков и инцидентов класса A.

- Hyperloop сценарии регресса: `INSPECTOR.RUN_ALL`, `CORE.PIPELINE.RUN ... WITH TRACE`, `TRACE.STEPS` — в ответе RS/Proxy есть корректный `trace_id` и шаги подписи.

## 21) Порядок изменений и преемственность

- Любая функция при переносе метится в реестре преемственности; PR содержит:

  - ссылку на функцию/модуль,

  - целевой `lang_state`,

  - отчёт Жандарма и метрики SLA,

  - план отката (флаги/единицы systemd).

- Откат: перевод `lang_state` на предыдущий, выключение флага зоны, рестарт sidecar; сервис остаётся доступным.

## 22) Python‑wrapper (фасад совместимости)

- Идея: внешние интерфейсы (API/DSL/UI) продолжают обращаться к Python, который делегирует вычисления в RS.

- Плюсы: прозрачность для FE/клиентов, быстрый откат, единая авторизация/аудит.

- Правила:

  - Python фасад реализует PEP/PDP/Two‑Keys и сохраняет шаги подписи (P27).

  - RS — чистые вычисления; коды ошибок мапятся в единый формат.

  - При готовности ядра к полному RS Python остаётся тонким слоем совместимости.

## 23) Двухконтурная безопасность (Control/Data planes)

- Контур A (внешний, контрольный): Python фасад (API/PEP/PDP/Two‑Keys), Nginx, WebAuth, аудит/метрики.

  - Экспонируемые порты: только HTTP(S); заголовок `X‑Telegram‑User‑ID` обязателен.

  - Решения допуска (RBAC/ABAC/Two‑Keys) принимаются только здесь; шаги `svc.rbac.*` и `cmd.hyperloop.authz.*` записываются до делегации в RS.

- Контур B (внутренний, вычислительный): Rust сайдкары (UDS), без сети/секретов, только чистые функции.

  - Развёртывание: отдельные systemd‑юниты с `NoNewPrivileges=yes`, `PrivateTmp=yes`, `ProtectSystem=strict`, `CapabilityBoundingSet=` (пусто), `MemoryMax=...`, `TasksMax=...`.

  - Доступ: только UDS‑сокеты в каталоге `/run/soul/*.sock` с ACL по группе `soulops`.

- Политика egress/ingress:

  - RS: полное отсутствие egress (nftables/iptables cgroup rules); ingress — только UDS.

  - Python: наружу — ограниченный список доменов (LLM провайдеры), Two‑Keys на опасные команды.

- Откат/kill‑switch: фичефлаг `rs.enabled=false` на фасаде переводит все вызовы в Python‑реализацию мгновенно.

## 24) 7‑уровневая архитектура решения

1) Web‑клиент (браузер/MiniApp)

2) Frontend (SPA, статика за Nginx; Telemetry minimal)

3) Python фасад API (FastAPI) — PEP/PDP/Two‑Keys, аудит/санитайзинг, Hyperloop endpoint

4) AuthZ/Policies (P44) и инспекторы (P29) — гейты переключений RS

5) Rust ядро (RS‑сервис(ы): Hyperloop/P27/P30/PDP) — UDS‑изолят, без сети/секретов

6) БД (PostgreSQL 16.x) — доступ строго из Python; RS не ходит в БД

7) Firewall/Nginx/systemd sandbox — сетевые/процессные ограничения и health/readiness

- Трасса: client → Nginx → Python(PEP) → (UDS) RS → Python(post‑processing/guard) → client.

- Наблюдаемость: общий trace_id; спаны Python/RS связаны; метрики p95/p99 по уровням.

## 25) Маскировка Python→Rust (без «security by obscurity»)

- Экспонируется только Python; идентификаторы RS не раскрываются в API/логах клиенту.

- Единый формат ошибок/логов; коды RS мапятся в нормализованный ответ фасада.

- Контракты I/O JSON (версионируемые); несовместимости блокируют переключение `lang_state`.

- Фичефлаги переключений (см. §16/20): `shadow/canary/primary_fallback/primary` с инспекторами Жандарма.

## 26) Firewall/UDS и системные ограничения

- Nginx: только HTTPS; `proxy_read_timeout`/`proxy_send_timeout`=120s (см. PROJECT_STRUCTURE), HSTS/CSP/XFO корректны.

- UDS каталог `/run/soul` владельцем `soulpulse-backend`; сокеты 660, группа `soulops`.

- nftables/iptables:

  - Блокировать любые egress для cgroup RS‑юнитов; разрешить только loopback/UDS.

  - Разрешить Python egress на whitelisted домены провайдеров LLM.

— UDS каталоги/ACL для RS Bus: `/run/soul` владелец `root`, группа `soulops`, права каталога `0770`, сокеты `0660`; Python фасад в группе `soulops`.

- systemd Hardening: `PrivateDevices=yes`, `ProtectHome=read-only`, `ProtectHostname=yes`, `RestrictAddressFamilies=AF_UNIX`, `RestrictSUIDSGID=yes`.

## Приложение: Контракты ошибок (единый формат)

```json
{ "ok": false, "code": 400|401|403|409|422|429|500, "error": "parse_error|policy_denied|two_keys_required|invalid_json_contract|timeout|engine_error", "reason": "...", "trace_id": "..." }

```

## 27) Runbook для LLM‑разработчика (пошагово)

Шаг 0. Подготовка

- Включить профиль `prod_safe`; проверить Health/DB/LLM/Hyperloop смоки (см. PROJECT_STRUCTURE).
- Убедиться: RS‑юниты установлены, UDS сокеты созданы, `readiness=ok`.

Шаг 1. Выбор функции для переноса

- Найти `function_id` в P27 Function Registry; зафиксировать `owner`, SLA, зависимости.
- Добавить запись в Реестр преемственности: `lang_state=python_only → rs_shadow`.

Шаг 2. Контракты I/O

- Описать JSON схемы request/response (версия v1); добавить пример(ы).
- В Python фасаде — валидация входов, нормализация; на RS — строгая десериализация.

Шаг 3. RS‑имплементация

- Реализовать чистую функцию (без сети/секретов/БД), метрики, спаны.
- Подключить UDS‑хендлер и адаптер в Python (`*_bridge_rs.py`).

Шаг 4. Тесты

- Golden‑наборы (≥50+/≥50−) Python↔RS; property/fuzz.
- Инспекторы Жандарма: `rs.parity`, `rs.performance_sla`, `rs.security_limits`.

Шаг 5. Shadow

- Включить `rs_shadow`: фасад вызывает RS в тени; клиенту отвечает Python.
- Собирать метрики parity/p95; исправить расхождения.

Шаг 6. Canary

- `rs_canary` 5–10% трафика; гейты: mismatches ≤ 0.5%/24h, p95 в бюджете.
- При фейлах — авто‑возврат к `shadow`.

Шаг 7. Primary (с fallback)

- `rs_primary_python_fallback`; soak 24h, фоллбеки ниже порога.
- Включить алерты на p95/ошибки/паритет.

Шаг 8. Primary (финал)

- `rs_primary_no_fallback`; soak 48h, инциденты класса A=0.
- Зафиксировать `lang_state` и обновить реестр/доки.

Шаг 9. Документация/реестры

- Обновить P48R (разделы функции/контракты/метрики), Master Registry, Project Structure.

## 28) Совместимость функций и интеграция (матрица)

Категории функций

- Hyperloop: parse/exec/proxy → RS; опасные группы (NET/DB/SCHEMA/DEPLOY) — решение допуска в Python (P44), RS только проверка/планирование.
- P27 Guard: валидация цепочки → RS; публикация ответа — Python Guard.
- P29 Инспекторы: быстрые проверки → RS; агрегация/панели — Python.
- P30 Processor: tick/agenda → RS; persist/notify/DB — Python.
- P44 PDP: решение → RS; PEP/Two‑Keys/headers/JWT — Python.

Границы интеграции

- Секреты/БД/сеть — только Python; RS — чистые вычисления.
- Контракты JSON версии `v1`; назад‑совместимые изменения: `additive`; breaking — только с bump версии и гейтами.
- Трассы: общий `trace_id`; шаги `cmd.hyperloop.*` и `svc.rbac.*` фиксируются до делегации в RS.

Политика версионирования I/O

- Семантика `vMAJOR.MINOR`: MINOR — `additive` поля (необязательные); MAJOR — breaking (только через shadow→canary→primary гейты, с двойной поддержкой в фасаде).

Коды ошибок/маппинг

- RS ошибки → фасад: `parse_error→400`, `invalid_json_contract→422`, `policy_denied→403/409/402/429` по причинам (см. P44R), `timeout→504`, `engine_error→500`.

## 29) Реестр совместимости и преемственности (БД)

Назначение: единый источник истины о статусе переноса функций/модулей Python↔Rust, паритете, SLA и этапности, чтобы «не разъезжалось» при множественных подходах.

### 29.1 Схема БД (DDL, эскиз)

```sql
create table if not exists lang_succession_registry (
  id uuid primary key default gen_random_uuid(),
  module_id text not null,
  function_id text not null,
  owner text,
  lang_state text not null check (lang_state in ('python_only','rs_shadow','rs_canary','rs_primary_python_fallback','rs_primary_no_fallback')),
  io_version text not null default 'v1',
  canary_share numeric,         -- 0..1
  sla_targets jsonb,            -- {p95_ms:..., error_rate:...}
  parity_mismatch_rate numeric, -- последние 24h
  last_parity_at timestamptz,
  notes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create unique index if not exists ux_lang_succession_module_fn on lang_succession_registry(module_id,function_id);

create table if not exists lang_succession_history (
  id uuid primary key default gen_random_uuid(),
  module_id text not null,
  function_id text not null,
  from_state text,
  to_state text,
  reason text,
  author text,
  created_at timestamptz default now()
);

```

(Опционально) агрегаты паритета:

```sql
create materialized view if not exists lang_succession_parity_24h as
select module_id,function_id, avg(mismatch::int)::numeric as mismatch_rate
from rs_parity_events
where ts>now()-interval '24 hours'
group by module_id,function_id;

```

### 29.2 API (админ)

- `GET /api/admin/lang-succession` — список/фильтр по `lang_state,module_id,function_id`.
- `POST /api/admin/lang-succession` — upsert записи (RBAC: architect/admin).
- `POST /api/admin/lang-succession/transition` — зафиксировать переход `from→to` с reason (обновляет `lang_state`, добавляет history).
- `GET /api/admin/lang-succession/history?function_id=...` — история переходов.

Требуется заголовок `X-Telegram-User-ID`; все операции аудируются; шаги P27 `svc.rbac.*`/`cmd.hyperloop.authz.*` записываются.

### 29.3 Правила ведения

- Единственная точка правды: любые изменения статуса переносятся в реестр немедленно PR‑владельцем.
- Переходы только по гейтам Жандарма (см. §20) и при соблюдении SLA (см. §3).
- `io_version` повышается при breaking‑изменениях контрактов; Python фасад должен поддерживать двойной режим до завершения перевода.
- Автосинхронизация: инспекторы могут обновлять `parity_mismatch_rate` и `last_parity_at` по результатам прогона.

### 29.4 Связи с Runbook

- Runbook Шаг 1/8/9 (см. §27): создание/обновление записей реестра на входе/выходе этапов, фиксация переходов в history.

## 30) Статус реализации (2025‑09‑24) и разрыв с ТЗ

Итоги инкремента (выполнено):

- RS System Bus (UDS) внедрён: `/run/soul/rsbus.dev.sock`, length‑prefixed JSON кадры; sandbox systemd; доступ группы `soulops`.
- Мосты Hyperloop/P27/P29 поддерживают `unix://…`; делегация по UDS включена.
- Hyperloop переведён в `rs_primary_python_fallback` (ENV + FLAGS); Python остаётся фасадом и fallback.
- Метрики RS Bus (через UDS `op=metrics`): `rsbus_latency_ms{op}`, `rsbus_requests_total{op}`, фазовые `hyperloop_rs_latency_ms{phase=parse|exec|total}`.
- Инспекторы: `rs.parity/p29_health/p27_guard` — passed (виден `svc.rs.proxy`).
- CLI `rsbusctl` (Rust) для `health/metrics/exec` по UDS.
- Нагрузочный прогон 500× `hyperloop.execute`: overhead шины — суб‑миллисекундный (все вызовы в бакете `≤0.1 ms`).

Не реализовано/в работе:

- RS‑исполнитель Hyperloop: минимальный (echo‑стаб), без реального parse/exec DSL.
- Инспектор `rs.security_limits` — отсутствует.
- OTel спаны (parse/exec/proxy) — не подключены.
- Golden‑наборы паритета (≥100+/100−) и property/fuzz тесты — не собраны.
- Реестр преемственности (DDL/API `lang_succession_*`) — не внедрён.
- P44 PDP RS и P30 Processor RS — не начаты в этом инкременте.
- Backpressure (`rsbus_backpressure_on`, лимиты очередей) — не включён.
- Переход Hyperloop в `rs_primary_no_fallback` — не выполнен (требуется soak 24–48h и расширение покрытия RS‑команд).

Дальнейшие шаги:

1) Расширить RS Hyperloop: безопасный парсер/исполнитель подмножества команд (без БД/сети), нормализованные ответы/подпись.
2) Подключить OTel + метрики backpressure; собрать p50/p95/p99 на канареечной нагрузке.
3) Реализовать `rs.security_limits`; подготовить и прогнать Golden‑наборы паритета.
4) Внедрить реестр преемственности (DDL+API) и протокол переходов `lang_state`.
5) При зелёных метриках 24–48h — перевести Hyperloop в `rs_primary_no_fallback`.
6) Запустить P44 PDP RS и P30 Processor RS (read‑only функции) параллельно.

Проверка (актуальные команды):

```bash
# RS Bus (UDS)
rsbusctl --sock /run/soul/rsbus.dev.sock health
rsbusctl --sock /run/soul/rsbus.dev.sock metrics | head -n 40
rsbusctl --sock /run/soul/rsbus.dev.sock exec --commands 'CORE.PIPELINE.RUN input_text="ping" WITH TRACE'

# Hyperloop API (rs_primary_python_fallback)
curl -sS -H 'X-Telegram-User-ID: 468326902' -H 'Content-Type: application/json' \
  -d '{"commands":"INSPECTOR.RUN key=rs.parity"}' http://127.0.0.1:8000/api/hyperloop/execute
```


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
