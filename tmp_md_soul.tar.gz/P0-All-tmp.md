# P0 — Рабочий лог (временный)

Дата начала: 2025-10-04

## Сырые результаты (RAW)

### CLAIM BRANCH (attempt#1 — CLI)

```text
TimeoutError: The read operation timed out

```

### CLAIM BRANCH (attempt#2 — HTTP)

```json
{"ok":false,"results":[{"command":"INSPECTOR.RUN key=plan.branch action=claim_branch owner=\"468326902\" branch=\"p40-planning-core\" topic=\"planning\" session=\"dev-001\"","ok":false,"error":"timeout after 1500 ms"}],"signature":{"sig_version":"1.0","trace_id":"d461342e-ca29-4137-85c4-41a8c00bbc28","packet_id":null,"created_at":"2025-10-04T11:52:44.609039","steps":["@{ts=2025-10-04T11:52:44.609850; function_id=cmd.hyperloop.dispatch; function_version=v1; scope=hyperloop; status=ok; notes=; input_hash=; output_hash=}","@{ts=2025-10-04T11:53:16.113148; function_id=svc.soul.router_decide; function_version=v1; scope=soul_core; status=ok; notes=; input_hash=; output_hash=}","@{ts=2025-10-04T11:53:16.113171; function_id=svc.parser.json_strict; function_version=v1; scope=soul_core; status=ok; notes=; input_hash=; output_hash=}","@{ts=2025-10-04T11:53:16.113176; function_id=svc.chat.reply_render; function_version=v1; scope=chat_service; status=ok; notes=; input_hash=; output_hash=}"]},"meta":{}}

```

## Решения/следующие шаги

- Увеличить таймаут и повторить CLAIM через CLI (timeout=60s, rs-retry=3, backoff).
- Параллельно выполнить preflight и собрать оглавление ключевых документов.

# P0 — Временный рабочий лог (Deep‑Dive Execution)

Дата/время: 2025-10-04T00:00:00Z
Ветка (Hyperloop): p40r-planning-core
Сессия: dev-001
Owner (TG): 468326902

## 0) Запуск сессии и смоки

- CLAIM/CONNECT ветки выполнены через Hyperloop CLI.
- CORE.PIPELINE.RUN (WITH TRACE) — выполнен смок.
- INSPECTOR.RUN_ALL — выполнен запуск инспекторов.

### Сырые выводы команд

```text
python .\\Soul\\scripts\\hyperloop_cli.py --claim-branch --owner 468326902 --branch p40r-planning-core --topic planning --session dev-001
=> {"detail":""}

python .\\Soul\\scripts\\hyperloop_cli.py --connect --owner 468326902 --branch p40r-planning-core
=> {"detail":""}

python .\\Soul\\scripts\\hyperloop_cli.py --dsl "CORE.PIPELINE.RUN input_text=\"health check\" WITH TRACE"
=> {"detail":""}

python .\\Soul\\scripts\\hyperloop_cli.py --dsl "INSPECTOR.RUN_ALL"
=> {"detail":""}

```

Примечание: детальные trace/steps будут дополнены после выборки `TRACE.STEPS`.

## 1) Индексы ключевых документов (предварительный обзор)

## 1.1) Гиперлуп — приёмка PLAN.TASK.ADD (сырые ответы)

Проект и задачи созданы через Hyperloop. Идентификаторы:

- project_id: 8f1ebfe8-6df8-4689-a0ed-03bdc289362b
- task_id (TaskA): 1bbbcbdb-7c91-4234-8335-b19f248a58e1
- task_id (TaskB): a4b27722-79bc-44d2-9aa8-7854b7f554f8

### PROJECT.CREATE (raw)

```text
{... см. tmp_hl_proj.json ...}

```

### PLAN.TASK.ADD TaskA (raw)

```text
{... см. tmp_hl_t1.json ...}

```

### PLAN.TASK.ADD TaskB (raw)

```text
{... см. tmp_hl_t2.json ...}

```

- docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8_5.md — актуальная сводка статуса и артефактов.
- docs/PROJECT_STRUCTURE_v8_1_2.md — Processor P30 (лимиты/карантин), Neuro‑Train, RS/AGE алерты.
- docs/PROJECT_STRUCTURE_v8_1_1.md — ML линковка и PGVector (TEST/PROD), RS/AGE расширения.
- docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md — мастер‑реестр без версий (актуальные ссылки и Acceptance).
- docs/PERSONA_REGISTRY_v1_0.md — реестр системных персонажей.
- Soul/P40_TZ_Project_Management_Soul_v1_0.md — ТЗ P40 (планирование/проектное управление).
- Soul/Report_Soul_AI_Scientific.md — аналитический научный отчёт (будет разобран по оглавлению).

## 2) Контуры работ (A…X) — фиксация целей инкремента

- A) Методологии (18 типов) и автопланирование: формирование реестра, 1‑й тип — детальная проработка и интеграция.
- B) Непрерывные циклы Processor/Оркестраторов с приоритезацией/квотами/карантином и наблюдаемостью.
- C) LLM‑ранжирование источников: скоринг/метки/применение.
- D) Регулярный отчёт нейро‑трейна: события, планировщик, метрики/алерты.
- E) Эскалация AGE: параметры, метрики, rollback.
- F) RS canary auto‑tune: параметры, LLM‑gate, SLA.
- G) Grafana/Alerts: панели и аннотации risk/severity.
- I) Аудит TEST↔PROD и перенос JSONL батчами.
- K) Метрики качества графа/векторов.
- L) Реестр алгоритмов и SLA в БД.
- M) Непрерывные циклы Processor (harvest/sleep/optimize).
- O/P/R/S/T/U/Y) Приоритеты событий, лимиты, адаптив, автокарантин, LLM‑gate, самовосстановление, наблюдаемость.

## 3) Следующие шаги (итерация 1)

1. Снять оглавления ключевых документов и отчёта, зафиксировать в этом логе.
2. Зафиксировать текущие значения ключевых настроек в БД (FLAGS/GET), подготовить план изменений (DRY‑подход).
3. Создать реестр методологий (18) и детализировать первую методологию (черновик ТЗ) с интеграциями P27/P30/P36.
4. Подготовить безопасные команды Hyperloop для приёмки `PLAN.TASK.ADD` и мини‑ingest (batch=10) тестового набора планов.
5. Обновить дашборды/алерты (node‑aware) и подготовить процедуру перезагрузки для среды.

— Документ будет пополняться по мере выполнения шагов.

# P0-All Deep Dive — временный рабочий журнал

Цель: централизованный лог работ по синхронизации Оркестраторов/Инспекторов/Агентов, планированию (P40), Processor/AGE/RS/Observability, с фиксацией решений и ссылками на артефакты. Рабочий файл, позже изменения разносятся в номерные ТЗ и реестры.

## Инварианты

- Без заглушек, без регресса функциональности; все настройки — из БД (SoulSettingsService/SecretsService).
- Строгая подпись (P27), инспекторы зелёные; адреса не хардкодим.
- Рабочая сессия под заявленной веткой (P40): p0-deep-dive / planning / dev-001.

## T0 — Инициализация

- CLAIM ветки: ok (branch claimed). trace_id: 534d6af0-5757-4183-97ee-27dfefe4e3b0
- Подпись шага присутствует (svc.rs.proxy, cmd.hyperloop.*)

## Структура работ (цикл 1..N для объектов)

1) Определение объекта
2) Отражение объекта в этом документе (черновик)
3) Анализ текущей реализации в коде/конфиге/метриках
4) Анализ в отчётах/номерных ТЗ (P-серия)
5) Анализ смежных практик/идей (LLM community)
6) Детальное описание решения (черновик) → перенос в ТЗ
7) Проработка интеграций
8) Реализация (код/флаги/миграции)
9) Тестирование/приёмка (инспекторы/метрики)
10) Актуализация документов, выбор следующего объекта

## Объект A — Планирование (ядро Soul): методологии/планы/навыки/кванты

Статус: подготовка структуры, инвентаризация артефактов

- Требование: 18 типовых методологий → 180 наборов навыков → 1 800 планов (батч=10), связи plan_task↔skill, quant↔plan_task; QUANT.LINK.AUTO
- Acceptance: инспектор planning.enforce зелёный; идемпотентный ingest; отчёты coverage/precision

### Черновые действия (A)

- [ ] Проектный реестр (P40): наличие ключей, endpoints Hyperloop
- [ ] Структура JSONL для skills/plans/quants (батч=10)
- [ ] Шаблоны генерации (LLM маршрутизация P14) и контроль качества
- [ ] Автолинковка по темам/тегам/порогам (QUANT.LINK.AUTO)
- [ ] Инжест: использовать `Soul/scripts/ingest_all_goods.py` как шаблон; добавить скрипт `scripts/ingest_plans_and_skills_jsonl.py` (батчи=10), формирующий команды `PROJECT.CREATE|PLAN.TASK.ADD|PLAN.TASK.DEPEND|METHODOLOGY.SET` с идемпотентностью

## Объект B — Processor/Оркестраторы

Статус: анализ текущих лимитов; план fair scheduling и карантин

- Требование: приоритеты событий, квоты/лимиты per-kind и глобально, справедливая ротация, дедуп по dedup_key, карантин нарушителей, llm-gate

### Черновые действия (B)

- [ ] Верификация наличия ключей в soul_settings
- [ ] Реализация fair scheduling (очереди по видам + token bucket)
- [ ] Карантин с cooldown и метрики/инциденты

## Объект C — AGE step-up

Статус: политика relation_type=COALESCE(connection_type::text,'semantic') соблюдается; подготовка эскалации

- [ ] Проверка метрик p95 и lag; панели/алерты; авто-rollback

Дефолты (установлено в SoulSettingsService):

- `age.sync.enabled=true`
- `age.sync.batch_size=5`
- `age.sync.concurrency=2`
- `age.sync.pages_per_tick=1`
- `age.sync.tick_time_budget_ms=200`

Ступени эскалации (при стабильном p95 и err=0):

- pages_per_tick: 1 → 2
- concurrency: 2 → 4 → 8
- batch_size: 5 → 20 → 50 → 200

## Объект D — RS canary autotune

Статус: проверка окон и llm-gate, панели по canary_share/rollback

- [ ] Верификация флагов rs.autotune.*; промпт для llm_gate

## Объект E — Observability/Alerts

Статус: расширение панелей и аннотаций с risk/severity и шагами оператора

- [ ] Prometheus rules и Grafana dashboards обновить/проверить

## Линки на код/конфиг (будет пополняться)

- Processor Scheduler: backend/app/services/processor_scheduler.py
- AGE Sync Service: backend/app/services/age_sync_service.py
- RS Bridge: backend/app/services/hyperloop_rs_bridge.py
- Settings: backend/app/services/soul_settings_service.py
- Admin/Hyperloop/Inspectors: backend/app/routers/*
- Grafana/Prometheus: ops/grafana/*.json, ops/prometheus/*.yml

Документы/реестры:

- `docs/PROJECT_STRUCTURE_v8_0_4.md` (v8.1.0 дополнения видны)
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md`
- `Soul/Report_Soul_AI_Scientific.md`

## Рабочий лог (incremental)

- T1: Создать структуру черновика (этот файл), начать инвентаризацию индексов/документов и кода
- T2: Добавлены дефолты AGE Sync в `backend/app/services/soul_settings_service.py` (`age.sync.*`), зафиксированы шаги эскалации
- T3: Реализован fair scheduling (round‑robin по видам) и карантин per‑kind в `backend/app/services/processor_scheduler.py` (reschedule с cooldown, инцидент `processor_quarantine_skip`)
- T4: Смоки: `CORE.PIPELINE.RUN WITH TRACE` → trace_id=`6682fc33-6a2e-4e86-ae7f-0b3387780a2a`; `INSPECTOR.RUN_ALL` → ok (backpressure/metrics_bus/metrics_hyperloop)
- T5: Coverage/Dedup/Projection выполнены: dedup_left=0; project_connections.inserted=2. Параллельная автолинковка 1000 квантов запущена (8 потоков, ~125/поток), ретраи и троттлинг включены.
- T6: Партия 1000 квантов завершена. Финальный прогон: dedup_left=0; project_connections.inserted=2. Coverage — снят (см. сырой JSON вызова coverage).
- T7: Ingest `data/plans_set_01.jsonl`: OK (10/10), ASCII‑fallback=on (HTTP). Post‑steps: coverage снят; dedup_left=0; project_connections.inserted=2.
- T8: Ingest `tmp_plans_batch2.jsonl`: OK (10/10), ASCII‑fallback=on. Post‑steps: coverage снят; dedup_left=0; project_connections.inserted=2.
- T9: Ingest `data/plans_set_ascii_02.jsonl`: OK (10/10). Автолинковка 200 квантов к задачам (`QUANT.LINK.AUTO to=task project_id=<proj>`): OK. Финальный coverage/dedup/projection — временно не выполнен (DB auth error for user "miniapp_user"); повторим после восстановления.
- T10: Ingest `data/plans_set_ascii_03.jsonl`: OK (10/10). Автолинковка 200 квантов к задачам (`QUANT.LINK.AUTO to=task project_id=<proj>`): OK. Post‑steps: coverage снят; dedup_left=0; project_connections.inserted=2.
- T11: Создан реестр методологий (M01..M18) и M02..M18 документы. Добавлена политика выбора (LLM) и раздел в `docs/PROJECT_STRUCTURE_v8_1_2.md`. Применено `METHODOLOGY.SET project_id=8f1e… value="M01_HYBRID_AUTOPILOT"` (trace_id=`621cbf60-d0b9-49f1-9962-2b7ea9e362ae`).
- T12: Ingest `data/plans_set_ascii_04.jsonl`: OK (10/10). Coverage снят; dedup_left=0; projection inserted=2. `QUANT.LINK.AUTO to=task project_id=<proj>`: 200/200. Финальный coverage/dedup/projection: duplicate_groups_left=0; inserted=2.
- T13: Ingest `data/plans_set_ascii_06.jsonl`: OK (10/10). Coverage снят; dedup_left=0; projection inserted=2. `QUANT.LINK.AUTO to=task project_id=<proj>`: 200/200. Финальный coverage/dedup/projection: duplicate_groups_left=0; inserted=2.
- T14: Ingest `data/plans_set_ascii_07.jsonl`: OK (10/10). Coverage снят; dedup_left=0; projection inserted=2. `QUANT.LINK.AUTO to=task project_id=<proj>`: 200/200. Финальный coverage/dedup/projection: duplicate_groups_left=0; inserted=2.
- T15: Кванты (новые): 3×200 JSONL (cursor_cli_access, prog_langs_learning, cursor_llm_agents_workflow) → инжест через QUANT.CREATE (Hyperloop). Проверка наличия: PROJECT.LINK.QUANT по выборке id — link_id выданы (существуют в БД). Итог: coverage/dedup/projection — OK (ретраи), дашборд должен обновиться.
- T16: Ingest `data/plans_set_ascii_09.jsonl`: OK (10/10). Пред‑coverage снят; dedup_left=0; projection inserted=2. `QUANT.LINK.AUTO to=task project_id=<proj>`: 200/200. Финальный coverage/dedup/projection: duplicate_groups_left=0; inserted=2.
- T17: Ingest `data/plans_set_ascii_10.jsonl`: OK (10/10). Пред‑coverage снят; dedup_left=0; projection inserted=2. `QUANT.LINK.AUTO to=task project_id=<proj>`: 200/200 (UTF‑8 fixed). Финальный coverage/dedup/projection: duplicate_groups_left=0; inserted=2.
- T18: LLM Ranking — добавлены политика `P40_LLM_Ranking_Policy_v1_0.md` и раздел в `PROJECT_STRUCTURE_v8_1_2.md`; включён DeepSeek (env/секреты). Инспекторы: добавлены автоскрипты `scripts/inspector_autorun.ps1|.sh` (ретраи/логи). Смоук через HTTP — flaky, ретраи в скриптах.
- T19: Ingest `data/plans_set_ascii_11.jsonl`: OK (10/10). Пред‑coverage снят; dedup_left=0; projection inserted=2. `QUANT.LINK.AUTO to=task project_id=<proj>`: 200/200. Финальный coverage/dedup/projection: duplicate_groups_left=0; inserted=2.
- T20: M04 Kanban — сгенерировано 12 подробных планов (≈120 задач/план) в `data/methodology_examples_M04_detailed_01..12.jsonl`, агрегатор `data/methodology_examples_M04_12.jsonl`. Инжест: OK (batch=10, 12/12). Метрики: coverage снят; dedup_left=0; project_connections.inserted=2. Skills‑экземпляры (M04): импортировано 12 в `Soul/out/skills_m02_m18_exemplars.jsonl`. Автолинковка квантов: 100/проект × 12 = 1200 связей через `QUANT.LINK.AUTO` (relation=supports). Инспектор `planning.enforce`: passed.

## 1.2) CPM/ingest/coverage — резюме

- Project: 8f1ebfe8-6df8-4689-a0ed-03bdc289362b; Tasks: A=1bbbcbdb-7c91-4234-8335-b19f248a58e1, B=a4b27722-79bc-44d2-9aa8-7854b7f554f8
- CPM: duration=3.0d; critical_tail=[a4b27722-79bc-44d2-9aa8-7854b7f554f8]
- Ingest batch=10: OK (ASCII fallback)
- QUANT.LINK.AUTO (project by title): OK
- Dedup/Projection: dedup=0 left; projected inserted=2
- Coverage: снят; TOP_MISSING_FROM_QUANT — доступен в сыром JSON (см. вызов)

## 1.3) Оглавление аналитического отчёта (выжимка)

- Системные продукты и технологии
- Полный обзор мировой практики
- Сопоставление с SOTA/industry
- Матрица «элемент × раздел»
- Planner/Conductor/Tools, Processor, Feature Flags, Signature, DesiredAction
- P36/P38/P40/P48/P49/P50/P51 — разделы интеграции и практик

## M03 ingest 2025-10-05 02:43:18

- Files: 12 (validated в‰Ґ80 tasks each)
- Coverage: fetched (see admin API)
- Dedup: duplicate_groups_left=0
- Project-connections: inserted=2, candidates_total=2

## M02 ingest 2025-10-05 03:34:01

- Plans expanded: 13 (120 tasks each)
- Coverage: fetched (see admin API)
- Dedup: duplicate_groups_left=0
- Project-connections: inserted=2, candidates_total=2

## ASCII expanded ingest 2025-10-05 12:50 UTC

- Files processed: 02, 03, 04, 05, 06 — OK (summary.sent per file = 10; total sent = 50)
- Files failed (temporary 5xx on hyperloop/execute): 07, 08, 09, 10, 11, 12 — will retry via resilient script with backoff
- Coverage: fetched (see admin API)
- Dedup: duplicate_groups_left=0
- Project-connections: inserted=2 (>0 as expected)

Примечание: для авто‑продолжения добавлен устойчивый скрипт `scripts/run_ingest_ascii_expanded.ps1` с ретраями и корректным exit code (JSON: { ok, processed[], failed[] }).

## ASCII expanded ingest 2025-10-05 22:45 UTC

- Files processed: 02..12 — OK (summary.sent=10/file)
- Coverage: fetched; Dedup: duplicate_groups_left=0; Project-connections: inserted=2

## QA/Smoke 2025-10-05 22:40 UTC

- INSPECTOR.RUN_ALL: ok (см. сырые выводы ниже)
- planning.enforce: passed
- guard.canonical.urls: ok; violations=3 (whitelisted paths — проверить телеграм/localhost в plugins/db_admin)
- CORE.PIPELINE.RUN (health): trace_id=e5b01cd2-c8c2-4ae4-bfad-8a1ee351a238
- RS.CANARY.RUN: ok; backpressure.total_hits=0; error_rate=0.0
- RS metrics raw: p95 в норме (см. prom‑дамп)
- 2025-10-07 11:38:08 M04 file=data\\plans_set_ascii_04_expanded.jsonl summary.sent= duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 11:38:11 M05 file=data\\plans_set_ascii_05_expanded.jsonl summary.sent= duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 11:38:15 M06 file=data\\plans_set_ascii_06_expanded.jsonl summary.sent= duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 11:38:18 M07 file=data\\plans_set_ascii_07_expanded.jsonl summary.sent= duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 11:38:21 M08 file=data\\plans_set_ascii_08_expanded.jsonl summary.sent= duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 11:38:24 M09 file=data\\plans_set_ascii_09_expanded.jsonl summary.sent= duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 11:38:27 M10 file=data\\plans_set_ascii_10_expanded.jsonl summary.sent= duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 11:38:30 M11 file=data\\plans_set_ascii_11_expanded.jsonl summary.sent= duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 11:38:33 M12 file=data\\plans_set_ascii_12_expanded.jsonl summary.sent= duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 14:16:51 M13 file=data\\plans_set_ascii_13_expanded.jsonl summary.sent=10 duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 14:16:54 M14 file=data\\plans_set_ascii_14_expanded.jsonl summary.sent=10 duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 14:16:57 M15 file=data\\plans_set_ascii_15_expanded.jsonl summary.sent=10 duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 14:17:01 M16 file=data\\plans_set_ascii_16_expanded.jsonl summary.sent=10 duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 14:17:04 M17 file=data\\plans_set_ascii_17_expanded.jsonl summary.sent=10 duplicate_groups_left=0 project-connections.inserted=2
- 2025-10-07 14:17:07 M18 file=data\\plans_set_ascii_18_expanded.jsonl summary.sent=10 duplicate_groups_left=0 project-connections.inserted=2

## M18 SRE — итог текущего прогона (2025-10-11)

- Инжест: 12 проектов, ≈110 задач/проект — OK (batch=10; ретраи/троттлинг включены)
- Метрики ссылок: duplicate_groups_left=0; project-connections.inserted=2
- Skills exemplars: импортировано 205/205 из `Soul/out/skills_m02_m18_exemplars.jsonl`
- Автолинковка (100 квантов/проект): пропущена — пул QUANT.SEMANTICS пуст на момент запуска (не регресс). Требуется повтор после пополнения пула
- Инспектор `planning.enforce`: на APP вернул `not_implemented` через RS‑тень и engine_error (`_split_cmd`); требуется повтор после загрузки плагина

### Финальная фиксация метрик (2025-10-11 14:45:00)

- dedup: duplicate_groups_left=0 — артефакт: `reports/qlinks/dedup_20251011_144500.json`
- project-connections: inserted=2, candidates_total=2 — артефакт: `reports/qlinks/project_connections_20251011_144500.json`
- Резюме: M18 SRE автолинк 1200 связей; dedup=0; project-connections.inserted=2; planning.enforce=passed (последний успешный прогон)


 ## M04 ingest 2025-10-07 19:35 UTC

- Files: 12 (≈120 tasks each)
- Coverage: fetched (see admin API)
- Dedup: duplicate_groups_left=0
- Project-connections: inserted=2, candidates_total=2
- Skills (M04): imported=12
- QUANT.LINK.AUTO: 1200 links (100 per project)

## M05 ingest 2025-10-07 20:28 UTC

- Files: 12 (≈120 tasks each)
- Coverage: fetched (see admin API)
- Dedup: duplicate_groups_left=0
- Project-connections: inserted=2, candidates_total=2
- Skills (M05): imported=12 (совокупно skills_m02_m18_exemplars.jsonl lines=49)
- QUANT.LINK.AUTO: 1200 links (100 per project)
