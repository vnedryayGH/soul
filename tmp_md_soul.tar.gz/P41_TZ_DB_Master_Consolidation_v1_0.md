# P41 — ТЗ: Консолидация БД и восстановление ядра SoulPulse (DB Master Consolidation)

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — актуальные инвентари документов.
- `tmp_p_series_plan.json` — план анализа P‑серии; проверить перекрёстные ссылки с P27/P30/P36.
- `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md` — требования подписи для DB‑сервисов/Router.
- `Soul/P30_TZ_Soul_Processor_v2_0.md` — интеграция Processor/Dispatcher и политика DSN/наблюдаемости.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр документов.

Проект: SP-DB-REMEDIATION-2025-10  
Ветка (branch key): remediation/db-master-consolidation  
Дата: 2025-10-08

## 1. Цели и границы

- Единый мастер PostgreSQL (APP2, 46.173.24.4), единый DSN для всех backend.
- Восстановление диагностируемости: `pg_stat_statements` + безопасный fallback на `pg_stat_activity`.
- DB Governor: политика таймаутов, автокиллер `idle in transaction`.
- Автосупервизор связей (AGE): дедупликация и проекция квант‑связей.
- Пошаговое включение ранее заглушенных функций с мониторингом и обратимостью.

Ограничения: все URL/порты/секреты — только из БД (`SoulSettingsService`/`SecretsService`), без хардкодов.

## 2. Целевая архитектура

- Master DB: APP2 (локальный DSN на APP2 указывает на localhost мастера). На APP1 локальный PostgreSQL остановлен и замаскирован.
- Backend интеграции:
  - `DBGovernorService` применяется для каждой новой `AsyncSession` (политика таймаутов).
  - Фоновые сервисы: `DBGovKillerService` (idle killer), `QLinksSupervisorService` (дедуп/проекция) — старт при `startup_event`, корректное завершение при `shutdown_event`.
  - Включён `system_api` роутер.
- AGE: единый граф, инвариант типа связи — `COALESCE(connection_type::text,'semantic')`.

## 3. Политика DB Governor

- Таймауты (рекомендуемые начальные значения, актуализируются флагами в БД):
  - `statement_timeout`: 30s (критичные пути могут иметь меньше)
  - `idle_in_transaction_session_timeout`: 15s–60s (в зависимости от среды)
  - `lock_timeout`: 5s–10s
- Применение: при создании каждой сессии — `apply_session_policy`.
- Idle killer (`DBGovKillerService`): периодический поиск `idle in transaction` и завершение сессий согласно правилам.

## 4. Диагностика и эндпоинты

- `GET /api/admin/db/top-queries` — источник `pg_stat_statements`; при отсутствии — fallback на `pg_stat_activity` с `rollback()` перед повтором при `InFailedSQLTransaction`.
- `GET /api/admin/db/pg_stat_statements/status` — проверка наличия/версии.
- `POST /api/admin/db/pg_stat_statements/ensure` — попытка включения (требует superuser, операционный сценарий).
- `GET /api/health` — расширенный `database: healthy` при успешной проверке.
- Processor/Dispatcher:
  - `/api/admin/processor/status`, `/stop`, `/emergency/apply`, `/requeue/dispatched` (каскадное восстановление и дренаж очередей).

## 5. Операционные процедуры

### 5.1. Консолидация мастера

1) Остановить и замаскировать PostgreSQL на APP1 (исключить ложного мастера).  
2) На APP2 убедиться, что `DATABASE_URL` всех backend указывает на локального мастера (localhost).  
3) Перезапустить backend (`soulpulse-backend.service`).

### 5.2. Включение `pg_stat_statements`

В Postgres конфигурации (APP2):

- `shared_preload_libraries = 'pg_stat_statements,age'`
- `pg_stat_statements.track = all`

Перезапуск PostgreSQL → проверить `GET /api/admin/db/pg_stat_statements/status`.

### 5.3. Smoke‑проверки

- `GET /api/health` → ожидается `database: healthy`.
- `GET /api/admin/db/top-queries` → источник `pg_stat_statements` или fallback метка.
- AGE: подсчёты/покрытие (`AGE.COUNTS`), инвариант связей соблюдён.

## 6. Наблюдаемость, Key Master пути и алерты

- Канонические пути загрузки модулей/плагинов (Key Master):
  - PROD: `/var/www/soulpulse/backend` (основной корень приложения), альтернативно `/var/www/soulpulse` (для узкопрофильных скриптов).
  - DEV (исторически): `/opt/soulpulse/app/Telegram_Bot/backend`, `/opt/soulpulse/app/backend`, `/opt/soulpulse/app`.
  - Эти пути добавляются в системный `sys.path` движком Hyperloop для стабильного импорта инспекторов и сервисов.
  - Запрет хардкодов URL/портов/секретов — все значения читаются из БД (`SoulSettingsService`/`SecretsService`).
  - DB Governor:
    - Метрики: p95 времени запросов, `idle_kills_rate`, ошибки применения политики.
    - Алерт пример: `DBIdleInTxSpike` (severity=high) — действия: снизить нагрузку, проверить долгие транзакции, повысить агрессивность idle killer при необходимости.
  - Processor/Dispatcher:
    - Очереди (`processor_events`, `flow_dispatch_queue`), p95 обработок, error rate; алерт при росте `dispatched`.
    - Инспекторы:
      - `guard.canonical.urls` (запрет хардкодов), `planning.enforce` (план/факт дисциплина).

## 6.1 Миграционный гейт и baseline‑инспекторы

- Блокировка запуска новой функциональности до подтверждённого успеха миграций и тестов:
  - Инспекторы: `guard.backend.baseline`, `guard.frontend.baseline`, `schema.drift` — должны возвращать `passed/ok`.
  - Флаги в БД: `migrations.last_acceptance_ok=true`, `tests.db_structure_check_ok=true`; для фронтенда — `frontend.build.last_ok=true`.
  - При несоблюдении условий Delivery Guard блокирует включение функциональности, а инспекторы записывают событие в `soul_audit_log`.
  - Процесс не блокирует другие подсистемы: инспекторы — read‑only; гейт применяется выборочно к вновь включаемым фичам (feature flags/Two‑Keys), существующие фичи продолжают работу.
  - Ссылки: baseline‑инспекторы интегрированы в CI (`.github/workflows/inspector.yml`, job `baseline-gate`) и PROD cron (`ops/systemd/soul-baseline-inspectors.*`), runbook по signed‑пути — `docs/RUNBOOK_Hyperloop_Signed_Path_Debug_v1_0.md`.

### 6.2 Runbook (PROD timers / observability / PROJECT.LOG)

- Таймеры:
  - `soul-baseline-inspectors.timer` — каждые 30 минут; `soul-baseline-nightly.timer` — 03:10 UTC.
  - Проверка и управление: `systemctl status|start|stop|enable --now` для соответствующих units.
- Отчёты:
  - `reports/baseline_backend.json`, `baseline_frontend.json`, `baseline_schema_drift.json`; таймстамп‑копии `baseline_*_YYYYmmdd_HHMM.json`.
  - Агрегат: `reports/baseline_aggregate_*.json` и `reports/baseline_aggregate.json`.
- Метрики/алерты:
  - `/api/metrics/prometheus`: `baseline_*_passed`, `baseline_status_ok_sum`, `baseline_last_mtime_epoch`.
  - Правило `BaselineInspectorsFailed` в `ops/prometheus/rules_baseline.yml`.
- Админ‑эндпоинт: `GET /api/admin/baseline/status` — итог по инспекторам и ссылки на отчёты.
- PROJECT.LOG: при `passed` раннер выполняет `PROJECT.LOG.SET` с путём агрегата.

### Acceptance (дополнение)

- [x] Активны таймеры baseline; ручной прогон — passed; отчёты присутствуют.
- [x] Метрики baseline экспортируются; алерт подключён; дашборд доступен.
- [x] Админ‑эндпоинт baseline/status отвечает корректно ≤ 1 KB.
- [x] PROJECT.LOG содержит ссылку на актуальный агрегат.
- [x] Chat LLM использует стратегию истории tail‑first (от последнего сообщения назад до лимита токенов), снижение деградации качества при длинной истории.

## 7. Риски и откаты

- Скрытые локальные DSN — аудит `.env.prod` на APP1/APP2, удаление дублей `DATABASE_URL`.
- Отсутствие `pg_stat_statements` после перезапуска — fallback в API + эндпоинт ensure/status + корректная `shared_preload_libraries`.
- Постепенное включение заглушенных функций с метриками; при деградации — мгновенный откат флагами и регистрация инцидента.

## 8. Acceptance checklist

- [ ] DSN всех backend указывает на мастера на APP2.
- [ ] `pg_stat_statements` активен, top‑queries возвращает данные из него; fallback работает.
- [ ] DB Governor политика применяется к новым сессиям; idle killer активен.
- [ ] QLinks Supervisor выполняет дедупликацию/проекцию; AGE инварианты соблюдены.
- [ ] Инспекторы зелёные: `guard.canonical.urls`, `planning.enforce`.
- [ ] Алерты человеко‑читаемые, содержат severity и шаги.

## 9. Приложение: артефакты и трасса

- Проект P40: SP-DB-REMEDIATION-2025-10 (id: d534d5a2-9ee8-4073-a2eb-568c27e1ccfb).
- Задачи P40 (ядро):
  - DSN_audit_APP1_APP2_deduplicate_DATABASE_URL
  - Master_DB_summary_sizes_queues_flags_report
  - Confirm_single_master_DB_and_document
  - Disable_local_Postgres_on_APP1_mask_service
  - Switch_backend_DSN_to_APP2_master_and_restart_backend
- Сервисы backend: DBGovernorService, DBGovKillerService, QLinksSupervisorService; роутеры: db_admin, processor_admin, system_api.

## 10. PostgreSQL 16 — апгрейд (конспект)

- Цель: ускорение JSONB/индексов/параллелизма, без регресса API. Рекомендация: side‑by‑side кластер PG16 и «холодный» свитч.
- Резервное копирование: `pg_dump -Fc` + `pg_dumpall --globals-only`; проверка восстановления на стенде.
- Базовый тюнинг (ориентиры): `shared_buffers` 10–25% RAM, `effective_cache_size` 60–70% RAM, `wal_level=replica`, JIT/параллелизм по профилю.
- Свитч приложений: либо прежний порт, либо смена `DATABASE_URL` + перезапуск сервисов; смоки `/api/health`, инспекторы `INSPECTOR.RUN_ALL`.
- Пост‑тюнинг: `vacuumdb --analyze-in-stages`, включить `pg_stat_statements`, targeted‑тюнинг планов/индексов.

## 11. Операции single‑host и эмбеддинги (конспект)

- Консолидация на одном мастере: APP2=БД; APP1 — без локального Postgres. Доступ только по приватной сети.
- `pgvector`: таблица `quant_embeddings` (dims=1024), стратегия массовых вставок — удалять ivfflat перед загрузкой и пересоздавать после, затем `ANALYZE`.
- Контроль инвариантов: размерность векторов, отсутствие дубликатов, паритет с `quants`.
- Примерные скрипты: дозаливка батчами, переменные `MAX_ROWS/BATCH_SIZE`, кеш модели `HF_HOME` с достаточным местом.

## 12. Multi‑DB/Pooler (опционально, будущее расширение)

- Разделение доменов на service_db / soul_db / analytics_db, DSN только из `soul_settings`/`soul_secrets`.
- PgBouncer (transaction pooling) перед БД, caps ниже `max_connections`, health‑пробы, метрики.
- Чтения на реплики только идемпотентные; fallback на primary при lag > threshold.

## 13. Лучшие мировые практики (по направлениям)

### 13.1 Консолидация мастера и DSN‑дисциплина

- Единый источник правды для DSN: только из `soul_settings`/`soul_secrets`, без хардкодов.
- Fail‑fast на дрейф: инспектор `guard.canonical.urls` в CI/PROD, автодействия/инциденты.
- Разделение ролей и прав доступов по least privilege; `application_name` для всех клиентов.
- Принудительные таймауты на уровне сессий: `statement|idle_in_tx|lock`.
- PgBouncer (transaction pooling) для стабильного caps и предсказуемости.
- Feature‑flags и Two‑Keys для чувствительных переключений DSN/режимов.

### 13.2 Диагностика и наблюдаемость (pg_stat_statements/locks/activity)

- Включать `pg_stat_statements` и регулярно агрегировать top‑N; fallback на `pg_stat_activity` безопасен.
- Нормализация SQL и fingerprint‑отчёты: сравнение планов и регрессий.
- Прозрачные метрики p95/p99, error‑rate, lock waits, idle‑in‑tx; панели Grafana с «что делать».
- Алерты с приоритетами и runbooks (человекочитаемые шаги + риск/срок).
- Трассировка `application_name`/контекстных тегов для поиска виновников.
- Контроль autovacuum и bloats: регулярные отчёты и плановые окна обслуживания.

### 13.3 DB Governor и политика таймаутов/капасити

- Классы нагрузки с caps и приоритетами; AIMD‑адаптация по p95/err_rate.
- Жёсткие таймауты: `statement_timeout` по классам; `idle_in_tx` и `lock_timeout` обязательны.
- Backpressure/отказ для низкоприоритетных операций при перегрузке вместо деградации всего ядра.
- Киллер зависших транзакций с исключениями для критичных админ‑сессий.
- Контролируемое увеличение капасити через фичефлаги/Two‑Keys.
- Обязательные метрики/аудит решений Governor (прозрачность).

### 13.4 AGE/Links и целостность графа

- Единый инвариант связей: `COALESCE(connection_type::text,'semantic')`.
- Периодическая дедупликация и проекция (`QLinksSupervisorService`) с метриками охвата.
- Идемпотентные операции и защитные предикаты от дублей.
- Смоки `AGE.COUNTS` и сравнение с реляционными счётчиками.
- Отчёт о покрытии связей и аномалиях (осиротевшие/циклы вне правил).
- Сегрегация «горячих» операций (RET/индексы) во внепиковые окна.

### 13.5 Репликации/пулы/партиционирование/индексы

- Чтения только идемпотентные на реплики; лаг‑порог и автоматический fallback.
- PgBouncer transaction pooling: reset‑query, серверные таймауты, health‑пробы.
- Индексы CONCURRENTLY; обслуживание и reindex по плану.
- Партиционирование горячих таблиц по времени/ключам; partitionwise aggregate/join.
- Параметры Postgres из эталонов под нагрузку; избегать «универсальных» значений.
- Превентивные проверки планов при смене версии/параметров (plan stability).

### 13.6 Безопасность/процессы/управление изменениями

- RBAC/ABAC; опасные операции — только через Two‑Keys.
- Секреты только в БД (pgcrypto), DSN не логировать, превью маскировать.
- Полный audit trail (P27): сигнатуры команд и связи с план‑тасками P40.
- Канареечные включения с быстрым откатом и инцидентами.
- Документация и инспекторы как часть CI (guard/planning/frontman).
- Runbooks с действиями и параметрами «когда останавливать».

## 14. Согласование с P‑серией и балансировка

- P27 Delivery Guard: все админ/DB‑операции фиксируются, шаги обязательной цепочки присутствуют.
- P29 Жандарм/Судья: инспекторы `guard.canonical.urls`, `planning.enforce` и фронтмен контракты включены.
- P30 Processor/Dispatcher: дренаж/очереди и requeue согласованы; Governor диктует caps/таймауты.
- P40 Planning: все изменения проводятся через план‑таски, ссылки на `plan_task.id` в логах.
- P44 RBAC: доступ к админ‑эндпоинтам/DSL только у `soul.admin`, опасные — Two‑Keys.
- P48R RS: тяжёлые граф‑операции/агрегации выводятся в RS при превышении SLA.

## 15. Соответствие целям SoulPulse (без регресса)

- Устойчивость ядра: единый мастер, устранение «ложных» локальных инстансов.
- Диагностируемость: top‑queries, алерты, отчёты и трассировка.
- Предсказуемость p95: капасити/таймауты/бэкпрешер вместо деградации.
- Целостность знаний: AGE/Links и инварианты соблюдены, дедуп автоматизирован.
- Управляемость рисков: фичефлаги/Two‑Keys/инциденты и быстрый откат.
- Совместимость: без хардкодов URL/портов/секретов; всё из БД сервисов.

## 16. Дополнения к Acceptance

- [ ] Включены инспекторы `guard.canonical.urls`/`planning.enforce` в CI и PROD.
- [ ] Настроены панели/алерты c runbooks (DBIdleInTxSpike/DBLockContention/DBP95BudgetBreach).
- [ ] Отчёты top‑N из pg_stat_statements собираются планово; fallback проверен.
- [ ] Резервы/капасити Governor документированы, решения аудируются.
- [ ] Реплики/лаг‑порог и fallback задокументированы (если включены).
- [ ] Документация согласована с P‑серией и ссылками в реестрах.

## 17. Требования к реестрам и инвентаризации

- При любых изменениях по БД/схемам обязательна актуализация:
  - `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` (мастер‑реестр)
  - `docs/PROJECT_STRUCTURE.md` (структура проекта)
  - `docs/DOCS_REGISTRY_v8_0_4.md`


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
