# M04 — Kanban Flow (v1.0)

Цель: непрерывный поток с ограничениями WIP и управлением очередями.

Инварианты: P27/P28/P29/P30/P36.

Процесс: pull‑подход, визуализация статусов, политика Service Classes, explicit policies.

Алгоритмы/метрики: WIP, Throughput, Lead Time, p95, err_rate.

Роли: Service Owner, Tech Lead, QA.

DSL: PLAN.TASK.ADD, POLICY.WIP.SET, METHODOLOGY.SET, QUANT.LINK.AUTO, INSPECTOR.RUN_ALL.

Acceptance: лимиты в БД; алерты по SLA; панели Kanban/Flow.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
