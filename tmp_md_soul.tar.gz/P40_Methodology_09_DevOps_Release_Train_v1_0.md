# M09 — DevOps Release Train (v1.0)

Цель: быстрые и безопасные релизы через CI/CD, фичефлаги и обратную связь.

Инварианты: P27/P28/P29/P30/P36.

Процесс: Trunk‑based dev → CI → Test → Canary → Full Rollout → Observability.

Алгоритмы/метрики: DORA (Deployment Frequency, Lead Time, MTTR, Change Failure Rate), p95/err_rate.

Роли: Dev Lead, QA Lead, SRE.

DSL: FLAGS.SET, RELEASE.CANARY, METHODOLOGY.SET, INSPECTOR.RUN_ALL.

Acceptance: DORA на панелях; алерты; контроль canary/rollback.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
