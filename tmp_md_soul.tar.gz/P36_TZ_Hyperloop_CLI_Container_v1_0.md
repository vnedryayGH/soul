# P36 — ТЗ: Контейнерный Hyperloop CLI (Soul CLI)

Цель: обеспечить быстрый и надёжный доступ к Hyperloop DSL из любой командной строки через контейнер, без проблем экранирования кавычек и с обязательным заголовком `X-Telegram-User-ID`.

## Контракты

- Образ: `soul-cli:latest`
- Entrypoint: `python Soul/scripts/hyperloop_cli.py`
- ENV (override):
  - `HL_API_URL` — по умолчанию `https://mini.soulpulse.art/api/hyperloop/execute`
  - `HL_USER_ID` — по умолчанию `468326902`

## Запуск

- Префлайт: `docker run --rm -e HL_USER_ID=468326902 soul-cli:latest --preflight`
- DSL (commands): `docker run --rm -e HL_USER_ID=468326902 soul-cli:latest --commands "INSPECTOR.RUN key=planning.enforce"`
- Локально к APP: `-e HL_API_URL=http://127.0.0.1:8000/api/hyperloop/execute`

Windows wrapper: `scripts/soul_cli.ps1`

```powershell
.\scripts\,soul_cli.ps1 -Commands 'INSPECTOR.RUN key=planning.enforce'
.\scripts\,soul_cli.ps1 -Commands 'FLAGS.STATE' -Local
```

## Acceptance

- `--dry-run` выводит JSON `{ "commands": "..." }` без отправки
- `--preflight` успешно возвращает `health/db/pipeline`
- INSPECTOR/TRACE/FLAGS команды проходят с `200` и шагами подписи (P27)

## Наблюдаемость

- Метрики DevConnect в ответах: `dev_connect_error_total{type}`, p95 по CLI-запросам
- Инциденты: таймауты/форбидден/URL — автосоздание (P50)

## Примечания

- CLI читает `HL_API_URL/HL_USER_ID` (commit включён)
- Образ минимален (`python:3.11-slim`), плагины не требуются
