### Инструмент сборки отчёта в PDF

Назначение
Собирает `Soul/Report_Soul_AI_Scientific.md` в PDF, проверяя базовую структуру и наличие изображений.

Зависимости (один из путей):

- Вариант A: Python пакеты `markdown`, `weasyprint` (`pip install markdown weasyprint`)
- Вариант B: Pandoc (`pandoc` в PATH)
- (Опционально) `wkhtmltopdf` как резерв

Запуск

```text
python Soul/ReportTools/md_report_builder.py --input Soul/Report_Soul_AI_Scientific.md

```

Выходные файлы

- `Soul/Report_Soul_AI_Scientific.html` (промежуточный)
- `Soul/Report_Soul_AI_Scientific.pdf` (итоговый)
- `Soul/ReportTools/report_style.css` (генерируется при первом запуске)

Проверки и автокоррекции

- Проверяется наличие изображений, базовая структура заголовков.
- При несущественных проблемах сборка не блокируется, но выводятся предупреждения.

Параметры оформления

- `--preset default|journal` — пресет макета; `journal` включает двухколонник и суженные поля.
- `--page-size A4|Letter` — размер страницы (по умолчанию A4).
- `--margin 15mm|20mm|...` — поля страницы.
- `--engine auto|weasyprint|pandoc|wkhtmltopdf` — механизм рендеринга PDF.
- `--css path/to/custom.css` — подключить собственный CSS (перекрывает пресеты).

Примеры

```text
# Журнальный стиль (двухколонник), A4, поля 15мм, авто-движок
python Soul/ReportTools/md_report_builder.py --input Soul/Report_Soul_AI_Scientific.md --preset journal --page-size A4 --margin 15mm --engine auto

# Использовать свой CSS и принудительно WeasyPrint
python Soul/ReportTools/md_report_builder.py --input Soul/Report_Soul_AI_Scientific.md --css Soul/ReportTools/custom.css --engine weasyprint

```
