---

## Индекс взаимных ссылок (P01–P37)

- P27 Signature — подпись всех шагов.
- P30 Processor — исполнительный контур процессов.
- P33 Personification — Mini Chat процессная цепочка (user_dialog).
- P36 Hyperloop DSL — команды управления/инспекции.

---

## Приложение — Промпты, Алгоритмы памяти, Напоминания, API v2.26 (2025‑09‑13)

Статус: актуально. Обновление: единый системный промпт `soul_core_system` для одиночной и пакетной генерации; уточнены правила batch/stateless.

### 1. Общие положения

- Провайдеры: `deepseek`, `gigachat`, `openai` (выбор через `LLM_PROVIDER`).
- Базовые промпты не изменяются напрямую; дополнительные указания добавляются динамически.
- Приоритет личности: активная личность всегда доминирует над историей и всякими доп. инструкциями.

### 2. Системный промпт `soul_core_system` (единый)

Сборка SYSTEM/USER должна содержать строго следующие блоки:

```text
[CORE]
[ROUTER_CONTEXT]
[MODULES]
[OUTPUT_SPEC]
[NEGATIVE]
+ История (до 12 сниппетов)
+ Вопрос пользователя (input_text)

```

- [CORE]: краткая миссия Soul, требования честности, недопущение галлюцинаций, приоритет личности.
- [ROUTER_CONTEXT]: JSON вида `{ "modules": ["Flow","Ved",...], "filters": {...} }`.
- [MODULES]: инструкции активированных модулей.
- [OUTPUT_SPEC]: строгая JSON‑схема кванта (см. §3).
- [NEGATIVE]: запреты (нет ссылок, нет фантазий, только JSON и т.д.).

Шаблон SYSTEM (фрагмент):

```text
[CORE]
Ты — Soul. Отвечай строго JSON массивом квантов. Не добавляй пояснений.

[ROUTER_CONTEXT]
<router_ctx_json>

[MODULES]
<modules_instructions>

[OUTPUT_SPEC]
Формат каждого кванта:
{
  "thought_form": "строка",
  "composite_emotion": { "valence": 0..1, "intensity": 0..1, "entropy": 0..1, "label": "neutral|..." },
  "desired_action": [],
  "energy_weight": 0..1,
  "tags": ["..."]
}
Верни массив таких объектов. Пуcтой массив допустим.

[NEGATIVE]
Никаких комментариев вне JSON. Не выдумывай фактов. Не выходи за схему.

```

### 2.1. Инструкция по языку Hyperloop DSL (для разработки проекта «Соул»)

Назначение: дать LLM ясные правила безопасного использования Hyperloop DSL как «языка управления ядром» в режиме разработки и диагностики.

Правила исполнения:

- Использовать Hyperloop DSL только при явном запросе разработчика/архитектора и только в виде строковых команд для эндпоинта `POST /api/hyperloop/execute` с телом `{ "commands": "..." }`.
- В любом статлес‑контексте не выполнять изменения БД и окружения, если не требуются; отдавать DRY‑RUN, когда доступно.
- Соблюдать RBAC/Two‑Keys: потенциально опасные команды (миграции, DDL, REINDEX.ALL, секреты enforced) требуют `request_id` с одобрением.
- Всегда формировать простые, однострочные команды; многострочные сценарии разбивать переводами строк внутри `commands`.
- При формировании примеров соблюдать строгий синтаксис: поле `commands` — строго строка, а не массив.

Безопасные команды (смоки/диагностика):

```text
INSPECTOR.RUN_ALL
CORE.PIPELINE.RUN input_text="health check" WITH TRACE
TRACE.STEPS trace_id="<UUID>"
FLAGS.APPLY_PROFILE name=prod_safe
SCHEMA.COLUMNS table=quants
MIGRATIONS.STATUS
DEPLOY.CHECK
MACRO.LIST

```

Команды БД/миграций/связей (использовать осторожно, предпочтительно DRY‑RUN или в тестовой среде):

```text
DB.SEARCH table=quants where={"created_by":468326902}
DB.UPSERT table=soul_settings key=key values={"key":"architect_reply_mode","value":"soul_core"}
RELATION.CREATE from=quants:<QID> to=users:468326902 type=born_for weight=0.9
INDEX.REBUILD table=quant_links name=idx_quant_links_to
MIGRATIONS.APPLY revision=head request_id=<UUID>
REINDEX.ALL request_id=<UUID>

```

Секреты (только через БД‑хранилище, с Two‑Keys для чувствительных):

```text
SCHEMA.SECRETS.ENSURE
SECRET.SET key=deepseek_api_key value="sk-***" request_id=<UUID>
SECRET.GET key=deepseek_api_key

```

Язык настроек, GPU, многопоточность и самопроверка:

```text
LANG.SET key=lang.ui.default value="ru"
LANG.GET key=lang.ui.default
GPU.STATUS
CONCURRENCY.LIMITS set send_threads=4 parse_threads=4
SELFTEST.RUN key=db_ping

```

Макрокоманды (сценарии):

```text
MACRO.LIST
MACRO.RUN key=smoke_all
MACRO.RUN key=p27_sign_guard_smoke

```

Примечания:

- Ответы ядра на команды Hyperloop возвращают JSON с полями `ok`, `results[]`, `signature.trace_id`, `signature_steps` (best‑effort). Для трассировки использовать `WITH TRACE` и `CORE.TRACE.REQUIRE`.
- Для видимых ответов пользователю Delivery Guard (P27) требует обязательную цепочку шагов; Hyperloop‑инструкции не должны попадать в видимый текст пользователя.

USER:

```text
Контекст:
<history_snippets>

Задача:
<input_text>

```

### 3. JSON‑схема ответа (строгая)

- `thought_form: str`
- `composite_emotion: { valence: float, intensity: float, entropy: float, label: str }`
- `desired_action: []` (в batch‑stateless всегда пусто)
- `energy_weight: float [0..1]`
- `tags: List[str]`

Правила:

- Только массив объектов; без markdown/комментариев.
- Числа — десятичные, в диапазонах.
- Теги — строки без спецсимволов.

### 4. Алгоритмы памяти (как в v2.25, уточнения)

- Подбор истории (30/70): 30% — последние, 70% — по ключевым словам → эмоции → дате.
- `deep_memory_only=true`: недавняя история берётся только после `user_settings.updated_at`.
- Служебный хвост `§svc{...}` допускается в других режимах чата, но не в ответах ядра Soul (для квантов требуется чистый JSON).

### 5. Batch‑стратегия (ядро Soul)

- Stateless по умолчанию для диагностики: LLM без DB; `desired_action=[]`; возврат без сохранения.
- Persistent — полный путь с сохранением; использовать при устойчивом async‑контексте.
- Фоллбек при ошибках batch — одиночная генерация.
- ENV: `SOUL_DISABLE_QUANT_PERSIST_BATCH=1`, `TEST_NO_DB=1`.

### 6. Параметры модели (по умолчанию)

- `max_output_tokens≈3000`, `temperature≈0.7` для `soul_core`.
- Провайдер и модель настраиваются через `llm_function_configs`.

### 7. Версионирование

- v2.26: Единая сборка промпта для single/batch, stateless‑ветка, строгая JSON‑схема кванта.
- v2.25: Спецификация промптов/памяти, политика видимости служебных блоков.

Связанные документы: `docs/PROJECT_STRUCTURE_v8_0_4.md`, `docs/SOUL_PIPELINE_v1_1.md`.

### 8. Sense Planner (единый конвейер: Ключевые слова → Смыслы → Кванты)

- Сервис: `MeaningExtractionService.run(input_text, history_snippets≤8, active_goal?, router_filters?, mode)`
- Шаги:
  - extract_keywords: до 15 ключевых элементов (entity|topic|temporal|action|affect|goal_hint), лемматизация/нормализация/дедупликация.
  - plan_meanings: LLM «Sense Planner» (STRICT JSON) → `meanings[]` c полями: `title, gist, reason, tags[], evidence[], confidence[0..1], emotion_hint{valence,intensity,entropy,label}, value_type[core|growth|utility|noise], recommended_action?`.
  - to_quant_candidates: формирование `quant_candidates[]` из принятых смыслов.
- Ограничение: максимум 3 смысла (настройка `meaning.max_meanings`). Пустые/бытовые — отбрасывать.
- Интеграция: вызывается перед сборкой промпта Soul Core; принятые смыслы кратко включаются в USER‑блок.
  - ВАЖНО: «бытовой шум» отсекается только в сервисном вызове Sense Planner; текст пользователя/ответ не модифицируются.

### 9. Двойной фильтр (Sense → Quant)

- Фильтр 1 (Смысл): `Score = 0.5*confidence + 0.3*value_weight + 0.2*goal_alignment`.
  - Порог принятия: `Score ≥ meaning.min_score_for_sense (деф. 0.6)` и `value_type ∈ {core,growth}`.
- Фильтр 2 (Квант): отбрасываем кандидата если `len(gist) < 20`, или `tags отсутствуют и confidence < 0.65`, или `energy_weight < meaning.min_energy_for_quant (деф. 0.2)`.
- В stateless: `desired_action = []` всегда.

Правило неизменности текста:

- Исходный текст пользователя и финальный текстовый ответ пользователю не модифицируются механизмом «отсечения шума». Фильтрация применяется только внутри сервисного вызова Sense Planner (для целей маршрутизации/контекста), а не в интерфейсном слое.

### 10. Разделение Большая/Малая LLM

- Большая LLM (DeepSeek): основное ядро `soul_core` (single и batch), высокий SLO/таймаут.
- Малая LLM (GigaChat): сервисные шаги — `meaning_sense_planner`, `soul_batch_planner`, `soul_quant_refiner` (низкая температура, малые токены).
- Маршрутизация выполняется через `LLMManager.get_model_for_function(function_name)`.

### 11. Централизованная схема OUTPUT_SPEC

- Источник: `backend/app/lib/response_schema.py::get_response_schema()`.
- Формирование строкового спецификатора: `format_output_spec(schema, batch=False|True)`.
- В single — объект; в batch — массив объектов.

### 12. Аудит и Метрики (observability)

- Новые события:
  - `soul_ctx_build` {recent_ratio, policy, snippets}
  - `soul_keywords_extracted` {count, latency_ms}
  - `soul_meanings_generated` {count, accepted, latency_ms, reasons_top}
  - `soul_quant_candidates` {count, accepted, avg_energy}
  - `soul_output_spec_sync` {batch, keys}
  - `soul_batch_validation` {in, out, dropped}
- Метрики (пример): распределение energy_weight, доля отфильтрованных на смысле/кванте, p95 длительностей по шагам.

### 12.1 Сон / Нейроперестройка (P49) — метрики, пороги, Acceptance

- Событие процессора: `soul.dream.rewire` — мягкая нормализация весов связей в пределах эпсилон‑порогов; глубина ограничена `radius`.
- Настройки (БД `soul_settings`):
  - `sleep.rewire.epsilon` (float, деф. 0.02) — макс. сдвиг веса за цикл.
  - `sleep.rewire.radius` (int, деф. 1) — радиус/глубина перестройки графа.
  - `sleep.rewire.max_edges` (int, деф. 500) — лимит рёбер на цикл.
  - Профили: `sleep.profile.{light,deep,repair}` — JSON {epsilon,radius,max_edges}.
  - Алерты: `sleep.alerts.{rewire_ratio_max,epsilon_drift_max}`.
- Метрики (экспорт Prometheus `/api/metrics/prometheus`):
  - `sleep_rewire_ratio_{p50,p95,p99}` — доля пересвязываний (updated/limit) за окно.
  - `sleep_rewire_epsilon_p50`, `sleep_rewire_radius_p50` — срезы дрейфа/глубины.
  - `sleep_rewire_events_total`, `sleep_rewire_edges_updated_total` — cumulative счётчики.
- Acceptance:
  - При запуске `soul.dream.rewire` фиксируется инцидент `dream_rewire_done` с параметрами `updated, epsilon, radius`.
  - Метрики выше экспонируются; профили доступны через `GET /api/admin/soul/settings/all`.
  - Пороговые значения для алертов соблюдаются; при превышении — уведомление/эскалация.

### 13. Настройки (soul_settings)

- `meaning.min_score_for_sense` (float, деф. 0.6)
- `meaning.min_energy_for_quant` (float, деф. 0.2)
- `meaning.max_meanings` (int, деф. 3)
- Политики контекста: `recent_ratio` и др. из контекста 30/70_v2.

Примечание: пороги читаются из БД в рантайме; хардкода нет. Все параметры доступны в панели администратора мини‑приложения.

### 14. Поведение при отсутствии смыслов/кандидатов

- Если `meanings=[]` и/или `quant_candidates=[]`, пайплайн НЕ возвращает предзаданный «уточняющий» текст и НЕ прерывается.
- Ядро `soul_core` всегда вызывается (с ретраями/таймаутами согласно настройкам), что позволяет LLM при необходимости породить осмысленный ответ и/или Квант(ы) даже без предварительно принятых смыслов.

### 15. Режим ответа Архитектора (architect_reply_mode)

- Хранится в `soul_settings.key = "architect_reply_mode"`, значения: `chat` | `soul_core`.
- `chat` (по умолчанию):
  - Пользователь видит чистый текст LLM‑чата (без техблоков).
  - Служебные маркеры (`§sense`, `§qtags`, `§qew`) формируются отдельно из stateless‑кванта и добавляются строками после ответа. `thought_form` для §sense санитизируется от префикса «Соул:».
- `soul_core`:
  - Пользовательский ответ строится через SoulCore (лучший квант). Маркеры остаются аналогичными.
- Управление в мини‑апп: Панель Архитектора → «Архитектор: режим ответа (человек ↔ SoulCore)».

### 16. Разделение «общение» vs «авторежим»

- Общение (чат): используется история диалога, напоминания, персонализация; источник показа пользователю — ответ LLM‑чата.
- Авторежим (фоновая генерация): используется текущий конвейер смыслов/квантов, batch/stateless по умолчанию; сохранение управляется политиками.
- Правило неизменности текста сохраняется: мы не изменяем/не режем пользовательский текст и итоговый ответ человеку; фильтрация «шума» применяется только внутри Sense Planner.

# P35 — ТЗ: Процессы Ядра Соул (UNIFIED) v2.1

Статус: Каноничный (заменяет разрозненные версии P35 для исполнения)  
Примечание: Самодостаточный документ — все приложения и исправления интегрированы внутрь

## 0) Executive Summary

Цель: единый канонический документ, объединяющий спецификацию процессов (v2.0), исправления и расширения (v2.0.1), результаты 35‑шагового сопоставления с P01–P36 и требования интеграции с P30/P36/P27/P29.

Ключевые положения:

- Процессы — сущности первого класса с трассируемостью (P27), качественными воротами (P29), управлением через Hyperloop DSL (P36) и приоритезацией очередей.
- Процессор (P30) — основной исполнитель; персонажи (Дирижёр, Жандарм, Судья, Архивариус, Матерь флагов, Отец санитайзеров) — Process Actors.
- Quantum Process Computing — операционная модель через Кванты и шаги с инвариантами (идемпотентность, Delivery Guard, RBAC/Two‑Keys).

## 0.1) Глоссарий (минимум)

- Ядро Соул (ЯС): центральный вычислительный контур, исполняющий процессы и OODA‑цикл, обеспечивающий инварианты безопасности/качества и управление через Hyperloop.
- STRICT_JSON_QUANT: строгий JSON‑контракт вывода LLM; верхний уровень — массив объектов; числа → float; поля массивов типизированы; недопустим markdown/комментарии.

## 0.2) Соответствие процедуре создания (шаги 1–7)

1) Критический анализ отчёта и лучших практик — интегрирован в требования §3, §7, §14.
2) Дополнение лучшими практиками — отражено в §4 (Process Intelligence) и §14.2.
3) Сопоставление с номерными ТЗ — выжимка и требования в §8.
4) Создание ТЗ — настоящее UNIFIED (самодостаточно, без внешних приложений).
5) Повторный анализ целостности — правки и инварианты в §3, §7, §14.
6) 35‑шаговый цикл P01–P36 — выводы сведены в §8; доработки — в соответствующих §.
7) Детализация до уровня реализации — DDL §5.2, процессы §9/§12/§13, DSL §2/§2.1, acceptance §7/§13.8/§13.9.

## 1) Сущность «Процесс» и шаги (ядро)

- Формальные атрибуты процесса и шага — как в P35 v2.0, раздел 2.1/1.3 (включая input/output схемы, таймауты, retries, error_policy, SLA, security/privacy, multilingual/multisensory).
- Очереди: приоритетные пулы (critical/high/medium/low); внутри одного приоритета — FIFO по времени появления.
- Триггеры: событийные/по расписанию/ручные через Hyperloop; разовые и цикличные.

## 2) Управление через Hyperloop DSL (P36)

- Команды PROCESS.*, ACTOR.*, QUALITY.*, INTELLIGENCE.* — как в P35 v2.0, раздел 3, с расширениями v2.0.1 (интервалы, очереди, шаги, маршрутизация).
- Требования безопасности: RBAC (process.*), Two‑Keys для опасных операций; все команды порождают шаги подписи `cmd.hyperloop.*` (P27).

### 2.1 Обязательные расширения DSL (соответствие исходным вводным)

- Маршрутизация: `ACTOR.ROUTER.DECIDE context_data='{"priority":0.8,"lang":"ru"}'`.
- Шаги процесса: `PROCESS.STEP.EXECUTE process_id="..." step_id="..." WITH TRACE`.
- Интервалы: `PROCESS.START process_id="..." schedule='{"interval":"5m"}'`.
- Очереди/приоритеты: `PROCESS.QUEUE.REORDER queue_name="default" strategy="priority_first_fifo"`; `PROCESS.QUEUE.STATUS`.
- RT‑параметры: для команд ядра, вызывающих LLM/батчи, поддерживаются `TIMEOUT=<ms>` и `append=true|false` (накопление микро‑батчей). Примеры: `CORE.PIPELINE.RUN ... TIMEOUT=1500`, `BATCH.GENERATE_QUANTS n=1 append=true TIMEOUT=3000`.

## 3) Инварианты качества/безопасности

- Delivery Guard: обязательная цепочка перед публикацией ответа; при нарушении — блок/инцидент/уведомление Судьи.
- STRICT_JSON_QUANT: все stateless ответы — массив объектов; числа → float; без markdown; tags: List[str].
- RBAC/Two‑Keys: роли process.admin/operator/viewer; подтверждение двумя администраторами для override/abort/чувствительных ACTOR.*

## 4) Процессор (P30) и Process Intelligence

- Петля perceive→appraise→decide→act→observe→learn; события (чат/напоминания/инциденты/цели/расписания) → очередь → выполнение шагов процессов.
- Интеграции: P27 подпись, P28 флаги, P29 гейты, P23/UI, P24/тесты.
- Process Intelligence (LLM‑booster):
  - Назначение: анализ и улучшение цепочек решения задач/достижения целей на основе подписи шагов и метрик качества.
  - Источники: `signature_steps`, метрики §7 (p95 стадий, success_rate, incidents), контекст задач/целей.
  - Тактики: рекомендации по маршрутизации (эвристика/LLM/смешанный), подсказки RouterContext, генерация рефлексивных Квантов (см. §13.5/§30) для корректировок курса.
  - Ограничения: изменения политик/фич‑профилей — только через RBAC/Two‑Keys (P29/P28); статлес‑анализ по умолчанию.

## 5) Модели данных

### 5.1 Кратко

- Таблицы `soul_processes`, `soul_process_steps`, `soul_process_step_dependencies`, `soul_process_executions`, `soul_process_step_executions` — полный DDL ниже.
- Версионирование процессов: semver; dual‑run для major; feature‑flag переключение профилей (P28); хранить active_version/supported_versions.

### 5.2 Полный DDL (self-contained)

```sql
-- Таблица определений процессов
CREATE TABLE soul_processes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    version VARCHAR(50) NOT NULL,
    category process_category NOT NULL,
    priority DECIMAL(3,2) CHECK (priority >= 0.0 AND priority <= 1.0),
    criticality process_criticality NOT NULL,
    
    -- Триггеры и расписание
    trigger_config JSONB NOT NULL,
    schedule_config JSONB,
    timeout_ms INTEGER NOT NULL DEFAULT 300000,
    max_retries INTEGER NOT NULL DEFAULT 3,
    
    -- Схемы данных
    input_schema JSONB NOT NULL,
    output_schema JSONB NOT NULL,
    
    -- SLA и мониторинг
    sla_requirements JSONB NOT NULL,
    monitoring_config JSONB NOT NULL,
    
    -- Безопасность
    security_level security_level NOT NULL,
    privacy_requirements JSONB NOT NULL DEFAULT '[]',
    rbac_permissions JSONB NOT NULL DEFAULT '[]',
    
    -- Поддержка модальностей
    supported_languages JSONB NOT NULL DEFAULT '["ru", "en"]',
    supported_modalities JSONB NOT NULL DEFAULT '["text"]',
    feature_flags JSONB NOT NULL DEFAULT '[]',
    
    -- Метаданные
    owner VARCHAR(255) NOT NULL,
    tags JSONB NOT NULL DEFAULT '[]',
    documentation_url VARCHAR(500),
    
    -- Связи
    parent_process_id UUID REFERENCES soul_processes(id),
    
    -- Аудит
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by VARCHAR(255) NOT NULL,
    
    -- Индексы
    CONSTRAINT unique_process_name_version UNIQUE (name, version)
);

CREATE INDEX idx_soul_processes_category ON soul_processes(category);
CREATE INDEX idx_soul_processes_priority ON soul_processes(priority DESC);
CREATE INDEX idx_soul_processes_owner ON soul_processes(owner);
CREATE INDEX idx_soul_processes_tags ON soul_processes USING GIN(tags);

-- Таблица шагов процессов
CREATE TABLE soul_process_steps (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    process_id UUID NOT NULL REFERENCES soul_processes(id) ON DELETE CASCADE,
    step_order INTEGER NOT NULL,
    
    name VARCHAR(255) NOT NULL,
    description TEXT,
    step_type process_step_type NOT NULL,
    actor VARCHAR(100) NOT NULL,
    function_id VARCHAR(255) NOT NULL,
    
    -- Схемы данных шага
    input_schema JSONB NOT NULL,
    output_schema JSONB NOT NULL,
    
    -- Управление выполнением
    timeout_ms INTEGER NOT NULL DEFAULT 30000,
    retries INTEGER NOT NULL DEFAULT 1,
    error_policy error_policy NOT NULL DEFAULT 'fail',
    
    -- SLA шага
    sla_metrics JSONB NOT NULL,
    
    -- Безопасность шага
    security_level security_level NOT NULL,
    privacy_requirements JSONB NOT NULL DEFAULT '[]',
    
    -- Поддержка модальностей
    multilingual_support BOOLEAN NOT NULL DEFAULT false,
    multisensory_support JSONB NOT NULL DEFAULT '["text"]',
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT unique_process_step_order UNIQUE (process_id, step_order)
);

CREATE INDEX idx_soul_process_steps_process_id ON soul_process_steps(process_id);
CREATE INDEX idx_soul_process_steps_actor ON soul_process_steps(actor);
CREATE INDEX idx_soul_process_steps_function_id ON soul_process_steps(function_id);

-- Таблица связей между шагами
CREATE TABLE soul_process_step_dependencies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    process_id UUID NOT NULL REFERENCES soul_processes(id) ON DELETE CASCADE,
    predecessor_step_id UUID NOT NULL REFERENCES soul_process_steps(id) ON DELETE CASCADE,
    successor_step_id UUID NOT NULL REFERENCES soul_process_steps(id) ON DELETE CASCADE,
    dependency_type dependency_type NOT NULL DEFAULT 'sequence',
    condition_expression TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT unique_step_dependency UNIQUE (predecessor_step_id, successor_step_id),
    CONSTRAINT no_self_dependency CHECK (predecessor_step_id != successor_step_id)
);

CREATE INDEX idx_soul_process_step_deps_process_id ON soul_process_step_dependencies(process_id);
CREATE INDEX idx_soul_process_step_deps_predecessor ON soul_process_step_dependencies(predecessor_step_id);
CREATE INDEX idx_soul_process_step_deps_successor ON soul_process_step_dependencies(successor_step_id);

-- Таблица выполнений процессов
CREATE TABLE soul_process_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    process_id UUID NOT NULL REFERENCES soul_processes(id),
    process_version VARCHAR(50) NOT NULL,
    
    status process_execution_status NOT NULL DEFAULT 'pending',
    priority DECIMAL(3,2) NOT NULL,
    
    input_data JSONB NOT NULL,
    output_data JSONB,
    
    execution_context JSONB NOT NULL,
    trace_id UUID NOT NULL,
    correlation_id UUID,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    
    duration_ms INTEGER,
    steps_completed INTEGER NOT NULL DEFAULT 0,
    steps_failed INTEGER NOT NULL DEFAULT 0,
    
    error_message TEXT,
    error_stack TEXT,
    diagnostic_info JSONB,
    
    triggered_by VARCHAR(255),
    trigger_data JSONB
);

CREATE INDEX idx_soul_process_executions_process_id ON soul_process_executions(process_id);
CREATE INDEX idx_soul_process_executions_status ON soul_process_executions(status);
CREATE INDEX idx_soul_process_executions_priority ON soul_process_executions(priority DESC);
CREATE INDEX idx_soul_process_executions_trace_id ON soul_process_executions(trace_id);
CREATE INDEX idx_soul_process_executions_created_at ON soul_process_executions(created_at DESC);

-- Таблица выполнений шагов процессов
CREATE TABLE soul_process_step_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    execution_id UUID NOT NULL REFERENCES soul_process_executions(id) ON DELETE CASCADE,
    step_id UUID NOT NULL REFERENCES soul_process_steps(id),
    
    status step_execution_status NOT NULL DEFAULT 'pending',
    actor VARCHAR(100) NOT NULL,
    function_id VARCHAR(255) NOT NULL,
    
    input_data JSONB NOT NULL,
    output_data JSONB,
    
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    duration_ms INTEGER,
    
    attempt_number INTEGER NOT NULL DEFAULT 1,
    max_attempts INTEGER NOT NULL,
    error_message TEXT,
    error_stack TEXT,
    
    metrics JSONB NOT NULL DEFAULT '{}',
    
    signature_step_id UUID
);

CREATE INDEX idx_soul_process_step_executions_execution_id ON soul_process_step_executions(execution_id);
CREATE INDEX idx_soul_process_step_executions_step_id ON soul_process_step_executions(step_id);
CREATE INDEX idx_soul_process_step_executions_status ON soul_process_step_executions(status);
CREATE INDEX idx_soul_process_step_executions_actor ON soul_process_step_executions(actor);

-- Enum типы
CREATE TYPE process_category AS ENUM ('core', 'service', 'integration', 'maintenance');
CREATE TYPE process_criticality AS ENUM ('low', 'medium', 'high', 'critical');
CREATE TYPE process_step_type AS ENUM ('transform', 'validate', 'route', 'quality_gate', 'security_check', 'integration');
CREATE TYPE security_level AS ENUM ('public', 'internal', 'sensitive', 'critical');
CREATE TYPE error_policy AS ENUM ('fail', 'retry', 'skip', 'escalate');
CREATE TYPE dependency_type AS ENUM ('sequence', 'parallel', 'conditional', 'loop');
CREATE TYPE process_execution_status AS ENUM ('pending', 'running', 'paused', 'completed', 'failed', 'aborted');
CREATE TYPE step_execution_status AS ENUM ('pending', 'running', 'completed', 'failed', 'skipped', 'retrying');

```

## 6) Ошибки, компенсации, идемпотентность

- error_policy: fail/retry/skip/escalate; компенсации через `compensation_function_id`; реестр компенсирующих действий; идемпотентность по dedup_key.

## 7) Наблюдаемость и Acceptance

- Метрики (p50/p95, throughput, incidents, guard_chain_pass_rate, coverage_signature_percent) и инспекторы; Acceptance — как в P35 v2.0 (раздел 8) и v2.0.1 (Delivery Guard/RBAC/DSL).
- RT‑метрики (обязательно): `time_send_to_recv_ms{p50,p95}`, `processor.queue_len`, `events_processed_per_min`, доля фоллбеков batch→single, `rt_gap_closures_count`, `rt_time_to_first_result_ms`.
- RT‑Acceptance: при RT gap‑closure p95 `time_send_to_recv_ms ≤ 3000`, `rt_time_to_first_result_ms ≤ 1200`; Delivery Guard блокирует ответы без обязательной цепочки; JSON Validity ≥ 99% в stateless.

## 8) Карта стыковок с номерными ТЗ (выжимка 35‑шагового анализа)

- Must‑Have в P35: MetaLoop Actor (P02), Router Actor (P03), SelfConsistency (P06), Privacy (P08), Security Incident Response (P09), Schema Validation (P10), Process Eval (P13), Process API (P22).
- Should‑Have: Multilingual (P15), Voice (P18/P19), Multisensory (P31), Skills (P25), External Proxy (P34).

## 9) Конкретные эталонные процессы (для внедрения)

- Рождение Квантов: preanalysis → route → llm send/recv → parse → persist → rank → reply (Delivery Guard обязательный).
- RT Gap‑Closure: событие (нет нужных данных) → микро‑батч `n=1..3` (`TIMEOUT≤1500–3000 мс`, `append=true`) → parse → (probe) rank → (опц.) persist (по policy) → метрики/трасса.
- Цели: goal_signal → progress/assess/adjust → confirm/incident → plan‑task spawn.
- Напоминания/Календарь: due → notify/snooze/reschedule → confirm → RRULE next.
- Навыки: skill_signal → plan_session → run_session → feedback → spaced_repetition schedule.

## 10) План внедрения (12 недель)

- Этапы соответствуют P35 v2.0, раздел 7: инфраструктура → Process Actors → DSL/Intelligence → API/UI → спец‑процессы → тесты/прод.

## 14) Errata & Enhancements v2.0.1 (интегрировано)

### 14.1 Исправления

- Глоссарий: добавить термин `Ядро Соул (ЯС)` и уточнить `STRICT_JSON_QUANT`.
- RBAC/Two‑Keys: роли, разрешения; Two‑Keys для критических операций (PROCESS/ACTOR/QUALITY overrides).
- Delivery Guard (P27): обязательная цепочка шагов для видимых ответов; блок/инцидент при нарушении.
- Версионирование/миграции: semver, dual‑run для major, переключение P28; хранить active/supported_versions.

### 14.2 Расширения

- Hyperloop DSL: примеры маршрутизации, шагов, интервалов, очередей (priority+FIFO), REQUIRE TRACE.
- Саги/компенсации: `error_policy=escalate` + `compensation_function_id`.
- UI/UX (P23): Constructor/Runs/Quality экраны; наблюдаемость по умолчанию.
- Внешние интеграции (P34): proxy‑workflow, idempotency‑key, correlation‑id, подпись на границе.
- Базовые процессы: эталонные цепочки для Рождения Квантов, Целей, Напоминаний, Навыков.

## 11) Процесс общения Архитектора с Соул (under Processor control)

Цель: формализовать управляемый процесс взаимодействия Архитектора с Ядром через Hyperloop/панель, с трассировкой и инвариантами P27/P29.

Триггеры:

- Запрос Архитектора (UI/P23) или CLI/DSL (P36) на анализ/проверку/внесение изменений.
- Системные события: деградация метрик, инциденты качества, изменения фич‑профиля.

Шаги (эталонная цепочка, Hyperloop‑only):
1) perceive: зафиксировать контекст (цель операции, scope ТЗ, риски); шаг `svc.processor.perceive`.
2) appraise: оценить приоритет/Two‑Keys/требования безопасности; шаг `svc.processor.decide`.
3) plan: сформировать план Hyperloop‑команд/тестов; шаг `cmd.hyperloop.* (plan)`.
4) act: выполнить безопасные команды/тесты (INSPECTOR/TEST/FLAGS), собрать `trace_id`; шаги `cmd.hyperloop.*`. Архитекторский чат (`architect_chat`) работает строго через Hyperloop, stateless; SoulCore fallback запрещён.
5) observe: собрать результаты/метрики/инциденты; при провале — ретрай/эскалация/заявка (REQUEST.CREATE).
6) learn: записать знания/решения в Архив (REQUEST/notes), обновить политики/профили при одобрении Судьи (Two‑Keys).

Hyperloop (пример):

```text
REQUEST.CREATE type=architect_session subject="P35 process tuning" payload={"tz":"P35","goal":"guard tighten"}
INSPECTOR.RUN_ALL scope=signature
TEST.RUN key=p27_guard_chain
FLAGS.APPLY_PROFILE name=prod_safe
CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"

```

Процессор: события `architect_session_start|result` инжектируются для учёта и метрик; Delivery Guard включён для любых видимых ответов в диалогах с Архитектором.

Acceptance:

- Все действия Архитектора проходят через RBAC/Two‑Keys, фиксируются в подписи; инспекторы/тесты зелёные до публикации изменений.

### 11.1 Эталонная цепочка (соответствует исходным вводным) и маппинг на svc.*

1) Сообщение Архитектора → `svc.soul.preanalysis` (извлечение ключевых слов, интентов, контекста; P01/P03).
2) Оценка ключевых слов/повестки → `svc.soul.router_decide` (маршрутизация по стратегии; P03).
3) Сборка дополнительной информации/промптов → `svc.context.enrich` и `svc.prompt.build` (подготовка входа в LLM; P22/P36).
4) Запрос в большую LLM → `svc.llm_client.send` / получение → `svc.llm_client.recv` (stateless; db=None; P14/P30).
5) Получение и строгий разбор ответа → `svc.parser.json_strict` (STRICT_JSON_QUANT; P10/P27).
6) Дообогащение/санитизация → `svc.sanitizer.clean` и, при необходимости, `svc.context.enrich_post` (P09/P08).
7) Разбор смыслов → `svc.quant.analyze` и рождение квантов → `svc.persist.quant` (single/persistent) с `quant_links` к инициатору (P27/P30, см. §13.3/13.9).
8) Ответ Архитектору → `svc.chat.reply_render` (Delivery Guard перед публикацией; см. обязательную цепочку).

Требуется соответствие P‑ТЗ: P01 (meaning), P03 (router), P10 (schema/STRICT), P14 (provider), P27 (signature), P29 (гейты), P30 (processor), P36 (DSL). Любой видимый ответ допускается только если вся цепочка присутствует в `signature_steps`.

## 12) Процесс рождения Квантов — инициатор Дирижёр (under Processor control)

Цель: гарантировать управляемое и наблюдаемое рождение Квантов по событиям/повестке.

Триггеры:

- События очереди Процессора (чат/напоминание/цель/инцидент/календарь) и плановые слоты.

Шаги (цепочка):
1) preanalysis (svc.soul.preanalysis) — извлечение смысла/контекста.
2) routing (svc.soul.router_decide) — выбор стратегии/модулей.
3) llm send/recv (svc.llm_client.*) — генерация кандидатов (batch → db=None).
4) parse (svc.parser.json_strict) — строгий парсинг.
5) persist (svc.persist.*) — запись Кванта/связей (в single/persistent режимах).
6) rank (svc.quant.rank) — обновление рейтингов.
7) reply_render (svc.chat.reply_render) — подготовка видимого ответа (если есть).

Инварианты:

- Delivery Guard — обязательная цепочка шагов перед любым видимым ответом.
- Идемпотентность и dedup по ключу события.

Hyperloop (смок):

```text
CORE.PIPELINE.RUN input_text="Рождение Квантов: смок" WITH TRACE
CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.soul.router_decide,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"

```

Процессор: Дирижёр оркестрирует выполнение шагов, регистрируя `svc.processor.*` и `cmd.hyperloop.*`, управляет очередями по приоритетам.

Acceptance:

- `signature_steps` содержат все шаги; при нарушении — блок публикации и инцидент; метрики p95 по стадиям в норме.

## 13) Процесс: от Инициатора Кванта до Рождения Кванта (настройка, исполнение, тесты)

Цель: детерминированно породить Квант по запросу инициатора, зафиксировать принадлежность/связи, встроить его в цепочку решения задачи/достижения цели, обеспечить подпись/инварианты и последующий анализ эффективности.

### 13.1 Инициаторы и контекст

- Инициаторы: задача плана (`plan_tasks.id`), цель (`goals.id`), календарное событие/напоминание (`calendar_events.id`/`reminders.id`), инцидент (`processor_incidents.id`), пользовательское сообщение (chat), внешний прокси (P34).
- Формат запроса (envelope): `initiator={type,id}`, `intent={class: plan_support|goal_progress|calendar_support|...}`, `context={...}`, `priority`, `due_at?`, `dedup_key`.

### 13.2 Поток (OODA под управлением Процессора и Дирижёра)

1) perceive: собрать контекст инициатора, проверить дубликаты по `dedup_key`, прочитать политики/флаги.
2) appraise: оценить приоритет/срочность/риск, бюджет LLM, выбрать профиль.
3) decide (Дирижёр): маршрут «эвристика | LLM | шаблон | смешанный»; выбрать класс Кванта.
4) act — рождение Кванта:

   - stateless: `svc.llm_client.send/recv` → `svc.parser.json_strict` (если нужен LLM);
   - persist (single): `svc.persist.quant`, запись связей `quant_links`.

5) observe: подтвердить успех парсинга/записи; при провале — ретрай/компенсация/эскалация.
6) learn: обновить ранги, метрики, при необходимости — инициировать рефлексивный Квант (см. §30).

Обязательная цепочка подписи перед публикацией видимого ответа: `svc.soul.preanalysis, svc.soul.router_decide, svc.llm_client.send, svc.llm_client.recv, svc.parser.json_strict, svc.chat.reply_render` (см. Delivery Guard).

### 13.3 Принадлежность и физические связи Кванта

- Основная связь: `quant_links(from_quant=<new_quant_id>, to_entity_type=<initiator_type>, to_entity_id=<initiator_id>, relation_type='born_for'|'supports'|'advances'|'triggers')`.
- Дополнительные связи:
  - к цели: `advances|assesses|adjusts` (см. §29);
  - к задаче плана: `supports|closes|confirms` (см. §24);
  - к календарю: `triggers|confirms|snoozes` (см. §28);
  - к навыку: `plans|improves|assesses` (см. P25 §15);
  - к инциденту: `explains|mitigates`.
- Требования: запись хотя бы одной «основной» связи на этапе рождения; недопустима «висячая» сущность без принадлежности в режимах single/persistent.

### 13.4 Цепочка решения задачи (построение и контроль)

- Модель: FSM из §25, связанный с инициатором; каждый новый Квант формирует ребро в маршруте решения.
- Политики качества:
  - SelfConsistency (P06) — согласованность шагов/данных;
  - Judge/Gendarme (P29) — ворота перед публикацией и ключевыми изменениями (Two‑Keys при опасных действиях);
  - RouterContext (P03) — стабильность ветки/контекста.

### 13.5 Анализ эффективности и оптимизация цепочек

- Метрики: `time_to_progress_ms`, `chain_length`, `success_rate`, вклад в KPI цели (см. §29.5), p95 стадий.
- Инструменты: A/B (P04) тактик рождения Квантов, Process Intelligence (§4) для рекомендаций (снижение латентности, повышение успеха), рефлексия (§30) при деградации.
- Эволюция: шаблоны «успешных» цепочек сохраняются, используются для эвристик/Router hints.

### 13.6 Гиперлуп — настройка и тестирование процесса

Примеры:

```text
# Инъекция запроса на рождение Кванта для задачи плана
PROCESSOR.EVENT.INJECT kind=plan_update payload={"plan_task_id":"t-42","intent":"plan_support","dedup_key":"plan:t-42:2025-09-19"}
PROCESSOR.PROCESS_ONCE

# Смок-цепочка ядра с подписью и проверкой
CORE.PIPELINE.RUN input_text="Рождение Кванта: смок" WITH TRACE
CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.soul.router_decide,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"

# Инспекторы/тесты качества связей
INSPECTOR.RUN key=signature.required_steps.consistency
TEST.RUN key=p29.quant_links_ownership

```
Ожидается: наличие `quant_links(born_for|supports)` на новый Квант; присутствуют обязательные шаги подписи.

### 13.7 Требуемые доработки ЯС (если отсутствуют)

- Данные:
  - ввести/проверить таблицу `quant_links` (индексы: `to_entity_type,to_entity_id`, GIN по `relation_type` при необходимости);
  - обеспечить миграции для `plan_tasks`, `goals`, `reminders`, консистентные ключи.
- Инспекторы/тесты (P27/P29):
  - инспектор `signature.required_steps.consistency` — правила для цепочек рождения;
  - тест `p29.quant_links_ownership` — запрет рождения Кванта без «основной» связи к инициатору.
- Политики/фичефлаги (P28):
  - `processor.quant_birth.mode` (heuristic|llm|mixed), `quant_links.enforce_ownership=true`.
- UI (P23):
  - виджет цепочки решения по инициатору: маршрут Квантов, текущий прогресс, узкие места.

### 13.8 Acceptance (процесс рождения)

- По каждому событию‑инициатору в режимах single/persistent рождается Квант с записью основной связи в `quant_links` к инициатору.
- Обязательная цепочка шагов подписи присутствует для видимых ответов; Delivery Guard блокирует публикацию при нарушении.
- Метрики/трассы доступны; инспекторы/тесты зелёные; Process Intelligence выдаёт рекомендации при росте p95 или снижении успеха.

### 13.9 Задача: схемы БД для quants/инициаторов и SQL‑инспектор владения

Требование:

- Определить и зафиксировать в БД схемы:
  - `quants(id uuid pk, class text, purpose text, payload jsonb, created_at timestamptz, created_by bigint, trace_id uuid, tags text[])` (+ индексы: `created_at desc`, GIN по `tags`).
  - `quant_links(id uuid pk, from_quant uuid, to_entity_type text, to_entity_id text, relation_type text, weight float, created_at timestamptz)` (см. миграции §13.7).
  - Инициаторы (проверка наличия): `plan_tasks`, `goals`, `reminders`, `calendar_events`, `processor_incidents` — первичные ключи и необходимые поля `status|due_at`.
- Обновить миграции Alembic, если какие‑либо из указанных сущностей отсутствуют или расходятся со спецификацией.

Инспектор качества (P29):

- Реализовать SQL‑инспектор `p29.quant_links_ownership` который:

  1) Выбирает последние N (конфиг) записей из `quants`.
  2) Проверяет на каждую запись наличие хотя бы одной строки в `quant_links` с `from_quant=<id>` и `relation_type in ('born_for','supports','advances','triggers')`.
  3) При отсутствии — возвращает `failed` с перечнем проблемных `quant_id`.

- Параметры: окно времени/лимит N, список допустимых `relation_type`.

Acceptance:

- Миграции применяются без ошибок; таблицы и индексы присутствуют.
- Инспектор возвращает `passed` при корректной привязке и `failed` c подробностями при нарушениях.
- `TEST.RUN key=p29.quant_links_ownership` интегрирован в smoke‑набор и CI Schema Guard процесса (внутренний режим).

### 13.10 Практические проверки (API и Hyperloop)

- Быстрые проверки API (PowerShell):
  - Базовый URL: `API_BASE`
  - Заголовок: `X-Telegram-User-ID: ADMIN_TG_ID`
  - Примеры:

```powershell
$H=@{ 'X-Telegram-User-ID'='ADMIN_TG_ID' }
Invoke-RestMethod -Uri 'API_BASE/health' -Headers $H -Method Get
Invoke-RestMethod -Uri 'API_BASE/admin/soul/llm/test?provider=gigachat&prompt=ping' -Headers $H -Method Get
$B=@{ input_text='single test'; num_candidates=1 } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'API_BASE/soul/process' -Headers $H -Method Post -ContentType 'application/json' -Body $B

```

- Hyperloop DSL (смоки):

```powershell
$B=@{ commands='CORE.PIPELINE.RUN input_text="Рождение Кванта: смок" WITH TRACE' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'API_BASE/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B
$BI=@{ commands='INSPECTOR.RUN_ALL' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'API_BASE/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $BI

```

Ожидается: `ok=true`, наличие `signature.trace_id`, `signature_steps`, `signature_saved_steps`; в `TRACE.STEPS` присутствуют шаги Delivery Guard.

### 13.11 Отметки выполнения инкремента (P35)

- [OK] Инициатор → Рождение Кванта: поток и инварианты — см. §13.1–13.6.
- [OK] Принадлежность/связи `quant_links` к инициатору — см. §13.3/§13.7/§13.9.
- [OK] Подпись/Delivery Guard (обязательная цепочка) — см. §3/§12/§13.6/§14.
- [OK] Анализ цепочек/оптимизация (Process Intelligence, LLM‑booster) — см. §4/§13.5.
- [OK] Acceptance/тесты/инспекторы — см. §7/§13.6/§13.8/§13.9/§14.
- [OK] Практические проверки API/Hyperloop — см. §13.10.

Примечание (AGE sync): при синхронизации отношений использовать `COALESCE(connection_type::text,'semantic')` для `relation_type`.

## 14) Команда акторов: роли, интерфейсы и взаимодействия (канонично)

- Гиперлуп (P36): единый управляющий язык. Команды: `FLAGS.*`, `INSPECTOR.*`, `TEST.*`, `JUDGE.*`, `PROCESSOR.*`, `PROCESS.QUEUE.*`, `CORE.*`, `REQUEST.*`, `ACTOR.ROUTER.DECIDE`.
- Подпись/Delivery Guard (P27): обязательная цепочка шагов для видимых ответов; флаги: `signature.enabled`, `delivery_guard.enforce`, `signature.required_steps.single`; SDK `SignatureContext`; хранение `signature_steps`, инциденты `delivery_guard_failed`.
- Процессор (P30): очередь `processor_events`, политики `processor_policies` (`block.all`, `block.<kind>`), инциденты `processor_incidents`; админ‑API: `/api/admin/soul/processor/*` (`status|start|stop|agenda|event|process_once|runs|incidents`).
- Дирижёр/Роутер/Оркестратор: `ACTOR.ROUTER.DECIDE` (маршрутизация по модулям/политикам), `CORE.PIPELINE.RUN ... WITH TRACE` (смок ядра с подписью), системный оркестратор Sleep/Optimize/Harvest подключает модули по реестру.
- Судья/Жандарм (P29): `TEST.RUN key=...`, `JUDGE.CHARTER.UPSERT`, `JUDGE.CHECK`; инциденты `charter_incidents`; сервисный анализ через GigaChat (fallback DeepSeek).
- Архивариус: `REQUEST.CREATE|STATUS|LIST`; хранение в `service_requests`; `REQUEST.STATUS ... done` — завершение заявки.
- Мать флагов (P28): профили `prod_safe|diagnostics_on|dev_fast` через `FLAGS.APPLY_PROFILE`; `FLAGS.RECONCILE policy=p27` — приведение инвариантов подписи.
- Отец санитайзеров: `SANITIZER.PREVIEW` (предпросмотр очистки), ключи: `sanitizer.visible_text.enabled|patterns`, `sanitizer.thought_form.enabled|patterns`.

### 14.1 Интеграция акторов в основные процессы

- Рождение Квантов: `CORE.PIPELINE.RUN ... WITH TRACE` → шаги P27; при persist — `svc.persist.*`; владение квантов проверяется инспектором `p29.quant_links_ownership`. Через Hyperloop: `QUANT.CREATE`, `QUANT.LINK`, `QUANT.LINK.CHECK`.
- Цели: auto‑goal по policy (ограничения ratio/daily/max, близость к существующим), подтверждение Судьёй (при включённых политиках) — `JUDGE.*`/Two‑Keys.
- Напоминания: события в `processor_events(kind=reminder)` → Процессор `process_once`; снести блокировки через `processor_policies`.
- Навыки/Optimize: системные модули Sleep/Optimize/Harvest запускаются оркестратором (ночной слот) с фиксацией подписей и метрик.

Дополнительные команды (канонично):

- `SCHEMA.ENSURE_QUANT_LINKS` — гарантированное наличие `quant_links` на PROD (создание таблицы и индексов).
- `GOAL.CREATE quant_id=<uuid> [title,description,priority]` — создание цели на квант с учётом дрейфа схемы.

Пример связки (квант → пользователь → цель):

```text
QUANT.CREATE thought_form="P35 quant via hyperloop" energy_weight=0.5
SCHEMA.ENSURE_QUANT_LINKS
QUANT.LINK from_quant="<QID>" to_type=user to_id="468326902" relation=born_for
QUANT.LINK.CHECK from_quant="<QID>" to_type=user to_id="468326902"
GOAL.CREATE quant_id="<QID>" title="P35 goal via hyperloop" priority=0.7
QUANT.LINK from_quant="<QID>" to_type=goal to_id="<GOAL_ID>" relation=born_for
QUANT.LINK.CHECK from_quant="<QID>" to_type=goal to_id="<GOAL_ID>"

```

Примеры DSL (смок):

```text
FLAGS.APPLY_PROFILE name=prod_safe
CORE.PIPELINE.RUN input_text="Рождение Квантов: смок" WITH TRACE
CORE.TRACE.REQUIRE chain="svc.soul.preanalysis,svc.soul.router_decide,svc.llm_client.send,svc.llm_client.recv,svc.parser.json_strict,svc.chat.reply_render"
CORE.PIPELINE.RUN input_text="RT gap-closure smoke" WITH TRACE TIMEOUT=1200
ACTOR.ROUTER.DECIDE input_text="RT policy check" context_data={"priority":0.9}
"BATCH.GENERATE_QUANTS n=3 input_text=\"RT micro-batch\" append=true TIMEOUT=3000"
ACTOR.ROUTER.DECIDE input_text="Оркестратор смок" context_data={"user_id":468326902}
REQUEST.CREATE type=architect_session subject="P35 smoke" payload={"note":"ok"}

```

Acceptance (акторы):

- Команды Hyperloop по всем актором возвращают `ok`; шаги `cmd.hyperloop.*` и P27 фиксируются в `signature_steps` (доступны через `TRACE.STEPS`).
- Профиль фичефлагов применим; Guard включаем/выключаем без регресса видимого ответа.
- Инспекторы и тесты P29 зелёные; системные события в Процессоре обрабатываются, политики блокировок применяются; `quant_links` присутствует, линковки к user/goal проходят, проверки `QUANT.LINK.CHECK` возвращают `count>=1`.
- Архивариус: реестр — операции выполнены (регистрация `hyperloop_engine.py`); допускается добавление дополнительных артефактов (документы P35/P36, openapi, конфиги).


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
