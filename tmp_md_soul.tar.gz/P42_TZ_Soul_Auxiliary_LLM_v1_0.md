# P42 — Вспомогательная LLM (Aux Phi‑4) / Маршрутизация, Расписание

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — инвентари.
- `tmp_p_series_plan.json` — план P‑серии.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр.
- `Soul/P14_TZ_Soul_MultiProviderRouting_v1_0.md`, `Soul/P21_TZ_P95_Observability_and_Regulation_v1_0.md`, `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`, `Soul/P28_TZ_FeatureFlags_Registry_and_Policies_v1_0.md`, `Soul/P30_TZ_Soul_Processor_v2_0.md`, `Soul/P36_TZ_Hyperloop_DSL_v1_1.md` — ключевые интеграции.

Дата: 2025‑10‑06

## Контуры

- Провайдер Aux: `phi-4` (llama.cpp/onnx), публичный прокси `/api/aux-llm`.
- Совместимые пути: `/v1/completions`, `/completion`, `/v1/chat/completions` (автоматический перебор).
- Таймауты сервисов: до 60000 мс; ретраи: 2.
- Смоки Admin: `POST /api/admin/llm/service_smoke` — принудительный `model_config` (Aux phi‑4, `max_tokens=64`).

## Расписание Phi

- Ключи БД (`soul_settings`):
  - `phi.schedule.enabled` (bool)
  - `phi.schedule.total_minutes_per_day` (int)
  - `phi.schedule.windows` (json: [{start,end}])
  - `phi.schedule.reserve.policy` (string)
  - `phi.schedule.min_slice_sec`, `phi.schedule.max_slice_sec` (int)
  - `phi.schedule.criticality.default` (float)
- Сервис: `backend/app/services/phi_schedule_service.py` — проверка окна и возврат `{allow, eta_sec}`.
- Интеграция:
  - `LLMClient` — сверка перед Aux сервисами, метрика `phi_schedule_reserve_total{allow}`.
  - `ProcessorScheduler` — перенос `aux.smoke.*` при `eta_sec>0` (перепланировка `due_at`).

## Маршрутизация/Режимы

- Ключи:
  - `llm.routing.mode = primary_only|primary_with_aux_failover|aux_primary_python_fallback`
  - `aux.service.types.override = true|false`
  - `llm.aux.provider = phi-4`, `llm.aux.url`, `llm.aux.timeout_ms.svc`, `llm.aux.retries.svc`
- Поведение:
  - При `aux_primary_python_fallback` и/или `aux.service.types.override=true` сервисные типы идут в Aux.
  - `llm_service_smoke` форсирует Aux и уменьшенные токены.

## Наблюдаемость

- Метрики: `llm_aux_req_total`, `llm_aux_err_total`, `llm_aux_latency_ms`, `phi_schedule_reserve_total{allow}`.
- Смоки A/B: `scripts/tmp_ab_runner.py`, сводка `scripts/tmp_ab_summary.py`; артефакты в `out/ab_*.jsonl`, `out/ab_summary.*`.

# P42 — Техническое задание: Вспомогательная LLM система (Aux LLM) для сервисных функций и failover

- Аннотация
- Цель: внедрить вспомогательную LLM систему (далее Aux LLM), которая берёт на себя все сервисные функции ядра (перевод, консистентность, эмодзи/эмоции, интроспекция, резюме и т.п.) и автоматически заменяет «большую» LLM при её недоступности (failover), сохраняя инварианты STRICT_JSON, безопасность и наблюдаемость.
- Основание: раздел «Интеграция opensource LLM» в `Soul/Report_Soul_AI_Scientific.md` (§world integration, §tz42-candidates) и матрица P01–P51.

- Ограничения окружений
- Локально/тест: не устанавливать и не использовать DeepSeek; сервисные функции и failover проверяются на локальном Aux провайдере `phi3-mini` (stateless).
- PROD: все ключи/провайдеры только из PROD ENV; соблюдение RBAC/Two‑Keys, журнал действий. Резерв места — предварительно (см. §11).

Выбранная модель Aux (фиксируется)

- Единственный Aux‑провайдер в рамках P42: `Phi‑3 Mini 3.8B (Instruct)` под MIT лицензией.
- Альтернативные варианты исключены из настоящего ТЗ, чтобы исключить двусмысленность.

Область и роли

- Область: серверное ядро Soul (P01/P03/P14/P21/P27/P28/P29/P30/P41), административные фасады (P22), план/инциденты (P40/P50), личность (P51), квоты/роли (P32).
- Роли доступа: `soul.admin` (управление провайдером/флагами), `architect` (Two‑Keys для опасных операций маршрутизации/профилей), `premium+` (использование сервисных функций согласно квотам P32/P41).

1) Функциональные требования
1.1 Failover (замена «большой» LLM)

- Условия переключения (любое):
  - Circuit Breaker primary открыт (ошибки/таймауты по порогам).
  - Достигнуты лимиты/квоты (429/402) по P41/P32.
  - Ошибки авторизации/сети у primary или SLA p95 выходит за бюджет.
  - Флаг аварийного профиля включён (см. P28: `aux.failover.force=true`).
- Режимы маршрутизации (P14): `primary_only | primary_with_aux_failover | aux_primary_python_fallback` (для сервисных функций), задаются в БД настройкой `llm.routing.mode`.

1.2 Сервисные функции (перевод/оценки/инструменты)

- По умолчанию все «сервисные типы запросов» маршрутизируются в Aux LLM (может быть переопределено профилем):
  - `planner`, `consistency`, `judge`, `emoji_analysis`, `emotion_detection`, `translator`, `introspection_quant`, `self_consistency`, `reminder` (перечень расширяемый через настройки).
- Mapping типов → Aux LLM управляется ключом `llm.aux.request_types` (JSON‑массив в БД).

1.3 STRICT_JSON и статусы batch

- Любые ответы Aux LLM обязаны соответствовать контракту STRICT_JSON_QUANT (P01). В stateless‑batch `desired_action=[]` (нормализация).
- Нельзя выводить текст вне JSON; NEGATIVE‑санитизация обязательна.

1.4 Router V2 (P03)

- Эвристики выбора: сервисные типы → Aux; сложные рассуждения/код → primary; мультиязычные RU/EN задачи перевода → Aux.
- При failover эвристикам разрешено делать мягкие смещения, но итог должен фиксироваться в событии аудита.

1.5 Управление/флаги (P28)

- Профили:
  - `aux_failover_on`: включает `llm.routing.mode=primary_with_aux_failover`, пороги CB и таймауты для сервисных функций, метрики экспорта.
  - `aux_primary_services`: принудительно направляет все сервисные типы в Aux независимо от состояния primary.
- Ключи в БД (через `SoulSettingsService`):
  - `llm.aux.provider = phi3-mini`
  - `llm.aux.timeout_ms.<function>` и `llm.aux.retries.<function>`
  - `llm.aux.request_types` (JSON‑список типов)
  - `llm.routing.mode` (см. выше)
  - `aux.failover.cb.{error_rate_threshold,timeout_ms,p95_budget_ms,open_seconds}`
  - `aux.service.types.override` (bool) — при true все сервисные типы идут только в Aux.

1.6 RBAC/Quotas (P32/P41)

- Проверка квот: перед отправкой в Aux вызывается `require_llm_quota` по роли пользователя; при исчерпании — 402/429 и аудит.
- Rate limiting: лимитер API учитывает совокупные маршруты; для Aux введены отдельные лимиты класса `aux_llm`.

1.7 API/Фасады (P22)

- Тест провайдера: `GET /api/admin/soul/llm/test?provider=aux&prompt=ping` (возвращает JSON с полями ok/p95/tokens).
- Read‑only статус профиля: `GET /api/admin/llm-providers/aux/status` (mode, health, recent p95, error_rate, circuit_state).

1.8 Telemetry/Observability (P21)

- Метрики Prometheus (префикс `llm_aux_*`):
  - `llm_aux_req_total{function,route}`
  - `llm_aux_err_total{function,code}`
  - `llm_aux_latency_ms{function}{p50,p95,p99}`
  - `llm_failover_used_total{reason}` (circuit_open, quota, timeout, 5xx, manual)
  - `llm_route_selected_total{route=primary|aux}`
- Аудит событий: `soul_llm.aux.failover`, `soul_llm.route.decide`, `soul_llm.cb.state_change`.

2) Нефункциональные требования (SLA/SLO)

- JSON Validity (stateless батчи): ≥ 99.0%.
- p95 latency (сервисные функции): ≤ 1800 мс (целевой), допустимый пик ≤ 3000 мс (1% запросов).
- Error rate (HTTP/LLM): ≤ 1.5% на окне 5 мин; при превышении — автооткрытие CB и перевод на Aux.
- Доля фоллбеков single←batch: ≤ 5%.

3) Интеграции по P‑серии (обязательные)

- P01 STRICT_JSON: строгость схемы, автопочинка JSON при погрешностях — без нарушения контракта.
- P03 Router V2: эвристики и bias для сервисных типов; журнал решений роутера.
- P14 Multi‑Provider: регистрация Aux как провайдера, таблица правил выбора, CB/ретраи/таймауты.
- P16 Sleep/Memory: совместимость контекста 30/70_v2; не изменять алгоритм под Aux.
- P21 Health/Observability: метрики/события, дешборды p95/error/failover.
- P22 API Alignment: синхронизация OpenAPI↔Pydantic↔DDL для путей провайдера/статуса.
- P27 Signature/Delivery Guard: шаги подписи `svc.llm_client.send/recv`, `svc.soul.router_decide`, `svc.chat.reply_render` обязательны.
- P28 Feature Flags: профили включения `aux_failover_on`, `aux_primary_services`; reconcile в Supervisor.
- P29 Quality/Gendarme: инспекторы JSON Validity, NEGATIVE, failover‑масштаб (без эскалации ошибок).
- P30 Processor: события планирования/обслуживания (`processor_events`) не должны блокироваться из‑за провайдера; failover прозрачен.
- P32 RBAC & Subscriptions: квоты/лимиты для Aux; тарифная матрица ролей.
- P41 Rate Limits/Quotas: AIMD/429; отдельный класс лимитов `aux_llm`.
- P43 Two‑Keys/HMAC: опасные изменения маршрутов/профилей — через Two‑Keys; execute‑signed для PROD.
- P45 Ingest/Quants: статусы batch генерации при использовании Aux; Acceptance QC сохраняются.
- P50 Incidents: при SEV1/2 падениях провайдера — автоматическая запись инцидентов и таймлайн failover.
- P51 Personality: неизменность личности; NEGATIVE‑гейт; влияния профиля не меняют выбор провайдера без явных правил.

- Связанные задачи (детализация интеграций)
- P05 Planner: обратная связь планировщику при failover (событие `planner.feedback.failover_used`), ограничение автопубликаций при Aux.
- P06 Self‑Consistency: включение `self_consistency` как сервисного типа в Aux; пороги согласованности.
- P07 DesiredAction: сохраняем deny‑by‑default исполнение при Aux; подсхемы DA не меняются.
- P11 Provenance: запись `provenance_edges` для Aux маршрута (класс `llm.aux`).
- P12 TraceViewer: быстрый фильтр по `route_selected=aux`.
- P23 UI Rebuild: панели статуса провайдера в админ‑UI; read‑only витрина режимов маршрутизации.
- P34 External Chat Proxy: health‑прокси отражает состояние Aux.

4) Архитектура и потоки

- Поток выбора: `LLMManager.select_route(request_type, locale, health, quotas)` → `primary|aux`.
- Circuit Breaker:
  - Ошибки/таймауты на окне T: при превышении порогов → `OPEN` на `open_seconds`.
  - Half‑open проба: доля трафика ≤ 0.1; при успехах — `CLOSE`, при фейлах — снова `OPEN`.
- Failover шаги:

  1) Primary попытка → ошибка/таймаут/429 → CB учёт.
  2) Решение роутера: `aux` (reason=...
  3) Вызов Aux LLM → STRICT_JSON парсинг; запись метрик/аудита.

- Сервисные типы: минуют primary; идут напрямую в Aux (если профиль активирован).

5) Настройки/Секреты/ENV

- Секреты только из PROD ENV; ключи Aux не логируются (политика P09/P22).
- Пример ENV (имена — ориентир, источник истины — БД настроек):
  - `LLM_AUX_PROVIDER=phi3-mini`
  - `LLM_AUX_API_URL=http://127.0.0.1:8085/v1/completions`
  - `LLM_AUX_TIMEOUT_MS_DEFAULT=1800`
  - Для PROD включение через фичепрофили P28 (`FLAGS.APPLY_PROFILE`).

6) API/DSL (P36) — предложения к реализации

- Admin API (P22):
  - `GET /api/admin/llm-providers/aux/status` — статус провайдера.
  - `POST /api/admin/llm-providers/aux/settings { key, value }` — изменение настроек (RBAC: soul.admin, Two‑Keys на опасные ключи).
- DSL (расширение P36):
  - `LLM.AUX.SET key=<k> value=<v>` (RBAC: soul.admin; Two‑Keys на ключи маршрутизации/CB).
  - `LLM.AUX.STATUS` — сводка health/metrics.
  - `LLM.ROUTING.MODE mode=<primary_only|primary_with_aux_failover|aux_primary_python_fallback>`.

7) Команда //ЛЛМ (UX)

- В пользовательских сценариях допускается текстовая команда `//ЛЛМ <инструкция>` для быстрого запроса к сервисной LLM (Aux) в рамках админских инструментов и smoke‑роутов. Команда пробрасывается в Aux с профилем `aux_primary_services` при активном режиме.

7) Метрики/панели (P21)

- Панель «Aux LLM»: p95/p99 по функциям, error_rate, доля failover, circuit_state, route_selected.
- Алерты: `llm_aux_error_rate>1.5% 5m`, `llm_failover_used_total{reason!~"manual"} > X/5m`, `llm_aux_latency_ms_p95>1800 5m`.

8) Acceptance (минимум)

- JSON Validity stateless ≥ 99.0%; NEGATIVE нарушений = 0.
- p95 ≤ 1800 мс по сервисным функциям (на окне 1h), фоллбеки single←batch ≤ 5%.
- Failover активируется при CB/квоты/429/таймауте и фиксируется в событиях/метриках.
- Смоки Hyperloop возвращают `trace_id` и шаги подписи (P27) присутствуют.
- Read‑only фасады статуса/теста провайдера доступны и защищены RBAC.

9) План внедрения

- Этап 1: Регистрация провайдера (P14), настройки/ENV, базовые метрики и смоки; профиль `aux_primary_services`.
- Этап 2: Circuit Breaker и failover режим `primary_with_aux_failover`; метрики/алерты; аудит событий.
- Этап 3: Инспекторы качества (P29) и дешборды; UI фасады статуса (read‑only); Two‑Keys на опасные операции.
- Этап 4: Расширение типов сервисных запросов и A/B‑оценка цен/latency; документация и обучение.

10) Быстрая реализация (безопасные шаги)

- Backend (минимальные PR‑изменения):
  - `llm_manager.py`: добавить `aux` провайдера в конфиг выбора, режимы failover, CB параметры из `SoulSettingsService`.
  - `llm_client.py`: чтение таймаутов/ретраев для Aux; маркировка метрик `route=aux`.
  - `soul_router_v2.py`: маршрут сервисных типов в Aux при активном профиле.
  - `monitoring.py`: экспорт метрик `llm_aux_*` и `llm_failover_used_total`.
  - `routers/llm_admin.py` (новый/расширение): `GET /api/admin/llm-providers/aux/status`, `POST /api/admin/llm-providers/aux/settings` (RBAC: soul.admin, Two‑Keys на ключи маршрутизации/CB).
  - `openapi.json`/Pydantic: добавить схемы ответов статуса/настроек.
- Flags (P28): добавить профили `aux_failover_on`, `aux_primary_services` в Supervisor.
- Docs: обновить `docs/PROJECT_STRUCTURE.md` (сделано), `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` (сделано), добавить раздел в `docs/LLM_SYSTEM_FIXES_v3_2.md`.

11) PROD резервирование места

- Каталоги (на сервере PROD): `/var/www/soulpulse/aux_llm/{logs,cache,tmp}` с владельцем `www-data` и правами `0750`.
- Логи/ротация: `logrotate.d/soulpulse-aux-llm` (ежедневно, 7 ротаций, compress), интеграция в journald — не требуется.
- Ограничения: хранить только служебные кэши/логи; модели локально не скачивать без отдельного решения (стоимость/лицензии).

12) Примечания безопасности

- Локально/тест: DeepSeek не устанавливать/не использовать.
- PROD: секреты строго из ENV; Two‑Keys на смену режима/провайдера; аудит всех отказов/разрешений (P44/P22).

13) Установка и интеграция Phi‑3 Mini (пошагово, PROD)

Предпосылки

- ОС: Linux (Prod). Пользователь: `www-data` (служба), root для установки.
- Порты: внутренний HTTP на `127.0.0.1:8085` (firewall закрыт наружу).
- Runtime: llama.cpp server (GGUF, CPU‑friendly), без GPU обязателен INT4/INT8 квант.

Шаг 1. Резерв диска и каталоги

- Создать каталоги моделей/логов/кэшей (см. §11), дополнительно: `/opt/models/phi3-mini`
- Право собственности `root:root`, чтение для `www-data` на модели, запись `www-data` в `logs/cache/tmp`.

Шаг 2. Загрузка модели Phi‑3 Mini (GGUF)

- Выбрать quant GGUF (например, `Q4_K_M`) с HuggingFace для «phi-3-mini-4k-instruct».
- Сохранить в `/opt/models/phi3-mini/phi3-mini-4k-instruct.Q4_K_M.gguf`.
- Контроль суммы (sha256) и прав `0640`.

Шаг 3. Установка llama.cpp (server)

- Сборка:

```bash
sudo apt update && sudo apt install -y build-essential cmake git curl
sudo git clone https://github.com/ggerganov/llama.cpp /opt/llama.cpp
cd /opt/llama.cpp
cmake -S . -B build
cmake --build build -j

```

- Бинарь: `/opt/llama.cpp/build/bin/server` (исполняемый, `0755`).

Шаг 4. Systemd unit для сервера

- Файл `/etc/systemd/system/phi3-aux-llm.service`:

```ini
[Unit]
Description=Phi-3 Mini Aux LLM (llama.cpp)
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/var/www/soulpulse/aux_llm
ExecStart=/opt/llama.cpp/build/bin/server -m /opt/models/phi3-mini/phi3-mini-4k-instruct.Q4_K_M.gguf -c 2048 -ngl 0 --host 127.0.0.1 --port 8085 --timeout 30 --parallel 2 --threads auto
Restart=always
RestartSec=3
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target

```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now phi3-aux-llm
curl -sS 127.0.0.1:8085/ | head -c 200 || true

```

Шаг 5. Nginx (опционально)

- Если требуется прокси: `location /aux-llm/ { proxy_pass http://127.0.0.1:8085; }` (внутренний only).

Шаг 6. Конфигурация Ядра «Соул» (DB Settings, P14/P28)

- В `SoulSettingsService` задать ключи:
  - `llm.aux.provider = phi3-mini`
  - `llm.aux.url = http://127.0.0.1:8085/v1/completions`
  - `llm.aux.timeout_ms.svc = 1800`, `llm.aux.retries.svc = 0..1`
  - `llm.aux.request_types = ["planner","consistency","judge","emoji_analysis","emotion_detection","translator","introspection_quant","self_consistency","reminder"]`
  - `llm.routing.mode = primary_with_aux_failover`
  - `aux.failover.cb.error_rate_threshold = 0.015`, `aux.failover.cb.p95_budget_ms = 1800`, `aux.failover.cb.open_seconds = 60`
- Включить профиль флагов (P28): `aux_primary_services` (по необходимости) и/или `aux_failover_on`.

  Примеры устойчивых вызовов (Hyperloop CLI):

```bash
# Статус проекта/канала
python ./Soul/scripts/hyperloop_cli.py --preflight

# Установка режима маршрутизации (через профиль фич)
python ./Soul/scripts/hyperloop_cli.py --dsl FLAGS.APPLY_PROFILE name="aux_failover_on"

# Проверка DSL smokes (с трассировкой)
python ./Soul/scripts/hyperloop_cli.py --dsl CORE.PIPELINE.RUN input_text="Aux LLM health check" WITH TRACE

```

15) Последовательность реализации (PROD команды)

Шаг A. Каталоги и права

```bash
sudo mkdir -p /var/www/soulpulse/aux_llm/{logs,cache,tmp}
sudo chown -R www-data:www-data /var/www/soulpulse/aux_llm/{logs,cache,tmp}
sudo chmod 0750 /var/www/soulpulse/aux_llm/{logs,cache,tmp}
sudo mkdir -p /opt/models/phi3-mini
sudo chown -R root:root /opt/models/phi3-mini
sudo chmod 0755 /opt/models/phi3-mini

```

Шаг B. Установка llama.cpp

```bash
sudo apt update && sudo apt install -y build-essential cmake git curl
sudo git clone https://github.com/ggerganov/llama.cpp /opt/llama.cpp
cd /opt/llama.cpp && cmake -S . -B build && cmake --build build -j

```

Шаг C. Загрузка модели (вариант с huggingface-cli)

```bash
python3 -m pip install -U huggingface_hub
huggingface-cli download microsoft/Phi-3-mini-4k-instruct-gguf Phi-3-mini-4k-instruct-Q4_K_M.gguf --local-dir /opt/models/phi3-mini --local-dir-use-symlinks False
sudo chown root:root /opt/models/phi3-mini/Phi-3-mini-4k-instruct-Q4_K_M.gguf
sudo chmod 0640 /opt/models/phi3-mini/Phi-3-mini-4k-instruct-Q4_K_M.gguf

```

Шаг D. Systemd unit и запуск

```bash
sudo tee /etc/systemd/system/phi3-aux-llm.service >/dev/null <<'EOF'
[Unit]
Description=Phi-3 Mini Aux LLM (llama.cpp)
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/var/www/soulpulse/aux_llm
ExecStart=/opt/llama.cpp/build/bin/server -m /opt/models/phi3-mini/Phi-3-mini-4k-instruct-Q4_K_M.gguf -c 2048 -ngl 0 --host 127.0.0.1 --port 8085 --timeout 30 --parallel 2 --threads auto
Restart=always
RestartSec=3
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now phi3-aux-llm
curl -sS 127.0.0.1:8085/ | head -c 200 || true

```

Шаг E. (Опционально) Nginx внутренняя прокси

```bash
sudo tee /etc/nginx/snippets/aux-llm.conf >/dev/null <<'EOF'
location /aux-llm/ {
  proxy_pass http://127.0.0.1:8085;
  proxy_read_timeout 60s;
}
EOF
sudo nginx -t && sudo systemctl reload nginx

```

Шаг F. Настройки в БД/фичепрофиль и смоки

```bash
# Включение профиля failover (через Hyperloop CLI)
python ./Soul/scripts/hyperloop_cli.py --dsl FLAGS.APPLY_PROFILE name="aux_failover_on"

# Смок с трассировкой и проверкой шагов подписи
python ./Soul/scripts/hyperloop_cli.py --dsl CORE.PIPELINE.RUN input_text="Aux LLM health check" WITH TRACE

```

Шаг G. SSH one‑liners (Windows PowerShell)

```powershell
$HOST = '217.12.38.238'
$KEY  = '.\Arh\spbd_ed25519'

# A1. Каталоги/права
ssh -i $KEY -o StrictHostKeyChecking=accept-new root@$HOST "mkdir -p /var/www/soulpulse/aux_llm/{logs,cache,tmp} /opt/models/phi3-mini; chown -R www-data:www-data /var/www/soulpulse/aux_llm/{logs,cache,tmp}; chmod 0750 /var/www/soulpulse/aux_llm/{logs,cache,tmp}; chown -R root:root /opt/models/phi3-mini; chmod 0755 /opt/models/phi3-mini"

# B1. Установка llama.cpp
ssh -i $KEY -o StrictHostKeyChecking=accept-new root@$HOST "apt update && apt install -y build-essential cmake git curl && git clone https://github.com/ggerganov/llama.cpp /opt/llama.cpp && cd /opt/llama.cpp && cmake -S . -B build && cmake --build build -j"

# C1. Загрузка GGUF (через huggingface-cli)
ssh -i $KEY -o StrictHostKeyChecking=accept-new root@$HOST "python3 -m pip install -U huggingface_hub && huggingface-cli download microsoft/Phi-3-mini-4k-instruct-gguf Phi-3-mini-4k-instruct-Q4_K_M.gguf --local-dir /opt/models/phi3-mini --local-dir-use-symlinks False && chown root:root /opt/models/phi3-mini/Phi-3-mini-4k-instruct-Q4_K_M.gguf && chmod 0640 /opt/models/phi3-mini/Phi-3-mini-4k-instruct-Q4_K_M.gguf"

# D1. Unit systemd, запуск и health
ssh -i $KEY -o StrictHostKeyChecking=accept-new root@$HOST "printf '%s\n' '[Unit]' 'Description=Phi-3 Mini Aux LLM (llama.cpp)' 'After=network.target' '' '[Service]' 'Type=simple' 'User=www-data' 'Group=www-data' 'WorkingDirectory=/var/www/soulpulse/aux_llm' 'ExecStart=/opt/llama.cpp/build/bin/server -m /opt/models/phi3-mini/Phi-3-mini-4k-instruct-Q4_K_M.gguf -c 2048 -ngl 0 --host 127.0.0.1 --port 8085 --timeout 30 --parallel 2 --threads auto' 'Restart=always' 'RestartSec=3' 'LimitNOFILE=65535' '' '[Install]' 'WantedBy=multi-user.target' > /etc/systemd/system/phi3-aux-llm.service; systemctl daemon-reload; systemctl enable --now phi3-aux-llm; curl -sS 127.0.0.1:8085/ | head -c 200 || true"

# E1. (Опционально) Nginx сниппет и reload
ssh -i $KEY -o StrictHostKeyChecking=accept-new root@$HOST "printf '%s\n' 'location /aux-llm/ {' '  proxy_pass http://127.0.0.1:8085;' '  proxy_read_timeout 60s;' '}' > /etc/nginx/snippets/aux-llm.conf; nginx -t && systemctl reload nginx"

```

Шаг 7. Маппинг форматов запроса/ответа

- LLMClient адаптировать к REST llama.cpp server: поля prompt, temperature, top_p, max_tokens; парсинг ответа в STRICT_JSON.
- NEGATIVE: жёсткий контракт «never output non-JSON».
- В stateless batch нормализовать `desired_action=[]`.

Шаг 8. Наблюдаемость (P21)

- Метрики на стороне ядра: `llm_aux_req_total`, `llm_aux_err_total`, `llm_aux_latency_ms{p50,p95,p99}`, `llm_failover_used_total{reason}`.
- Алерты: error_rate >1.5%/5m, p95 >3000ms/5m, всплеск failover без manual.

Шаг 9. RBAC/Quotas (P32/P41)

- Проверка квот `require_llm_quota` перед вызовом Aux; лимит‑класс `aux_llm`.

Шаг 10. Acceptance/смоки (P27/P24)

- `CORE.PIPELINE.RUN input_text="Aux LLM health check" WITH TRACE` — p95 ≤1800ms.
- JSON Validity ≥99% за 24h; NEGATIVE нарушений = 0; фоллбеки single←batch ≤5%.
- `TRACE.STEPS` содержит `svc.llm_client.send/recv`, `svc.soul.router_decide`, `svc.chat.reply_render`.

Шаг 11. Чек‑лист интеграции по файлам ядра

- `backend/app/services/llm_manager.py`: добавить профиль провайдера `phi3-mini` (URL/таймауты/ретраи/маркировка route=aux, CB‑параметры из Settings).
- `backend/app/services/llm_client.py`: REST вызов `/v1/completions`, маппинг параметров (prompt, max_tokens, temperature, top_p), разбор JSON.
- `backend/app/services/soul_router_v2.py`: маршрут сервисных типов в Aux при активном профиле/override.
- `backend/app/monitoring.py`: метрики `llm_aux_*`, счётчик `llm_failover_used_total`.
- `backend/app/routers/llm_admin.py` (новый/расширение): read‑only статус Aux и установка настроек (RBAC + Two‑Keys).
- OpenAPI/Pydantic: описать ответы статуса/настроек.

Шаг 12. Rollback/безопасная деградация

- Отключить unit: `systemctl disable --now phi3-aux-llm`.
- Включить профиль `aux_failover_on=false` (или `llm.routing.mode=primary_only`).
- Проверить смоки и метрики p95/ошибок (возврат к норме).

14) Дообучение Phi‑3 Mini (QLoRA) — дорожная карта

Корпус и формат

- Пары: `input_text → QuantStrict JSON` (RU bias). Шаблон вывода жёсткий (STRICT_JSON_QUANT).

Техника

- QLoRA (bnb 4‑bit), LoRA r=16–32, alpha=16–32, lr≈1e‑4, seq 1–2k, epochs 1–3.
- Инструменты: Transformers+PEFT+bitsandbytes; заморозка базовых слоёв; валидация JSON Validity/NEGATIVE.

Внедрение адаптера

- Хранить адаптер отдельно от базовых весов; включать флагом (P28) `aux.adapter.enabled=true`.
- Acceptance после фтн: не хуже базового по p95/err_rate, JSON Validity ≥99%.

Приложение A — Смоки Hyperloop (Windows PowerShell)

```text
# Тест связи/health (signed не обязателен для dev):
python .\Soul\scripts\hyperloop_cli.py --dsl CORE.PIPELINE.RUN input_text=\"Aux LLM health check\" WITH TRACE

# Применение профиля флагов (пример):
python .\Soul\scripts\hyperloop_cli.py --dsl FLAGS.APPLY_PROFILE name=\"aux_failover_on\"

# Предпросмотр статуса провайдера (через HTTP helper):
python .\Soul\scripts\hyperloop_cli.py --http-get https://mini.soulpulse.art/api/admin/llm-providers/aux/status

```


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
