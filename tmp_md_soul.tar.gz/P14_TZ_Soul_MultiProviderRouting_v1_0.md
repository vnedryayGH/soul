---

## Индекс взаимных ссылок (P01–P37)

- P03 RouterContext — влияет на объёмы/бюджеты контекста.
- P21 Health/Monitoring — метрики провайдеров.
- P23 UI Spec — отображение статуса провайдера.
- P27 Signature/Lineage — подпись переключений.
- P33 Personification — Mini Chat политика провайдеров.
- P35/36 — команды и процессы для трасс/инспекции.
- P45 Quant Generation Modes — источники/режимы генерации квантов (онлайн/офлайн, JSONL/SQL), связка с планированием.

### ТЗ Soul v1.0 — Стоимость/латентность: мульти‑провайдерный роутинг (LLM Multi‑Provider Routing)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: ЧАСТИЧНО ВЫПОЛНЕНО (MVP‑1: маршрутизация/фейловер/CB); CI‑отчёт добавлен

---

### 0. Executive summary

- Цель: управлять стоимостью и латентностью LLM‑вызовов, сохраняя качество, за счёт маршрутизации по провайдерам/аккаунтам на уровне функций ядра (`soul_core`, `planner`, `consistency`, `judge`, `safety_guard`…), с фейловером и бюджетами.
- Интеграция: расширение `LLMManager` профилями функций и стратегиями, конфиги провайдеров/аккаунтов/лимитов, метрики и аудит. По умолчанию — текущее поведение, фичефлаги OFF.
- Результат: предсказуемый SLA (p95), контролируемая стоимость «за квант», прозрачный фейловер и отчётность.

---

### 1. Актуальная реализация (аудит)

- В проекте уже используется выбор модели через `LLMManager.get_model_for_function(...)` (см. документацию пайплайна проекта).
- В стартовой инструкции зафиксированы практики таймаутов/ретраев и stateless режимов.
- ENV: провайдеры и ключи для DeepSeek/OpenAI/GigaChat присутствуют.

Вывод: есть точка выбора модели и базовые настройки. Нужны: стратегия маршрутизации per‑function, список провайдеров/аккаунтов, бюджетирование, фейловер, метрики «стоимость/латентность/ошибки».

---

### 2. Архитектура и точки интеграции

- `backend/app/services/llm_manager.py` — расширить функционалом:
  - Карта функций → стратегий/профилей: `function_profiles`.
  - Каталог провайдеров/аккаунтов: `providers`, `accounts`, лимиты и цены.
  - Роутер стратегии: `select_route(function, constraints) -> ProviderRoute`.
  - Исполнитель: обёртка с ретраями/таймаутами/фейловером.
- Вызовы в сервисах (`soul_core_manager`, `planner_service`, `consistency_service`, `judges`, `safety_guard`) остаются через `LLMManager.get_model_for_function(func)`.
- Никаких миграций БД в MVP. Метрики/аудит — через существующую подсистему.

---

### 3. Модель конфигурации (Pydantic/YAML)

Конфиг `backend/config/llm_routing.yaml`:

```yaml
providers:
  deepseek:
    base_url: https://api.deepseek.com
    pricing: { input_per_1k: 0.20, output_per_1k: 0.80 }
    default_models: { chat: deepseek-chat, fast: deepseek-mini }
  openai:
    base_url: https://api.openai.com
    pricing: { input_per_1k: 0.50, output_per_1k: 1.50 }
    default_models: { chat: gpt-4o-mini, fast: gpt-4o-mini }
  gigachat:
    base_url: https://api.aai.sbercloud.ru
    pricing: { input_per_1k: 0.10, output_per_1k: 0.30 }
    default_models: { chat: GigaChat }

accounts:
  - id: ds_prod
    provider: deepseek
    api_key_env: DEEPSEEK_API_KEY
    rate_limit_rps: 3
    monthly_budget_usd: 300
    enabled: true
  - id: oa_prod
    provider: openai
    api_key_env: OPENAI_API_KEY
    rate_limit_rps: 2
    monthly_budget_usd: 500
    enabled: true
  - id: gc_prod
    provider: gigachat
    api_key_env: GIGACHAT_API_KEY
    rate_limit_rps: 5
    monthly_budget_usd: 150
    enabled: true

function_profiles:
  soul_core:
    strategy: cost_latency_balance  # cost_first|latency_first|balance|strict_provider
    primary: [ds_prod]
    fallback: [oa_prod, gc_prod]
    timeout_ms: 12000
    retries: 2
    max_output_tokens: 900
  planner:
    strategy: latency_first
    primary: [gc_prod]
    fallback: [ds_prod]
    timeout_ms: 1500
    retries: 1
    max_output_tokens: 256
  consistency:
    strategy: cost_first
    primary: [gc_prod]
    fallback: [ds_prod]
    timeout_ms: 1000
    retries: 0
    max_output_tokens: 200
  judge:
    strategy: cost_first
    primary: [gc_prod]
    fallback: [ds_prod]
    timeout_ms: 2500
    retries: 0
    max_output_tokens: 200

global:
  failover_enabled: true
  circuit_breaker: { error_rate_threshold: 0.2, min_samples: 20, cooldown_sec: 60 }
  cache: { enabled: true, ttl_sec: 60, max_entries: 200 }

```

Pydantic‑модели: `ProviderConfig`, `AccountConfig`, `FunctionProfile`, `RoutingConfig`.

---

### 4. Алгоритм маршрутизации (MVP)

1) На вход: `function`, `constraints` (max_latency_ms?, max_cost_per_call?).
2) Сформировать список `candidates`: `primary` + `fallback` из профиля функции, исключая выключенные и сработавшие circuit‑breaker.
3) Для каждого кандидата посчитать «оценку»: `score = w_cost*norm(cost_est) + w_lat*norm(p95_ms) + w_err*norm(error_rate)` по стратегии:

   - `cost_first`: w_cost=0.6, w_lat=0.3, w_err=0.1
   - `latency_first`: w_cost=0.2, w_lat=0.7, w_err=0.1
   - `balance`: w_cost=0.4, w_lat=0.4, w_err=0.2
   - `strict_provider`: брать только `primary[0]`

4) Выбрать минимальный `score`; проверить лимиты RPS/бюджета; при переполнении — следующий кандидат.
5) Выполнить запрос с `timeout/retries`; при ошибке — фейловер по списку fallback; записать метрики/аудит.

Оценка стоимости: 

- Если доступен токен‑каунт — `cost = in_tokens/1k * pricing.input + out_tokens/1k * pricing.output`.
- Иначе — прокси по длине сообщений/лимитам; обучать поправочный коэффициент от логов.

---

### 5. Исполнитель и фейловер

- Ретраи: только на сетевые/429/5xx; не ретраить на 4xx по контенту.
- Фейловер: включён, если `global.failover_enabled=true` и `retries` исчерпаны — перейти к следующему аккаунту/провайдеру.
- Circuit breaker: по провайдеру/аккаунту — при `error_rate > threshold` на последних `min_samples` запросов → пауза `cooldown_sec`.
- Rate limiting: простой токен‑бакет в памяти на процесс (учитывать многопроцессный деплой — допустимо консервативно).

---

### 6. Конфигурация/флаги

- `llm.routing.enabled=false` (по умолчанию)
- `llm.routing.config_path=backend/config/llm_routing.yaml`
- `llm.routing.failover_enabled=true`
- `llm.timeout_ms.<function>`, `llm.retries.<function>` — перекрывают профиль.

ENV (пример): `LLM_ROUTING_ENABLED`, `LLM_ROUTING_CONFIG`, ключи провайдеров (`DEEPSEEK_API_KEY`, `OPENAI_API_KEY`, `GIGACHAT_API_KEY`).

---

### 7. Наблюдаемость и аудит

- Метрики (labels: function, provider, account):
  - `llm.req_count`, `llm.err_count`, `llm.fallback_count`, `llm.cb_open`
  - `llm.p50_ms`, `llm.p95_ms`, `llm.cost_usd`, `llm.tokens_in/out`
- Аудит:
  - `llm_route_selected` {function, account, est_cost, p95_ref}
  - `llm_failover` {from→to, reason}
  - `llm_circuit_open` {account, error_rate}

Отчёт: агрегаты по функциям/провайдерам за сутки; cost per quant.

CI‑отчёт:

- Скрипт: `backend/scripts/ci/llm_routing_ci.py` формирует `Soul/CI/llm_routing_report.md` с текущими маршрутами на функции (`soul_core|planner|consistency|judge`).
- Интеграция: запускать на CI с `LLM_ROUTING_ENABLED=1` и `LLM_ROUTING_CONFIG=backend/config/llm_routing.yaml`.

---

### 8. Acceptance

- При `llm.routing.enabled=false` поведение неизменно.
- При включении:
  - p95 по `planner` ≤ 1.5с, по `consistency` ≤ 1.2с (на baseline трафике DEV).
  - Доля фейловера ≤ 5%; error_rate не увеличивается.
  - Отчёт содержит стоимость на квант; суммарная стоимость не превышает заданный бюджет.
  - Политика по умолчанию (правило проекта): "Дипсик для обработки сложных запросов, генерации Квантов и общения с пользователями; Гигачат — для сервисных запросов". Соответственно, профили:
    - `function_profiles.soul_core.primary=[deepseek...]` с `fallback=[gigachat, ...]`.
    - `planner|consistency|judge` — `primary=[gigachat...]`, `fallback=[deepseek]`.
  - Политика фиксируется в `docs/PERSONA_REGISTRY_v1_0.md` для `soul`, `processor`, `bot_orchestrator` и контролируется через фичефлаги P28.

---

### 9. Траблшутинг

- Частые фейловеры → увеличить `timeout_ms`/`retries` или поменять `primary` порядок; проверить ключи/квоты.
- Дорогие ответы → стратегия `cost_first`, уменьшить `max_output_tokens` или сменить модель.
- Латентность выросла → стратегия `latency_first`, shift на быстрый провайдер для `planner/consistency`.
- Circuit breaker ложноположит. → поднять `min_samples`/порог.

---

### 10. Быстрая реализация (≤ 1 день)

1) Добавить `llm_routing.yaml` и Pydantic‑модели; загрузчик в `LLMManager`.
2) Реализовать `select_route()` со стратегиями и метриками.
3) В исполнителе — ретраи/фейловер/CB/лимиты; логирование.
4) Привязать функции: `soul_core`, `planner`, `consistency`, `judge`, `safety_guard`.
5) Добавить метрики/аудит; smoke‑тесты с разными профилями.

---

### 11. Мировая практика (ориентиры)

- LiteLLM Router / OpenRouter — маршрутизация между провайдерами по цене/скорости/доступности.
- Azure/OpenAI/Anthropic мульти‑аккаунты — квоты, RPS и бюджет‑менеджмент.
- Circuit breaker/Retry/Rate limit — стандарт SRE‑практик (Polly, Envoy, Hystrix).
- Кэширование на коротких окнах — снижение джиттера и нагрузки.

Мы применяем упрощённый, но прозрачный вариант с отчётностью и лёгкими стратегиями.

---

### 12. Ссылки на проектные файлы/документы

- Менеджер моделей: `backend/app/services/llm_manager.py`
- Ядро: `backend/app/services/soul_core_manager.py`
- Планер/Консистентность/Судьи: соответствующие сервисы (см. ТЗ 1/2/5)
- Док пайплайна: `docs/SOUL_PIPELINE.md`
- Инструкции: `Arh/Стартовый набор для новой ветки_v2_2.md`

---

### 12.1 LLM Management (UI/API/Prefs) — консолидация

- UI (P23): страница `LLMSettings` с вкладками «Модели», «Функции», «Мои настройки»; отображение и правки конфигов.
- API: `/api/llm/models`, `/api/llm/functions`, `/api/llm/preferences`, `/api/llm/overview` — управление моделями, профилями функций и пользовательскими переопределениями.
- Менеджер: `LLMManager.get_model_for_function(function_name, user_id)` — учёт пользовательских глобальных/функциональных overrides, fallback к системным профилям.
- Логирование/метрики: `log_model_usage`, `available_models`, валидация конфигураций.
- Инициализация: предустановленные провайдеры (DeepSeek/OpenAI/GigaChat) и связки функций; соответствующие поля токен‑лимитов/стоимости.

---

### 13. SLO/алерты

- SLO: `planner.p95_ms ≤ 1500`, `consistency.p95_ms ≤ 1200`, `fallback_share ≤ 5%`
- Алерты: `llm.cb_open spikes` (>5% запросов за 10 мин), `failover_rate > 10%`, `p95_ms` рост > 30% к baseline

---

### 14. Rollout

- DEV: `llm.routing.enabled=false` (собрать метрики), затем включить на `planner/consistency`
- STAGE: включить на 25% трафика для всех функций; мониторить CB/Failover
- PROD: расширять до 100%; фиксировать недельный отчёт «cost per quant»

---

### 15. Тест‑план

- Unit: парсинг `llm_routing.yaml`, выбор стратегии, расчёт score
- Integration: фейловер при 429/5xx, CB cooldown, respect rate‑limit
- Perf: отсутствие деградации p95 на `planner/consistency` профилях


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
