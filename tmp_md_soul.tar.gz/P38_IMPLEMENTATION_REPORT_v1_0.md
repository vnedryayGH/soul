# P38 — Implementation Report v1.0

Изменённые файлы

- `Soul/P38_TZ_Soul_NeuroTraining_v1_0.md`
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8_2.md`
- `docs/PROJECT_STRUCTURE_v8_0_4.md`
- `Soul/Report_Soul_AI_Scientific.md` (добавлен блок P38)

Команды/сырой вывод (PROD PowerShell)

```powershell
$OutputEncoding = [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$H=@{ 'X-Telegram-User-ID'='468326902' }

# Health/DB/LLM
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/health
curl.exe -s -S -H "X-Telegram-User-ID: 468326902" https://mini.soulpulse.art/api/admin/soul/db/check
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/soul/llm/test?provider=deepseek&prompt=ping' -Headers $H -Method Get
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/admin/soul/llm/test?provider=gigachat&prompt=ping' -Headers $H -Method Get | ConvertTo-Json -Compress

# Stateless batch
$B=@{ input_text='batch stateless'; num_quants=2; persist_all=$false } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/soul/process_batch' -Method Post -Headers $H -ContentType 'application/json' -Body $B

# Single
$S=@{ input_text='single test'; num_candidates=1 } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/soul/process' -Method Post -Headers $H -ContentType 'application/json' -Body $S

# Hyperloop: TRACE + TRAIN
@(
  'CORE.PIPELINE.RUN input_text="health check" WITH TRACE',
  'BATCH.GENERATE_QUANTS n=10 provider=deepseek topic="connect gaps" STRICT',
  'TRAIN.EVAL.LAST_BATCH',
  'LEARN.APPLY_FEEDBACK mode=reinforce window=24h'
) | ForEach-Object {
  $B=@{ commands=$_ } | ConvertTo-Json -Compress
  Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress
}

```

Статусы (ожидаемые)

- Health=200, DB=OK, LLM(deepseek/gigachat)=OK
- Batch(stateless)=массив квантов; desired_action=[]
- Single=персистенция ок
- greenlet_spawn=0
- TRACE: есть `svc.soul.preanalysis`, `svc.soul.router_decide`, `svc.llm_client.send/recv`, `svc.parser.json_strict`, `svc.chat.reply_render`

Выводы/решения

- NeuroTraining P38 интегрирован в мастер‑реестр и структуру проекта; добавлены DSL команды и acceptance.

Следующий шаг

- Калибровка весов ранга (A/B) и включение Two‑Keys фасада для TRAIN.* в админ‑UI.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
