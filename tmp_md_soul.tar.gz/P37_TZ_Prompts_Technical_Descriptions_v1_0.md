<!-- markdownlint-disable MD041 MD022 MD032 MD012 -->
---

## Индекс взаимных ссылок (P01–P37)

- P20/P33 — Mini App/Mini Chat каталог персон.
- P21 — мониторинг использования персон.
- P23 — UI карточек персон.
- P36 — команды инспекции персон/§svc.

# P37 — ТЗ: Технические описания промптов v1

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — инвентари.
- `tmp_p_series_plan.json` — план P‑серии.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр.
- `Soul/P33_TZ_Soul_Personification_and_Profile_v1_0.md`, `Soul/P23_TZ_UI_Spec_v2_1.md`, `Soul/P20_TZ_Telegram_Bot_Orchestrator_and_E2E_Dataflow_v1_1.md`, `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md` — ключевые интеграции.

Перенесено из P38 без изменений содержания и с сохранением увязки с Ядром Соул. См. исходники в истории Git.

---

## 0. Встраивание в Ядро Соул (добавление)

- Инварианты P27 (Delivery Guard): видимый ответ — без техмаркеров; §svc парсится сервером, не отображается пользователю.
- Hyperloop (P36): Mini‑chat использует MINICHAT.REPLY; Архитектор — CORE.PIPELINE.RUN; персоналии являются данными для сборки system‑prompt.
- История 30/70 (P03): персоналии допускают `history_bundle` в `content_json`; Mini‑chat применяет recent/deep смешение по правилу 30/70.
- Stateless LLM: при Mini‑chat — LLM вызывается без БД; никакой бизнес‑логики в промптах.
- §svc API v2: единый формат задач и нормализация на бэкенде.

---

## 1. Поля БД `prompts` (с объяснениями)

- id, key, locale, group_key, name, description, file_path, icon_emoji, icon_color, category, features, target_audience, activation_triggers, is_base, can_work_alone, kind, memory_algorithm, is_active, sort_order, content_json.

---

## 2. Единый блок §svc (API_250829_v2)

- Формат, правила, примеры, нормализация — как в исходной спецификации; перенос без изменений.

---

## 3. Каталог персон (сводка)

- Включает: SoulPulse (prompt-4), Flow, Language Trainer, Раневская, Дядя Миша, Каббала, Klee, модуль Female Resonance.

---

## 4. UI рекомендации

- Поля отображения, копирайтинг, сортировка, цвета — без изменений.

---

## 5. Загрузка в БД

- Чек‑лист валидности записей; примечания по `user_settings` и `is_active`.

---

## Acceptance

- Документ самодостаточен, соответствует инвариантам и не содержит регресса относительно P38.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
