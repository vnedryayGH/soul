---

## Индекс взаимных ссылок (P01–P37)
- P23 UI Spec — Mini App UI/потоки.
- P26 Calendar Transport — события/напоминания.
- P30 Processor — очередь/доставка уведомлений.
- P33 Personification — Mini Chat поведение/персоны.
- P34 External Chat Proxy/Mobile — интеграция каналов.
- P36 Hyperloop DSL — команды для тестов/инспекции.
### ТЗ Soul v1.0 — Платформа Telegram‑ботов на инфраструктуре Soul (P20)

Дата: 2025‑09‑15
Ответственный: Архитектура Soul Core
Статус: К реализации (MVP без миграций; Stage‑2 — платежи/витрина/mini‑apps)

---

### 0. Executive summary

- Цель: дать возможность создавать и управлять настраиваемыми Telegram‑ботами без программирования, используя ядро Soul (персоны/память/смыслы/инструменты/напоминания/голос/маршрутизация/безопасность). Все боты расширяют возможности Соула и используют его интеллект; по мере роста ядра Soul он управляет ботами и их сценариями.
- MVP: без миграций — опираемся на существующие контракты P01–P19 (desired_action, напоминания, ASR/TTS, маршрутизация LLM, privacy/security, eval, trace/provenance). Админка — базовая вкладка «Bots Studio» с шаблонами.

---

### 1. Архитектура и интеграции (карта к P01–P19)

- Пайплайн ядра: `soul_core_manager.generate_quant_enhanced` (P01, P03, P06)
- Персоны/модули/роутер: RouterContext 2.0 (P03), Modules as Policies, STRICT_JSON_QUANT
- Действия: формальный контракт `desired_action` (P07) — маршрутизация сценариев
- Напоминания с поиском: P17
- Голос: ASR (P18) и TTS (P19)
- Мульти‑провайдер LLM: P14
### 1.1 Архитекторский режим и Hyperloop (канонично)
- Мини‑app/Telegram ветка `architect_chat` работает строго через Hyperloop DSL, stateless. Запросы формируются и отправляются в ядро командой DSL `CORE.PIPELINE.RUN input_text="..." WITH TRACE`.
- Запрет альтернативных веток: маршрутизация в SoulCore из `architect_chat` отключена (fallback удалён). Ответ собирается из результата Hyperloop и санитизируется согласно P27/P29.
- Антидубли: перед входом в цепочку Hyperloop применяется ключ `tg_id + update_id + sha256(normalized_text)` для предотвращения повторной обработки.
- Быстрый TRACE: шаги доступны через `TRACE.STEPS trace_id="..."` (см. P36 §5.1). В панели архитектора предусмотрен быстрый доступ к просмотру шагов по `trace_id`.
- Безопасность/приватность: P09/P08; SchemaGuard: P10
- Трейсы/причинность/оценка: P12/P11/P13
- Память: компакция/архив (P16); Многоязычие/выравнивание (P15)

---

### 1.1 Слои единой архитектуры ядра (в контексте ботов)

- Transport Layer: Telegram Bot API/Webhook, Mini Apps, Files; нормализация апдейтов → `ChatEvent`
- Orchestration Layer: RouterContext(P03), Planner/Tools(P05), Conductor, Backpressure
- Reasoning Layer: SoulCore enhanced (P01, STRICT_JSON_QUANT), Self‑Consistency/Contradiction(P06)
- Action Layer: DesiredAction(P07) → ActionRouter → Reminders(P17)/Tools/Webhooks
- Memory Layer: Quants/Connections, 30/70 Retrieval, Compaction(P16), Multilingual(P15)
- Safety Layer: Privacy(P08), Guard(P09), SchemaGuard(P10)
- Observability Layer: Audit, TraceViewer(P12), Provenance(P11), Eval/AB(P13)
- Provider Layer: LLM Multi‑Routing(P14), ASR/TTS(P18/P19), Search providers

— Голос как подключаемый шаг процесса (новое):
- Голос (TTS) не является самостоятельной веткой. Это шаг доставки ответа, включаемый политикой/триггером.
- Ветвь //Соул формирует текст строго через Hyperloop → затем политика канала решает: добавить озвучку (sendVoice) или только текст.
- Поддерживается режим: voice_only | voice_and_text; триггеры: входное сообщение голосом; пользовательский флаг; политика ветки.

Все слои общие для Soul и всех ботов, отличается лишь `BotProfile` и политика.

---

### 1.11 Пять путей общения через Telegram‑бота (каналы взаимодействия)

Цель: формализовать 5 стандартных способов (API‑пути) общения пользователя с ИИ через Telegram‑бот, с едиными контрактами и наблюдаемостью.

1) Старт диалога (инициализация ветки)
   - Эндпоинт: `POST /api/bot/chat/start`
   - Вход: `{ tg_id: string, prompt_id?: string }`
   - Выход: `{ thread_id: string, greeting: string }`
   - Назначение: создать ветку общения с выбранной персоной/политикой.

2) Отправка сообщения (основной диалог)
   - Эндпоинт: `POST /api/bot/chat/send`
   - Вход: `{ tg_id: string, message: string, thread_id?: string }`
   - Выход: `{ thread_id: string, reply: string, tokens_in: int, tokens_out: int, latency_ms: int }`
   - Назначение: доставка текста в ChatService → LLMClient (маршрутизация P14) → ответ пользователю; сохраняется контекст и метрики.

3) Сброс контекста (новая ветка)
   - Эндпоинт: `POST /api/bot/chat/reset`
   - Вход: `{ tg_id: string, thread_id?: string }`
   - Выход: `{ thread_id: string }`
   - Назначение: завершить текущую ветку и начать новую (чистый контекст).

4) История сообщений (чтение)
   - Эндпоинт: `GET /api/bot/chat/history?thread_id=...&limit=30`
   - Выход: `[{ role, content, created_at }]`
   - Назначение: безопасная отдача истории для UI/диагностики.

5) Настройки диалога/модели
   - Эндпоинт: `POST /api/bot/chat/settings`
   - Вход: `{ tg_id: string, model?: string, temperature?: number, max_tokens?: number }`
   - Выход: `{ ok: true }`
   - Назначение: точечное переопределение параметров модели/ветки под пользователя.

Примечания и интеграции:
- Webhook Telegram → `process_update` (бот‑оркестратор) нормализует события и вызывает перечисленные API.
- LLM маршрутизация и фолбэки: через `LLMClient` (P14), сервисные типы допускают Aux/локальную LLaMA при включённой политике.
- Прямая связь с локальной LLaMA (опционально для сервисных функций): HTTP `POST http://127.0.0.1:8085/completion` (JSON `{ prompt, n_predict, temperature }`) и CLI `/usr/local/bin/llm-cli '...'
  - Наблюдаемость: `lima_local_up`, `lima_local_connect_ms` в `/api/metrics`; p95/счётчики — через стандартные `llm_aux_*` метрики.
- Безопасность: RBAC (P44), PII‑санитайзер (P08), Delivery Guard (P27), SchemaGuard (P10).

Acceptance (для 5 путей):
- Все 5 эндпоинтов доступны и возвращают валидный JSON; p95 ответа ≤ 3с; error rate ≤ 1% за 24ч.
- В Trace/Provenance фиксируются шаги ChatService/LLMClient; в метриках растут счётчики запросов и p95 в бюджете.

См. также: SPEC «Интеграция LLM…» (раздел API), P14 (маршрутизация), P27/P29/P21 (подпись/санитайзер/метрики).

---

### 1.2 Единый SDK (Server‑side)

- Модуль `soul_sdk`:
  - `ChatEvent` — нормализованное событие Telegram (ЛС/группы/вложения/голос)
  - `BotProfileClient` — загрузка профиля/политик/триггеров
  - `SoulGateway` — фасад: Router→Planner→Core→Actions
  - Клиенты: `ReminderClient`, `VoiceClient`, `SearchClient`
  - `TraceHelper` — прокидка `trace_id`, сбор мета
  - Политики: deny‑by‑default для autopublish, guard hooks

---

### 1.3 Единая БД и тенантность

- MVP: существующие таблицы (`quants`, `quant_desired_actions`, `generation_request`, …) без миграций
- Тенантность: soft‑tenant `bot_id` в аудите/настройках; знание об источнике в тегах квантов `source:bot/<id>`
- Stage‑2: view/partitions по `bot_id`, витрина/биллинг

---

### 1.4 Реестр ИИ‑сервисов

- LLMManager(P14), Speech(P18/19), Search(P17), Embeddings(если есть); профили/лимиты/стоимость, аудит маршрутов

---

### 1.8 Бот‑Оркестратор (единая точка контроля платформы)

Назначение: централизованно управлять всеми процессами, связанными с работой Telegram‑ботов на базе ядра Soul: приём апдейтов, форматирование/доставка исходящих сообщений, очереди и троттлинг, соблюдение политик (безопасность/приватность), наблюдаемость и алерты.

- Ответственность Оркестратора:
  - Режимы приёма апдейтов: PROD — только webhook; polling запрещён. Любая попытка запуска polling фиксируется инцидентом и блокируется.
  - Анти‑дедупликация входящих апдейтов: ключ (tg_id, update_id, text_hash) в памяти и БД; идемпотентность.
  - Очередь исходящих сообщений: sendMessage, sendVoice, sendChatAction. Экспоненциальный бэкофф, учёт Retry‑After (429), троттлинг.
  - Централизованное форматирование: префикс ответа формируется здесь. В режиме //Соул — строго «Соул: …». В режиме //Бот — имя активной персоны пользователя. Значение «AI» как имя не допускается.
  - Единый HTML‑санитайзер: parse_mode=HTML, экранирование &, <, >, кавычек; удаление служебных маркеров (§error, §sense, §qtags, §qew, §svc и обобщённых §word{...}/[...]).
  - Единый HTML‑санитайзер: parse_mode=HTML, экранирование &, <, >, кавычек; удаление служебных маркеров (§error, §sense, §qtags, §qew, §svc и обобщённых §word{...}/[...]). Поддерживается безопасная конвертация Markdown→HTML (жирный/курсив/код/ссылки/зачёркнутый); при конвертации не выполняется повторное экранирование.
  - Голос (TTS) и фоллбеки: в голосовом входе — озвучка с caption; в user_dialog — опциональная озвучка; при ошибке TTS — безопасный текст.
  - Для //Соул: озвучка включается как шаг доставки при policy.voice_enabled=1; провайдер закрепляется политикой (SpeechKit/Piper), голос — конфигом.
- ReminderActor: доставка напоминаний как исходящее событие Телеграм
  - Обогащение фактов перед отправкой (P17): LLM‑план поисковых запросов (с использованием актуального промпта персоны/ветки), Web‑fetch, краткая суммаризация
  - Генерация финального текста: DeepSeek, системный промпт = актуальный `persona_prompt` (снимок на момент создания события)
  - Доставка голосом: sendVoice (OGG/Opus 48 kHz mono, ≤10MB), алиасы голосов Piper (`faina`→`ru_RU-kseniya-medium`, `ru_male_baritone`→`ru_RU-ruslan-medium`) с FX для низкого женского тембра
  - Подпись (P27): `svc.reminder.context.restore|enrich.plan|enrich.fetch|enrich.summarize|generate|deliver` фиксируются и доступны в TraceViewer
  - Ключи/секреты: проверка наличия и срока действия (LLM/Telegram); деградация маршрута (DeepSeek при отсутствии GigaChat), алерты.
  - Мониторинг и алерты: размер очередей, error rate исходящих, 4xx/5xx Bot API, webhook 5xx, cron overlaps (с исключением flock/sh wrapper), polling‑детектор.

— Политики Telegram/лимиты:
  - sendVoice: формат OGG Opus mono 48 kHz; caption ≤ 1024 символов.
  - Лимит размера файла ≤ 10 MB (в Оркестраторе порог 9 MB с фоллбеком в текст).
  - Безопасное parse_mode=HTML; санитайзер устраняет служебные маркеры, нормализует переносы.

- Интерфейсы Оркестратора:
  - process_update(update: dict) → нормализация апдейта, анти‑дедуп, маршрутизация в ChatService/Processor.
  - enqueue_outbound(message: {chat_id, text_html?|voice_bytes?, caption?}) → помещает исходящее в очередь с политиками доставки.
  - health() → метрики очереди/ретраев/ошибок/пинга WebhookInfo; алерты по порогам.
  - Public health: `GET /api/bot/orchestrator/health` (queue_size, sent_ok/fail, errors_recent, started).

- Панель управления (Bots Studio → Orchestrator):
  - Вкладка «Orchestrator»: состояние очередей, последние ошибки, включение/выключение TTS в канале, проверка ключей, enforce webhook‑only.
  - Быстрые действия: test send (HTML/voice), getWebhookInfo/setWebhook, drop_pending_updates (debug‑флаг), mute channel.

- Acceptance (Оркестратор):
  - На PROD polling не запускается; любые попытки фиксируются инцидентом.
  - Префиксы соблюдаются: в //Соул «Соул», в //Бот — активная персона, «AI» не встречается.
  - Санитайзер устраняет parse‑ошибки Telegram и служебные маркеры; error rate исходящих ≤ 2%.

---

### 1.5 API/Секреты/Конфиг

- Admin API: CRUD BotProfile, тест триггеров, dry‑run
- Secrets: токены ботов через ENV/SecretStore; masked в логах/трейсах
- Config: `bots.enabled`, лимиты сообщений, дефолтные провайдеры ASR/TTS/Search

### 1.9 Голос (ASR/TTS: параметры, фолбэки, политика DeepSeek)

- Вход `voice|audio` скачивается через Bot API, конвертируется `ffmpeg` в WAV 16 kHz mono.
- ASR провайдеры: `yandex_speechkit` (по умолчанию), `whisper_openai`, `vosk` (DEV). Таймауты до 30–60с, устойчивый парсинг JSON от Yandex STT.
- ENV: `ASR_PROVIDER`, `ASR_MODEL`, `FFMPEG_BIN`, `YANDEX_SPEECHKIT_API_KEY`, `YANDEX_SPEECHKIT_LANG_DEFAULT`, `OPENAI_API_KEY`, `VOSK_MODEL_DIR`.
- Фолбэки ASR: при ошибке скачивания/конвертации/распознавания — ответ «(ошибка распознавания голоса)»/«(голос не распознан)», ядро не вызывается.
- TTS провайдеры: `piper` (дефолт, оффлайн) → OGG Opus 48 kHz; фолбэк `yandex_speechkit` при наличии ключа.
- Параметры TTS по пользователю/персоне: таблицы `user_persona_voice`/`persona_voice_profile` (голос/скорость/тон).
- Лимиты Telegram: caption ≤ 1024; размер ≤ 10MB (порог 9MB в Оркестраторе, фолбэк в текст).
- Политика провайдера LLM: `chat|architect_chat|user_dialog|soul_core|soul_quant|hyperloop` — строго DeepSeek; сервисные задачи допускают GigaChat при наличии креденшалов.

---

### 1.9.1 Реестр голосов TTS и выбор в мини‑приложении

- Реестр хранится в `SoulSettingsService` (ключ `tts.registry`: JSON id→{provider, model, display_name}).
- Таблицы параметров:
  - `persona_voice_profile(persona_key PK, tts_voice_id TEXT, tts_rate NUMERIC, tts_pitch NUMERIC, updated_at)`
  - `user_persona_voice(user_id BIGINT, persona_key TEXT, tts_voice_id TEXT, tts_rate NUMERIC NULL, tts_pitch NUMERIC NULL, updated_at, PK(user_id, persona_key))
- API (мини‑приложение):
  - `GET /api/voice/voices` — список голосов (из реестра + обнаруженные Piper‑модели)
  - `POST /api/voice/set_voice` — установка голоса:
    - body: `{ persona_key?: string, voice_id: string, rate?: number, pitch?: number }`
    - если задан `persona_key` — сохраняется в `persona_voice_profile`, иначе — дефолт `tts.default.voice|rate|pitch`.
- Оркестратор Telegram:
  - В режиме голосового входа отвечает `voice` (sendVoice) с caption HTML; формат OGG Opus 48kHz mono, ≤10MB.
  - Подстановка имени: //Соул — «Соул:», //Бот — имя выбранной персоны.
- Качество/акценты (P19): допускается FX‑пост‑обработка (pitch/equalizer/compression) при конвертации в Opus.

---

### 1.6 Наблюдаемость/Дашборды

- Дашборд «Bots»: сообщения/мин, p95, err_rate, доля голос/напоминаний, top‑triggers
- Трассы: фильтр по `bot_id`, ссылки на provenance/actions

---

### 1.7 План миграций (Stage‑2)

- Таблицы: `bot_profiles` (jsonb), `bot_triggers`, `bot_billing`
- Интеграции: Payments/Stars, Mini Apps витрина, marketplace шаблонов

---

### 2. Объёмы MVP (без миграций)

- Создание/редактирование «бот‑профиля» в админке: имя, описание, аватар, persona (архетип), язык, политики безопасности
- Подключение токена бота (BotFather) и Webhook (существующий сервер)
- Настройка триггеров: ключевые слова/смыслы → действия (desired_action)
- Шаблоны ответов: приветствия/FAQ/ошибки (через persona и NEGATIVE)
- Включение инструментов: web‑поиск, калькулятор, время (через Planner, P05)
- Вложения: приём/отдача файлов, сохранение минимальной меты в память (без миграций)
- Личные/групповые чаты: режим модерации, реакция на упоминание, управление префиксами
- Голос: опционально включаем ASR/TTS (P18/P19)
- Напоминания: настройка шаблонов и «поиск перед отправкой» (P17)
- Метрики/трассы: вкладка в TraceViewer фильтр по bot_id (P12)

---

### 3. Admin UI: Bots Studio (MVP)

- Разделы:
  - Боты: список, создать из шаблона (Care, MedAssist, SafetyButton, MoodCoach, CommunityPro)
  - Persona/Policies: выбор архетипа, язык, NEGATIVE level, guard level
  - Triggers: ключевые слова/смыслы → desired_action (UI‑редактор правил)
  - Tools: включение/лимиты (web‑поиск/ASR/TTS/calculator)
  - Reminders: дефолтные оффсеты, поиск, окна отправки
  - Payments (Stage‑2): тарифы/подписки/Stars
  - Observability: метрики p95, error rate, последние трассы

---

### 4. Контракты и конфигурации

- BotProfile (server json): `{ id, title, description, avatar_url?, persona_key, language, safety:{negative_level, guard_level}, triggers:[...], tools:{...}, reminders:{...}, tts/asr:{...} }`
- Triggers: `keyword|meaning` → `{ desired_action, payload_template }`
- DesiredAction (P07): использовать существующие типы (`proposal|request|research|reminder|goal_update|note`)

---

### 5. Потоки и сценарии

- ЛС/Группы:
  - Упоминание/префикс → RouterContext(P03) → Planner(P05) → SoulCore → desired_action(P07) → исполнения
  - Модерация в группах: фильтр по ключевым словам/смыслам; предупреждения/ответы; эскалация
- Напоминания: создание через desired_action:reminder (P17); «поиск перед отправкой»
- Голос: вход ASR (P18) → текст → пайплайн; выход TTS (P19) по настройкам
- Инструменты: web‑поиск/внешние API — через Planner Tool‑Use (P05)

---

### 5.4 Сценарий Processor ↔ Архитектор: подтверждение в Telegram (ACK)

Цель: Процессор (P30) отправляет статус/заявку с inline‑кнопками; Архитектор подтверждает в Telegram. Оркестратор доставляет, нормализует callback, фиксирует подпись шагов.

- Поток:
  1) Processor генерирует событие `REQUEST.CREATE type=<...> subject=<...> payload={...}` (или `PROCESSOR.EVENT.INJECT ...`) с каналом доставки `telegram_dm`.
  2) ChatService формирует видимый текст (без техмаркеров); Оркестратор ставит исходящее сообщение в очередь с `reply_markup` (inline‑кнопки «Подтвердить/Отмена/Подробнее»).
  3) Пользователь нажимает кнопку → Telegram присылает `callback_query` → Orchestrator.process_update → маршрут в handler, проверка RBAC (Архитектор/владелец).
  4) Handler вызывает Processor API (`REQUEST.CONFIRM/REJECT` либо REST фасад), обновляет состояние заявки/кванта; Оркестратор редактирует исходное сообщение (editMessageText) и убирает клавиатуру.
  5) Подпись (P27): `svc.processor.act → svc.processor.observe → svc.chat.reply_render`, плюс `cmd.hyperloop.*` при использовании DSL.

- Инварианты:
  - Идемпотентность callback: ключ (chat_id, message_id, callback_data) и TTL; повторные нажатия не изменяют статус.
  - Безопасность: проверка роли/владения на каждое действие; логирование с маскировкой PII (P08/P09).
  - UX: успешные действия подтверждаются всплывающим уведомлением (`answerCallbackQuery`).

- Acceptance:
  - Кнопка подтверждения меняет статус в Processor; сообщение редактируется; подпись шагов видна в TraceViewer.

---

### 5.5 Сценарии общения с Акторами Ядра через Бота

- Архитектор ↔ Processor: подтверждения статусов/эскалаций (как в §5.4).
- Архитектор ↔ Gendarme/Judge (P29): подтверждение проверки/эскалации.
- Архитектор ↔ Conductor/Planner (P05): запуск/остановка авто‑циклов и профилей флагов (P28) через команды.
- Пользователь ↔ Персоны (P33): общение в user_dialog, выбор активной персоны, корректные префиксы.

---

### 6. Безопасность/Приватность/Стабильность

- Privacy (P08): PII‑санитизация входа/логов/экспортов, hash‑идентификаторы
- Guard (P09): pre‑scan, NEGATIVE усиление, post‑guard, deny autopublish по умолчанию
- Schema Guard (P10): контроль ABI (STRICT_JSON_QUANT/DesiredAction)

---

### 7. Метрики/SLO/Алерты (платформа)

- Метрики: `bot.msg_count`, `bot.err_rate`, `bot.p95_ms`, `bot.voice.share`, `bot.reminders.sent`, `bot.tools.usage`
- SLO: p95 ответов ≤ 8с; error rate ≤ 2%; JSON validity ≥ 98%
- Алерты: рост `err_rate`, падение validity, деградация p95; ASR/TTS ошибки

---

### 8. Тест‑план

- Unit: парсинг BotProfile/Triggers; нормализация desired_action
- Integration: ЛС и группа; ASR/TTS; напоминание с поиском; web‑поиск инструмент
- Security: guard блокирует опасные шаблоны; PII не утекает в аудите/трейсах
- Perf: 100 сообщений/мин на DEV — удержание SLO

---

### 9. Rollout

- DEV: 1–2 шаблона, без платежей; включить ASR/TTS выборочно
- STAGE: расширить шаблоны, наблюдать метрики; ограниченные домены для поиска
- PROD: тарифы и Stars (Stage‑2), шаблонная витрина

---

### 10. Мировая практика (референсы)

- Конструкторы: Chatfuel, BotMother, SendPulse, Flow XO — no‑code, сценарии/триггеры
- AI‑платформы: Botpress, Rasa, LangChain Agents — инструментальные агенты
- Telegram: Mini Apps/Payments/Stars, Login Widget — монетизация и UX
- Голос: Whisper/SpeechKit/Google/ElevenLabs — двухсторонний голос

---

### 11. Acceptance

- Создание бота из шаблона; ЛС и группа — корректное общение/триггеры/напоминания/голос
- Метрики и трассы доступны; безопасность и приватность соблюдены
- Никаких миграций; совместимость с P01–P19

---

### 12. Ссылки на существующие ТЗ

- P01–P19: см. файлы в `Soul/` (MeaningExtraction, MetaLoop, RouterContext, Hypotheses, Planner/Conductor, SelfConsistency, DesiredAction, Privacy, Security, SchemaGuard, Provenance, TraceViewer, Eval, MultiProvider, Multilingual, MemoryCompaction, Reminders, Voice ASR/TTS)



---

### 13. Платформа Telegram и веб‑версия: преимущества и интеграция

- Преимущества Telegram:
  - Массированное распространение и знакомый UX; один клик до бота, push‑уведомления нативно
  - Личные/групповые чаты, каналы, вложения, inline‑кнопки, меню, Login Widget
  - Payments/Stars, Mini Apps (WebApp API) — готовая монетизация и расширенный UI
  - Безопасность/аутентификация: Telegram‑ID, Deep Links, ограничение по чатам
- Веб‑версия (дополнение):
  - Admin Web (Bots Studio, дашборды, настройки, отчёты)
  - Lightweight User Web (просмотр задач/календаря/напоминаний, подтверждения)
  - SSO через Telegram Login Widget; единые роли/права
- Интеграция:
  - Mini App как «тонкий клиент» к ядру Soul (через существующие API)
  - Один источник прав/настроек; бот и веб синхронизированы в реальном времени

---

### 14. Дашборды команд и групп: календарь, Гант, авто‑обновления

- Объектная модель (MVP без миграций — audit/views; Stage‑2 — таблицы):
  - Group/Team (chat_id|bot_id), Member (user_id, role), Task (id, title, owner, assignees[], due, status, priority)
  - Event (id, title, start/end, place, participants[]), Reminder (link→Task/Event)
- Календарь:
  - Единый календарь группы/участника; фильтры (mine, team, project)
  - «Интеллектуальные напоминания»: P17 («поиск перед отправкой»), окна уведомлений, эскалации
  - Создание/смена статусов через чат‑команды/кнопки; подтверждения
- Диаграмма Ганта (web + мини‑приложение):
  - Временная шкала задач/подзадач, зависимости (визуально)
  - Статусы и прогресс обновляются ботом автоматически:
    - Из чата: распознавание формулировок «сделал/готово/переношу», реакций, ключевых слов
    - По событиям: дедлайны, ответы на опросы, контроль активности
  - Опросы ботом: периодические «чек‑ин» для ответственных, авто‑заполнение прогресса
- Chat‑mining → дашборды:
  - Бот мониторит чат (по ключам/смыслам, P01/P03) и предлагает создать/обновить Task/Event
  - Встройка подтверждения в диалог; отмена/редактирование безопасно
- Метрики/SLO (дашборды):
  - `dashboard.update.p95_ms ≤ 1500`; `task.auto_update_rate ≥ 60%` (MVP)
  - Алерты: рост «просроченных», низкий `check‑in` rate

---

### 15. Роли и права (многоуровневая, но простая иерархия)

- Уровни: Организация (опц.) → Team/Group → Bot → Channel/Chat → Task/Event
- Роли (минимум): `owner`, `admin`, `editor`, `viewer`
- Правила (общая матрица):
  - owner/admin: полный доступ на уровне сущности и ниже
  - editor: создавать/редактировать задачи/события в пределах команды/чата
  - viewer: просмотр, собственные подтверждения/ответы
- Тех. реализация (MVP):
  - RBAC в настройках бота/группы (json), проверка на сервере; Telegram‑роль (creator/admin/member) учитывается
  - Stage‑2: таблицы ролей и наследования, UI‑редактор прав

---

### 16. Преимущества интеграции с Telegram (резюме)

- Низкий порог входа (нет отдельной регистрации), мгновенные уведомления, офлайн‑толерантность
- Богатые чаты как источник данных для авто‑заполнения дашбордов и памяти Соула
- Mini Apps для удобного UI без установки приложений; Payments/Stars — готовая экономика
- Синергия с ядром Soul: персоны, память, планер/инструменты, напоминания, голос, безопасность

---

### 17. Stage‑2: схемы БД для Task / Event / Reminder

- Принципы:
  - Нормализованные сущности, soft‑delete (`deleted_at`), аудит (`created_by`, `updated_by`, `trace_id`), связи с Provenance (P11)
  - Многоарендность: `tenant_id` (организация) + `bot_id` + `chat_id` (группа/канал/ЛС)
  - RBAC: доступ на уровне `team_id/group_id` и ниже, через связку с ролями (см. раздел 15)

- Таблица `tasks` (основная):
  - id UUID PK; tenant_id; bot_id; chat_id; team_id
  - title TEXT; description TEXT; labels JSONB; priority ENUM(low,normal,high,urgent)
  - status ENUM(todo,in_progress,done,blocked,canceled); progress SMALLINT 0..100
  - start_at TIMESTAMPTZ; due_at TIMESTAMPTZ; completed_at TIMESTAMPTZ
  - owner_id BIGINT (Telegram user); parent_task_id UUID NULL (иерархия подзадач)
  - source_message_id BIGINT NULL; source_user_id BIGINT NULL; provenance_id UUID NULL
  - created_at/updated_at/deleted_at TIMESTAMPTZ; created_by BIGINT; updated_by BIGINT

- Таблица `task_assignments`:
  - id UUID PK; task_id UUID FK; user_id BIGINT; role ENUM(owner,assignee,watcher)
  - notify BOOLEAN DEFAULT true; created_at; updated_at

- Таблица `task_dependencies`:
  - id UUID PK; task_id UUID FK; depends_on_task_id UUID FK; type ENUM(fs,ss,ff,sf); lag INTERVAL NULL

- Таблица `events`:
  - id UUID PK; tenant_id; bot_id; chat_id; team_id
  - title TEXT; description TEXT; location TEXT
  - start_at TIMESTAMPTZ; end_at TIMESTAMPTZ; all_day BOOLEAN DEFAULT false
  - recurrence_rrule TEXT NULL; recurrence_exdates JSONB NULL
  - organizer_id BIGINT; status ENUM(planned,ongoing,done,canceled)
  - source_message_id BIGINT NULL; provenance_id UUID NULL
  - created_at/updated_at/deleted_at; created_by; updated_by

- Таблица `event_participants`:
  - id UUID PK; event_id UUID FK; user_id BIGINT; response ENUM(yes,no,maybe,none); checked_in_at TIMESTAMPTZ NULL

- Таблица `reminders`:
  - id UUID PK; tenant_id; bot_id; chat_id; team_id
  - target_type ENUM(task,event,note,message); target_id UUID/BIGINT
  - policy ENUM(once,repeat,escalate,windowed)
  - schedule_at TIMESTAMPTZ NULL; cron TEXT NULL; window_before INTERVAL NULL; timezone TEXT
  - channels JSONB (e.g. ["telegram_dm","telegram_group","web_push"]) 
  - message_template TEXT; status ENUM(scheduled,paused,sent,snoozed,canceled)
  - last_sent_at TIMESTAMPTZ NULL; next_run_at TIMESTAMPTZ NULL; retry_count INT DEFAULT 0
  - created_at/updated_at/deleted_at; created_by; updated_by; provenance_id UUID NULL

- Таблица `chat_mined_facts` (chat‑mining результаты):
  - id UUID PK; tenant_id; bot_id; chat_id; message_id BIGINT 
  - intent ENUM(task_create,task_update,event_create,status_update,due_change,assignment,note)
  - confidence NUMERIC(3,2); extracted JSONB; linked_task_id UUID NULL; linked_event_id UUID NULL
  - action_status ENUM(proposed,confirmed,rejected,auto_applied); confirmer_id BIGINT NULL
  - created_at; trace_id UUID

- Индексы: по (team_id,status,due_at), (chat_id,message_id), (next_run_at,status), полнотекст по title/description, GIN по labels/extracted

---

### 18. API: календарь, диаграмма Ганта, chat‑mining

- Аутентификация/авторизация:
  - Telegram Login Widget → short‑lived JWT; Bot → bot_token + chat_id; все методы проверяют RBAC

- Календарь (Tasks + Events)
  - GET `/api/calendar` — агрегированный фид
    - qparams: scope=user|team, team_id?, user_id?, from, to, status?, labels?, mine?
    - resp: { tasks: [...], events: [...], server_time }
  - GET `/api/tasks` | `/api/events` — списки с фильтрами (как выше)
  - POST `/api/tasks` — создать задачу
    - body: { title, description?, due_at?, assignees[], labels?, priority?, parent_task_id? }
  - PATCH `/api/tasks/{id}` — частичное обновление (status/progress/dates/labels)
  - POST `/api/events` / PATCH `/api/events/{id}` — аналогично; поддержка `recurrence_rrule`
  - POST `/api/reminders` — создать напоминание
    - body: { target_type, target_id, policy, schedule_at|cron, window_before?, channels?, message_template? }
  - GET `/api/reminders/next` — для планировщика; отдать пачку к исполнению до T+X

- Диаграмма Ганта
  - GET `/api/gantt` — задачи, зависимости, даты
    - qparams: team_id, from, to, include_subtasks?, critical_path?
    - resp: { tasks:[{id,title,start_at,due_at,progress,parent_task_id}], deps:[{from,to,type,lag}] }
  - PATCH `/api/tasks/{id}/schedule` — сдвиг даты/диапазона; валидатор зависимостей
  - PUT `/api/tasks/{id}/dependencies` — массовое обновление зависимостей

- Chat‑mining
  - POST `/api/chat-mining/ingest` — приём нормализованных событий из бота
    - body: { chat_id, message_id, text, entities?, attachments?, user_id, ts }
    - resp: { proposal_id, intents:[{type,confidence,extracted}] }
  - POST `/api/chat-mining/proposals/{id}/confirm` — подтверждение автозаполнения
    - body: { accept: true|false, link: task|event, link_id? }
  - GET `/api/chat-mining/proposals` — список «в ожидании» с фильтрами по чату/дате

- Realtime
  - WS `/ws/calendar` — подписка на изменения задач/событий/напоминаний для team_id/chat_id
  - События: `task.updated`, `event.created`, `reminder.sent`, `mining.proposed`

- Инварианты/валидация
  - Strict JSON (Pydantic) и SchemaGuard (P10); audit в `soul_audit_log` (создание/изменение/автоприменение)
  - Политики эскалаций напоминаний: не чаще N/час пользователю, уважение «тихих часов»

- SLO/метрики (минимум)
  - `calendar.feed.p95_ms ≤ 1200`; `gantt.feed.p95_ms ≤ 1500`; `mining.proposal.latency_p95 ≤ 800ms`
  - Ошибки парсинга mining ≤ 2% от сообщений; авто‑точность подтверждений ≥ 0.6

---

### 19. Контракты (Pydantic) и примеры запросов/ответов

- Базовые типы и enum:

```python
from typing import List, Optional, Literal, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field, conint, constr

Priority = Literal["low", "normal", "high", "urgent"]
TaskStatus = Literal["todo", "in_progress", "done", "blocked", "canceled"]
EventStatus = Literal["planned", "ongoing", "done", "canceled"]
DepType = Literal["fs", "ss", "ff", "sf"]
ReminderPolicy = Literal["once", "repeat", "escalate", "windowed"]
MiningIntent = Literal[
    "task_create", "task_update", "event_create",
    "status_update", "due_change", "assignment", "note"
]

class Pagination(BaseModel):
    limit: int = 50
    offset: int = 0
```

- Tasks

```python
class TaskBase(BaseModel):
    title: constr(min_length=1, max_length=300)
    description: Optional[str] = None
    labels: Optional[Dict[str, Any]] = None
    priority: Optional[Priority] = "normal"

class TaskCreate(TaskBase):
    due_at: Optional[datetime] = None
    start_at: Optional[datetime] = None
    assignees: Optional[List[int]] = Field(default_factory=list)
    parent_task_id: Optional[str] = None

class TaskUpdate(BaseModel):
    title: Optional[constr(min_length=1, max_length=300)] = None
    description: Optional[str] = None
    labels: Optional[Dict[str, Any]] = None
    priority: Optional[Priority] = None
    status: Optional[TaskStatus] = None
    progress: Optional[conint(ge=0, le=100)] = None
    start_at: Optional[datetime] = None
    due_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    assignees: Optional[List[int]] = None
    parent_task_id: Optional[str] = None

class TaskResponse(TaskBase):
    id: str
    status: TaskStatus
    progress: int
    start_at: Optional[datetime]
    due_at: Optional[datetime]
    completed_at: Optional[datetime]
    owner_id: Optional[int]
    parent_task_id: Optional[str]
    created_at: datetime
    updated_at: datetime
```

- Events

```python
class EventBase(BaseModel):
    title: constr(min_length=1, max_length=300)
    description: Optional[str] = None
    location: Optional[str] = None

class EventCreate(EventBase):
    start_at: datetime
    end_at: Optional[datetime] = None
    all_day: bool = False
    recurrence_rrule: Optional[str] = None
    participants: Optional[List[int]] = Field(default_factory=list)

class EventUpdate(BaseModel):
    title: Optional[constr(min_length=1, max_length=300)] = None
    description: Optional[str] = None
    location: Optional[str] = None
    start_at: Optional[datetime] = None
    end_at: Optional[datetime] = None
    all_day: Optional[bool] = None
    recurrence_rrule: Optional[str] = None
    status: Optional[EventStatus] = None
    participants: Optional[List[int]] = None

class EventResponse(EventBase):
    id: str
    start_at: datetime
    end_at: Optional[datetime]
    all_day: bool
    recurrence_rrule: Optional[str]
    status: EventStatus
    created_at: datetime
    updated_at: datetime
```

- Reminders

```python
class ReminderCreate(BaseModel):
    target_type: Literal["task", "event", "note", "message"]
    target_id: str
    policy: ReminderPolicy
    schedule_at: Optional[datetime] = None
    cron: Optional[str] = None
    window_before: Optional[str] = None
    timezone: Optional[str] = "UTC"
    channels: Optional[List[str]] = ["telegram_dm"]
    message_template: Optional[str] = None

class ReminderUpdate(BaseModel):
    policy: Optional[ReminderPolicy] = None
    schedule_at: Optional[datetime] = None
    cron: Optional[str] = None
    window_before: Optional[str] = None
    timezone: Optional[str] = None
    channels: Optional[List[str]] = None
    message_template: Optional[str] = None
    status: Optional[Literal["scheduled","paused","sent","snoozed","canceled"]] = None

class ReminderResponse(BaseModel):
    id: str
    target_type: str
    target_id: str
    policy: ReminderPolicy
    schedule_at: Optional[datetime]
    cron: Optional[str]
    next_run_at: Optional[datetime]
    status: Literal["scheduled","paused","sent","snoozed","canceled"]
    created_at: datetime
    updated_at: datetime
```

- Gantt/Calendar/Mining

```python
class Dependency(BaseModel):
    from_id: str
    to_id: str
    type: DepType = "fs"
    lag: Optional[str] = None  # ISO 8601 duration, e.g. "P1D"

class GanttTask(BaseModel):
    id: str
    title: str
    start_at: Optional[datetime]
    due_at: Optional[datetime]
    progress: int = 0
    parent_task_id: Optional[str] = None

class GanttResponse(BaseModel):
    tasks: List[GanttTask]
    deps: List[Dependency]

class CalendarResponse(BaseModel):
    server_time: datetime
    tasks: List[TaskResponse]
    events: List[EventResponse]

class ChatMiningIngestRequest(BaseModel):
    chat_id: int
    message_id: int
    text: Optional[str] = None
    entities: Optional[List[Dict[str, Any]]] = None
    attachments: Optional[List[Dict[str, Any]]] = None
    user_id: int
    ts: datetime

class MiningIntentItem(BaseModel):
    type: MiningIntent
    confidence: float
    extracted: Dict[str, Any]

class ChatMiningIngestResponse(BaseModel):
    proposal_id: str
    intents: List[MiningIntentItem]

class MiningProposalConfirm(BaseModel):
    accept: bool
    link: Optional[Literal["task", "event"]] = None
    link_id: Optional[str] = None
```

— Примеры запросов/ответов

- GET `/api/calendar` (scope=team; 7 дней)

```json
{
  "server_time": "2025-09-15T10:00:00Z",
  "tasks": [
    {
      "id": "7b6f...",
      "title": "Сверстать лендинг",
      "description": "Блоки: hero, цены",
      "labels": {"project": "site"},
      "priority": "high",
      "status": "in_progress",
      "progress": 40,
      "start_at": "2025-09-14T09:00:00Z",
      "due_at": "2025-09-20T18:00:00Z",
      "completed_at": null,
      "owner_id": 123456789,
      "parent_task_id": null,
      "created_at": "2025-09-14T08:00:00Z",
      "updated_at": "2025-09-15T09:30:00Z"
    }
  ],
  "events": [
    {
      "id": "e12c...",
      "title": "Стендап",
      "description": "ежедневный",
      "location": "VC",
      "start_at": "2025-09-16T08:00:00Z",
      "end_at": "2025-09-16T08:15:00Z",
      "all_day": false,
      "recurrence_rrule": null,
      "status": "planned",
      "created_at": "2025-09-14T08:00:00Z",
      "updated_at": "2025-09-14T08:00:00Z"
    }
  ]
}
```

- GET `/api/tasks?status=todo&limit=2`

```json
{
  "items": [
    {"id":"1", "title":"Подготовить ТЗ", "status":"todo", "progress":0},
    {"id":"2", "title":"Сделать макеты", "status":"todo", "progress":0}
  ],
  "limit": 2,
  "offset": 0,
  "total": 17
}
```

- POST `/api/tasks` (TaskCreate)

```json
{
  "title": "Настроить мониторинг",
  "description": "Grafana + алерты",
  "due_at": "2025-09-22T12:00:00Z",
  "assignees": [111111111, 222222222],
  "labels": {"area": "ops"},
  "priority": "high"
}
```

```json
{
  "id": "94a2...",
  "title": "Настроить мониторинг",
  "description": "Grafana + алерты",
  "labels": {"area": "ops"},
  "priority": "high",
  "status": "todo",
  "progress": 0,
  "start_at": null,
  "due_at": "2025-09-22T12:00:00Z",
  "completed_at": null,
  "owner_id": 111111111,
  "parent_task_id": null,
  "created_at": "2025-09-15T10:10:00Z",
  "updated_at": "2025-09-15T10:10:00Z"
}
```

- PATCH `/api/tasks/{id}` (TaskUpdate → TaskResponse)

```json
{"status":"in_progress", "progress": 20}
```

```json
{"id":"94a2...","title":"Настроить мониторинг","status":"in_progress","progress":20}
```

- POST `/api/events` (EventCreate)

```json
{
  "title": "Демо релиза",
  "start_at": "2025-09-25T15:00:00Z",
  "end_at": "2025-09-25T15:45:00Z",
  "participants": [111111111, 333333333]
}
```

```json
{"id":"e77a...","title":"Демо релиза","start_at":"2025-09-25T15:00:00Z","end_at":"2025-09-25T15:45:00Z","status":"planned"}
```

- POST `/api/reminders` (ReminderCreate)

```json
{
  "target_type": "task",
  "target_id": "94a2...",
  "policy": "escalate",
  "schedule_at": "2025-09-21T09:00:00Z",
  "channels": ["telegram_dm", "telegram_group"],
  "message_template": "Напоминание: {title} до {due_at}"
}
```

```json
{"id":"r1a...","target_type":"task","target_id":"94a2...","policy":"escalate","status":"scheduled","next_run_at":"2025-09-21T09:00:00Z"}
```

- GET `/api/reminders/next?window_minutes=30`

```json
{
  "items": [
    {"id":"r1a...","target_type":"task","target_id":"94a2...","next_run_at":"2025-09-21T09:00:00Z"}
  ],
  "server_time": "2025-09-15T10:12:00Z"
}
```

- GET `/api/gantt?team_id=42&from=2025-09-15&to=2025-10-01`

```json
{
  "tasks": [
    {"id":"94a2...","title":"Настроить мониторинг","start_at":"2025-09-18T09:00:00Z","due_at":"2025-09-22T12:00:00Z","progress":20}
  ],
  "deps": [
    {"from_id":"94a2...","to_id":"abc3...","type":"fs"}
  ]
}
```

- PATCH `/api/tasks/{id}/schedule`

```json
{"start_at":"2025-09-19T09:00:00Z","due_at":"2025-09-23T12:00:00Z"}
```

```json
{"id":"94a2...","start_at":"2025-09-19T09:00:00Z","due_at":"2025-09-23T12:00:00Z","validation":"ok"}
```

- PUT `/api/tasks/{id}/dependencies`

```json
{"deps":[{"from_id":"94a2...","to_id":"abc3...","type":"fs","lag":"P1D"}]}
```

```json
{"updated":1}
```

- POST `/api/chat-mining/ingest` (ChatMiningIngestRequest)

```json
{
  "chat_id": -1001234567890,
  "message_id": 5678,
  "text": "@ivan сделай отчёт к пятнице",
  "entities": [{"type":"mention","offset":0,"length":5}],
  "attachments": [],
  "user_id": 444444444,
  "ts": "2025-09-15T09:59:00Z"
}
```

```json
{
  "proposal_id": "p_9fa...",
  "intents": [
    {"type":"task_create","confidence":0.83,"extracted":{"title":"сделай отчёт","due_at":"2025-09-19T18:00:00Z","assignees":["@ivan"]}}
  ]
}
```

- POST `/api/chat-mining/proposals/{id}/confirm`

```json
{"accept": true, "link": "task"}
```

```json
{"status":"applied","linked":{"type":"task","id":"94a2..."}}
```

- GET `/api/chat-mining/proposals?chat_id=-100123...&status=proposed`

```json
{"items":[{"id":"p_9fa...","intent":"task_create","confidence":0.83,"extracted":{"title":"сделай отчёт"}}]}
```

- WS `/ws/calendar` — событие

```json
{"type":"task.updated","payload":{"id":"94a2...","status":"done","progress":100},"ts":"2025-09-15T10:20:00Z"}
```

---

### 20. Инструменты малых проектных групп (best‑practice toolkit)

- Режимы работы:
  - Scrum/Канбан гибрид: спринты + доски со swimlane и WIP‑лимитами
  - Дневные стендапы, недельные ретро, планирование спринтов, груминг бэклога
- Шаблоны и чек‑листы:
  - Типы задач: Story/Bug/Task/Spike; поля: оценки (story points), DoR/DoD чек‑листы
  - Авто‑чек‑листы по типам (например, релизные проверки, безопасность, документация)
- Роли и ответственность (RACI):
  - На задачу/эпик: Responsible, Accountable, Consulted, Informed
  - Автоматические уведомления для R/C при изменении статуса
- Воркфлоу:
  - Статусы расширены: backlog → selected → in_progress → review → done; блокировки/причины
  - Правила переходов по ролям; ревью‑гейты; автоматическая эскалация дедлайнов
- Авто‑стендапы и опросы:
  - Ежедневные короткие формы: что сделал/планы/блокеры; авто‑сбор в сводку команды
  - Выделение action items и автосоздание задач

---

### 21. Коллаборация и артефакты

- Комментарии и треды:
  - Комментарии к Task/Event, ответы (thread), @упоминания, эмодзи‑реакции
  - Автоссылки на сообщения из чата и обратная навигация
- Вложения:
  - Файлы/изображения/голосовые заметки (ASR авто‑транскрипция → прикреплённый текст)
  - Встроенная предпросмотрка для популярных форматов
- Знания и заметки:
  - Meeting notes/решения/итоги ретро в привязке к спринту/эвенту
  - Decision log: фиксирование ключевых архитектурных/продуктовых решений

Stage‑3 DB (расширение): `task_comments`, `task_threads`, `task_attachments`, `notes`, `decisions`

---

### 22. Интеграции и синхронизация

- Календарь:
  - Двусторонняя синхронизация с Google Calendar/Microsoft 365 (OAuth, incremental sync)
  - ICS импорт/экспорт, публичные read‑only ссылки на события/диапазоны
- Инструменты разработки:
  - GitHub/Jira: автоссылки, создание задач/линковка коммитов/PR, статус‑вебхуки
  - CI: публикация статусов сборок/релизов в события/задачи
- Автоматизации:
  - Webhooks, Zapier/Make сценарии, подписки по событиям (`task.updated`, `event.created`)

---

### 23. Тайм‑трекинг и отчёты

- Учёт времени:
  - Ввод по задаче/эпик, таймер, категории работ; лимиты; апрув ментором/лидом
- Метрики команды:
  - Burndown, velocity, нагрузка по людям, распределение по типам задач
  - SLA по инцидентам/багам; лид‑тайм/цикл‑тайм; прогноз завершения спринта

Stage‑3 DB: `time_entries`, агрегаты и представления для отчётов

---

### 24. Импорт/экспорт и вебхуки

- Импорт CSV/JSON задач/событий; соответствие полей, валидация, dry‑run
- Экспорт: фильтры, период, формат (CSV/JSON/ICS/PDF отчёты)
- Webhooks: подписка по сущности/фильтрам, ретраи, подпись HMAC, секреты в SecretStore

---

### 25. Нефункциональные требования (полноценное приложение)

- Доступность/производительность:
  - 99.9% monthly uptime; p95: календарь ≤ 1200 ms, гант ≤ 1500 ms, mining ≤ 800 ms
  - Горизонтальное масштабирование, кэширование, rate‑limit/квоты per‑tenant, circuit‑breaker
- Надёжность:
  - Идемпотентность для write‑эндпоинтов, дедупликация, повторная доставка задач планировщика
  - Резервное копирование, DR‑план, retention политики
- Локализация и доступность:
  - i18n (RU/EN), часовые зоны, A11y требования к веб‑UI

---

### 26. Безопасность и соответствие

- RBAC многоуровневый (см. 15), разграничение по командам/проектам/чатам
- PII/Privacy (см. P08): маскирование, хеширование, минимизация, политики хранения
- Аудит (см. Observability): кто/когда/что изменил, reason, trace_id; экспорт в SIEM
- Соответствие: GDPR/152‑ФЗ (по необходимости), DPA, права субъекта данных

---

### 27. Расширение API (высокоуровневое)

- Новые эндпоинты:
  - Комментарии: `/api/tasks/{id}/comments` (CRUD), треды, реакции
  - Вложения: `/api/tasks/{id}/attachments` (загрузка/удаление), presigned URLs
  - Спринты и бэклог: `/api/sprints`, `/api/backlog` (планирование, борды)
  - Тайм‑трекинг: `/api/time-entries` (CRUD, отчёты), агрегаты `/api/reports/*`
  - Интеграции: `/api/integrations/*` (OAuth, подключения, статусы)
- Реализация: Strict JSON + SchemaGuard; пагинация/сортировка/поиск, bulk‑операции, optimistic locking (`If-Match`/version)

Тест‑план дополнен сценариями для ролей/воркфлоу/интеграций; rollout — по фичефлагам, тёмный запуск, A/B на пилотных командах.

---

### 28. Stage‑3: расширенные схемы БД (комментарии, вложения, спринты, тайм‑трекер)

- `task_comments`:
  - id UUID PK; task_id UUID FK; parent_comment_id UUID NULL (threads)
  - author_id BIGINT; body TEXT; mentions JSONB; reactions JSONB
  - created_at/updated_at/deleted_at; edited_by BIGINT NULL

- `task_attachments`:
  - id UUID PK; task_id UUID FK; uploader_id BIGINT
  - kind ENUM(file,image,voice,video,link)
  - storage_key TEXT (path/blob id); content_type TEXT; size INT
  - meta JSONB (thumbnail, duration, asr_text, ocr_text)
  - created_at/updated_at/deleted_at

- `sprints`:
  - id UUID PK; team_id UUID; name TEXT; goal TEXT NULL
  - start_date DATE; end_date DATE; status ENUM(planned,active,closed)
  - capacity INT NULL (story points или часы); created_at/updated_at

- `sprint_tasks`:
  - id UUID PK; sprint_id UUID FK; task_id UUID FK; order_no INT

- `time_entries`:
  - id UUID PK; task_id UUID FK; user_id BIGINT
  - started_at TIMESTAMPTZ; ended_at TIMESTAMPTZ NULL; duration_sec INT
  - category ENUM(dev,review,meeting,research,ops,other)
  - note TEXT NULL; approved_by BIGINT NULL; created_at/updated_at

- Индексы: полнотекст по `task_comments.body`, GIN по `mentions/meta`, (sprint_id, order_no), (task_id, started_at)

Миграции: отдельный ревизионный файл Stage‑3, с безопасными default и обратимым downgrade.

---

### 29. Тест‑сценарии: чек‑листы и примеры (e2e)

- RBAC и роли
  - Создать команду, выдать роли owner/admin/editor/viewer; проверить доступы ко всем эндпоинтам
  - Попытка editor закрыть задачу без ревью‑гайта → 409; owner может
  - viewer может подтверждать собственные события/напоминания, но не менять чужие задачи → 403
- Календарь/Гант
  - Создать 3 задачи с зависимостями (fs, ss); сдвигать расписание и валидировать пересчёт
  - Проверить критический путь (если реализован) и подсветку просрочки
  - Веб‑сокет: подписка, приход событий task.updated/event.created
- Chat‑mining
  - Инжест 10 сообщений; ≥60% авто‑обновлений применяются; остальное — через подтверждение
  - Проверить извлечение due/assignees из упоминаний и дат
- События/Напоминания
  - Повторяющееся событие с исключениями; корректная генерация напоминаний в окне и эскалации
  - Тихие часы и rate‑limit: не более N/час/пользователь
- Комментарии/Вложения
  - Треды, @упоминания, реакции; загрузка файла через presigned URL; предпросмотр
- Спринты/Тайм‑трекер/Отчёты
  - Планирование спринта, изменение порядка задач; burndown/velocity соответствует перемещениям
  - Учёт времени по категориям, апрув; агрегаты по людям/периоду; экспорт CSV
- Интеграции
  - Google Calendar двусторонняя синхронизация: апдейт из внешнего календаря отражается в Event
  - GitHub/Jira: создание задачи из PR, вебхук CI переводит статус на review/done
- НФТ/Безопасность
  - Идемпотентность write эндпоинтов; SchemaGuard; аудит soul_audit_log; GDPR экспорт/удаление

SLO‑валидация: замер p95 на каждом ключевом фиде; алерты при регрессии. Логи включают trace_id для корреляции с mining/provenance.

---

### 30. Версионирование, Inbox и мобильные виды

- Optimistic locking:
  - Для `tasks`, `events`, `reminders`, `sprints` — поле `row_version TIMESTAMPTZ DEFAULT now()`; при PATCH требовать `If-Match: <row_version>` или передачу `row_version` в теле; при несовпадении возвращать 409
  - Для GET‑фидов (календарь/Гант) — ETag/Last-Modified; поддержка `If-None-Match`/`If-Modified-Since`

- Inbox (входящие предложения/события):
  - Содержимое: предложения chat‑mining, неподтверждённые изменения задач/событий, новые упоминания/назначения, эскалации напоминаний
  - Операции: batch‑accept/reject/assign; шаблоны быстрого создания задач/напоминаний; фильтры по источнику/типу/команде
  - API: `/api/inbox` (GET), `/api/inbox/batch` (POST)

- Мобильные виды:
  - Compact‑календарь (list + day/week), simplified‑Гант (линейка, свёртка подзадач), быстрые действия одним нажатием
  - В боте — короткие карточки с кнопками (перенести/назначить/закрыть), reply‑кнопки для чек‑инов

- Алгоритмичность и уровни ИИ:
  - Базово — эвристики/правила; при высокой неопределённости — LLM (малые для сервисных операций, большие — для сложных решений)
  - Наблюдаемость и управление: все вызовы инструментов/LLM логируются; при разрешении администратора Soul может менять политики и триггеры через Admin API/фичетогглы

---

### 31. Observability: UX‑метрики и контроль ИИ‑контуров

- UX‑метрики:
  - `ux.task_create.ms` (p50/p95), `ux.mining.confirmation.rate`, `ux.checkin.response.ms`, `ux.reminder.snooze.rate`, `ux.overdue.rate`
  - Разрезы: по командам/персонам/типам задач; ежедневные/недельные дайджесты в чат
- Контроль ИИ‑контуров:
  - Доли вызовов малых/больших моделей, латентность/стоимость, частота fallback
  - Качество: точность mining (auto vs confirmed), self‑check/consistency (см. P06), доля ручных правок после автоприменения
- Управление:
  - Feature‑toggles и бюджеты для ИИ; RBAC‑доступ к включению/отключению; аудит всех изменений политик

События аудита/метрик (добавить в Observability):
- `ux.task_create.ms`, `ux.task_update.conflict`, `ux.mining.apply.auto`, `ux.mining.apply.manual`, `ux.checkin.response.ms`, `ux.inbox.batch.ops`
- `ai.router.provider.pick`, `ai.llm.small.calls`, `ai.llm.large.calls`, `ai.fallback.triggered`, `ai.cost.usd`

---

### 32. Soul Control: инструменты, действия, защита, мониторинг и доступ к ПК/Cursor

- Профиль способностей Соула
  - Инструменты: Retrieval/Search, Planner Tool‑Use (HTTP, калькулятор, конвертеры), Reminders, Voice (ASR/TTS), Files (вложения), Webhooks
  - Действия (DesiredAction, P07): `proposal|request|research|reminder|goal_update|note|integration_call`
  - Ограничения: уровни доверия (sandbox → staging → prod); deny‑by‑default на автопубликации; квоты/лимиты по провайдерам

- Алгоритмы оптимизации
  - Выбор провайдера (P14): стоимость/латентность/надёжность; кэш/дедуп; circuit‑breaker; многоязычный роутинг
  - Контекст (P03/P01): адаптивная 30/70 выдача, гибридный ретривал, цель/план/фидбек
  - Самопроверка (P06): self‑consistency/contradiction, политика уточняющих вопросов при низкой уверенности

- Безопасность и защита
  - Guard (P09): pre‑scan входа, NEGATIVE‑фильтры, post‑guard выхода, анти‑инъекции
  - Privacy (P08): PII‑санитизация, маскирование/хеширование, минимизация данных
  - Политики инструментов: белые списки доменов/методов, токены в SecretStore, аудит каждого вызова с `trace_id`

- Мониторинг внешних сервисов
  - Регистры провайдеров: health‑пробы, ошибки/латентность, бюджеты и квоты
  - Алерты: деградация p95, рост ошибок, превышение бюджета, частые fallback
  - Автодействия: переключение на резервного провайдера, снижение частоты тяжёлых моделей

- Доступ Соула к ПК и Cursor
  - Модель доступа: инструмент `pc.exec` и `pc.fs` (ограниченный), `cursor.edit`/`cursor.run` — только при явном разрешении Архитектора (feature‑toggle + RBAC)
  - Политики:
    - Read‑only по умолчанию; write/exec разрешаются по скоупам (каталоги/файлы/команды)
    - Dry‑run и план изменений (diff) перед применением; обязательный audit лог с превью
  - Наблюдаемость: все действия с ПК/Cursor логируются и трассируются; rollback сценарии

- Управление Архитектором
  - Панель контроля: включение инструментов/LLM уровней, бюджетов, провайдеров; разрешение на доступ к ПК/Cursor по скоупам
  - Механизм «двух ключей»: на опасные операции требуется подтверждение Архитектора
  - Полный аудит: кто/когда/почему; экспорт в SIEM

— Политики scope‑ов (минимальный набор)
- `repo.read` — чтение git‑статуса/логов в пределах рабочей директории
- `repo.write` — изменение файлов в git‑репозитории (только через `cursor.edit` с dry‑run + diff)
- `workspace.read` — чтение файлов по белым путям (docs/, Soul/, backend/)
- `workspace.write` — запись в белые пути; требует двух ключей для backend/
- `workspace.exec` — запуск whitelisted команд (pytest, uvicorn, alembic current/upgrade heads, git status); всегда dry‑run по умолчанию
- `secrets.read` — чтение секретов только через proxy (маскировано, аудит)
- Дополнительно: пользовательские скоупы на команды/пути

— Очередь утверждений (two‑keys queue)
- Таблицы: `sensitive_op_requests` и `sensitive_op_approvals`
  - `sensitive_op_requests`: id UUID, action, scope, payload JSONB, requested_by, required_approvers[], ttl_at, status(pending/approved/rejected/expired), created_at
  - `sensitive_op_approvals`: id UUID, request_id, approver_id, decision(approve/reject), reason, created_at
- Политики TTL: авто‑истечение заявок (например, 24ч), алерты при зависании
- Исполнение: операция выполняется только после удовлетворения правил политики (requires_both или quorum), с фиксацией результата в аудите