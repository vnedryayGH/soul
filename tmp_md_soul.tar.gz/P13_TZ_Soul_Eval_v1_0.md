---

## Индекс взаимных ссылок (P01–P37)

- P01/P04/P06 — объекты оценки (смыслы, гипотезы, самосогласованность).
- P14 — провайдерные профили для сравнений.
- P21 — метрики мониторинга; P24 — интегрированные тесты.
- P27 — подпись результатов; P30 — события прогонов.
- P33 — Mini Chat сценарии для пользовательских метрик.
- P36 — команды запуска/сборов метрик через DSL.

### ТЗ Soul v1.0 — Офлайн‑оценка и A/B‑рамка (Golden‑Set, Eval Harness)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: К реализации (MVP офлайн без серверов; CI‑gate по порогам)

---

### 0. Executive summary

- Цель: получить воспроизводимую офлайн‑оценку качества ядра (JSON‑валидность, ясность, полезность, потребность в исследовании, латентность, стоимость, фоллбек/ошибки) и A/B‑сравнение веток/настроек.
- Интеграция: отдельный хранилище кейсов `Soul/CI/golden_set/`, скрипты запуска `backend/scripts/eval/*`, отчёт `Soul/CI/ci_report.md`. Запуск — без серверов/каналов, через прямой вызов сервисов ядра.
- CI‑ворота: pre‑merge падает при регрессе метрик выше порогов; отчёт артефактом.

---

### 1. Архитектура и точки интеграции

- Ядро: `backend/app/services/soul_core_manager.py: generate_quant_enhanced` (в stateless режиме, без БД).
- Модели/роутинг: `LLMManager` (функции `soul_core`, `planner`, `eval_judge`), `soul_settings_service.py` (параметры/флаги).
- Контекст: `soul_context.py` — для eval использовать минимальный/контролируемый контекст (или отключить fetch, подменяя фиктивным).
- Утилиты JSON: `backend/app/lib/json_strict.py` — строгий парсинг/нормализация.
- Аудит/метрики: не требуются серверные; время/стоимость собираем внутри харнесса.

Принципы:

- Без серверов/каналов и без записи в БД (stateless, `db=None`).
- Фиксированные параметры модели (seed, temperature, max_tokens) для воспроизводимости.
- Минимально необходимый набор метрик + лёгкий LLM‑оценщик (mini‑judge) при необходимости.

---

### 2. Структура Golden‑Set

Каталог: `Soul/CI/golden_set/`

Формат: JSONL (`.jsonl`) или JSON (`.json`) с массивом объектов, каждый кейс:

```json
{
  "id": "G001",
  "input_text": "Какой следующий шаг?",
  "history": [ {"role":"user","content":"контекст"} ],
  "expect": {
    "needs_research": false,
    "should_clarify": true,
    "min_tags": 1,
    "max_latency_ms": 6000
  },
  "notes": "ясный вопрос — ожидаем clarify"
}

```

Правила:

- 100± кейсов с репрезентативными типами запросов.
- Допускаются пустые `history` и пустой `expect` (тогда метрики только измеряются, без порогов на кейс).
- Язык кейса — RU/EN; итоговая оценка агрегируется по всем.

---

### 3. Метрики и определения

- JSON Validity: доля ответов, строго распарсенных как STRICT JSON (массив/объект по режиму).
- Field Completeness: доля ответов с заполненными полями (`thought_form`, `tags`, `energy_weight`, `composite_emotion`, `desired_action`).
- Clarity (0..1): оценка краткости/понятности — mini‑judge или эвристика (длина/структура).
- Actionability (0..1): пригодность к действию — mini‑judge.
- Research‑Need (0/1): mini‑judge флаг «нужен ли research/clarify». Сопоставляется с `expect`.
- Latency p50/p95 (мс): измерения на стороне харнесса.
- Cost: оценена по токенам (если доступны) или по прокси‑величине.
- Fallback Rate: доля переходов на `generate_quant_legacy`.
- Error Rate: доля ошибок (исключений) при обработке кейсов.

Агрегация: сводная таблица по всем кейсам и по поднаборам (RU/EN, типы запросов).

---

### 4. Eval Harness (скрипты)

Файлы (новые):

- `backend/scripts/eval/run_golden_eval.py` — основной запускатель (async).
- `backend/scripts/eval/metrics.py` — вычисление и агрегация метрик.
- `backend/scripts/eval/judges.py` — mini‑judge (малый LLM) и/или эвристический оценщик.
- `backend/scripts/eval/utils.py` — загрузка кейсов, таймеры, токены/стоимость.

Интерфейс запуска:

```bash
python -m backend.scripts.eval.run_golden_eval \
  --dataset Soul/CI/golden_set/main.jsonl \
  --output Soul/CI/results/run_YYYYmmdd_HHMM.json \
  --model-profile default \
  --stateless true \
  --max-cases 100

```

Требования к запуску:

- Не поднимать сервер. Импортировать и вызывать `SoulCoreManager.generate_quant_enhanced(db=None, ...)`.
- Зафиксировать параметры модели через `LLMManager` профиль `eval.soul_core` (temperature, max_output_tokens, retries, timeout).
- Отключить запись в БД и фоновые действия (статлесс путь, `SOUL_DISABLE_QUANT_PERSIST_BATCH=1`).

Выход:

- JSON с сырыми результатами по каждому кейсу + сводка метрик.
- Маркдаун отчёт `Soul/CI/ci_report.md` (перезапись) с таблицами/диаграммами.

---

### 5. A/B‑сравнение

Сценарии:

- HEAD vs baseline (файл `Soul/CI/baselines/main.json` или последняя сборка `main`).
- Профили моделей/настроек (например, `deepseek-vA` vs `deepseek-vB`).

Файлы (новые):

- `backend/scripts/eval/ab_compare.py` — сравнение двух результатов, подсветка дельт и регрессов по порогам.

Выход:

- `Soul/CI/ci_report.md` → секция A/B с таблицей метрик и красной подсветкой регрессов.

---

#### Быстрый запуск A/B (пример)

```bash
# baseline
python -m backend.scripts.eval.run_golden_eval \
  --dataset Soul/CI/golden_set/main.jsonl \
  --output Soul/CI/results/baseline.json \
  --report Soul/CI/ci_report.md \
  --model-profile default --stateless true --max-cases 100

# candidate (после изменений)
python -m backend.scripts.eval.run_golden_eval \
  --dataset Soul/CI/golden_set/main.jsonl \
  --output Soul/CI/results/candidate.json \
  --report Soul/CI/ci_report.md \
  --model-profile default --stateless true --max-cases 100

# сравнение по порогам
python -m backend.scripts.eval.ab_compare \
  --a Soul/CI/results/baseline.json \
  --b Soul/CI/results/candidate.json \
  --max-error-rate 0.01 \
  --min-json-validity 0.98 \
  --max-p95-mult 1.2

```

### 6. Пороговые условия (CI‑gate)

Пороговые проверки (пример для MVP):

- JSON Validity: не ниже 98% (−1% от baseline максимум).
- Error Rate: ≤ 1% и не выше baseline.
- Latency p95: не выше 120% от baseline (или фиксированный потолок, например 13с для полного пайплайна).
- Fallback Rate: не выше baseline + 2%.
- Clarity/Actionability: не ниже baseline − 2% (если есть mini‑judge оценки).

При нарушении — завершение с ненулевым кодом выхода.

---

### 7. Настройки/флаги

- `eval.stateless=true` (деф.) — запрет любых побочных эффектов.
- `eval.model_profile="default"` — фиксированные параметры для воспроизводимости.
- `eval.judge.enabled=false` (деф.), `eval.judge.model_profile="judge_fast"` — лёгкий LLM‑оценщик при включении.
- `eval.seed` — фиксировать сид, где это поддерживается.

ENV (опц.): `SOUL_EVAL_STATELESS`, `SOUL_EVAL_MODEL_PROFILE`, `SOUL_EVAL_JUDGE`.

---

### 8. Интеграция в CI

Job (пример):
1) Установить зависимости (без серверов).
2) Запустить `run_golden_eval.py` по основному набору.
3) Сравнить с baseline (если ветка ≠ main) через `ab_compare.py`.
4) Сохранить отчёт `Soul/CI/ci_report.md` как артефакт.

Pre‑merge правило: если exit code ≠ 0 — блокировать merge.

---

### 9. Быстрая реализация (≤ 1 день)

1) Подготовить 100 кейсов в `Soul/CI/golden_set/` (jsonl).
2) Реализовать `run_golden_eval.py` (вызов ядра, сбор метрик, stateless, таймеры).
3) Реализовать `metrics.py` (валидность, полнота, латентность, ошибки).
4) (Опц.) `judges.py` — mini‑judge для clarity/actionability/research‑need (можно выключить по умолчанию).
5) Сгенерировать `Soul/CI/ci_report.md`.
6) Добавить runbook в `Arh/Стартовый набор для новой ветки_v2_2.md`.

---

### 10. Acceptance

- Локальный запуск скрипта без серверов отрабатывает на 100 кейсах ≤ N минут, файл отчёта создан.
- При повторном запуске на одной версии кода метрики совпадают в пределах допустимой вариативности.
- CI‑job красит PR при регрессе согласно порогам.

---

### 11. Траблшутинг

- Нестабильные метрики → отключить mini‑judge; уменьшить `max_cases` для быстрого фидбэка; фиксировать seed.
- Высокая латентность → снизить `max_output_tokens`, температуру, отключить Planner/Consistency шаги флагами.
- JSON инвалидность → включить строгие нормализации и fallback ветки, диагностировать проблемные кейсы.

---

### 12. Мировая практика (ориентиры)

- OpenAI Evals / DeepEval / Ragas — наборы кейсов с автоматической оценкой/LLM‑судами.
- G‑Eval / Pairwise A/B — LLM‑оценка качеств ответа и сравнение двух вариантов.
- CI‑ворота по метрикам — стандарт индустрии для предотвращения регрессов.

Принцип: лёгкий офлайн‑харнесс с базовыми метриками + опциональный mini‑judge; жёсткие пороги в CI.

---

### 13. Ссылки на проектные файлы/документы

- Ядро: `backend/app/services/soul_core_manager.py`
- Менеджер моделей: `backend/app/services/llm_manager.py`
- Контекст: `backend/app/services/soul_context.py`
- JSON: `backend/app/lib/json_strict.py`
- Пайплайн: `docs/SOUL_PIPELINE.md`
- Инструкции разработчику: `Arh/Стартовый набор для новой ветки_v2_2.md`

---

### 14. Метрики/SLO/алерты (для CI)

- SLO: время полного прогона ≤ 10 мин на 100 кейсах (DEV runner);

  стабильность метрик между повторами (дрожание ≤ 2% absolute)

- Алерты (CI‑gate): нарушение порогов из раздела 6 → non‑zero exit
- Метрики (агрегаты в отчёте): JSON validity, error rate, p95 latency, fallback rate, clarity/actionability (если judge включён)

---

### 15. Rollout

- Шаг 1: локальный запуск и сохранение baseline `Soul/CI/baselines/main.json`
- Шаг 2: включить job в CI для веток с префиксом `feature/*` (без gate)
- Шаг 3: включить gate для PR в `main`; отчёт — артефакт в CI

### 16. Быстрый запуск (локально)

```bash
python -m backend.scripts.eval.run_golden_eval \
  --dataset Soul/CI/golden_set/main.jsonl \
  --output Soul/CI/results/run.json \
  --report Soul/CI/ci_report.md \
  --model-profile default \
  --stateless true \
  --max-cases 100

```

Файлы:

- `backend/scripts/eval/run_golden_eval.py`
- `backend/scripts/eval/metrics.py`
- `backend/scripts/eval/utils.py`
- `backend/scripts/eval/judges.py`
- `Soul/CI/golden_set/main.jsonl` (примерный набор)
- `Soul/CI/ci_report.md` (создаётся при запуске)


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
