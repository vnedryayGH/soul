# PROJECT AI AUTOPILOT v2.28

Версия: v2.28  
Дата: 2025‑09‑27  
Статус: актуально; добавлена политика First‑Try Success для P40, интеграция с P50 инцидентами.

## Обновления

- Политика First‑Try Success (P40 §2.3.0): первичный путь Invoke‑RestMethod, fallback файл+curl, максимум 2 попытки; LLM.MIRROR обязателен. DEV.CONNECT — опционально.
- Таксономия ошибок подключения и матрица смок‑тестов (§2.3.0.1/§2.3.0.2).
- Интеграция с P50: INCIDENT.CREATE при url_malformed/timeout/auth_forbidden (severity 2–3), отчётность.

## Быстрый контур Hyperloop (Windows PowerShell)

```powershell
$H=@{ 'X-Telegram-User-ID'='468326902' }
$B=@{ commands='SESSION.CLAIM owner="468326902" branch="p40-dev" topic="planning" session="dev-001"' } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri 'https://mini.soulpulse.art/api/hyperloop/execute' -Headers $H -Method Post -ContentType 'application/json' -Body $B | ConvertTo-Json -Compress
```

Примечания: STRICT JSON, P27 Guard, без локальных JSON как источника истины; ветка обязательна.
