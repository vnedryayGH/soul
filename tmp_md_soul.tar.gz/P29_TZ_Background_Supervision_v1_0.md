# P29 — Надзор фоновых процессов и подавление всплывающих окон (v1.0)

Назначение: систематизировать запуск/наблюдение фоновых процессов на DEV/Windows окружении и минимизировать визуальные помехи (мигающие красные окна), сохраняя полную наблюдаемость и контроль качества. Документ покрывает супервизор, мониторинговые скрипты, планировщик задач и политику окон.

## Компоненты

- Супервизор: `scripts/bg_supervisor.ps1`
  - Цели:
    - Гарантировать запуск ключевых фоновых наблюдателей (см. ниже).
    - Вести лог `logs/bg_supervisor.log` и события JSONL `logs/bg_supervisor_events.jsonl` (запуски `cmd.exe`/`powershell.exe`).
    - Делать снапшот планировщика задач в `logs/bg_tasks_snapshot.txt`.
  - Фичи:
    - Детекция процессов по командной строке (Win32_Process) и по заголовкам окон.
    - Мягкий WMI‑трейс стартов консольных процессов (короткий интервал).
    - Конфиг‑флаг в `logs/bg_supervisor_state.json`: `{ "enable_guardian": true|false }` — включает/исключает запуск GUI‑«Хранителя». По умолчанию: true.

- Монитор PROD (скрытый): `scripts/monitor_prod_services.ps1`
  - Запускает скрытые SSH‑хвосты (journalctl/nginx/pgsql) и пишет в файлы:
    - `logs/app_backend_journal.log`
    - `logs/app_nginx_access.log`
    - `logs/app_nginx_error.log`
    - `logs/db_postgresql.log`
  - Локальный health‑монитор в `logs/health_monitor.log` (каждые 5 сек).

- Страж окон: `scripts/console_window_guard.ps1`
  - Политика белых списков по заголовкам/командам; все прочие `cmd.exe`/`powershell.exe` окна минимизируются, а при «залипании» >10с — закрываются.
  - Не трогает окна:
    - мониторинга (`monitor_prod_services.ps1`),
    - супервизора (`bg_supervisor.ps1`),
    - coverage‑таска (`coverage_fast.ps1`),
    - целевых окон SoulPulse Backend/Frontend.
  - Чёрный список (адресное подавление): заголовки/команды, содержащие `Exception|Traceback|Fatal error|Unhandled|Error`, закрываются немедленно, событие пишется в JSONL.
  - Правила можно переопределять файлом `logs/window_guard_rules.json` (`allowed_titles[]`, `allowed_cmds[]`, `deny_titles[]`, `deny_cmds[]`).

- Тихий циклический страж: `scripts/console_window_guard_loop.ps1`
  - Запуск в скрытом режиме каждые 15 секунд, без открытия окон.
  - Управляется супервизором (предпочтительно вместо GUI‑батника), логирует действия в `logs/bg_supervisor_events.jsonl`.

- Регистратор coverage‑таска: `Soul/scripts/register_coverage_task.ps1`
  - Регистрирует `\SoulCoverageFast` с абсолютным путём и `-WindowStyle Hidden`.
  - Использует локальный `.venv` при наличии.

## Планировщик задач (Windows)

- `\SoulBgSupervisor` — каждые 1 мин, скрыто:
  - `powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/bg_supervisor.ps1`
- `\SoulCoverageFast` — каждые 2 мин, скрыто:
  - `powershell.exe -WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File Soul/scripts/coverage_fast.ps1`
- `\ConsoleWindowGuard` — каждые 1 мин, скрыто (опционально, как резерв):
  - `powershell.exe -WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File scripts/console_window_guard.ps1`
  - Предпочтительно — постоянный цикл `console_window_guard_loop.ps1`, запущенный супервизором (обновление частоты до ~15с без Планировщика).

Все задачи создаются под `SYSTEM`, без всплывающих окон.

## Интеграция с Processor (P30)

- Супервизор фиксирует технические события в JSONL; при необходимости Processor может инжектировать инциденты на основании эвристик (через админ‑роуты) либо отдельным сборщиком.
- Очереди/шедулеры сервера остаются под управлением backend (см. `app.main: startup_event`).

## Наблюдаемость и качество

- Логи/артефакты:
  - `logs/bg_supervisor.log` — статусы таргетов, health, ошибки трассировки.
  - `logs/bg_supervisor_events.jsonl` — события стартов `cmd.exe`/`powershell.exe`, события стража окон (`window_guard: minimize|deny_close|close|kill`) с `title`, `cmd`, `age_sec`.
  - `logs/bg_tasks_snapshot.txt` — полная выгрузка `schtasks /Query /V /FO CSV` со штампом времени.
  - `logs/*.log` — каналы мониторинга PROD.

- Метрики/проксими:
  - Кол‑во новых событий `proc_start` за интервал.
  - Отсутствие видимых всплывающих окон в интерактивной сессии (ручная валидация).

## Acceptance критерии

1) В планировщике присутствуют задания `\SoulBgSupervisor`, `\SoulCoverageFast`, `\ConsoleWindowGuard` (Active/Ready, без ошибок).
2) При работе в интерактивной сессии Windows всплывающие `cmd.exe`/`powershell.exe` окна, не входящие в белый список, не мигают (минимизируются/закрываются), при этом логирование не деградирует.
3) Файлы логов присутствуют и пополняются: `bg_supervisor.log`, `bg_supervisor_events.jsonl`, журналы PROD.
4) Никаких регрессий в серверных фоновых задачах: ProcessorScheduler/Dispatcher на PROD активны, метрики `/api/admin/dispatcher/metrics` валидны.

## Эксплуатация

- Включение/исключение GUI‑Хранителя: править `logs/bg_supervisor_state.json` → `{ "enable_guardian": false }`.
- Быстрые команды:
  - Пере‑регистрация Coverage: `Soul/scripts/register_coverage_task.ps1`
  - Форс‑запуск супервизора: `schtasks /Run /TN \SoulBgSupervisor`
  - Просмотр событий: `Get-Content .\\logs\\bg_supervisor_events.jsonl -Wait`

## Риски/заметки

- Ограничения WMI‑событий: возможен `Access denied` без повышенных прав — в этом случае действует fallback‑скан процессов.
- Некоторые внешние плагины/расширения (например, crypto‑провайдеры браузера) порождают краткоживущие консоли; они подавляются стражем окон, но остаются в JSONL для аудита.

## Подтверждённые источники «морганий» (DEV/Windows)

- Редакторская интеграция Cursor:
  - `Cursor.exe → conhost.exe --headless` (инициализация терминала)
  - `Cursor.exe → powershell.exe -noexit -command shellIntegration.ps1`
  - `Cursor.exe → powershell.exe -NoProfile ... PowerShellEditorServices.psd1` (PSES)
  - Команды запускаются в headless/скрытом режиме; визуальных окон от них быть не должно. События фиксируются в `logs/proc_spawn_trace.jsonl`.

- Браузерная Native Messaging интеграция (YandexBrowser):
  - `browser.exe → cmd.exe → rtconnect.exe` (Rutoken Connect)
  - `browser.exe → cmd.exe → kontur.plugin.host.exe` (СКБ Контур)
  - Это кратковременные консольные процессы, инициируемые расширениями. Подавляются стражем окон; события отражаются в `logs/bg_supervisor_events.jsonl` как `window_guard`.

- Наши локальные процессы (контролируемые):
  - `powershell.exe → scripts/proc_spawn_poll.ps1` — запускается с `-WindowStyle Hidden`, всплывающих окон не порождает; служит только для телеметрии запусков.
  - `scripts/bg_supervisor.ps1`, `scripts/console_window_guard_loop.ps1` — скрытый режим; запись в JSONL‑логи.

Сводный отчёт за период: `logs/proc_spawn_summary.txt` — топ инициаторов, временные кластеры и примеры цепочек родительских процессов. Документ подтверждает, что «моргания» не связаны с Processor/Dispatcher/Квантами, а вызваны безопасными интеграциями редактора и браузера.


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
