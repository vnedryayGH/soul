---

## Индекс взаимных ссылок (P01–P37)

- P01/P03 — исходные данные/контекст для формализации.
- P13 Eval — проверка формализованных правил.
- P27 Signature — фиксация принятых формальных решений.
- P33 Personification — применение правил в Mini Chat (опционально).
- P35/36 — интеграция правил в процессы/DSL.

### ТЗ Soul v1.0 — Оркестратор (Дирижёр) и Планер/Инструменты (Planner → Tool‑Use → Feedback)

Дата: 2025‑09‑14
Ответственный: Архитектура Soul Core
Статус: Реализовано (MVP; без изменения схемы БД)

---

### 0. Executive summary

- В ядро добавляется управляемое «мышление как процесс» (Планер→Инструменты→Короткий фидбек) и единый фоновый оркестратор «Дирижёр» (единая кнопка: запустить/остановить цикл plan→materialize→consume).
- Цель: устойчивое качество, предсказуемые SLO и простое управление авто‑режимом генерации Квантов.
- MVP не меняет схему БД: используем существующие `flow_dispatch_queue`, `generation_request`, аудит `soul_audit_log` и ядро `SoulCoreManager.generate_quant_enhanced`.

---

### 1. Архитектура и точки интеграции

- Пайплайн ядра (4 шага) уже реализован в `backend/app/services/soul_core_manager.py: generate_quant_enhanced`.
- Добавляется этап «2.5 PlannerFeedback»: PlannerService генерирует до 3 шагов, ToolRunner исполняет доступные инструменты, формируется краткий `[PLANNER_FEEDBACK]` для промпта.
- Оркестрация «Дирижёра»: каждые 5–10 секунд выполняется цикл plan→materialize→consume. Materializer создаёт записи `generation_request` из `flow_dispatch_queue`. GenerationWorker потребляет `generation_request` и вызывает ядро.

Слои:

- UI/Админка: `ArchitectPanel` (уже есть кнопки для настроек/метрик, добавляем run/stop)
- API: `backend/app/routers/dispatcher_admin.py` (добавить `POST /run_for`, `POST /stop`)
- Services: `planner_service.py`, `tool_registry.py`, `tool_runner.py`, `conductor_service.py`, `generation_worker.py`, `input_budget_manager.py`, `backpressure.py`
- Core: `soul_core_manager.py` (интеграция [PLANNER_FEEDBACK])
- DB: таблицы `flow_dispatch_queue`, `generation_request` (миграции уже есть)

---

### 2. ТЗ‑A. Планер и Инструменты (Planner → Tool‑Use → Feedback)

#### A.1 Цели

- Дать Соулу управляемые шаги размышления и действия (аналог ReAct/Toolformer/Voyager) без утечки цепочки рассуждений в итоговый ответ.
- Повышать полезность/ясность за счёт точечных инструментов: retrieval/calc/datetime (минимальный набор).
- Вписаться в существующий Assembly Contract v1.1: добавить секцию `[PLANNER_FEEDBACK]` перед `[OUTPUT_SPEC]`.

#### A.2 Файлы и изменения

- Новые:
  - `backend/app/services/planner_service.py`
  - `backend/app/services/tool_registry.py`
  - `backend/app/services/tool_runner.py`
  - `backend/app/services/tools/retrieval_tool.py`
  - `backend/app/services/tools/calc_tool.py`
  - `backend/app/services/tools/datetime_tool.py`
- Изменить:
  - `backend/app/services/soul_core_manager.py` — вызвать этап 2.5 и передать `[PLANNER_FEEDBACK]` в сборку промпта.
  - `backend/docs/SOUL_PROMPT_BUILDING.md` — описать секцию `[PLANNER_FEEDBACK]`, лимиты и санитизацию.
  - `docs/SOUL_PIPELINE.md` — дополнить шагом Planner.
  - `backend/app/services/soul_settings_service.py` — флаги `planner.*`.

#### A.3 Контракты (серверные Pydantic‑модели)

```python
# planner_contracts.py (можно разместить рядом с planner_service.py)
from typing import Any, Dict, List, Optional, Literal
from pydantic import BaseModel

class ToolSpec(BaseModel):
    key: str
    description: str
    input_schema: Dict[str, Any]
    output_schema: Dict[str, Any]
    timeout_ms: int
    safety_policy: Literal["stateless_ok", "persistent_only"]
    enabled: bool = True

class PlanStep(BaseModel):
    tool_key: str
    arguments: Dict[str, Any]
    rationale_hidden: str
    expected_signal: str

class PlanPolicy(BaseModel):
    max_steps: int
    stop_reason: str

class PlanResult(BaseModel):
    steps: List[PlanStep] = []
    policy: PlanPolicy

class ToolExecutionRecord(BaseModel):
    trace_id: str
    tool_key: str
    input_hash: str
    status: Literal["ok", "error", "timeout"]
    duration_ms: int
    output_excerpt: str

class PlannerSignal(BaseModel):
    name: str
    value: float
    note: str

class PlannerAttachment(BaseModel):
    label: str
    text: str

class PlannerFeedback(BaseModel):
    summary: str  # ≤300 chars
    signals: List[PlannerSignal] = []
    attachments: Optional[List[PlannerAttachment]] = None

```

Пример JSON‑плана (LLM‑ответ):

```json
{
  "steps": [
    {
      "tool_key": "retrieval.search",
      "arguments": { "query": "ключевые факты по теме запроса", "top_k": 3 },
      "rationale_hidden": "уточняем фактуру",
      "expected_signal": "evidence_found"
    }
  ],
  "policy": { "max_steps": 3, "stop_reason": "enough_evidence" }
}

```

#### A.4 Набор инструментов (минимальный)

- `retrieval.search`
  - Вход: `{query:str, top_k:int<=5}`
  - Выход: `{items:[{quant_id:str, score:float, snippet:str}]}`
  - Источник: `SoulContextService`/индексы квантов; чтение‑only.
  - Safety: `stateless_ok`.
- `calc.eval`
  - Вход: `{expression:str}`
  - Выход: `{result:str}`
  - Реализация: безопасная математика (например, `numexpr`), без `eval`.
  - Safety: `stateless_ok`.
- `datetime.now`
  - Вход: `{timezone?:str}`
  - Выход: `{iso8601:str}`
  - Safety: `stateless_ok`.

Все спецификации регистрируются в `ToolRegistry`.

#### A.5 Планирование и исполнение

- `PlannerService.plan(input_text, context, goals, tools[]) -> PlanResult`
  - Модель: быстрая/дешевая через `LLMManager.get_model_for_function("planner")`.
  - Промпт (серв. шаблон): краткие инструкции, список `tool_key`/описания, пример JSON, без CoT в вывод.
  - Валидация: строгий JSON → `PlanResult`.
  - Аудит: `soul_plan_issued` {trace_id, num_steps, tools_used, stop_reason}.
- `ToolRunner.execute(plan) -> PlannerFeedback`
  - Валидировать входы по `ToolSpec.input_schema`, таймауты, нормализовать вывод по `output_schema`.
  - Собрать `PlannerFeedback` (≤700 символов в секции промпта) и события аудита.

#### A.6 Встраивание в промпт

- Порядок секций (обновить `backend/docs/SOUL_PROMPT_BUILDING.md`):
  - `CORE → ROUTER_CONTEXT → MODULES → PLANNER_FEEDBACK → OUTPUT_SPEC → NEGATIVE`
- Правила `[PLANNER_FEEDBACK]`:
  - `summary` (2–3 строки), `signals` (список индикаторов), до 2 `attachments` (≤500 символов каждый), без PII, без имен модулей.
  - Жёсткая обрезка до ~700 символов.

#### A.7 Конфигурация

- `SoulSettingsService`:
  - `planner.enabled=true`
  - `planner.max_steps=3`
  - `planner.tools_allow=["retrieval.search","calc.eval","datetime.now"]`
  - `planner.timeout_ms=1500`
  - `planner.attachments_max=2`
  - `planner.include_feedback_in_prompt=true`
- ENV: `SOUL_PLANNER_ENABLED`, `SOUL_PLANNER_TOOLS`, `SOUL_PLANNER_TIMEOUT_MS`

#### A.8 Безопасность/ошибки/наблюдаемость

- Safety: allow‑list, запрет запрещённых инструментов в stateless, PII‑санитизация attachments, скрытый `rationale_hidden`.
- Ошибки: не валидный план/таймаут → пропуск этапа 2.5; пайплайн не падает.
- Метрики: `planner.steps_per_call`, `planner.ms_total`, `tool.<key>.p95_ms`, `tool.<key>.error_rate`.

#### A.9 Тесты и приёмка

- Golden‑set: рост clarity/actionability ≥ +5%, без падения JSON‑валидности.
- Юнит: валидация `PlanResult`, таймауты, нормализация вывода, санитизация.
- Интеграция: stateless попытка `persistent_only` инструмента → deny и аудит.

---

### 3. ТЗ‑B. Единый оркестратор «Дирижёр» (one‑button Conductor)

#### B.1 Цели

- Одна кнопка запуска/паузы авто‑генерации: единый цикл каждые 5–10 секунд — plan → materialize → consume.
- Предсказуемость: SLO, backpressure, безопасные ретраи.

#### B.2 Файлы и изменения

- Новые:
  - `backend/app/services/conductor_service.py` — основной цикл/фон.
  - `backend/app/services/generation_worker.py` — потребитель `generation_request`.
  - `backend/app/services/input_budget_manager.py` — бюджет токенов/контекста.
  - `backend/app/services/backpressure.py` — адаптация частоты/конкурентности.
- Использовать существующее:
  - `backend/app/services/materializer.py` — материализация `flow_dispatch_queue → generation_request`.
- Изменить:
  - `backend/app/routers/dispatcher_admin.py` — добавить `POST /api/admin/dispatcher/run_for?minutes=15`, `POST /api/admin/dispatcher/stop`.
  - `docs/SOUL_PIPELINE.md` — дописать раздел «Conductor loop».

#### B.3 Контракты/статусы БД

- `generation_request` (раздел 7.9 в `docs/DATABASE_STRUCTURE_v8_0_2.md`):
  - Статусы: `queued | processing | succeeded | failed | cancelled`.
  - Индексы для выборки: `(status, priority_bucket, dgw_value desc nulls last, created_at asc)`.
- Аудит: `soul_audit_log` — события `conductor_*` и `generation_request_*` с `trace_id`.

#### B.4 Цикл Conductor (каждый тик)

1) plan — опционально (если включён быстропланировщик), иначе пропустить.
2) materialize — `MaterializerService.run_once(db)`.
3) consume — `GenerationWorker.consume_batch(db, N)`.
4) backpressure.update(metrics) — адаптация интервала/конкурентности.
5) сон до следующего тика или выход по `run_until/stop_event`.

Single‑instance: при старте — `pg_try_advisory_lock(912345678)`. Нет lock → 409/ошибка «already running».

#### B.5 Потребитель GenerationWorker

- Выборка (атомарно):

  ```sql
  select id from generation_request
  where status = 'queued'
  order by priority_bucket desc, dgw_value desc nulls last, created_at asc
  limit :L for update skip locked;

  ```

- Пометить выбранные `processing`, `attempts=attempts+1` в транзакции.
- По каждой записи:
  - Сформировать `input_text` из `prompt_hint` (или иного источника, если указан).
  - Вызвать `SoulCoreManager.generate_quant_enhanced(db, user_id=None, input_text=..., trace_id=...)`.
  - Запись результатов (ядро само сохраняет `messages`/`quants`/`quant_connections`).
  - Привязать к цели, если указан `goal_id`.
  - Обновить статус `succeeded/failed`, `processed_at`, и аудит событий.
- Retry: `max_attempts=3` (MVP — после 3 ошибок → `failed`).

#### B.6 Input Budget Manager

- Интерфейс: `make_budget(user_tier: Optional[str]) -> {max_input_tokens:int, recent_ratio:float, batch_max_quants:int}`.
- Использование: перед вызовом ядра задать лимиты для контекста/параметров.

#### B.7 Backpressure

- Сигналы: `error_rate`, `p95_ms_soulcore`, `%fallback`.
- Политика MVP: при `error_rate>10%` или `p95>15s` — увеличить интервал тика (до 30s), снизить конкурентность до 1; при стабильно хороших метриках — вернуть базовые.

#### B.8 Эндпоинты управления

- `POST /api/admin/dispatcher/run_for?minutes=15`
  - RBAC: `soul.admin`; если уже запущен — 409.
  - Ответ: `{status:"started", run_until:"ISO"}`.
- `POST /api/admin/dispatcher/stop`
  - Ответ: `{status:"stopping"|"stopped"}`.
- Метрики/очередь уже реализованы: `/metrics`, `/queue`, `/settings`, `/plan_once`, `/materialize_once` — оставить.

PowerShell (Invoke‑RestMethod) примеры:

```powershell
$H = @{ Authorization = "Bearer <TOKEN>"; 'Content-Type' = 'application/json' }
Invoke-RestMethod -Uri 'https://<host>/api/admin/dispatcher/run_for?minutes=15' -Headers $H -Method Post
Invoke-RestMethod -Uri 'https://<host>/api/admin/dispatcher/metrics' -Headers $H -Method Get
Invoke-RestMethod -Uri 'https://<host>/api/admin/dispatcher/stop' -Headers $H -Method Post

```

#### B.9 Конфигурация

- `SoulSettingsService`/`conductor_settings`:
  - `dispatcher.enabled` (bool)
  - `dispatcher.poll_interval_sec` (int, default 5)
  - `dispatcher.max_concurrency` (int, default 1)
  - `dispatcher.batch_max_quants` (int)
  - `dispatcher.max_attempts` (int, default 3)
- ENV: `DISPATCHER_ENABLED`, `DISPATCHER_POLL_INTERVAL`, `DISPATCHER_MAX_CONCURRENCY`, `DISPATCHER_BATCH_MAX_QUANTS`.

#### B.10 Метрики/аудит

- Метрики `/metrics` дополнить:
  - `planned_per_min`, `materialized_per_min`, `picked`, `succeeded`, `failed`, `p95_ms_soulcore`, `fallback_share`, `curr_poll_interval`, `curr_concurrency`, `since`, `run_until`.
- Аудит в `soul_audit_log`:
  - `conductor_cycle_start|end`, `generation_request_picked`, `generation_request_succeeded|failed` (+ `trace_id`, `req_id`, `latency_ms`).

#### B.11 Приёмка

- За 1 минуту тестового запуска: materialized>0, consumed>0, в БД появляются новые `quants`, статусы `succeeded|failed`.
- Повторный запуск при активном цикле возвращает 409.
- Метрики и аудит содержат связку `request_id → trace_id → quant_id`.

---

### 4. Быстрая реализация (ускоритель)

#### 4.1 Пошаговый чек‑лист (MVP ≤ 1 день)

1) Создать сервисы: `planner_service.py`, `tool_registry.py`, `tool_runner.py`, базовые инструменты (retrieval/calc/datetime).
2) Включить этап 2.5 в `soul_core_manager.py` и секцию `[PLANNER_FEEDBACK]` в сборке промпта.
3) Создать `conductor_service.py` (loop с advisory lock) и `generation_worker.py` (consume_batch с SKIP LOCKED).
4) Добавить эндпоинты `run_for/stop` в `dispatcher_admin.py`.
5) Метрики/аудит: дописать счётчики и события.
6) Обновить `SOUL_PROMPT_BUILDING.md` и `SOUL_PIPELINE.md`.

#### 4.2 Шаблоны (контуры кода) для ускорения

```python
# conductor_service.py — контур
class ConductorService:
    def __init__(self, settings, audit):
        self._task = None
        self._stop = False
        self._run_until = None
        self._stats = {}
    async def start(self, minutes: int): ...  # advisory lock + create_task(self._loop)
    async def stop(self): ...                 # soft stop
    async def _loop(self): ...                # while not stop/run_until: await self._tick()
    async def _tick(self): ...                # materialize → consume → backpressure

```

```python
# generation_worker.py — контур
class GenerationWorker:
    async def consume_batch(self, db, batch_size: int, policy) -> dict:
        # select ... for update skip locked
        # mark processing, attempts += 1
        # call SoulCoreManager.generate_quant_enhanced(...)
        # update status, processed_at, audit
        return {"picked": n, "succeeded": s, "failed": f}

```

```python
# tool_registry.py — регистрация мини‑набора
REGISTRY = [
  ToolSpec(key="retrieval.search", description="Поиск по памяти/квантам", input_schema={"query":"str","top_k":"int<=5"}, output_schema={"items":"list"}, timeout_ms=1000, safety_policy="stateless_ok"),
  ToolSpec(key="calc.eval", description="Безопасная арифметика", input_schema={"expression":"str"}, output_schema={"result":"str"}, timeout_ms=500, safety_policy="stateless_ok"),
  ToolSpec(key="datetime.now", description="Текущее время", input_schema={"timezone":"str?"}, output_schema={"iso8601":"str"}, timeout_ms=200, safety_policy="stateless_ok"),
]

```

#### 4.3 Быстрая проверка (PowerShell)

```powershell
$H = @{ Authorization = "Bearer <TOKEN>"; 'Content-Type' = 'application/json' }
Invoke-RestMethod -Uri 'https://<host>/api/admin/dispatcher/run_for?minutes=1' -Headers $H -Method Post
Start-Sleep -Seconds 10
Invoke-RestMethod -Uri 'https://<host>/api/admin/dispatcher/metrics' -Headers $H -Method Get
Invoke-RestMethod -Uri 'https://<host>/api/admin/dispatcher/stop' -Headers $H -Method Post

```

---

### 5. Политики качества и безопасность

- Planner: строгий JSON план, allow‑list инструментов, скрытый `rationale_hidden`.
- Orchestrator: SKIP LOCKED, max_attempts=3, backpressure, advisory lock.
- NEGATIVE/санитизация: без PII в `[PLANNER_FEEDBACK]` и логах.
- Stateless режим: исполнять только `stateless_ok` инструменты.

---

### 6. Acceptance (общий)

- Включение Planner увеличивает clarity/actionability ≥ +5% на golden‑кейсах.
- Кнопка `run_for` запускает фоновый цикл; за 1 минуту появляются новые `quants`; метрики/аудит полны.
- Повторный запуск при активном цикле возвращает 409; `stop` останавливает ≤3 секунды.

---

### 7. Ссылки на существующий код/документы

- Пайплайн ядра: `backend/app/services/soul_core_manager.py: generate_quant_enhanced`
- Материализация: `backend/app/services/materializer.py`
- Админ‑роутер: `backend/app/routers/dispatcher_admin.py` (добавить run/stop)
- UI: `frontend/src/pages/ArchitectPanel.tsx` (добавить кнопки run/stop при необходимости)
- Таблицы/миграции: `backend/alembic/versions/20250910_000020_dispatcher_v7.py`, `...000021_dispatcher_base_tables.py`, `...000024_goals_views_and_genreq_cols.py`
- Структура БД: `docs/DATABASE_STRUCTURE_v8_0_2.md` (7.9 generation_request)
- Сборка промпта: `backend/docs/SOUL_PROMPT_BUILDING.md` (дополнить [PLANNER_FEEDBACK])
- Пайплайн: `docs/SOUL_PIPELINE.md` (дополнить Planner/Conductor)

---

### 8. Дополнить для максимально быстрой практичной реализации

- Сразу заложить три feature‑флага в `SoulSettingsService`: `planner.enabled`, `dispatcher.enabled`, `dispatcher.max_concurrency` — позволит безопасно включать/выключать без релиза.
- В окружении PROD заранее выставить лимиты LLM через `LLMManager` для функций `planner` и `soul_core` (таймауты/ретраи/модели).
- Добавить простейший текстовый «Trace Viewer» в админке (дерево шагов по последнему ответу) — упростит отладку без чтения логов.
- Предварительно ограничить размер `[PLANNER_FEEDBACK]` на уровне сервера (усечение), чтобы исключить регресс по длине промпта.
- Подготовить тестовые записи `flow_dispatch_queue` + `generation_request` (скрипт сидирования) для моментальной валидации конвейера.

---

### 9. Отметка принятия (2025-09-20)

- Планер/инструменты интегрированы: секция `[PLANNER_FEEDBACK]` формируется за флагом; безопасность stateless соблюдена (allow‑list, таймауты, санитизация).
- Оркестратор/диспетчер работают: `/api/admin/dispatcher/run_for`/`metrics`/`stop` — ок; метрики возвращаются; фоновый цикл запускается и останавливается.

---

### 9. Расширение: SLO, backpressure, бюджеты

- SLO ядра (ориентиры DEV):
  - `p95_ms_soulcore_single ≤ 12000`, `p95_ms_soulcore_batch ≤ 15000`
  - Успех конвейера (succeeded/(succeeded+failed)) ≥ 95%
  - Fallback share ≤ 5%
- Backpressure (динамика):
  - Интервал тика: 5s ⇄ 30s в зависимости от `error_rate`/`p95_ms_soulcore`
  - `max_concurrency`: 1 ⇄ 3 (при хороших метриках и запасе CPU/LLM квот)
- Budget Manager:
  - Вход: user_tier|policy → `{max_input_tokens, recent_ratio, batch_max_quants}`
  - Алгоритм: при перегрузе снижать `batch_max_quants` и `recent_ratio`, при простое — повышать в пределах лимита

---

### 10. Ошибки, идемпотентность и восстановление

- Классы ошибок:
  - Transient (сетевые/429/5xx LLM) → ретрай (экспоненциальная пауза, макс 2)
  - Persistent (валидация JSON, schema guard) → `failed` без ретраев, аудит с причиной
  - External (БД/доступ) → мягкая деградация, пауза цикла
- Идемпотентность:
  - `FOR UPDATE SKIP LOCKED` + отметка `processing` в транзакции — исключить двойную обработку
  - Повторная обработка одной записи (после сбоя) — распознаётся по `attempts`
- Восстановление после падения:
  - При старте Conductor — проверять зависшие `processing` старше `T_recover` и переводить назад в `queued`
  - Advisory lock гарантирует один активный цикл

---

### 11. Тест‑план и нагрузочные испытания

- Unit:
  - Планер: валидация `PlanResult`, обрезка `[PLANNER_FEEDBACK]`, deny запрещённых инструментов
  - Worker: корректная выборка/обновление статусов, лимиты попыток
- Integration:
  - Фоновый цикл 1 мин: появление `quants`, статусы, трассы с `trace_id`
  - Планер включён → прирост clarity/actionability ≥ +5% на golden‑кейсах
- Load:
  - 1k записей в `generation_request`, `batch=10`, `max_concurrency=2` — p95 цикла стабильный, нет starvation
- Chaos:
  - Симуляция ошибок LLM/БД — корректные ретраи/отказы, отсутствие залипаний `processing`

---

### 12. Rollout и Observability

- Флаги: `planner.enabled`, `dispatcher.enabled`, `dispatcher.max_concurrency`
- Постепенное включение: DEV → STAGE → PROD (5% → 25% → 100%)
- Дашборд: графики `planned/materialized/consumed/succeeded/failed`, p95, fallback share, concurrency, interval
- Алерты: `error_rate>10%`, `p95_ms_soulcore>15s`, рост `failed` подряд > N

---

### 13. Сценарии/кейсы (пример)

- Case A (быстрый контент): малый `input_text`, policy recent, batch=3 → за 1 тик consumed=3, succeeded=3
- Case B (тяжёлый ответ): большой контекст → backpressure увеличивает интервал, batch=1, p95 в норме
- Case C (LLM 429): ретрай 2 раза, затем `failed`, цикл продолжает работу


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
