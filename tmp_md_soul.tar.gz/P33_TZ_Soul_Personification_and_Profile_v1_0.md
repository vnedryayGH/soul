# P33 — ТЗ: Персонификация и Профиль пользователя

Интеграции (актуализация 2025‑10‑10):

- `docs/DOCS_INVENTORY_SOUL.md`, `docs/DOCS_INVENTORY_DOCS.md` — инвентари.
- `tmp_p_series_plan.json` — план P‑серии.
- `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` — мастер‑реестр.
- `Soul/P23_TZ_UI_Spec_v2_1.md`, `Soul/P20_TZ_Telegram_Bot_Orchestrator_and_E2E_Dataflow_v1_1.md`, `Soul/P27_TZ_Signature_and_Data_Lineage_v1_0.md`, `Soul/P30_TZ_Soul_Processor_v2_0.md`, `Soul/P37_TZ_Prompts_Technical_Descriptions_v1_0.md` — ключевые интеграции.

Версия: v1.0 (draft→ready)
Статус: Консолидация docs/PERSONIFICATION_TECHNICAL_SPEC_v2_17.md и docs/CHAT_PERSONALIZATION_SPEC_v1_0.md без регресса объёма/смысла

## 0) Цель и область (актуализировано под Mini App)

- Персонализация диалогов базового пользователя Mini App (не Architect mode): выбор и применение личности (промпта) к user_dialog.
- Автоматическое извлечение, хранение и безопасное использование персональных данных для персонализации промптов.
- Минимизация PII, соблюдение приватности, контроль включаемых блоков. Исключено: режим Соул/Архитектора, рождение квантов и извлечение смыслов.

## 0.1) Быстрый гид по реализации (для LLM инженера)

- Шаг 1. API MiniChat:
  - Реализовать/проверить `POST /api/chat/send` (headers: `X-Telegram-User-ID`) и `GET /api/chat/threads/{id}/messages`.
  - Санитизация на записи и на чтении (перечень маркеров в §19 и §6).
- Шаг 2. История 30/70:
  - Функция `build_context_30_70(thread_id, limit_tokens, recent_ratio=0.3)` → возвращает список сниппетов (role,text,trunc_tokens).
  - Эвристики усечения (§56), бюджет токенов по модели (§23/§31).
- Шаг 3. Персона/сборка system‑prompt:
  - Получить `active_prompt_key` из `user_prompt_settings`; загрузить `content_json` из БД (P37). Сформировать system‑prompt по §4/§3.2.
- Шаг 4. Вызов LLM (stateless):
  - `LLMClient.send(messages, provider, model, db=None)`; таймауты/ретраи (§23). Провайдер по окружению (P14). Без БД при db=None.
- Шаг 5. Санитайзер и ответ:
  - Удалить тех‑маркеры (§19), сгенерировать `reply_prefixed_html` (имя персоны), записать сообщение; сохранить метрики.
- Шаг 6. Keywords:
  - `extract_keywords(text, lang)` → top‑N (§54); сохранить в `keyword_extractions` c `relevance` и `lang`.
- Шаг 7. Напоминания/§svc:
  - Распарсить §svc; кандидаты дат нормализовать; поставить события в Процессор (P30).
- Шаг 8. Тест‑смоки:
  - Прогнать раздел §16 и §28; проверить истории без маркеров; webhook set/get.

## 1) Архитектура

- Клиент (Mini App): страницы «Чат», «Выбор личности», «Профиль». Persona JSON формируется локально с учётом настроек пользователя.
- Backend‑сервисы: `PersonificationService` (форматирование и валидация Persona), `KeywordService` (извлечение ключевых слов), `ReminderService` (интеграция). `ChatService` — точка включения персонального контекста.
- Данные: `user_profiles` (расширенно), `keyword_extractions`, `reminders`, настройки `user_prompt_settings` (активная личность, флаги).

## 2) Модель данных (совместимо с v2.17)

- user_profiles: поля base + 15 новых (nickname, age, profession, interests[], personality_traits[], relationship_status, family_info{}, goals[], preferences{}, important_dates{}, is_familiar, first_meeting_date, last_interaction_date, familiarity_level) + системные счётчики.
- keyword_extractions(message_id, keyword, relevance, type, normalized_date, created_at).
- reminders(user_id, title, date, priority, source_message_id, ai_prompt, …).

## 3) Persona JSON (клиент)

- metaVersion, user{firstName, age, gender, locale, timezone}, dialogStyle{tone, verbosity, emoji, language}, addons[], emotions{periodDays, top[], trend{}, lastPeak{emotion,date}}, upcoming[{title,daysLeft}].
- Ограничения: не передавать email/телефон/дату рождения; addons — только ключи.

Источники промптов (каталог backend/prompts): описания и шаблоны личностей (`*.json`), технические описания (`TECH_DESCRIPTIONS_v1.md`, `API_*.md`).

## 3.2) Сборочный промпт (template)

Используется как `messages[0]` при формировании запроса в LLM; наполняется из активной персоны и профиля.

```text
[MINI_CHAT]
Persona: {{persona.name}} (key={{persona.key}}, locale={{persona.locale}})
Style: tone={{dialogStyle.tone}}, verbosity={{dialogStyle.verbosity}}, emoji={{dialogStyle.emoji}}, language={{dialogStyle.language}}
Rules:
- reply concisely; no JSON; no technical markers; no diagnostics in visible text
- be supportive; respect privacy; avoid medical/financial advice
Addons: {{addons|comma}}
Upcoming: {{upcoming|compact}}
ContextHint: {{flow_context_summary|<=300chars}}


```

## 3.1) Окно «Выбор личности» (Mini App)

- Список доступных персон (из backend/prompts/*.json), отображение имени/краткого описания.
- Выбор фиксирует `prompt_key` (активная личность) в настройках пользователя (`user_prompt_settings`) через API.
- Правила:
  - По умолчанию назначается базовая личность (fallback), если активная не выбрана.
  - Переключение сохраняется немедленно и применяется к следующему сообщению в чате.
  - Админ‑персоны/служебные промпты скрыты для базового пользователя.

## 4) Композиция system‑prompt (Mini App)

- Состав: имя персоны, стиль ответа (dialogStyle), допустимые аддоны, краткая контекстная сводка (без техмаркеров), ближайшие события/намеки на напоминания.
- Использование: `messages[0].role="system"` в LLM‑вызове; добавляются правила: краткость, отсутствие служебных блоков, отсутствие диагностики в видимом тексте.

### 4.1) Источники персонализации (явно)

- Настройки пользователя (`user_prompt_settings`): `active_prompt_key`, флаги (`deep_memory_only`, язык/тон при наличии).
- Профиль (`user_profiles`): поля из §2 (interests[], goals[], important_dates{}, personality_traits[] и др.) — проходят фильтрацию приватности и сжимаются до краткого резюме для prompt.
- Календарь/напоминания (`reminders`): ближайшие события и активные задачи в окне 7–14 дней; используются только заголовки/дни‑до, без PII; подаются как подсказки «Upcoming».
- История ключевых слов (`keyword_extractions`): топ‑n последних релевантных ключей для короткого контекстного намёка (без служебных маркеров).

## 5) API (минимум)

- GET/POST `/api/miniapp/profile/dev` — профиль (dev режим); формат соответствует спецификации Persona/Profile из docs.
- Приватность: только владелец, PII‑редакция логов, запрещено отправлять Telegram токены.

## 5.1) Telegram Mini App — процесс общения (user_dialog)

- Вход: Telegram user_id, thread_id, текст пользователя, активный `prompt_key`.
- Шаги: `svc.keywords.extract.user` → `svc.history.build.30_70` → `svc.persona.apply` → `svc.llm_client.send/recv` → `svc.chat.reply_render` → `svc.keywords.extract.ai` → `svc.keywords.save`.
- Ограничения: stateless LLM (db=None), провайдер по настройке (Gigachat на PROD), без хардкода; Delivery Guard исключает техмаркеры в видимом тексте.
- Санитария выдачи: при записи/чтении истории очищать `§error{…}`, `§sense{…}`, `§qtags[…]`, `§qew[…]`, `[АНАЛИЗ]…[/АНАЛИЗ]`, хвост `§svc{…}`.
- История: политика 30/70 (см. §3 и P03), recent≈30%/deep≈70% с отсечением по лимиту токенов.

### 5.3) Режимы в Telegram‑боте: //Соул ↔ //Бот (персоналия и префикс)

Правила переключения и применения персоны в Telegram‑канале:

- //Соул:
  - `current_chat_mode=architect_chat`, `branch_label='architect_main'`.
  - Персона «Соул» назначается принудительно: при входе в ветку и при каждом сообщении ветки обновлять `thread.persona_prompt_id` на последний активный промпт «Соул» (по `Prompt.key|name ilike '%soul|соул%'`).
  - Префикс ответа всегда «Соул: …» (если `reply_prefixed_html` отсутствует — формировать строку с префиксом «Соул: …» без HTML‑тегов).

- //Бот (возврат в обычный режим):
  - `current_chat_mode=user_dialog`.
  - Персона берётся из `UserSettings.active_prompt_key`; при необходимости обновлять `thread.persona_prompt_id` согласно активной персоне пользователя.
  - Префикс отвечает имени выбранной персоны (не базовому шаблону).

- Обновление треда:
  - При повторном использовании существующего треда после смены режима обязательно синхронизировать `thread.persona_prompt_id` (исключить «залежалую» персону и префикс).
  - `reply_prefixed_html` не кэшируется между режимами; формируется для каждой персоны отдельно.

- Acceptance:
  - После `//Соул` ответы содержат префикс «Соул: …»; после `//Бот` — имя активной пользовательской персоны.
  - Смена режима не приводит к использованию прежней персоны/префикса в новом режиме.

#### 5.3.1) Форматирование и доставка через Бот‑Оркестратор (P20)

- Префикс формируется централизованно в Оркестраторе: в //Соул — «Соул», в //Бот — `Persona.name`. Строка «AI» как имя не допускается.
- Санитизация: видимый текст и префикс проходят HTML‑санитайзер Оркестратора (parse_mode=HTML; экранирование &,<,>, кавычек; удаление служебных маркеров).
- Голос: при входящем голосе — озвучка ответа с caption; в user_dialog — опционально озвучка по политике.
- Acceptance: ни один ответ не вызывает parse‑ошибок Telegram; префиксы корректны в обоих режимах.

### 5.2) Извлечение напоминаний/задач/дат и интеграция с Процессором

- Обнаружение в тексте: при `svc.chat.reply_render` применить парсер сигналов (естественные фразы вида «завтра в 10», «в пятницу», «через 2 часа», «напомни…») → нормализовать в ISO и сохранить как кандидаты.
- §svc как канал задач: если ИИ предлагает микро‑шаги — §svc парсится и кладётся в очередь Процессора (P30) как события `processor.events` с типом `task.suggested`.
- Напоминания: при наличии валидных дат/времени создаются записи `reminders` со статусом `scheduled`; Процессор отвечает за доставку (уведомление через чат‑бота в нужный момент).
- Уведомления: Процессор формирует исходящие сообщения и отправляет через чат‑бот API (не напрямую из LLM‑ветки), соблюдая Delivery Guard и RBAC (P32).
- Управление: редактирование/отмена напоминаний — через команды Mini App; все изменения проходят через Процессор.

## 6) Backend контракты

- PersonificationService: `get_or_create_user_profile(db,user,telegram_data?)`, `analyze_message_for_personal_info(text,profile)`, `update_profile_with_extracted_info(db,profile,extracted)`; `check_familiarity(profile)`, `format_for_ai_prompt(profile)`.
- UserPromptSettings API: установить/получить `active_prompt_key`, флаги (`deep_memory_only`).
- Интеграция в ChatService (user_dialog):
  - Подключить активную личность в system‑prompt.
  - Сформировать контекст истории 30/70 (ref: P03 §8.1) — recent≈30%/deep≈70% от лимита токенов.
  - Извлечь и сохранить ключевые слова из запроса и ответа.
  - Исключить рождение квантов/смыслов; обеспечить санитайзер видимого текста.

### 6.1) Контракты сервисов (точно)

- HistoryService:
  - `build_context_30_70(thread_id: UUID, user_id: int, limit_tokens: int, recent_ratio: float=0.3) -> List[HistoryItem]`
  - `HistoryItem = {"role":"user|assistant","text":"str","trunc_tokens":int}`
- PersonaService:
  - `get_active_persona(user_id:int) -> PersonaRecord{key, content_json}`
  - `compose_system_prompt(persona, profile_summary, upcoming, keywords_hint) -> str`
- LLMClient:
  - `send(messages:list, provider:str, model:str, db=None, timeout:Seconds=60) -> {ok:bool, reply:str, tokens_in:int, tokens_out:int, provider, model}`
- KeywordService:
  - `extract_keywords(text:str, lang:str, top_n:int=10, min_rel:float=0.15) -> List[{keyword,relevance,lang,normalized}]`
- ReminderBridge (Processor):
  - `enqueue_task_suggestions(user_id, tasks:list)` из §svc
  - `schedule_reminders(user_id, items:list[{title,when,tz}])`

## 7) Процессная модель (Hyperloop, Mini Chat)

Мини‑чат без смыслов и квантов — шаги:

1) `svc.keywords.extract.user` → 2) `svc.history.build.30_70` → 3) `svc.persona.apply` → 4) `svc.llm_client.send` → 5) `svc.llm_client.recv` → 6) `svc.chat.reply_render` → 7) `svc.keywords.extract.ai` → 8) `svc.keywords.save`.

DSL варианты:

```text
MINICHAT.REPLY input_text="..." persona="<key>" include_context=true recent_ratio=0.3 WITH TRACE
# или
CORE.MINICHAT.RUN input_text="..." persona="<key>" recent_ratio=0.3 WITH TRACE


```

### 7.1) Обязательная подпись шагов (минимум)

- `svc.keywords.extract.user`
- `svc.history.build.30_70`
- `svc.persona.apply`
- `svc.llm_client.send` / `svc.llm_client.recv`
- `svc.chat.reply_render`
- `svc.keywords.extract.ai`
- `svc.keywords.save`

## 7) Приватность и безопасность

- Минимизировать PII; BODY‑логи выключены в release; Persona JSON формируется на клиенте.
- Пользователь может отключить блоки; Telegram ID защищён от изменения через API.

## 8) Производительность (таргеты)

- Анализ сообщения: 8–12с (LLM), обновление профиля <100мс, загрузка профиля <50мс, форматирование <10мс.

## 9) Тест‑план

- Unit: методы PersonificationService.
- Integration: API профиля, сохранение `active_prompt_key`, формирование system‑prompt (без PII).
- Integration (ChatService user_dialog): формирование контекста 30/70; извлечение/сохранение ключевых слов; санитизация ответа.
- E2E: Mini App «Выбор личности» → сообщение → сохранение истории/ключевых слов → отсутствие техмаркеров в UI/истории.

## 10) Мониторинг

- Логи создания/обновления профиля; метрики: точность извлечения, использование полей, latency LLM.

## 11) Миграции БД (эскиз)

- ALTER user_profiles ADD IF NOT EXISTS … (все новые поля); CREATE TABLE keyword_extractions; CREATE TABLE reminders.

## 12) Acceptance

- Окно «Выбор личности» корректно устанавливает `active_prompt_key`, недоступны админ‑персоны.
- В user_dialog подключается активная личность, контекст строится 30/70, видимый текст очищен.
- Ключевые слова (user/ai) сохраняются и доступны для ретривала; PII не течёт; тесты проходят.

---

## Приложение A — Поля БД `prompts` (перенос из prompts/TECH_DESCRIPTIONS_v1.md)

- id, key, locale, group_key, name, description, file_path, icon_emoji, icon_color, category, features(JSON), target_audience, activation_triggers(JSON), is_base, can_work_alone, kind, memory_algorithm(JSON), is_active, sort_order, content_json(JSONB — источник истины для личности).

## Приложение B — Единый блок §svc (API v2)

- Формат строки в конце ответа: `§svc{"tasks":[{"t":"Короткое действие","when":"естественный триггер","tags":["tag"]}]}`
- Правила: 1–2 задачи; нормализация на бэкенде; допустимые теги (focus, reflect, write, read, plan, micro, calm, brainstorm, learn, review).

## Приложение C — Каталог персон (сводка)

- Базовая личность `prompt-4` (SoulPulse): поддерживающий стиль; §svc по необходимости.
- Креативные: `zhvan_prompt_clean_v3_3` (Дядя Миша), `Zhvanetsky_Persona_v4_1` — ирония/афористика, мини‑монологи; Local Resonance; §svc мягкие шаги.
- Духовные/этика: `Kabbalah_prompt-3_v16` (цитатность, локаторы), `Ved_prompt_Masterpiece_v4_3` (этические контуры, ритуалы); §svc когнитивные шаги.
- Режимы: `flow_prompt-3_v4` (микро‑шаги, поток), `LT_Prompt_Masterpiece_v1_9` (Language Trainer) — учебные задания; §svc учебные шаги.
- Модули: `female_resonance` — дополнительный слой поддержки, не самостоятельный.

## Приложение D — UI рекомендации (Mini App)

- Отображать: name, description, category/kind, icon; признаки `can_work_alone`.
- В деталях: features, target_audience, activation_triggers; техполя (key, locale, updated_at).
- Копирайтинг без пафоса; пример формата ответа; подсказки «Скажи: …» для активации.

## Приложение E — Загрузка в БД (чек‑лист)

- Убедиться в валидности `content_json` (включая §svc‑политику, history bundle, алгоритмы памяти).
- Поля ограничений (длины/списки) соблюдены; `key` уникален; `is_active` включён только для протестированных персон.

## 13) Ссылки/происхождение

- Консолидация: `docs/PERSONIFICATION_TECHNICAL_SPEC_v2_17.md`, `docs/CHAT_PERSONALIZATION_SPEC_v1_0.md`.

---

## Раздел: Мини‑чат (user_dialog) — перенесено из P37 v1.0

Версия: v1.0 (draft)
Статус: новое ТЗ; основано на P03 (RouterContext) и P33 (Personification), без смыслов/квантов

## 0) Цель и область

- Описать процесс формирования ответа ИИ в контексте мини‑чата (user_dialog) для базового пользователя Mini App.
- Поддержать выбор активной личности, контекст 30/70 (recent/deep), извлечение и сохранение ключевых слов до/после ответа.
- Исключить рождение Квантов и извлечение Смыслов; обеспечить чистоту видимого текста (санитайзер).

Вне области: архитектурный режим Architect (//соул), рождение квантов, STRICT JSON, расширенные цепочки P35.

## 1) Инварианты

- Без смыслов и квантов: никаких вызовов модулей `svc.soul.*` и парсинга STRICT JSON.
- Персона (личность) берётся из активного промпта пользователя (см. P33) и подключается в system‑prompt.
- История контекста формируется политикой 30/70: recent≈30%, deep≈70% от лимита контекста.
- До LLM извлекаются ключевые слова из запроса; после LLM — из ответа; оба набора сохраняются в БД под пользователем/сообщением.
- Видимый ответ очищается от служебных маркеров; тех‑диагностика не попадает в текст.
- Stateless LLM (db=None) при batch‑вызовах; секреты через настройки/ENV; без доступа к БД из LLM‑клиента при db=None.

## 2) Поток (процессная модель)

Шаги (function_id):

1. `svc.keywords.extract.user` — извлечь ключевые слова из пользовательского ввода; сохранить черновик (не блокирующе).
2. `svc.history.build.30_70` — построить контекст из истории: recent/deep согласно политике; учесть активную персону.
3. `svc.persona.apply` — сформировать system‑prompt для выбранной личности (P33), добавить правила мини‑чата (краткость, без техмаркеров).
4. `svc.llm_client.send` — отправить запрос в LLM (stateless для мини‑чата), учесть лимиты модели.
5. `svc.llm_client.recv` — получить ответ; латентность и токены — в метаданные.
6. `svc.chat.reply_render` — подготовить видимый ответ; применить санитайзер видимого текста.
7. `svc.keywords.extract.ai` — извлечь ключевые слова из ответа ИИ.
8. `svc.keywords.save` — сохранить ключевые слова пользователя/ИИ, связать с сообщениями/тредом.

Диагностика/подпись (опционально): записывать шаги в `signature_steps` для трассировки (без обязательной P27‑цепочки архитектора).

## 3) Построение контекста 30/70 (P03 ref.)

- Получить полную историю треда (ограничение N сообщений/по токенам).
- Разделить: recent — K последних сообщений (эвристика: 12); deep — остальная история (или ретривал по ключевым словам пользователя).
- Сформировать итоговый набор в пропорции recent_ratio=0.3 (настраиваемо), затем отсечь по лимиту токенов модели.
- При наличии флага пользователя `deep_memory_only` — сместить баланс к deep; при пустом deep — увеличивать recent.

## 4) Персона (P33 ref.)

- Активный промпт пользователя определяет имя личности и доп. параметры.
- System‑prompt композер добавляет: название персоны, стиль ответа, язык, запрет техмаркеров.

## 5) LLM вызов

- Формат сообщений: system (persona+правила), user (input_text), optional context (history items, компактные сниппеты).
- Ограничения: max_output_tokens ≤ лимит модели; temperature дефолт 0.7 (override настройками).
- Провайдер по умолчанию — через настройки (Gigachat на PROD), без хардкода.

## 6) Пост‑обработка

- Санитайзер видимого текста: удалить `§error{…}`, `§sense{…}`, `§qtags[…]`, `§qew[…]`, `[АНАЛИЗ]…[/АНАЛИЗ]`, хвост `§svc{…}`; нормализовать перевод строк.
- Сохранить ответ ИИ в БД; к метаданным прикрепить измерения (tokens_in/out, latency_ms, provider, model).
- Извлечь ключевые слова из ответа, сохранить в таблицу `keyword_extractions` с привязкой к `message_id` и `user_id`.

## 7) DSL/Hyperloop

Вариант A (расширенный MINICHAT):

```text
MINICHAT.REPLY input_text="..." persona="<name>" include_context=true recent_ratio=0.3 WITH TRACE


```
Обязательные шаги:

`svc.keywords.extract.user, svc.history.build.30_70, svc.persona.apply, svc.llm_client.send, svc.llm_client.recv, svc.chat.reply_render, svc.keywords.extract.ai, svc.keywords.save`

Вариант B (новая команда):

```text
CORE.MINICHAT.RUN input_text="..." persona="<name>" recent_ratio=0.3 WITH TRACE


```

## 8) Данные и таблицы

- `messages` — как сейчас; добавляем метадату (provider, model, tokens, signature опц.).
- `keyword_extractions(message_id, keyword, relevance, type, created_at, user_id)` — обязательная запись для user/ai сообщений.
- `user_prompt_settings` — хранит активный `prompt_key` и флаги (`deep_memory_only`).

## 9) Безопасность/санитария

- Видимый текст очищается перед записью/выдачей; техданные — только в логах/мета.
- Stateless: LLM‑клиент не открывает БД‑сессию при `db=None`.

## 10) Наблюдаемость

- Метрики: `minichat.latency_ms`, `minichat.tokens_in/out`, `minichat.errors_total`.
- Трассировка: `signature_steps` c перечисленными шагами.

## 11) Приёмка

- При запросе user_dialog: подключается активная персона, формируется контекст 30/70, сохраняются ключевые слова (user/ai), ответ очищен.
- Нет служебных маркеров в выдаче (вкл. историю в Mini App).
- Gigachat (PROD) и fallback провайдеры — зелёные тесты `/api/admin/soul/llm/test`.

## 12) Риски и отказы

- Пустая deep‑история → recent_ratio адаптировать к доступному контексту.
- Ошибки LLM → безопасный ответ без техдеталей, запись инцидента, без заглушек в видимом тексте.

## 13) Связанные документы

- P03_TZ_Soul_RouterContext_v1_0.md — гибридный ретривал 30/70.
- P33_TZ_Soul_Personification_and_Profile_v1_0.md — персонализация/личности.
- P23_TZ_Soul_UI_Rebuild_v1_0.md — UI Mini App (санитария/без техмаркеров).

## 14) Пакет обновлений промптов (2025‑09‑04)

### Что нового

- Интеграция задач/напоминаний через служебную строку §svc{...} во всех ключевых персонах и режимах.
- Протокол использования истории и «нити разговора» (keyword‑threads) для контекстной последовательности.
- Политика видимости метрик: технические показатели скрыты; в речь выводятся метафорические/качественные формулировки.

### Новые версии (полноразмерные, самодостаточные копии в корне)

- `prompt-4.json` — базовая личность: §svc и протокол истории (full/self‑contained).
- `flow_prompt-3_v4.json` — режим Поток: §svc и протокол истории (full/self‑contained).
- `LT_Prompt_Masterpiece_v1_9.json` — упрощённые метрики, буфер усталости, чеклист ответа, §svc, история (full/self‑contained).
- `FR_Ranevskaya_Persona_v1_4.json` — §svc, история/нить, dev‑tips (full/self‑contained).
- `Kabbalah_prompt-3_v16.json` — §svc (только когнитивные шаги), история/нить; запреты сохранены (full/self‑contained).
- `Klee_prompt_Masterpiece_v6_2.json` — §svc после соматики/рефлексии, протокол истории (full/self‑contained).
- `Ved_prompt_Masterpiece_v4_3.json` — §svc как элементы Ягьи, протокол истории (full/self‑contained).
- `zhvan_prompt_clean_v3_3.json` — задачи/напоминания, история по ключам, dev‑notes (full/self‑contained).
- `Zhvanetsky_Persona_v4_1.json` — §svc, история/нить, пример строки (full/self‑contained).
- `API_250829_v2.md` — спецификация §svc, пакет истории, ключевые слова, даты/ремайндеры.

### Пример служебной строки

§svc{"tasks":[{"t":"Записать мини‑монолог про очередь к окну","when":"до пятницы","tags":["humor","homework"]}]}

### Заметки для внедрения

- Подключайте версии из корня (full/self‑contained). Оригиналы в подпапках оставлены без изменений.
- Парсите последнюю строку, начинающуюся с §svc{, как JSON; отсутствие строки значит, что подсказок нет.

### Встраивание в Ядро Соул (добавление)

- Mini‑chat использует §svc только как служебный канал задач; Delivery Guard скрывает строку из видимого текста.
- Для истории используется смешение 30/70 (см. P03); персоналии поддерживают `history_bundle` в `content_json`.
- Проверка на отсутствие регресса: контент раздела соответствует исходному документу и расширяет P33 без противоречий.

---

## 15) Ссылки на процессные ТЗ (парсинг/календарь/напоминания)

- `P30_TZ_Soul_Processor_v1_0.md` — событийная петля; источники событий (чат/календарь/напоминания); Delivery Guard; очереди и исполнение.
- `P35_TZ_Soul_Processes_v2_1_UNIFIED.md` — триггеры Процессора, инициаторы (включая `reminders`), контексты и шаги процессов.
- `P36_TZ_Hyperloop_DSL_v1_1.md` — команды для инжекции/обработки событий (`PROCESSOR.EVENT.INJECT kind=reminder`, `PROCESSOR.PROCESS_ONCE`).
- `P20_TZ_Soul_TelegramBots_Platform_v1_0.md` — платформа ботов, API календаря/задач/напоминаний (`POST /api/reminders`, realtime WS); пользовательские сценарии (для всех пользователей).
- `P34_TZ_Soul_External_Chat_Proxy_and_Mobile_Integration_v1_0.md` — канал доставки сообщений в чат‑бот (прокси/интеграция мобильного клиента).
- `P37_TZ_Prompts_Technical_Descriptions_v1_0.md` — §svc‑политика и каталоги персон (канал микро‑шагов).

Применимость: указанные процессы и API предназначены для всех пользователей Mini App (не только для Архитектора/Соула); доступ и действия контролируются RBAC (P32).

---

## 16) Быстрые проверки (после деплоя)

- Health/DB/LLM:
  - `GET /api/health` — 200
  - `GET /api/admin/soul/db/check` — 200
  - `GET /api/admin/soul/llm/test?provider=gigachat&prompt=ping` — `{ok:true}`
- Telegram webhook:
  - `POST https://api.telegram.org/bot<BOT_TOKEN>/setWebhook url=https://mini.soulpulse.art/webhook/telegram drop_pending_updates=true`
  - `GET https://api.telegram.org/bot<BOT_TOKEN>/getWebhookInfo` — `url` установлен, `pending_update_count=0`
- MiniChat:
  - `POST /api/chat/send` с заголовком `X-Telegram-User-ID` — ответ без техмаркеров
  - `GET /api/chat/threads/{id}/messages` — история без `§error/§sense/§qtags/§qew/[АНАЛИЗ]/§svc`

## 17) RBAC/политики (P32 ref.)

- Роли: базовый пользователь может создавать/отменять собственные напоминания/задачи; админ — управляет глобальными политиками.
- Ограничения: «тихие часы», rate‑limit уведомлений, запрет на чужие объекты.

## 18) Наблюдаемость

- Метрики: `minichat.latency_ms`, `minichat.tokens_in/out`, `minichat.errors_total`, `reminders.sent_total`.
- Алерты: рост ошибок > p95, отсутствие webhook, пустые ответы LLM.
- Трассы: `signature_steps` по шагам §7; выборка последних трасс инспектором.

## 19) Санитайзер «последней мили»

- Маркеры к удалению: `§error{…}`, `§sense{…}`, `§qtags[…]`, `§qew[…]`, `[АНАЛИЗ]…[/АНАЛИЗ]`, хвост `§svc{…}`.
- Негативные тесты: отправка сообщений с искусственно вставленными маркерами → пользователь видит чистый текст.

## 20) Маппинг §svc → Процессор

- `§svc.tasks[*]` → событие `task.suggested` (payload: text, when?, tags)
- Наличие нормализованной даты/времени → `reminder.schedule` (payload: title, when, tz)
- Dedup: ключ `(user_id,title,when)` с окном ±1 мин.

## 21) Pre‑commit hooks

- Автогенерация индексов ENV/API/Prompts на каждый коммит; проверка ссылок на номерные ТЗ; запрет на техмаркеры в видимых строках тестов.

## 22) Регистры и структура

- Обновить `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8*` — добавить ссылки на P33 и P37, актуализировать статусы.
- Обновить `PROJECT_STRUCTURE` — раздел «Prompts/Personas» (ссылка на `backend/prompts`) и «MiniChat user_dialog (P33)».

---

## 23) Политика LLM провайдеров и фолбэков (P14 ref.)

- Приоритет: Gigachat → OpenAI/DeepSeek (по окружению) → локальный профиль (если включён).
- Таймауты: send 30s, recv 60s; ретраи: 1 попытка с backoff 1.5x.
- Переключение профиля: при `ok=false` и кодах сетевых ошибок → следующий доступный провайдер без изменения бизнес‑логики; stateless.

## 24) Локализация и таймзоны

- Язык ответа = язык профиля или `dialogStyle.language`.
- Нормализация дат/времени с учётом `profile.timezone`; фразы «сегодня/завтра/в пятницу/через N …» приводятся к ISO.

## 25) Безопасность webhook (Telegram)

- Проверка IP Telegram, валидация токена, ограничение методов, idempotency‑ключ по update_id.
- Логи без BODY в release; rate‑limit.

## 26) RBAC‑матрица (P32 ref.)

- Базовый пользователь: create/update/cancel своих напоминаний и задач; confirm своих событий.
- Запрет операций над чужими объектами; админ — управление политиками и глобальными настройками.

## 27) UI‑флоу Mini App (напоминания)

- Подтверждение созданного напоминания; редактирование даты/текста; отмена; статусы (scheduled/sent/cancelled).

## 28) Тест‑матрица

- Комбинации: персонa × провайдер LLM × язык. Негатив: пустая deep‑история; невалидные даты; провайдер timeout.

## 29) DDL (фиксация)

- `keyword_extractions(message_id uuid, user_id bigint, keyword text, relevance float, type text, created_at timestamptz, PRIMARY KEY(message_id, keyword, type))`.
- `reminders(id uuid, user_id bigint, title text, when timestamptz, tz text, status text, source_message_id uuid, created_at timestamptz, updated_at timestamptz)` + индексы по (user_id, when), (status, when).

## 30) Retention/Privacy

- История и ключевые слова: retention 365 дней (по умолчанию); удаление по запросу пользователя (право на забвение).
- Уведомления/напоминания: логи доставки 90 дней; §svc не хранится в видимом тексте.

## 31) Метрики и алерты (пороговые)

- Метрики: `minichat.latency_ms` (p95<12s), `minichat.errors_total` (rate<2%), `reminders.sent_total`, `webhook.errors_total`.
- Алерты: webhook down, ошибки >2% за 5мин, latency p95>15s, отсутствует доставка напоминаний 10мин.

## 32) Pre‑commit (команды)

- Hook путь: `.git/hooks/pre-commit`.
- Команды: генерация индексов ENV/API/Prompts; линт ссылок на номерные ТЗ; запрет видимых техмаркеров.

---

## 33) План трассируемости (R→T)

- Требования R1..Rk → тесты T1..Tm → метрики/алерты A1..An; матрица ведётся в `docs/QA/TRACING_MATRIX.md`.

## 34) Контракты API (MiniChat)

- `POST /api/chat/send` — body: `{ thread_id?, input_text, persona_key? }`; headers: `X-Telegram-User-ID`.
  - 200: `{ id, reply, provider, model, tokens_in, tokens_out }`
  - 4xx: `{ error, code }` (видимые сообщения без техмаркеров)
- `GET /api/chat/threads/{id}/messages` — 200: `[{ id, role, text_visible, created_at }]` (санитизировано).

## 35) Политика ошибок

- Классы: input_error, provider_error, timeout, rate_limited.
- Фолбэк: безопасный короткий ответ без техдеталей; ретраи согласно §23.

## 36) Логи и аудит

- Уровни: info/warn/error; без PII; маскирование токенов.
- Audit‑трассы: ключевые шаги §7; хранение 90 дней.

## 37) Лимиты и защита

- Rate‑limit по user_id/thread_id; анти‑спам для webhook; idempotency по update_id.

## 38) Управление секретами

- Источники: `.env.prod`/ENV; ротация по расписанию; health‑probe проверяет наличие обязательных ключей.

## 39) Версионирование промптов

- Семантические версии; обратная совместимость контента; откат через переключение `prompt_key` на предыдущую версию.

## 40) Миграции/совместимость

- One‑time job очистки исторических техмаркеров в БД; миграции схем без простоя (ADD COLUMN/CREATE INDEX CONCURRENTLY).

## 41) Экспорт/удаление данных (GDPR)

- Экспорт: профиль/ключевые слова/напоминания по запросу; удаление — безвозвратно, с audit‑записью.

## 42) UX Mini App (тексты/состояния)

- Кнопки: «Подтвердить напоминание», «Изменить дату», «Отменить», пустые состояния: «Пока ничего нет — создадим напоминание?».

## 43) Capacity/SLO

- Цели: p95<12s, err<2%, 100 rps на API MiniChat на DEV; деградация: отключение deep‑части истории и повышение recent_ratio.

## 44) DR/Rollback

- Фичефлаги для инкрементов; откат без простоя: выключение флагов, перезапуск сервиса, сохранение состояния очередей.

## 45) Governance промптов

- Процесс ревью/одобрения: чек‑лист качества, smoke‑прогон, включение в каталог только после зелёных тестов.

---

## 46) Примеры API и сборки

- Пример `POST /api/chat/send` (ru, persona=prompt-4): body `{ input_text:"Напомни завтра в 10 позвонить маме" }` → 200 `{ reply:"...", provider:"gigachat", tokens_in:..., tokens_out:... }`
- Пример `GET /api/chat/threads/{id}/messages` — массив сообщений, поле `text_visible` без техмаркеров.
- Пример system‑prompt: persona name+style + «Upcoming: …» + keywords‑hint; перед отправкой — без техмаркеров.

## 47) Парсинг дат (локали)

- ru: «сегодня/завтра/послезавтра», «в пятницу», «через 2 часа/3 дня», «в обед/вечером» (нормализация к 13:00/19:00 по профилю).
- en: today/tomorrow/next Friday, in 2 hours/3 days; DST/границы суток: «через 24 часа» уходит ровно на +24h, не на следующий день 00:00.

## 48) Коды ошибок и лимиты

- Ошибки: `input_error`, `provider_error`, `timeout`, `rate_limit`; тексты пользовательские без техдеталей.
- Квоты: сообщений/сутки/пользователь; создание напоминаний/задач — суточный лимит; при превышении — мягкая эскалация.
- Безопасность ввода: максимальные размеры, фильтр управляющих символов; §svc JSON — строгая валидация и падение блока при ошибке (без отображения).

## 49) Совместимость персон и UI

- Персоны: семантические версии; Mini App совместим с N‑1; откат на предыдущий `prompt_key`.
- UI тексты: «Подтвердить», «Изменить дату», «Отменить», пустые состояния: «Пока пусто — создать напоминание?», ошибки: «Не удалось сохранить, попробуем ещё раз».

## 50) Эталонные тест‑данные

- Фразы: «завтра в 10», «в пятницу в обед», «через 2 часа», «в конце месяца», «через 1 неделю» — ожидаемые ISO с таймзоной профиля.
- Негатив: «во вторник 25:61», «вчера в 10» (прошлое) — отклонение/уточнение.

## 51) Post‑deploy runbook

- Проверить Health/DB/LLM, webhook set/get, MiniChat send/history, метрики ошибок/латентности, отсутствие техмаркеров в истории, доставку напоминаний.
- Дашборды и алерты включены; фичефлаги в нужном состоянии; логи без PII.

## 52) Реестры (финальная отметка)

- В `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY_v8*` и `PROJECT_STRUCTURE` — отметить обновление P33 (дата/версия), добавить ссылки на `P37` и `backend/prompts`.

---

## 53) Форматы HTML/markup

- Допустимые теги в ответах/истории: `<b> <i> <u> <a href>`; запрещены `<script> <style> <iframe>`.
- Политика экранирования: все пользовательские вставки HTML экранируются; разрешён только whitelisted‑рендер сервером.
- Ограничение стилей: inline‑стили запрещены, кроме безопасных `style="text-decoration:underline"` при необходимости.

## 54) Keywords контракт

- Поля: `keyword: str`, `relevance: float [0..1]`, `lang: str (ISO)`, `normalized: str`.
- Нормализация: лемматизация/нижний регистр; стоп‑слова отбрасываются; язык ключей = язык сообщения.
- Лимиты: top‑N по relevance (по умолчанию N=10), минимум relevance=0.15.

## 55) Каналы уведомлений

- Текущий канал: Telegram чат‑бот.
- Будущие: push/email как фича‑флаги; выбор канала политикой пользователя/организации.

## 56) Токенизация/лимиты

- Бюджеты: recent≈30%, deep≈70%; жёсткие лимиты по модели (max_context_tokens); усечение deep в первую очередь.
- Эвристики: агрессивное усечение цитат/URL; конденсация длинных сообщений в сниппеты.

## 57) Доступность/UX

- Screen‑readers: альтернативные тексты для ссылок/кнопок; понятные статусы.
- Контраст: соответствие WCAG AA для основных цветов Mini App.
- Плохая сеть: отображать состояния «повторяем…/безопасный офлайн», сохранять действие для повторной отправки.

## 58) i18n

- Хранилище строк: отдельный ресурс Mini App (`/i18n/{locale}.json`).
- Добавление локалей: PR с ресурсами, ревью лингвиста, smoke UI.

## 59) Правовая часть

- Ссылка на общую политику проекта по хранению/удалению персональных данных.
- Процедуры удаления реализованы в разделе §30; экспорт данных — §41.

---

## 60) Индекс взаимных ссылок (P01–P37)

- P01 MeaningExtraction — N/A для Mini Chat (без смыслов); применимо в Architect.
- P02 MetaLoop — N/A.
- P03 RouterContext — используется (30/70 история).
- P04 Hypothesis A/B — N/A.
- P05 Och — N/A.
- P06 SelfConsistency — N/A.
- P07 DesiredAction — N/A (stateless: desired_action=[]).
- P08 Privacy — применяется (ретеншн/удаление; без PII в логах).
- P09 Security — применяется (webhook/IP/валидация/лимиты).
- P10 SchemaGuard — N/A напрямую; используется косвенно в API проверках.
- P11 Provenance — опционально (трассы/аудит без PII).
- P12 TraceViewer — опционально (просмотр `signature_steps`).
- P13 Eval — опционально (качество персон/UI сценариев).
- P14 MultiProviderRouting — применяется (политика LLM/фолбэки).
- P15 Multilingual — применяется (локализация/i18n).
- P16 MemoryCompaction — N/A.
- P17 Reminders Search — применяется (поиск при уведомлениях, если включён).
- P18 Voice ASR — N/A (в текущем объёме Mini App).
- P19 Voice TTS — N/A.
- P20 TelegramBots Platform — применяется (канал доставки и API календаря/задач/напоминаний).
- P21 Health/Monitoring — применяется (метрики/алерты).
- P22 API Alignment — опционально (согласование схем MiniChat API).
- P23 UI Spec — применяется (Mini App UI/санитария/статусы).
- P24 Integrated Tests — применяется (смоки/интеграция MiniChat).
- P25 Skills Routes — опционально (инициаторы от напоминаний/практик).
- P26 Calendar Transport — применяется (транспорт напоминаний/событий).
- P27 Signature/Lineage — опционально (подпись шагов MiniChat).
- P28 FeatureFlags — применяется (флаги поведения/санитарии/диагностики).
- P29 Quality Registry — опционально (гейты качества персон/ответов).
- P30 Processor — применяется (очередь, доставка, §svc→события).
- P31 Multisensory Quants — N/A.
- P32 RBAC/Subscriptions — применяется (права на напоминания/задачи).
- P33 Personification — этот документ.
- P34 External Chat Proxy/Mobile — применяется (канал и мобильная интеграция).
- P35 Processes Unified — применяется (инициаторы/процессные шаги Процессора).
- P36 Hyperloop DSL — применяется (MINICHAT.REPLY, команды инспектора/процессора).
- P37 Prompts Technical — применяется (§svc/каталог персон).


## Мировые аналоги и практики
- TODO: пример 1
- TODO: пример 2
- TODO: пример 3
- TODO: пример 4
- TODO: пример 5
- TODO: пример 6
