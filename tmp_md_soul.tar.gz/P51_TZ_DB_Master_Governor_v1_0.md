### P51 — ТЗ: DB Master/Governor и продвинутая архитектура БД для Soul

Версия: v1.0  
Статус: Draft → To Implement  
Связанные ТЗ и спецификации: P27 (Delivery Guard), P30/P36 (Processor/Sequences/Rate Limits), P38/P46 (Neuro‑Integrity/Sleep), P40 (Planning), P41 (Rate Limits), P44 (RBAC/Access), P45 (Ingest/Quants), P48R (RS), P50 (Incident‑first).

---

#### 1. Цель и задачи

- Устранить «бутылочное горлышко» единой БД, обеспечить предсказуемую латентность и отказоустойчивость при пиках.
- Развести данные по доменам с централизованным управлением доступами, приоритетами и соединениями (DB Master/Governor).
- Интегрировать in‑memory слой Соула (рабочая модель/граф) с периодической синхронизацией через «Сон».
- Сохранить совместимость и не допустить регрессов ядра Soul.

Нефункциональные цели (целевые бюджеты p95):
- service (настройки/секреты/RBAC): ≤ 20 ms; core OLTP (кванты/связи): ≤ 50 ms; analytics: ≤ 200 ms.
- error_rate доступа к БД ≤ 1% (окно 5 мин), отсутствие коллапса по соединениям.

---

#### 2. Текущий контекст и опорные точки реализации

- Пулы SQLAlchemy: `backend/app/db.py` (async, pool_size/max_overflow/timeout) и `backend/app/background_dispatcher.py` (sync).  
- Сервис настроек/секретов: `SoulSettingsService` (`soul_settings`) и `SecretsService` (`soul_secrets`, pgcrypto).  
- «Сон»/обслуживание: `SleepService` (refresh MV и аудит), `system_api.py` sleep endpoint.  
- Инфраструктурные DSL/админка: `HyperloopEngine`, админ‑роуты `/api/admin/soul/*`, guard/canonical, incidents.

Примечание: по результатам диагностики перегрузка возникала из‑за исчерпания соединений и отсутствия `application_name`; часть соединений «idle in transaction».

---

#### 3. Целевая архитектура данных (разделение по БД)

- service_db (маленькая, быстрая, на APP backend server):
  - Таблицы: `soul_settings`, `soul_secrets` (pgcrypto), `roles`, `permissions`, `rbac_user_roles`, `feature_flags`, `system_audit`, `incidents`.
  - Приоритет: самый высокий; строгие таймауты.

- soul_db (ядро Соула, отдельный сервер):
  - Таблицы: `quants`, `quant_links`, `quant_rank_mv`, `messages`, векторные индексы (`pgvector`), служебные индексы для контекста.
  - Поддержка «Сна» (обновление MV/весов/связей) и in‑memory слоя.

- analytics_db (отчёты/витрины, опционально — отдельный инстанс):
  - Материализованные витрины, агрегации, off‑line отчёты и авто‑отчёты топ‑запросов.
  - Низкий приоритет, допускается деградация/отложенное выполнение.

- logs_db (опционально):
  - Трассы/инциденты/сырые метрики, если не покрыты Prometheus/Grafana.

Сетевое соединение между серверами (высокоскоростное):
- Защищённый приватный линк (WireGuard wg0) между APP (service_db) и DB (soul_db, analytics_db), восстановить и верифицировать throughput/latency.  
- Тесты связности/пропускной (ICMP, iperf3, MTU discovery), контроль маршрутизации (policy‑routing при необходимости).

---

#### 4. DB Master/Governor — дизайн

Функции:
- Классификация запросов на классы нагрузки: `service`, `core_oltp`, `analytics`, `maintenance` (sleep/refresh).
- Приоритизация и caps: семафоры/токен‑бакеты поверх пула/pgbouncer с AIMD‑адаптацией на основе p95/err_rate/queue_len.
- Circuit‑breaker и backpressure: изоляция деградирующих классов, отказ/отложение низкоприоритетных при перегрузке.
- Управление соединениями: caps на класс и суммарные лимиты << `max_connections` Postgres.
- Таймаут‑политики: `statement_timeout`, `idle_in_transaction_session_timeout`, `lock_timeout` — на класс.
- «Киллер» подвисших транзакций: детектор `idle in transaction`/lock waits с безопасным `pg_terminate_backend` по политикам.
- Аннотация `application_name` и контекстных тегов (трассировка/метрики/инциденты).

Интерфейсы:
- Admin API: `/api/admin/db-gov/*` (status/limits/cap.set/timeout.set/kill.idle_in_tx).
- Hyperloop DSL: `DB.GOV.CAP`, `DB.GOV.TIMEOUT`, `DB.GOV.KILL IDLE_IN_TX`, `DB.GOV.MODE` (auto/manual), `DB.GOV.RESET`.
- Метрики Prometheus: `db_gov_requests_total{class,status}`, `db_gov_concurrency_cap{class}`, `db_gov_queue_len{class}`, `db_gov_p95_ms{class}`, `db_gov_err_rate`.

In‑memory слой Соула:
- Оперативная модель (граф/кванты/веса) в памяти процесса; снапшоты и восстановление.
- Во время «Сна» — commit в soul_db (MV/веса/связи), затем prewarm и delta‑sync.
- Единый writer, версионирование состояния, идемпотентные апдейты.

LLM‑управление потоками:
- LLM‑gate (по аналогии rs.autotune.llm_gate): при плановом увеличении caps Governor запрашивает LLM‑оценку риска/контекста; применяет инкремент только при `{ allow: true }`.
- Авто‑отчёты (NLP) по топ‑запросам и аномалиям (генерация человекочитаемого отчёта с рекомендациями).

---

#### 4.1 Политика реализации (Rust, без заглушек, интеграционные тесты)

- Rust must‑use: все низкоуровневые и высоконагруженные функции реализуются на Rust без компромиссов по функциональности. Включая, но не ограничиваясь:
  - тики/петли Governor (AIMD, семафоры/очереди, быстрая телеметрия p95/err_rate/queue_len),
  - сбор/агрегацию pg‑метрик (pg_stat_statements/pg_locks/pg_stat_activity) и быструю сериализацию в JSON,
  - тяжёлые граф‑операции/ретривер/индексные обходы (см. P48R),
  - сетевые I/O‑участки (PgBouncer health/админ, WireGuard проверки) и OS‑уровневые пробы.
  Интеграция через стабильные JSON‑контракты `svc.rs.proxy` (P48R); контракты версионируются, PII не логируется.

- Без заглушек/MVP: сразу поставляется полнофункциональная версия. Feature‑flags только для раскатки/отката, но не для «заглушек». Любой fallback на Python сохраняет полный функционал (возможна лишь деградация производительности) и использует те же публичные контракты.

- Интеграционные тесты — обязательны и блокируют раскатку: E2E‑проверки Governor API/DSL, маршрутизации multi‑engine, PgBouncer transaction pooling, чтений/записей в service_db/soul_db/analytics_db, операций `kill idle in tx`, а также путей RS‑акторов (при доступности), без поднятия серверов тестами (см. §11).

---

#### 5. Параметры Postgres и пулы

Postgres (per‑DB):
- `max_connections` разумный (100–200); `superuser_reserved_connections` ≥ 3.
- Включить: `pg_stat_statements`, `pgcrypto`, `pgvector` (при необходимости), `pg_prewarm` (опц.).
- Таймауты по умолчанию: service: `statement_timeout=10s`, core: `30s`, analytics: `120s`; `idle_in_transaction_session_timeout=30–60s`; `lock_timeout=2–5s`.

Пулы/прокси:
- PgBouncer (transaction pooling) перед каждой БД; DSN для приложений — только через `SoulSettingsService` (без хардкодов).  
- Application pools (SQLAlchemy/asyncpg): caps ниже `max_connections`, pre_ping, recycle.

---

#### 6. Настройки/секреты (через БД)

Ключи `soul_settings` (примеры):
- `db.service.dsn`, `db.soul.dsn`, `db.analytics.dsn` — DSN через `soul_secrets`.
- `db.gov.cap.service|core|analytics|maint` (int), `db.gov.mode` (auto|manual), `db.gov.p95_budget_ms.*`, `db.gov.err_rate_max`.
- `db.gov.timeout.statement_ms.*`, `db.gov.timeout.idle_in_tx_ms.*`, `db.gov.timeout.lock_ms.*`.
- `db.gov.kill.idle_in_tx_older_s`, `db.gov.kill.enabled`.
- `net.priv.app_addr`, `net.priv.db_addr`, `net.priv.ping_count`, `net.priv.ping_timeout_ms`.

Секреты `soul_secrets` (pgcrypto):
- `db.service.secret_dsn`, `db.soul.secret_dsn`, `db.analytics.secret_dsn`.

---

#### 7. API/DSL (черновая спецификация)

Admin API (RBAC: `soul.admin`):
- `GET /api/admin/db-gov/status` → caps/очереди/p95/err_rate, режим.
- `POST /api/admin/db-gov/cap/set { class, value }`
- `POST /api/admin/db-gov/timeout/set { class, key, value_ms }`
- `POST /api/admin/db-gov/kill/idle_in_tx { older_than_s }`
- `GET  /api/admin/db/locks` (обзор блокировок), `GET /api/admin/db/activity` (активные/idle‑in‑tx).

Hyperloop DSL:
- `DB.GOV.CAP class=<service|core|analytics|maint> value=<int>`
- `DB.GOV.TIMEOUT key=<statement|idle_in_tx|lock> class=<...> value_ms=<int>`
- `DB.GOV.KILL IDLE_IN_TX older_than_s=<int>`
- `DB.GOV.MODE value=<auto|manual>`

Все операции фиксируются P27‑подписью.

---

#### 8. Пошаговая реализация (миграции/код/инфра)

Шаг 0. Планирование (P40):
- Завести план‑таск, связать со скиллами/квантами, включить инспекторы `planning.enforce`.

Шаг 1. Инфраструктура:
- Развернуть PgBouncer на APP (для service_db) и на DB (для soul_db/analytics_db).  
- Включить `pg_stat_statements`, настроить `shared_preload_libraries`; перезапуск по maintenance окну.
- Восстановить WireGuard wg0 (APP↔DB), прогнать `iperf3`, настроить MTU/маршрутизацию.

Шаг 2. Миграции (Alembic):
- Создать `service_db`: перенести `soul_settings`, `soul_secrets`, RBAC и аудит.  
- Создать `soul_db`: перенести `quants`, `quant_links`, `quant_rank_mv`, индексы; добавить `pgvector` (если нужно).  
- Создать `analytics_db`: схемы под витрины/отчёты.  
- Временная совместимость: при необходимости `postgres_fdw` для чтений между БД (только read).

Детализация миграций (alembic):
- service_db:
  - Создать схемы и перенести таблицы: `soul_settings`, `soul_secrets` (ensure pgcrypto), `roles`, `permissions`, `rbac_user_roles`, `feature_flags`, `system_audit`, `incidents`.
  - Инициализировать ключи `db.*.dsn`, `db.gov.*`, `net.priv.*`; добавить мастер‑ключ `secrets.master_key`.
- soul_db:
  - Перенести `quants`, `quant_links`; материализованное `quant_rank_mv`.
  - Включить `pgvector` при наличии векторного поиска; создать индексы (ivfflat/hnsw) с параметрами под объём/латентность.
  - Партиционирование: по времени (`created_at`) или по пользователю (`user_id`) — RANGE/LIST; родительская таблица, дочерние партиции, индексы на партициях; процедуры attach/detach при ротации.
- analytics_db:
  - Создать витрины и таблицы для автоотчётов топ‑запросов: `pgstat_report` (ts, window, data jsonb), `lock_report`, `idle_in_tx_report`.
  - Настроить FDW (опц.) для чтения агрегатов из soul_db без нагрузки на primary.

Read replicas:
- Развернуть streaming replication для soul_db; `hot_standby=on`, `primary_conninfo`, мониторинг lag.
- В приложении: маршрутизировать идемпотентные чтения на реплики; fallback на primary при lag > threshold.

PgBouncer (transaction):
- Конфигурация пулов раздельно для service_db/soul_db/analytics_db; caps с запасом относительно Postgres `max_connections`.
- health‑пробы и авто‑рестарт под systemd; логи в journald; метрики через exporter.

Шаг 3. Кодовые изменения:
- Ввести мульти‑движки: `engine_service`, `engine_soul`, `engine_analytics`; маршрутизация сессий через фасад DB Master.
- Включить `application_name` в connect_args; проставлять класс нагрузки в контекст.
- DB Master (middleware/facade): семафоры на классы, очередь, backpressure, таймауты, “киллер”, метрики.
- Эндпоинты/DSL из раздела 7; интеграция с `SoulSettingsService`/`SecretsService`.

Шаг 4. «Сон» и in‑memory:
- Добавить prewarm/delta‑sync; снапшоты состояния модели; единый writer.
- Governor: класс `maintenance` с мягким throttle по CPU/DB load.

Шаг 5. Analytics/реплики:
- Развернуть read‑replicas для soul_db (streaming); роутинг чтений (только идемпотентные) на реплики.
- В analytics_db — материализованные представления и авто‑отчёты топ‑запросов (см. §10).

Шаг 6. Наблюдаемость/алерты:
- Экспорт метрик Governor + pg метрик (pg_exporter/интеграция).  
- Grafana: дашборды caps/queue/p95/err_rate/locks; алерты (см. §9).

Шаг 7. Feature‑flags и раскатка:
- Флаги включения Governor/analytics/replicas; canary‑rollout с поэтапным повышением caps.

---

#### 9. Алерты/Инциденты (P50)

- `DBConnExhaustion` (High): «Слоты соединений на исходе». Действия: снизить caps analytics/maint; проверить PgBouncer; таймауты; при повторе — scale out.
- `DBIdleInTxSpike` (Medium): «Рост idle in transaction». Действия: terminate > N s; включить idle_in_tx timeout.
- `DBP95BudgetBreach` (Medium): «Бюджет p95 нарушен». Действия: Governor снижает caps; анализ топ‑запросов.
- `DBLockContention` (Medium): «Рост lock waits». Действия: диагностика блокировок; пересмотр транзакций/индексов.

Все события через INCIDENT.* DSL с таймлайном; Severity 1–2 — Two‑Keys.

---

#### 10. Автоотчёты и аналитика топ‑запросов

- Включить `pg_stat_statements`; собрать авто‑отчёты (cron/фоновая задача) с топ‑N по total_time/calls/старам и регрессиям.  
- LLM‑саммаризация: краткий отчёт с рекомендациями индексов/переписей запросов (без PII).  
- Сохранение отчётов в analytics_db; предпросмотр через админ‑UI.

Хранимые формы отчётов:
- `pgstat_report(ts timestamptz, window text, data jsonb)` — top‑N pg_stat_statements (total_time/calls/mean_time), fingerprints/normalized SQL, регрессии планов.
- `lock_report(ts timestamptz, data jsonb)` — активные блокировки и граф ожиданий.
- `idle_in_tx_report(ts timestamptz, count int, offenders jsonb)` — длительные `idle in transaction` с деталями.

Планировщик:
- Периодичность 5–10 минут (адаптивно); при высокой нагрузке — только агрегаты, полные отчёты реже.
- Алерты прикрепляют свежий отчёт соответствующего типа.

---

#### 11. Тест‑план (всесторонний)

Функциональные:
- Маршрутизация по БД (service/soul/analytics) — корректные записи/чтения; RBAC/секреты из service_db.
- Эндпоинты/DSL Governor: caps/timeout/kill — корректная работа и P27‑подписи.

Нагрузочные:
- RPS профили (OLTP/analytics смешанные), провалы сети (wg0), задержки; валидация p95 и err_rate.
- Исчерпание соединений: Governor не допускает коллапс, backpressure/отказ только для низких приоритетов.

Отказоустойчивость:
- Падение analytics_db — сервис продолжает работать (degrade); падение реплики — fallback на primary (только чтение).
- wireguard flap — деградация analytics/maint; service/core остаются в бюджете.

Регрессии/совместимость:
- Все существующие сценарии ядра (Health/DB/Batch API, Sleep) — без регресса.  
- Инспекторы: `INSPECTOR.RUN_ALL` зелёный, `planning.enforce` без нарушений.

Технологические:
- Партиционирование горячих таблиц (по времени/пользователю): корректность маршрутизации, планы запросов, VACUUM/ANALYZE, Attach/Detach.
- pgvector: корректность индексов/опций (ivfflat/hnsw, параметры); p95 поиска.

Метрики/обзор:
- Проверка экспорта метрик Governor, pg_exporter; дашборды и алерты — корректные.

Принципы тестирования (соответствие проекту):
- Тесты не поднимают серверы/каналы; используют реальные TG‑ID; статусы/смоки через Hyperloop CLI и админ‑эндпоинты.

Матрица тестов (сценарии):
- Исчерпание соединений: пул приложений > caps → ожидание/отказ только низких классов; service/core в бюджете.
- Долгие транзакции: `idle in transaction` > N s → авто‑килл в рамках политики; отсутствие каскада ошибок.
- Репликационный лаг: lag ↑ → чтения на primary; алерт lag_threshold.
- Сетевые аномалии wg0: jitter/loss → деградация analytics/maint; budgets для service/core соблюдены.
- Топ‑запросы: всплеск total_time по fingerprint → автоотчёт и рекомендация.
- Партиции: rollover/attach/detach, reindex; планы неизменны, p95 не деградирует.

---

#### 12. Распределение нагрузки между серверами

- Приложение: распределить воркеры/процессы по APP серверам; включить quotas через Governor/API `/api/admin/soul/governor/*` (см. `governor_admin.py`).
- БД: service_db на APP, soul_db/analytics_db на отдельном узле; чтения analytics на репликах.
- RS‑ветка (P48R): тяжёлые граф‑операции/ретривер — вынести в RS при SLA порогах (см. политику p95≤50ms, err≤1%).

Детали балансировки приложения:
- CPU‑связанные воркеры — равномерно по APP1/APP2; квоты через `governor_admin.py` (cpuquota/max‑mode) и настройки RS.
- I/O‑связанные — очереди с backpressure; низкий приоритет переводить в отложенное исполнение при спайках.

---

#### 13. Риски и откат

- Ошибки маршрутизации/конфигурации — feature‑flags для быстрого отката на единый engine/единую БД.
- Перераспределение пулов — предварительно понизить `pool_size` приложений; наблюдать caps.
- Реплики/аналитика — только идемпотентные чтения; при отставании — автоматический fallback.

---

#### 14. Acceptance критерии

- При целевом RPS: `db connection utilization` ≤ 70% без спайков отказов; p95 в бюджетах.
- Governor завершает `idle in transaction > N s` ≤ T секунд; алерты создаются и закрываются автоматически.
- Sleep с in‑memory слоями: после цикла состояние консистентно; prewarm/delta‑sync укладываются в бюджет.

---

#### 15. План документации и реестры

- Обновить: `docs/PROJECT_STRUCTURE_v8_1_1.md` (архитектура БД/потоки), `docs/SYSTEM_MASTER_DOCUMENTS_REGISTRY.md` (регистрация P51), индексы API/ENV.
- Добавить: ops/grafana панели и ops/prometheus правила (DB Governor/pg/replica).

---

#### 16. Приложение: ключи настроек/секретов (список)

Настройки (soul_settings):
- `db.service.dsn`, `db.soul.dsn`, `db.analytics.dsn`
- `db.gov.mode`, `db.gov.cap.*`, `db.gov.timeout.*`, `db.gov.kill.*`
- `net.priv.*` (WireGuard/health)

Секреты (soul_secrets):
- `db.service.secret_dsn`, `db.soul.secret_dsn`, `db.analytics.secret_dsn`

---

#### 17. Интеграции с другими P‑ТЗ и модулями

- P27 Delivery Guard: все операции Governor/DB‑управления подписываются и трассируются.
- P30/P36 Processor/Sequences/Rate Limits: Governor предоставляет caps/backpressure; процессоры уважают деградацию классов.
- P38/P46 Sleep/Neuro‑Integrity: Sleep использует класс `maintenance`; выполняет prewarm/snapshot in‑memory слоя.
- P40 Planning: работы через план‑таски, покрытие `planning.enforce`.
- P41 Rate Limits: синхронизация caps классов с лимитами API.
- P44 RBAC: доступ к `/api/admin/db-gov/*` — `soul.admin`; опасные операции — Two‑Keys.
- P45 Ingest/Quants: batch‑ингест уважает лимиты/классы Governor; крупные партии — в окна analytics/maint.
- P48R RS: тяжёлые граф‑операции — через RS с канареечным режимом и fallback на Python.
- Guard Canonical: DSN/ключи только через `soul_settings`/`soul_secrets`; инспектор блокирует хардкоды.

#### 18. Алгоритмическое и LLM‑управление потоками

Адаптивная схема (AIMD):
- На тиках пересчитывать p95/err_rate/queue_len; при `p95>budget`/`err>max` — multiplicative decrease; при норме — additive increase.
- Жёсткие триггеры: lock contention/idle in tx spike → мгновенное снижение caps `analytics|maint` + запуск киллера.

LLM‑gate (опция):
- Перед ростом caps выше порога — LLM‑оценка (контекст: метрики/инциденты); принять только при `{ allow: true }`.

#### 19. Сетевой контур (WireGuard/высокоскоростная связь)

- Проверка/ремедиэйшн wg0: ping/jitter/iperf3; корректная MTU; перезапуск при flap.
- Ключи настроек: `net.priv.app_addr`, `net.priv.db_addr`, `net.priv.ping_count`, `net.priv.ping_timeout_ms` в `soul_settings`.
- Алерт `NetPrivDegraded`: действия — проверить интерфейс/маршруты/WG статус; при длительной деградации — снижение caps analytics.

#### 20. Автоотчёты top‑queries и оптимизация

- Планировщик собирает срезы `pg_stat_statements` (если включён), `pg_locks`, `pg_stat_activity` и сохраняет в analytics_db.
- LLM‑саммаризация выдаёт рекомендации (индексы/перепись запросов/пулы); без PII.
- Дашборд — тренды total_time по fingerprints и вклад в p95 по классам.

---

#### 21. Низкоуровневый тюнинг ОС/ядра (Linux, для DB/APP)

Цель: стабильная низкая латентность, предсказуемость под пиковыми нагрузками и отсутствие сетевых/диск I/O аномалий.

Рекомендации (адаптировать под хост/оборудование; изменения проходить через maintenance окно):

- CPU/Процессы:
  - Выделить CPU‑пулы под Postgres и PgBouncer (cpu affinity/isolcpus/cset), разделив их с CPU для Nginx/APP.
  - NUMA: включить `numa_balancing=0` при явном пиннинге; для БД предпочтителен фиксированный NUMA‑узел и память локально к сокету.
  - Планировщик: `sched_migration_cost_ns` повысить умеренно для снижения прыжков между ядрами.

- Память:
  - Отключить Transparent Huge Pages (THP): always off; оставить HugePages по необходимости для специфичных модулей.
  - `vm.swappiness=1..5`, `vm.dirty_ratio=10`, `vm.dirty_background_ratio=5`, `vm.max_map_count` повысить при больших индексах.
  - `vm.zone_reclaim_mode=0` (NUMA) если наблюдаются reclaim‑пробки.

- FS/Диск:
  - I/O scheduler: для NVMe — `none`/`mq-deadline`; для SATA SSD — `mq-deadline`.
  - readahead для Postgres томов 8–32 КБ (минимально под OLTP), для реплик/аналитики допускается 128–256 КБ.
  - noatime для томов с данными БД; гарантировать `barrier=1` (по умолчанию) для целостности WAL.

- Сеть:
  - WireGuard wg0: корректный MTU (обычно 1380–1420), постоянные keepalive; проверить `rmem_max/wmem_max`.
  - TCP keepalive для APP↔PgBouncer↔Postgres: включить на уровне системных сокетов.

- Дескрипторы/очереди:
  - `fs.file-max` увеличить > 1e6; user limits для `postgres`/`pgbouncer` — `nofile 262144` и выше.
  - `net.core.somaxconn=4096`, `net.core.netdev_max_backlog=65536`.

Пример sysctl (эталон, адаптировать):

```ini
# /etc/sysctl.d/99-soul-db.conf
vm.swappiness = 1
vm.dirty_ratio = 10
vm.dirty_background_ratio = 5
vm.max_map_count = 1048576
vm.zone_reclaim_mode = 0
net.core.somaxconn = 4096
net.core.netdev_max_backlog = 65536
net.ipv4.tcp_fin_timeout = 15
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_keepalive_time = 600
net.ipv4.tcp_keepalive_intvl = 30
net.ipv4.tcp_keepalive_probes = 10
```

Пример limits:

```ini
# /etc/security/limits.d/80-soul-db.conf
postgres soft nofile 262144
postgres hard nofile 262144
pgbouncer soft nofile 262144
pgbouncer hard nofile 262144
```

THP disable (RHEL/Debian‑семейство):

```ini
# /etc/tuned/disable-thp/tuned.conf
[main]
include=throughput-performance
[vm]
transparent_hugepages=never
```

Результат: снижение джиттера p95 и устойчивость под спайками соединений.

---

#### 22. Рекомендуемые параметры Postgres (ориентиры)

Важно: параметры рассчитывать от RAM/CPU/нагрузки; числа ниже — ориентиры для prod‑узла 16–32 vCPU, 64–128 ГБ RAM, OLTP‑профиль.

```ini
# postgresql.conf (фрагменты)
shared_buffers = 8GB            # ~10–25% RAM
effective_cache_size = 48GB     # ~60–70% RAM
work_mem = 32MB                 # OLTP; аналитика отдельным профилем
maintenance_work_mem = 1GB
wal_level = replica
max_wal_size = 8GB
min_wal_size = 1GB
checkpoint_timeout = 15min
random_page_cost = 1.1
cpu_tuple_cost = 0.03
default_statistics_target = 200
shared_preload_libraries = 'pg_stat_statements,pg_prewarm,pgcrypto,pgvector'
pg_stat_statements.max = 10000
pg_stat_statements.track = all
# Таймауты управляются на уровне сессий/классов Governor
```

Для реплик: `hot_standby=on`, `max_standby_streaming_delay` сбалансировать с бюджетами p95 для чтений.

---

#### 23. PgBouncer: эталонные конфигурации и systemd

Принципы: transaction pooling, отделить пулы на service_db/soul_db/analytics_db, caps с запасом к `max_connections` Postgres, health‑пробы.

```ini
; /etc/pgbouncer/pgbouncer.ini (пример)
[databases]
service_db = host=127.0.0.1 port=5432 auth_user=pgbouncer pool_size=50 min_pool_size=10 reserve_pool_size=10
soul_db    = host=10.0.0.2 port=5432 auth_user=pgbouncer pool_size=80 min_pool_size=20 reserve_pool_size=20
analytics_db = host=10.0.0.3 port=5432 auth_user=pgbouncer pool_size=30 min_pool_size=5 reserve_pool_size=10

[pgbouncer]
listen_addr = 0.0.0.0
listen_port = 6432
auth_type = scram-sha-256
auth_file = /etc/pgbouncer/userlist.txt
pool_mode = transaction
max_client_conn = 2048
default_pool_size = 50
min_pool_size = 10
reserve_pool_size = 20
server_reset_query = DISCARD ALL
server_idle_timeout = 30
server_lifetime = 3600
query_timeout = 0
tcp_keepalive = 1
ignore_startup_parameters = extra_float_digits
stats_users = admin
admin_users = admin
```

```ini
; /etc/pgbouncer/userlist.txt (пример)
"admin" "SCRAM-SHA-256$..."
"app"   "SCRAM-SHA-256$..."
```

systemd unit:

```ini
# /etc/systemd/system/pgbouncer.service
[Unit]
Description=PgBouncer Connection Pooler
After=network.target

[Service]
User=pgbouncer
Group=pgbouncer
ExecStart=/usr/bin/pgbouncer /etc/pgbouncer/pgbouncer.ini
Restart=always
RestartSec=2
LimitNOFILE=262144

[Install]
WantedBy=multi-user.target
```

Особенности transaction pooling: все session‑уровневые `SET` должны выполняться в каждой транзакции; использовать `application_name` на connect.

---

#### 24. Alembic: multi‑DB стратегия (service_db / soul_db / analytics_db)

Подход: единый репозиторий Alembic с multi‑binds или три профиля. Рекомендуется multi‑binds для сквозного контроля версий.

Ключевые моменты:
- В `alembic.ini` добавить именованные bind‑ы: `service`, `soul`, `analytics`.
- В `env.py` — карта движков по bind‑ключам; автогенерация по схемам/метаданным, разделённым по доменам.
- Миграции декорировать `op.get_bind().engine.url` или использовать `context.config.get_main_option("sqlalchemy.url_service")` и т.п.

Фрагменты (док‑пример):

```python
# alembic/env.py (фрагмент идеи)
from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool
from alembic import context

config = context.config
fileConfig(config.config_file_name)

target_metadata_map = {
    'service': service_metadata,   # содержит модели soul_settings/soul_secrets/RBAC
    'soul': soul_metadata,         # модели quants/quant_links/...
    'analytics': analytics_metadata,
}

def run_migrations_offline():
    for name, md in target_metadata_map.items():
        url = config.get_main_option(f'sqlalchemy.url_{name}')
        context.configure(url=url, target_metadata=md, literal_binds=True)
        with context.begin_transaction():
            context.run_migrations()

def run_migrations_online():
    for name, md in target_metadata_map.items():
        cfg_section = config.get_section(config.config_ini_section)
        cfg_section['sqlalchemy.url'] = config.get_main_option(f'sqlalchemy.url_{name}')
        connectable = engine_from_config(cfg_section, prefix='sqlalchemy.', poolclass=pool.NullPool)
        with connectable.connect() as connection:
            context.configure(connection=connection, target_metadata=md)
            with context.begin_transaction():
                context.run_migrations()
```

Именование версий: директории `versions_service/`, `versions_soul/`, `versions_analytics/` либо префиксы в файлах `xxx_service_*.py`.

FDW (временная совместимость, только чтение):

```sql
CREATE EXTENSION IF NOT EXISTS postgres_fdw;
CREATE SERVER soul_remote FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host '10.0.0.2', dbname 'soul_db', port '5432');
CREATE USER MAPPING FOR current_user SERVER soul_remote OPTIONS (user 'fdw_user');
IMPORT FOREIGN SCHEMA public LIMIT TO (quants, quant_links) FROM SERVER soul_remote INTO staging;
```

---

#### 25. Multi‑engine фасад в приложении

Идея: централизованный фасад выдает сессии по классу нагрузки и домену данных, расставляет `application_name`, таймауты и применяет семафоры Governor.

Требования:
- Три движка: `engine_service`, `engine_soul`, `engine_analytics`; DSN — из `soul_secrets`, путь — через `SoulSettingsService`.
- На connect: `SET application_name`, `SET statement_timeout`, `SET idle_in_transaction_session_timeout`, `SET lock_timeout` по классу.
- Семафоры/очередь: перед выдачей сессии — проверка cap класса; при переполнении — backpressure/отказ (для низких приоритетов).
- Трассировка: теги класса/пользователя/эндпоинта в метриках/логах.

Схема ошибок:
- При сетевых/pgbouncer ошибках — быстрый retry с джиттером; при p95 breach — сигнал Governor на снижение caps.

---

#### 26. Репликация и маршрутизация чтений

Политика:
- Реплики только для идемпотентных чтений; запись всегда на primary.
- Лаг‑порог (например, 2–5 секунд) из `soul_settings` → при превышении — fallback на primary.

Проверка лага (пример SQL):

```sql
-- На реплике
SELECT EXTRACT(EPOCH FROM now() - pg_last_xact_replay_timestamp()) AS lag_s;
```

В приложении: кешировать лаг на 0.5–1с; роутинг чтений в зависимости от класса и лаг‑порога.

---

#### 27. Troubleshooting / Runbooks

- remaining connection slots are reserved for SUPERUSER:
  - Проверить PgBouncer `show pools; show clients;` → снизить caps низких классов, временно урезать `default_pool_size`.
  - Включить `server_idle_timeout`, обнаружить `idle in transaction` и завершить (`/kill/idle_in_tx`).

- idle in transaction растет:
  - Принудительно активировать `idle_in_transaction_session_timeout` через Governor, запустить киллер > N секунд.
  - Проанализировать кодовые пути долгих транзакций, внедрить ранние commit/авто‑rollback.

- Высокий p95 OLTP:
  - Снять `pg_stat_statements` top‑N; сверить планы; предложить индексы/перепись; снизить caps analytics/maint.

- Блокировки:
  - `pg_locks` ожидания → найти владельца/ожидающих; по возможности разбить транзакции; перестроить индексы off‑peak.

- WireGuard деградация:
  - Проверить MTU/jitter `iperf3`; при flap — временно снизить caps analytics.

---

#### 28. Capacity planning (ориентиры)

- Max concurrent sessions (через PgBouncer):
  - service ≤ 30–50; core ≤ 80–120; analytics ≤ 20–40; maint ≤ 5–10.
- Connection utilization target: ≤ 70% устойчиво.
- WAL/IO: обеспечить пропускную способность записи WAL ≥ 50–150 MB/s под пиками ingest.

---

#### 29. Безопасность и RBAC (P44)

- Доступ к `/api/admin/db-gov/*` — только `soul.admin`; операции `kill/idle_in_tx` и `mode` — Two‑Keys.
- Значения DSN/секретов — только через `soul_secrets` (pgcrypto); не логировать значения, только маскированные превью.
- Инциденты фиксируются с указанием severity и пошаговыми рекомендациями.

---

#### 30. Раскатка и откат (canary)

Этапы:
1) Включить PgBouncer с caps=низкими значениями, проверить health и метрики.
2) Развести БД (service/soul/analytics), переключить DSN через `soul_settings` (feature‑flag).
3) Включить Governor в режиме `manual`; измерить p95 и err_rate.
4) Перевести Governor в `auto` + LLM‑gate; постепенно увеличивать caps по классам.
5) Включить реплики и роутинг чтений; настроить алерты lag.

Откат: флагом вернуть единый engine/DSN; отключить реплики/analytics; вернуть caps к минимальным.

---

#### 31. Примеры DSL/CLI для администрирования

Примеры команд (через Hyperloop CLI):

```powershell
python .\Soul\scripts\hyperloop_cli.py --dsl "DB.GOV.CAP class=core value=60"
python .\Soul\scripts\hyperloop_cli.py --dsl "DB.GOV.TIMEOUT key=idle_in_tx class=core value_ms=45000"
python .\Soul\scripts\hyperloop_cli.py --dsl "DB.GOV.KILL IDLE_IN_TX older_than_s=60"
python .\Soul\scripts\hyperloop_cli.py --dsl "DB.GOV.MODE value=auto"
```

---

#### 32. Высокоскоростные каналы Soul и Hyperloop (канал управления и данных)

Назначение: детерминированная, малозадержная передача команд/DSL и данных телеметрии/отчётов между компонентами Soul, DB Governor и RS‑акторами.

- **Канал управления (Hyperloop CLI/DSL)**:
  - Транспорт: подписанные JSON‑пакеты (STRICT JSON) через API `.../api/hyperloop/execute` с заголовком `X-Telegram-User-ID`.
  - Контракты: одно строковое поле `commands` (DSL) или `commands + options` (для сложных JSON‑параметров через `--options-json-file`).
  - Политики: Delivery Guard (P27) неизменно; все шаги команд фиксируются с `trace_id` и хранятся в цепочке подписи.
  - Надёжность: backpressure/ретраи на RS‑мосте, canary‑профиль `prod_safe`, запрет «заглушек».
  - Примеры: `DB.GOV.CAP`, `DB.GOV.TIMEOUT`, `DB.GOV.KILL IDLE_IN_TX`, `PLAN.TASK.ADD`, `INSPECTOR.RUN ...`.

- **Высокоскоростной канал данных (RS Hyperloop, P48R)**:
  - Транспорт: rsbus/UDS, стабильные JSON‑контракты `svc.rs.proxy → svc.<actor>`; UTF‑8; без PII.
  - Политика canary: `rs.hyperloop.canary_share` с автотюном; SLA пороги p95/err_rate; мгновенный fallback на Python при деградации.
  - Применение: тяжёлые граф‑операции над квантами, ретривер, агрегации метрик Governor/pg.
  - Инварианты: добавляются шаги `svc.rs.proxy`/`svc.<actor>.*` в P27 подпись; публичные контракты не нарушаются.

- **Сетевой профиль**:
  - Приоритет трафика управления над аналитическим (QoS); предпочтение приватного линка (WireGuard wg0) между APP↔DB/RS.
  - Health: периодические `RS.CANARY.RUN`, `TRACE.STEPS trace_id=...`, проверка `/api/health` и `/api/admin/rs/metrics-raw`.

- **Наблюдаемость/алерты**:
  - Метрики: `dev_connect_latency_ms_p50|p95`, `dev_connect_total{status}`, `dev_connect_error_total{type}`, `rs_actor.p95_ms`, `fallback_rate`.
  - Алерты: деградация `dev_connect` (401/404/422/timeout), превышение p95/err_rate RS‑акторов, рост fallback_rate.

- **Безопасность**:
  - RBAC по ключам и ролям (`soul.admin` для опасных операций), Two‑Keys для чувствительных DSL.
  - Все адреса/URL/порты читаются из `soul_settings`/`soul_secrets`; хардкоды запрещены.

---

Конец документа P51.


