import { R as React, j as jsxRuntimeExports } from "./react-DAIzMmXQ.js";
import Prompts from "./Prompts-CHKQEwNY.js";
import { c as apiRequest } from "./index-xwdu3tSt.js";
import "./index-BAyJFXc0.js";
import "./index-BHcQqKzx.js";
import "./Skeleton-CH9fV77T.js";
import "./FileTextOutlined-DrMdduVt.js";
import "./AntdIcon-BO7NkY_e.js";
import "./index-uYz9xaHY.js";
import "./context-_BQpt2pb.js";
import "./index-B-ER_dlH.js";
import "./index-Cyv665q3.js";
import "./StarOutlined-BW1bbEqm.js";
import "./index-xSNZqJ8F.js";
import "./index-DOcBOK61.js";
import "./index-BvrbUfLH.js";
import "./index-Cpn0Ssy1.js";
import "./InfoCircleOutlined-DS0GPTcq.js";
const PromptsStandalone = () => {
  const [prompts, setPrompts] = React.useState([]);
  const [selectedPrompt, setSelectedPrompt] = React.useState(null);
  const [disableBasePersonality, setDisableBasePersonality] = React.useState(false);
  const [loading, setLoading] = React.useState(true);
  const load = React.useCallback(async () => {
    try {
      const tgId = (() => {
        try {
          return sessionStorage.getItem("tg_id");
        } catch (e) {
          return null;
        }
      })();
      if (!tgId) {
        setLoading(false);
        return;
      }
      const res = await apiRequest("/miniapp/prompts", "GET", null, { "X-Telegram-User-ID": String(tgId) });
      const items = res.items || [];
      setPrompts(items);
      const active = items.find((p) => p.is_active) || items.find((p) => p.key === "prompt-4") || null;
      if (active) {
        setSelectedPrompt(active);
        setDisableBasePersonality(!!active.disable_base_personality);
      }
    } finally {
      setLoading(false);
    }
  }, []);
  React.useEffect(() => {
    load();
  }, [load]);
  const onPromptSelect = (p) => setSelectedPrompt(p);
  const onSetActivePersonality = async (promptKey, disableBase) => {
    try {
      const tgId = sessionStorage.getItem("tg_id");
      if (!tgId) throw new Error("Unauthorized");
      const form = new FormData();
      form.append("prompt_key", promptKey);
      if (typeof disableBase === "boolean") form.append("disable_base", String(disableBase));
      const resp = await fetch("/api/miniapp/prompts/set-active", { method: "POST", body: form, headers: { "X-Telegram-User-ID": String(tgId) } });
      if (resp.ok) {
        const data = await resp.json();
        setDisableBasePersonality(!!data.disable_base_personality);
        await load();
      }
    } catch (e) {
    }
  };
  const onPromptStatusChange = async (promptId, newStatus) => {
    const p = prompts.find((px) => px.id === promptId);
    if (!p || !p.key) return;
    await onSetActivePersonality(newStatus ? p.key : "prompt-4");
  };
  const onDisableBasePersonalityChange = async (checked) => {
    try {
      const tgId = sessionStorage.getItem("tg_id");
      if (!tgId) throw new Error("Unauthorized");
      const form = new FormData();
      form.append("disable_base", String(checked));
      const resp = await fetch("/api/miniapp/prompts/update-settings", { method: "POST", body: form, headers: { "X-Telegram-User-ID": String(tgId) } });
      if (resp.ok) setDisableBasePersonality(checked);
    } catch (e) {
    }
  };
  if (loading) return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "screen loading", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "spinner" }) });
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Prompts,
    {
      prompts,
      selectedPrompt,
      onPromptSelect,
      onPromptStatusChange,
      onSetActivePersonality,
      disableBasePersonality,
      onDisableBasePersonalityChange
    }
  );
};
export {
  PromptsStandalone as default
};
//# sourceMappingURL=PromptsStandalone-B9CWVNxE.js.map
