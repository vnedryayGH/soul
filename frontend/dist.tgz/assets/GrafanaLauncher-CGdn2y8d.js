import { a as reactExports, j as jsxRuntimeExports } from "./react-DAIzMmXQ.js";
import { j as buildAuthHeaders, T as Typography, l as Space, B as Button, s as staticMethods } from "./index-xwdu3tSt.js";
const GrafanaLauncher = () => {
  const [url, setUrl] = reactExports.useState("https://mini.soulpulse.art/grafana");
  const [loading, setLoading] = reactExports.useState(true);
  reactExports.useEffect(() => {
    (async () => {
      try {
        const resp = await fetch("/api/miniapp/grafana/ml", { headers: buildAuthHeaders() });
        if (resp.ok) {
          const data = await resp.json();
          const u = String((data == null ? void 0 : data.url) || "");
          if (u.startsWith("http")) setUrl(u);
        }
      } catch (e) {
      } finally {
        setLoading(false);
      }
    })();
  }, []);
  const openExternal = () => {
    var _a;
    try {
      const tg = (_a = window == null ? void 0 : window.Telegram) == null ? void 0 : _a.WebApp;
      if (tg == null ? void 0 : tg.openLink) {
        tg.openLink(url, { try_instant_view: false });
        return;
      }
    } catch (e) {
    }
    try {
      window.location.href = url;
    } catch (e) {
      staticMethods.error("Не удалось открыть Grafana");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { maxWidth: 520, width: "100%", textAlign: "center", background: "var(--sp-bg-card)", border: "1px solid var(--sp-border-primary)", borderRadius: 12, padding: 24 }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Typography.Title, { level: 3, style: { marginTop: 0, marginBottom: 12 }, children: "ML Grafana" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Typography.Paragraph, { type: "secondary", style: { marginBottom: 16 }, children: "Отдельный запуск дашборда Grafana в новом окне. Рекомендуется открывать вне мини‑приложения." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Space, { direction: "vertical", size: 12, style: { width: "100%" }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "primary", size: "large", loading, onClick: openExternal, children: "Открыть Grafana" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { fontSize: 12, wordBreak: "break-all", color: "var(--sp-text-secondary)" }, children: url })
    ] })
  ] }) });
};
export {
  GrafanaLauncher as default
};
//# sourceMappingURL=GrafanaLauncher-CGdn2y8d.js.map
