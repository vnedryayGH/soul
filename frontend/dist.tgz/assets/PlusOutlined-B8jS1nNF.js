import { a as reactExports } from "./react-DAIzMmXQ.js";
import { P as PlusOutlined$1 } from "./index-BHcQqKzx.js";
import { I as Icon } from "./AntdIcon-BO7NkY_e.js";
function _extends() {
  _extends = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}
const PlusOutlined = (props, ref) => /* @__PURE__ */ reactExports.createElement(Icon, _extends({}, props, {
  ref,
  icon: PlusOutlined$1
}));
const RefIcon = /* @__PURE__ */ reactExports.forwardRef(PlusOutlined);
export {
  RefIcon as R
};
//# sourceMappingURL=PlusOutlined-B8jS1nNF.js.map
