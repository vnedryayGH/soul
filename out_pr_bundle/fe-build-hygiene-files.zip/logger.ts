// logger utility with gated levels for production
// Only console.warn/error stay in production by default; logs can be enabled via VITE_DEBUG_LOGS=1

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

function isDebugEnabled(): boolean {
  try {
    // vite injects import.meta.env at build time
    // @ts-ignore
    const v = (import.meta?.env?.VITE_DEBUG_LOGS ?? '0') as string;
    const s = String(v).toLowerCase();
    return s === '1' || s === 'true';
  } catch {
    return false;
  }
}

function formatMessage(args: unknown[]): unknown[] {
  try {
    const ts = new Date().toISOString();
    return [`[${ts}]`, ...args];
  } catch {
    return args;
  }
}

export const logger = {
  debug: (...args: unknown[]) => {
    if (isDebugEnabled()) {
      // eslint-disable-next-line no-console
      console.debug(...formatMessage(args));
    }
  },
  info: (...args: unknown[]) => {
    if (isDebugEnabled()) {
      // eslint-disable-next-line no-console
      console.info(...formatMessage(args));
    }
  },
  warn: (...args: unknown[]) => {
    // eslint-disable-next-line no-console
    console.warn(...formatMessage(args));
  },
  error: (...args: unknown[]) => {
    // eslint-disable-next-line no-console
    console.error(...formatMessage(args));
  },
};
