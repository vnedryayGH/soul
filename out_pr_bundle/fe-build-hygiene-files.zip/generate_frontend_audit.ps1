Param(
  [string]$FrontendDir = "frontend",
  [string]$DocsDir = "docs"
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path -LiteralPath $FrontendDir)) {
  Write-Error "Frontend directory not found: $FrontendDir"
  exit 1
}

New-Item -ItemType Directory -Force -Path $DocsDir | Out-Null

$patterns = @('*.ts','*.tsx','*.js','*.jsx')
$files = Get-ChildItem -Path $FrontendDir -Recurse -File -Include $patterns -Force |
  Where-Object { $_.FullName -notlike '*\node_modules\*' -and $_.FullName -notlike '*\dist\*' }

$todo = @()
if ($files.Count -gt 0) {
  $todo = Select-String -Path ($files.FullName) -SimpleMatch -Pattern 'TODO','FIXME'
}

$logs = @()
if ($files.Count -gt 0) {
  $logs = Select-String -Path ($files.FullName) -Pattern 'console\.log\s*\(' 
}

$now = Get-Date -Format 'yyyyMMdd_HHmmss'
$reportPath = Join-Path $DocsDir ("FRONTEND_AUDIT_REPORT_${now}.md")


$sb = New-Object System.Text.StringBuilder
[void]$sb.AppendLine("# Frontend Audit Report $now")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("## Summary")
[void]$sb.AppendLine("- TODO/FIXME: $($todo.Count)")
[void]$sb.AppendLine("- console.log: $($logs.Count)")
[void]$sb.AppendLine("")

[void]$sb.AppendLine("## console.log by file (desc)")
$logByFile = $logs | Group-Object Path | Sort-Object Count -Descending
foreach ($g in $logByFile) {
  [void]$sb.AppendLine("- $($g.Count) $($g.Name)")
}
[void]$sb.AppendLine("")

[void]$sb.AppendLine("## TODO/FIXME (first 300 lines)")
$i = 0
foreach ($m in $todo) {
  [void]$sb.AppendLine("- $($m.Path):$($m.LineNumber) $([string]::Copy($m.Line).Trim())")
  $i++
  if ($i -ge 300) { break }
}
[void]$sb.AppendLine("")

[void]$sb.AppendLine("## console.log lines (first 300 lines)")
$j = 0
foreach ($m in $logs) {
  [void]$sb.AppendLine("- $($m.Path):$($m.LineNumber) $([string]::Copy($m.Line).Trim())")
  $j++
  if ($j -ge 300) { break }
}

Set-Content -Path $reportPath -Value $sb.ToString() -Encoding UTF8

Write-Output $reportPath


