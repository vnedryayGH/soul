Param(
  [string]$RepoRoot = "."
)

$ErrorActionPreference = 'Stop'

$gitDir = Join-Path $RepoRoot ".git"
if (-not (Test-Path -LiteralPath $gitDir)) {
  Write-Error "Git repository not found at $RepoRoot"
  exit 1
}

$hooksDir = Join-Path $gitDir "hooks"
New-Item -ItemType Directory -Force -Path $hooksDir | Out-Null
$hookPath = Join-Path $hooksDir "pre-commit"

$hook = @(
  "#!/usr/bin/env pwsh",
  "# Auto-generated pre-commit hook: frontend audit + build + dist gate",
  "Set-StrictMode -Version Latest",
  "$ErrorActionPreference = 'Stop'",
  "Write-Output '[pre-commit] Running frontend audit'",
  "powershell -NoProfile -File scripts/generate_frontend_audit.ps1 -FrontendDir frontend -DocsDir docs",
  "Write-Output '[pre-commit] Building frontend (vite build)'",
  "pushd frontend | Out-Null",
  "npm run build --silent",
  "popd | Out-Null",
  "Write-Output '[pre-commit] Gating dist'",
  "powershell -NoProfile -File scripts/gate_dist.ps1 -DistDir frontend/dist",
  "Write-Output '[pre-commit] OK'"
) -join "`n"

Set-Content -Path $hookPath -Value $hook -Encoding ASCII
try { & git update-index --chmod=+x -- hooks/pre-commit } catch {}
Write-Output $hookPath


