Param(
  [string]$DistDir = "frontend/dist"
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path -LiteralPath $DistDir)) {
  Write-Error "Dist directory not found: $DistDir"
  exit 1
}

$index = Join-Path $DistDir 'index.html'
if (-not (Test-Path -LiteralPath $index)) {
  Write-Error "index.html not found in $DistDir"
  exit 1
}

$html = Get-Content -Raw -Path $index -Encoding UTF8

# 1) index.html должен ссылаться на assets/index-*.js
if ($html -notmatch 'assets/index-[^"\']+\.js') {
  Write-Error "index.html does not reference assets/index-*.js"
  exit 1
}

# 2) Проверим отсутствие абсолютных путей на localhost
if ($html -match 'http://localhost' -or $html -match 'http://127\.0\.0\.1') {
  Write-Error "index.html contains absolute localhost references"
  exit 1
}

# 3) Проверьте наличие .map для основного бандла, если есть карта
$matches = [System.Text.RegularExpressions.Regex]::Matches($html, 'assets/index-[^"\']+\.js')
if ($matches.Count -gt 0) {
  $firstJs = Join-Path $DistDir $matches[0].Value
  $mapPath = $firstJs + '.map'
  if (-not (Test-Path -LiteralPath $mapPath)) {
    Write-Warning "Sourcemap not found for $($matches[0].Value). Continuing (not fatal)."
  }
}

Write-Output "dist gate: OK"


