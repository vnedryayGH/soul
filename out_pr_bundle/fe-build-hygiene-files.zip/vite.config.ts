import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  const debugLogs = String(env.VITE_DEBUG_LOGS || "0").toLowerCase() === "1" || String(env.VITE_DEBUG_LOGS || "").toLowerCase() === "true";

  return {
    plugins: [react()],
    server: {
      port: 5173,
      // Слушаем на всех интерфейсах, чтобы reverse-SSH мог подключаться
      host: true,
      // Разрешаем проксирование с тестового домена через reverse SSH и Nginx
      allowedHosts: ['test.soulpulse.art', 'mini.soulpulse.art', 'localhost'],
      // Не фиксируем HMR-хост на localhost, чтобы dev‑клиент использовал текущий origin
      proxy: {
        '/api': {
          target: 'http://localhost:8000',
          changeOrigin: true
        }
      }
    },
    define: {
      global: 'globalThis',
    },
    build: {
      sourcemap: true,
    },
    // Дропаём только debugger. Управление логами — через util logger и VITE_DEBUG_LOGS
    esbuild: {
      drop: ["debugger"],
    },
  };
});
