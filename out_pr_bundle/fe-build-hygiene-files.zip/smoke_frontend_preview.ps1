Param(
  [int]$Port = 4173,
  [string[]]$Paths = @('/', '/webauth', '/chat', '/dates-reminders')
)

$ErrorActionPreference = 'Stop'

Write-Output "[1/4] Building frontend (vite build)"
if (Test-Path -LiteralPath 'frontend') { pushd frontend | Out-Null }
try {
  npm run build --silent | Out-Null
} finally {
  try { popd | Out-Null } catch {}
}

Write-Output "[2/4] Starting preview on port $Port"
if (Test-Path -LiteralPath 'frontend') { $workDir = 'frontend' } else { $workDir = '.' }
$preview = Start-Process -FilePath "npm" -ArgumentList "run","preview","--silent","--","--port",$Port.ToString(),"--strictPort" -WorkingDirectory $workDir -PassThru
Start-Sleep -Seconds 2

Write-Output "[3/4] Curl routes"
foreach ($p in $Paths) {
  $resp = curl.exe -sI "http://127.0.0.1:$Port$p"
  if ($LASTEXITCODE -ne 0) { Write-Error "request failed: $p" }
  $respText = ($resp | Out-String)
  if ($respText -notmatch 'HTTP/(1\.1|2) 200') { Write-Error "non-200 for $p`n$respText" }
  $ctype = ($resp | Select-String -Pattern '^Content-Type:' | Select-Object -First 1)
  if (-not $ctype) { Write-Warning "No Content-Type for $p" }
  $resp | Write-Output
}

Write-Output "[4/4] HEAD first assets/index-*.js"
if (Test-Path -LiteralPath 'frontend/dist') { $distDir = 'frontend/dist' } else { $distDir = 'dist' }
$index = Get-Content -Raw -Path (Join-Path $distDir 'index.html') -Encoding UTF8
$match = [System.Text.RegularExpressions.Regex]::Match($index, 'assets/index-[^"]+\.js')
if ($match.Success) {
  $asset = $match.Value
  $resp2 = curl.exe -sI "http://127.0.0.1:$Port/$asset"
  $resp2Text = ($resp2 | Out-String)
  if ($resp2Text -notmatch 'HTTP/(1\.1|2) 200') { Write-Error "non-200 for $asset`n$resp2Text" }
  if ($resp2Text -notmatch 'Content-Type: application/javascript') { Write-Warning "Unexpected Content-Type for $asset`n$resp2Text" }
  $resp2 | Write-Output
} else {
  Write-Warning "assets/index-*.js not found in index.html"
}

try { Stop-Process -Id $preview.Id -Force } catch {}


