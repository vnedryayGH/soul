"""P20 Stage-3: comments, attachments, sprints, time_entries

Revision ID: 20250915_000041_p20_stage3
Revises: 20250915_000040_p20
Create Date: 2025-09-15 00:10:41

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision = '20250915_000041_p20_stage3'
down_revision = '20250915_000040_p20'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'task_comments',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('task_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('parent_comment_id', postgresql.UUID(as_uuid=False), nullable=True),
        sa.Column('author_id', sa.BigInteger(), nullable=False),
        sa.Column('body', sa.Text(), nullable=False),
        sa.Column('mentions', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('reactions', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('edited_by', sa.BigInteger(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        'task_attachments',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('task_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('uploader_id', sa.BigInteger(), nullable=False),
        sa.Column('kind', sa.Enum('file','image','voice','video','link', name='attachment_kind'), nullable=False),
        sa.Column('storage_key', sa.Text(), nullable=False),
        sa.Column('content_type', sa.Text(), nullable=True),
        sa.Column('size', sa.Integer(), nullable=True),
        sa.Column('meta', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        'sprints',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('team_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('name', sa.Text(), nullable=False),
        sa.Column('goal', sa.Text(), nullable=True),
        sa.Column('start_date', sa.Date(), nullable=False),
        sa.Column('end_date', sa.Date(), nullable=False),
        sa.Column('status', sa.Enum('planned','active','closed', name='sprint_status'), nullable=False, server_default='planned'),
        sa.Column('capacity', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    )

    op.create_table(
        'sprint_tasks',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('sprint_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('task_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('order_no', sa.Integer(), nullable=False, server_default='0'),
    )

    op.create_table(
        'time_entries',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('task_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('user_id', sa.BigInteger(), nullable=False),
        sa.Column('started_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('ended_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('duration_sec', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('category', sa.Enum('dev','review','meeting','research','ops','other', name='time_category'), nullable=False, server_default='other'),
        sa.Column('note', sa.Text(), nullable=True),
        sa.Column('approved_by', sa.BigInteger(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    )

    # indexes
    op.create_index('ix_task_comments_task', 'task_comments', ['task_id'])
    # Текстовые GIN-индексы через pg_trgm и opclass, JSONB — стандартный gin
    op.execute("CREATE EXTENSION IF NOT EXISTS pg_trgm")
    op.execute("CREATE INDEX IF NOT EXISTS ix_task_comments_body_fts ON task_comments USING gin (body gin_trgm_ops)")
    op.create_index('ix_task_comments_mentions', 'task_comments', ['mentions'], postgresql_using='gin')
    op.create_index('ix_task_attachments_task', 'task_attachments', ['task_id'])
    op.create_index('ix_sprint_tasks_order', 'sprint_tasks', ['sprint_id','order_no'])
    op.create_index('ix_time_entries_task_started', 'time_entries', ['task_id','started_at'])


def downgrade():
    op.drop_index('ix_time_entries_task_started', table_name='time_entries')
    op.drop_index('ix_sprint_tasks_order', table_name='sprint_tasks')
    op.drop_index('ix_task_attachments_task', table_name='task_attachments')
    op.drop_index('ix_task_comments_mentions', table_name='task_comments')
    op.drop_index('ix_task_comments_body_fts', table_name='task_comments')
    op.drop_index('ix_task_comments_task', table_name='task_comments')
    op.drop_table('time_entries')
    op.drop_table('sprint_tasks')
    op.drop_table('sprints')
    op.drop_table('task_attachments')
    op.drop_table('task_comments')


