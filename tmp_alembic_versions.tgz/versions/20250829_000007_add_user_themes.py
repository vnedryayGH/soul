"""add user themes

Revision ID: 20250829_000007
Revises: 20250814_000006
Create Date: 2025-08-29 12:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '20250829_000007'
down_revision = '001'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Создаем таблицу user_themes
    op.create_table('user_themes',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('user_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=100), nullable=False),
    sa.Column('is_active', sa.Boolean(), nullable=False),
    sa.Column('is_custom', sa.Boolean(), nullable=False),
    sa.Column('bg_primary', sa.String(length=7), nullable=False),
    sa.Column('bg_secondary', sa.String(length=7), nullable=False),
    sa.Column('bg_card', sa.String(length=7), nullable=False),
    sa.Column('bg_hover', sa.String(length=7), nullable=False),
    sa.Column('bg_topbar', sa.String(length=20), nullable=False),
    sa.Column('text_primary', sa.String(length=7), nullable=False),
    sa.Column('text_secondary', sa.String(length=7), nullable=False),
    sa.Column('text_hint', sa.String(length=7), nullable=False),
    sa.Column('primary_color', sa.String(length=7), nullable=False),
    sa.Column('primary_hover', sa.String(length=7), nullable=False),
    sa.Column('secondary_color', sa.String(length=7), nullable=False),
    sa.Column('accent_color', sa.String(length=7), nullable=False),
    sa.Column('success_color', sa.String(length=7), nullable=False),
    sa.Column('danger_color', sa.String(length=7), nullable=False),
    sa.Column('warning_color', sa.String(length=7), nullable=False),
    sa.Column('border_color', sa.String(length=7), nullable=False),
    sa.Column('border_light', sa.String(length=7), nullable=False),
    sa.Column('grad_start', sa.String(length=7), nullable=False),
    sa.Column('grad_end', sa.String(length=7), nullable=False),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.Column('updated_at', sa.DateTime(), nullable=False),
    sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('id'),
    sa.UniqueConstraint('user_id', 'name', name='uq_user_theme_name')
    )
    
    # Создаем индексы для оптимизации
    op.create_index('ix_user_themes_user_id', 'user_themes', ['user_id'])
    op.create_index('ix_user_themes_is_active', 'user_themes', ['is_active'])
    
    # Добавляем системные темы по умолчанию для существующих пользователей
    op.execute("""
        INSERT INTO user_themes (
            user_id, name, is_active, is_custom,
            bg_primary, bg_secondary, bg_card, bg_hover, bg_topbar,
            text_primary, text_secondary, text_hint,
            primary_color, primary_hover, secondary_color, accent_color, 
            success_color, danger_color, warning_color,
            border_color, border_light, grad_start, grad_end,
            created_at, updated_at
        )
        SELECT 
            u.id as user_id,
            'Темная (по умолчанию)' as name,
            true as is_active,
            false as is_custom,
            '#0f0f0f' as bg_primary,
            '#1a1a1a' as bg_secondary,
            '#2a2a2a' as bg_card,
            '#3a3a3a' as bg_hover,
            'rgba(15,15,15,0.85)' as bg_topbar,
            '#ffffff' as text_primary,
            '#a0a0a0' as text_secondary,
            '#666666' as text_hint,
            '#6366f1' as primary_color,
            '#5048e5' as primary_hover,
            '#8b5cf6' as secondary_color,
            '#f59e0b' as accent_color,
            '#10b981' as success_color,
            '#ef4444' as danger_color,
            '#f59e0b' as warning_color,
            '#404040' as border_color,
            '#303030' as border_light,
            '#1a1a3a' as grad_start,
            '#0f0f0f' as grad_end,
            NOW() as created_at,
            NOW() as updated_at
        FROM users u
        WHERE NOT EXISTS (
            SELECT 1 FROM user_themes ut WHERE ut.user_id = u.id
        );
    """)


def downgrade() -> None:
    # Удаляем индексы
    op.drop_index('ix_user_themes_is_active', table_name='user_themes')
    op.drop_index('ix_user_themes_user_id', table_name='user_themes')
    
    # Удаляем таблицу
    op.drop_table('user_themes')
