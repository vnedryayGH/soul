"""P20 tasks/events/reminders/chat_mined_facts tables

Revision ID: 20250915_000040_p20
Revises: 20250912_add_current_chat_mode
Create Date: 2025-09-15 00:00:40

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision = '20250915_000040_p20'
down_revision = '20250912_add_current_chat_mode'
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM pg_type WHERE typname = 'task_priority'
            ) THEN
                CREATE TYPE task_priority AS ENUM ('low','normal','high','urgent');
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM pg_type WHERE typname = 'task_status'
            ) THEN
                CREATE TYPE task_status AS ENUM ('todo','in_progress','done','blocked','canceled');
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='tasks'
            ) THEN
                CREATE TABLE tasks (
                    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                    tenant_id uuid NULL,
                    bot_id bigint NULL,
                    chat_id bigint NULL,
                    team_id uuid NULL,
                    title text NOT NULL,
                    description text NULL,
                    labels jsonb NULL,
                    priority task_priority NOT NULL DEFAULT 'normal',
                    status task_status NOT NULL DEFAULT 'todo',
                    progress smallint NOT NULL DEFAULT 0,
                    start_at timestamptz NULL,
                    due_at timestamptz NULL,
                    completed_at timestamptz NULL,
                    owner_id bigint NULL,
                    parent_task_id uuid NULL,
                    source_message_id bigint NULL,
                    source_user_id bigint NULL,
                    provenance_id uuid NULL,
                    created_at timestamptz NOT NULL DEFAULT now(),
                    updated_at timestamptz NOT NULL DEFAULT now(),
                    deleted_at timestamptz NULL,
                    created_by bigint NULL,
                    updated_by bigint NULL
                );
            END IF;
        END$$;
        """
    )

    op.create_table(
        'task_assignments',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('task_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('user_id', sa.BigInteger(), nullable=False),
        sa.Column('role', sa.Enum('owner','assignee','watcher', name='task_assignment_role'), nullable=False, server_default='assignee'),
        sa.Column('notify', sa.Boolean(), nullable=False, server_default=sa.text('true')),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    )

    op.create_table(
        'task_dependencies',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('task_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('depends_on_task_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('type', sa.Enum('fs','ss','ff','sf', name='task_dependency_type'), nullable=False, server_default='fs'),
        sa.Column('lag', sa.Interval(), nullable=True),
    )

    op.create_table(
        'events',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('tenant_id', postgresql.UUID(as_uuid=False), nullable=True),
        sa.Column('bot_id', sa.BigInteger(), nullable=True),
        sa.Column('chat_id', sa.BigInteger(), nullable=True),
        sa.Column('team_id', postgresql.UUID(as_uuid=False), nullable=True),
        sa.Column('title', sa.Text(), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('location', sa.Text(), nullable=True),
        sa.Column('start_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('end_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('all_day', sa.Boolean(), nullable=False, server_default=sa.text('false')),
        sa.Column('recurrence_rrule', sa.Text(), nullable=True),
        sa.Column('recurrence_exdates', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('organizer_id', sa.BigInteger(), nullable=True),
        sa.Column('status', sa.Enum('planned','ongoing','done','canceled', name='event_status'), nullable=False, server_default='planned'),
        sa.Column('source_message_id', sa.BigInteger(), nullable=True),
        sa.Column('provenance_id', postgresql.UUID(as_uuid=False), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_by', sa.BigInteger(), nullable=True),
        sa.Column('updated_by', sa.BigInteger(), nullable=True),
    )

    op.create_table(
        'event_participants',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('event_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('user_id', sa.BigInteger(), nullable=False),
        sa.Column('response', sa.Enum('yes','no','maybe','none', name='event_response'), nullable=False, server_default='none'),
        sa.Column('checked_in_at', sa.DateTime(timezone=True), nullable=True),
    )

    # Reminders: создаём типы и таблицу, только если отсутствуют (idempotent)
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'reminder_target_type') THEN
                CREATE TYPE reminder_target_type AS ENUM ('task','event','note','message');
            END IF;
            IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'reminder_policy') THEN
                CREATE TYPE reminder_policy AS ENUM ('once','repeat','escalate','windowed');
            END IF;
            IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'reminder_status') THEN
                CREATE TYPE reminder_status AS ENUM ('scheduled','paused','sent','snoozed','canceled');
            END IF;
        END$$;
        """
    )
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='reminders'
            ) THEN
                CREATE TABLE reminders (
                    id uuid PRIMARY KEY,
                    tenant_id uuid NULL,
                    bot_id bigint NULL,
                    chat_id bigint NULL,
                    team_id uuid NULL,
                    target_type reminder_target_type NOT NULL,
                    target_id varchar(64) NOT NULL,
                    policy reminder_policy NOT NULL,
                    schedule_at timestamptz NULL,
                    cron text NULL,
                    window_before interval NULL,
                    timezone text NOT NULL DEFAULT 'UTC',
                    channels jsonb NULL,
                    message_template text NULL,
                    status reminder_status NOT NULL DEFAULT 'scheduled',
                    last_sent_at timestamptz NULL,
                    next_run_at timestamptz NULL,
                    retry_count integer NOT NULL DEFAULT 0,
                    created_at timestamptz NOT NULL DEFAULT now(),
                    updated_at timestamptz NOT NULL DEFAULT now(),
                    deleted_at timestamptz NULL,
                    created_by bigint NULL,
                    updated_by bigint NULL,
                    provenance_id uuid NULL
                );
            END IF;
        END$$;
        """
    )
    # Идемпотентно добавим недостающие колонки, если таблица уже существовала
    op.execute(
        """
        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='reminders'
            ) THEN
                IF NOT EXISTS (
                    SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='reminders' AND column_name='next_run_at'
                ) THEN
                    ALTER TABLE reminders ADD COLUMN next_run_at timestamptz NULL;
                END IF;
                IF NOT EXISTS (
                    SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='reminders' AND column_name='status'
                ) THEN
                    ALTER TABLE reminders ADD COLUMN status reminder_status NOT NULL DEFAULT 'scheduled';
                END IF;
            END IF;
        END$$;
        """
    )

    op.create_table(
        'chat_mined_facts',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('tenant_id', postgresql.UUID(as_uuid=False), nullable=True),
        sa.Column('bot_id', sa.BigInteger(), nullable=True),
        sa.Column('chat_id', sa.BigInteger(), nullable=False),
        sa.Column('message_id', sa.BigInteger(), nullable=False),
        sa.Column('intent', sa.Enum('task_create','task_update','event_create','status_update','due_change','assignment','note', name='mining_intent'), nullable=False),
        sa.Column('confidence', sa.Numeric(3,2), nullable=False),
        sa.Column('extracted', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('linked_task_id', postgresql.UUID(as_uuid=False), nullable=True),
        sa.Column('linked_event_id', postgresql.UUID(as_uuid=False), nullable=True),
        sa.Column('action_status', sa.Enum('proposed','confirmed','rejected','auto_applied', name='mining_action_status'), nullable=False, server_default='proposed'),
        sa.Column('confirmer_id', sa.BigInteger(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('trace_id', postgresql.UUID(as_uuid=False), nullable=True),
    )

    # indexes
    op.create_index('ix_tasks_team_status_due', 'tasks', ['team_id','status','due_at'])
    # Для GIN по text — используем pg_trgm и opclass gin_trgm_ops
    op.execute("CREATE EXTENSION IF NOT EXISTS pg_trgm")
    op.execute("CREATE INDEX IF NOT EXISTS ix_tasks_title_fulltext ON tasks USING gin (title gin_trgm_ops)")
    op.create_index('ix_tasks_labels_gin', 'tasks', ['labels'], postgresql_using='gin')
    op.execute(
        """
        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='reminders' AND column_name='next_run_at'
            ) AND EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='reminders' AND column_name='status'
            ) THEN
                CREATE INDEX IF NOT EXISTS ix_reminders_next ON reminders (next_run_at, status);
            END IF;
        END$$;
        """
    )
    op.create_index('ix_mining_chat_msg', 'chat_mined_facts', ['chat_id','message_id'])


def downgrade():
    op.drop_index('ix_mining_chat_msg', table_name='chat_mined_facts')
    op.drop_index('ix_reminders_next', table_name='reminders')
    op.drop_index('ix_tasks_labels_gin', table_name='tasks')
    op.drop_index('ix_tasks_title_fulltext', table_name='tasks')
    op.drop_index('ix_tasks_team_status_due', table_name='tasks')
    op.drop_table('chat_mined_facts')
    op.drop_table('reminders')
    op.drop_table('event_participants')
    op.drop_table('events')
    op.drop_table('task_dependencies')
    op.drop_table('task_assignments')
    op.drop_table('tasks')


