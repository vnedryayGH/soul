"""Add permissions column to roles and create soul role

Revision ID: 20250908_000022
Revises: 20250908_000021
Create Date: 2025-09-08 18:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
import json

# revision identifiers, used by Alembic.
revision = '20250908_000022'
down_revision = '20250908_000021'
branch_labels = None
depends_on = None


def upgrade():
    # Добавляем столбец permissions
    op.add_column('roles', sa.Column('permissions', postgresql.JSONB(), nullable=True))
    
    # Создаем индекс для permissions
    op.create_index('ix_roles_permissions', 'roles', ['permissions'], postgresql_using='gin')
    
    # Определяем полномочия для ролей
    architect_permissions = {
        "soul": {
            "read": True,
            "write": True,
            "admin": True,
            "settings": True,
            "prompts": True,
            "optimization": True,
            "cleanup": True,
            "import": True,
            "export": True
        },
        "users": {
            "read": True,
            "write": True,
            "admin": True,
            "roles": True
        },
        "system": {
            "admin": True,
            "monitoring": True,
            "logs": True,
            "backup": True
        }
    }
    
    soul_permissions = {
        "soul": {
            "read": True,
            "write": True,
            "admin": False,
            "settings": False,
            "prompts": False,
            "optimization": False,
            "cleanup": False,
            "import": False,
            "export": False
        },
        "users": {
            "read": False,
            "write": False,
            "admin": False,
            "roles": False
        },
        "system": {
            "admin": False,
            "monitoring": False,
            "logs": False,
            "backup": False
        }
    }
    
    admin_permissions = {
        "soul": {
            "read": True,
            "write": False,
            "admin": False,
            "settings": False,
            "prompts": False,
            "optimization": False,
            "cleanup": False,
            "import": False,
            "export": False
        },
        "users": {
            "read": True,
            "write": True,
            "admin": True,
            "roles": True
        },
        "system": {
            "admin": True,
            "monitoring": True,
            "logs": True,
            "backup": True
        }
    }
    
    # Обновляем существующие роли
    op.execute(f"""
        UPDATE roles 
        SET permissions = '{json.dumps(architect_permissions)}'::jsonb
        WHERE name = 'architect'
    """)
    
    op.execute(f"""
        UPDATE roles 
        SET permissions = '{json.dumps(admin_permissions)}'::jsonb
        WHERE name = 'admin'
    """)
    
    # Создаем роль Soul если её нет
    op.execute(f"""
        INSERT INTO roles (name, description, permissions, is_system, created_at, updated_at)
        SELECT 'soul', 'Soul AI Entity', '{json.dumps(soul_permissions)}'::jsonb, true, NOW(), NOW()
        WHERE NOT EXISTS (SELECT 1 FROM roles WHERE name = 'soul')
    """)
    
    # Устанавливаем базовые полномочия для остальных ролей
    basic_permissions = {
        "soul": {"read": False, "write": False, "admin": False},
        "users": {"read": False, "write": False, "admin": False},
        "system": {"admin": False, "monitoring": False, "logs": False}
    }
    
    op.execute(f"""
        UPDATE roles 
        SET permissions = '{json.dumps(basic_permissions)}'::jsonb
        WHERE permissions IS NULL
    """)


def downgrade():
    # Удаляем индекс
    op.drop_index('ix_roles_permissions', table_name='roles')
    
    # Удаляем роль soul
    op.execute("DELETE FROM roles WHERE name = 'soul'")
    
    # Удаляем столбец permissions
    op.drop_column('roles', 'permissions')
