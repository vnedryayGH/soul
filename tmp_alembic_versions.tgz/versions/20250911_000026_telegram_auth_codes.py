from __future__ import annotations

"""
v7+: telegram one-time auth codes for Architect login

Revision ID: 20250911_000026
Revises: 20250911_000025
Create Date: 2025-09-11 12:20:00.000000
"""

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250911_000026"
down_revision = "20250911_000025"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        create table if not exists telegram_auth_codes (
          id uuid primary key,
          user_id int not null references users(id) on delete cascade,
          code text not null unique,
          expires_at timestamptz not null,
          used_at timestamptz null,
          created_at timestamptz not null default now()
        );
        """
    )


def downgrade() -> None:
    # Do not drop table on downgrade for safety
    pass




