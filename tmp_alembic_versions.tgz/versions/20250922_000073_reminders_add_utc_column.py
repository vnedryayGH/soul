from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '20250922_000073_reminders_add_utc_column'
down_revision = '20250922_000072_frontman_issues'
branch_labels = None
depends_on = None


def upgrade() -> None:
	# 1) Добавляем колонку reminder_date_utc (nullable на этапе миграции)
	op.add_column('reminders', sa.Column('reminder_date_utc', sa.DateTime(), nullable=True))
	# 2) Backfill на основе текущей системной TZ (предполагаем Europe/Moscow как дефолт)
	#    Переводим локальное время (reminder_date) в UTC: reminder_date - interval '3 hours'
	#    Для простоты и отсутствия DST-знаний в SQL используем PostgreSQL AT TIME ZONE.
	#    Выражение: (reminder_date AT TIME ZONE 'Europe/Moscow') AT TIME ZONE 'UTC'
	op.execute("""
		UPDATE reminders
		SET reminder_date_utc = (
			(reminder_date AT TIME ZONE 'Europe/Moscow') AT TIME ZONE 'UTC'
		);
	""")
	# 3) Индекс по UTC-колонке для due-поиска
	op.create_index('idx_reminders_due_utc', 'reminders', ['reminder_date_utc'], unique=False)


def downgrade() -> None:
	try:
		op.drop_index('idx_reminders_due_utc', table_name='reminders')
	except Exception:
		pass
	op.drop_column('reminders', 'reminder_date_utc')
