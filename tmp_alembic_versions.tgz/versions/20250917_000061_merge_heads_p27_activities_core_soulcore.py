"""
Merge heads: p27_signature_tables + activities_core + soul_core_tables

Revision ID: 20250917_000061_merge_heads
Revises: 20250917_000060_p27_signature_tables, 20250915_090001_activities_core, 20250911_000037
Create Date: 2025-09-17 10:10:00
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa  # noqa: F401


revision = '20250917_000061_merge_heads'
down_revision = (
    '20250917_000060_p27_signature_tables',
    '20250915_090001_activities_core',
    '20250911_000037',
)
branch_labels = None
depends_on = None


def upgrade() -> None:
    # merge-only revision; no ops required
    pass


def downgrade() -> None:
    # merge-only revision; no ops required
    pass


