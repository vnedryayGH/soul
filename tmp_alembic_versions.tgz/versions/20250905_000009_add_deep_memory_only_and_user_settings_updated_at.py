"""
add deep_memory_only and user_settings.updated_at

Revision ID: 20250905_000009
Revises: 20250905_000008_add_core_indexes
Create Date: 2025-09-05 15:10:00.000000
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20250905_000009'
down_revision = '20250905_000008'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Безопасно добавляем колонку deep_memory_only
    op.execute("""
    ALTER TABLE user_prompt_settings
    ADD COLUMN IF NOT EXISTS deep_memory_only BOOLEAN DEFAULT FALSE;
    """)

    # Безопасно добавляем updated_at в user_settings
    op.execute("""
    ALTER TABLE user_settings
    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now();
    """)


def downgrade() -> None:
    # Откатываем изменения (без IF NOT EXISTS для совместимости)
    try:
        op.execute("ALTER TABLE user_prompt_settings DROP COLUMN IF EXISTS deep_memory_only;")
    except Exception:
        pass
    try:
        op.execute("ALTER TABLE user_settings DROP COLUMN IF EXISTS updated_at;")
    except Exception:
        pass


