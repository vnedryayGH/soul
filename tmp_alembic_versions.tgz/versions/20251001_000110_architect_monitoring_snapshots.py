from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = "20251001_000110_architect_monitoring_snapshots"
down_revision = "20250930_000100_p50_postmortem_versions"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Ensure pgcrypto for gen_random_uuid if available (best-effort)
    try:
        op.execute("CREATE EXTENSION IF NOT EXISTS pgcrypto")
    except Exception:
        pass

    op.create_table(
        "architect_monitoring_snapshots",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("created_at", sa.TIMESTAMP(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("source", sa.Text(), nullable=False, server_default=sa.text("'hyperloop'")),
        sa.Column("metrics", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("note", sa.Text(), nullable=True),
        sa.Column("tags", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
    )
    op.create_index("ix_arch_mon_snapshots_created_at", "architect_monitoring_snapshots", ["created_at"], unique=False)


def downgrade() -> None:
    try:
        op.drop_index("ix_arch_mon_snapshots_created_at", table_name="architect_monitoring_snapshots")
    except Exception:
        pass
    op.drop_table("architect_monitoring_snapshots")


