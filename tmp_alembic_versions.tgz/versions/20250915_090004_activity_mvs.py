"""Materialized views for energy balance and activity effectiveness

Revision ID: 20250915_090004_activity_mvs
Revises: 20250915_090001_activities_core
Create Date: 2025-09-15 09:00:04

"""
from alembic import op


revision = '20250915_090004_activity_mvs'
down_revision = '20250915_090001_activities_core'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # energy_balance_mv: агрегирует по часам из sensation_events
    op.execute(
        """
        create materialized view if not exists energy_balance_mv as
        select date_trunc('hour', created_at) as ts_hour,
               sum(coalesce((payload->>'energy_in')::numeric, 0)) as energy_in,
               sum(coalesce((payload->>'energy_out')::numeric, 0)) as energy_out,
               sum(coalesce((payload->>'sensations_delta')::numeric, 0)) as sensations_delta,
               avg(coalesce((payload->>'value_per_cost')::numeric, 0)) as value_per_cost_avg
          from sensation_events
         group by 1;

        create index if not exists idx_energy_balance_mv_ts on energy_balance_mv(ts_hour);
        """
    )

    # activity_effectiveness_mv: агрегирует эффективность по активности/дням из очереди
    op.execute(
        """
        create materialized view if not exists activity_effectiveness_mv as
        select activity_id,
               date_trunc('day', created_at) as ts_day,
               avg(coalesce((reason->>'energy')::numeric, 0)) as avg_energy,
               sum(coalesce((reason->>'completed_goals')::int, 0)) as completed_goals,
               avg(coalesce((reason->>'value_per_cost')::numeric, 0)) as value_per_cost_avg,
               count(*) filter (where status='queued')::int * 1.0 / nullif(count(*),0) as queue_share
          from flow_dispatch_queue
         group by 1,2;

        create index if not exists idx_activity_effectiveness_mv on activity_effectiveness_mv(activity_id, ts_day);
        """
    )


def downgrade() -> None:
    op.execute("drop index if exists idx_activity_effectiveness_mv;")
    op.execute("drop materialized view if exists activity_effectiveness_mv;")
    op.execute("drop index if exists idx_energy_balance_mv_ts;")
    op.execute("drop materialized view if exists energy_balance_mv;")


