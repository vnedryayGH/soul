"""
add flags to promo_redemptions for notifications

Revision ID: 20250907_000014
Revises: 20250907_000013
Create Date: 2025-09-07 12:22:14.000000
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20250907_000014'
down_revision = '20250907_000013'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('promo_redemptions', sa.Column('notify_3d_sent', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('promo_redemptions', sa.Column('notify_1d_sent', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('promo_redemptions', sa.Column('expired_processed', sa.Boolean(), nullable=False, server_default=sa.text('false')))


def downgrade() -> None:
    op.drop_column('promo_redemptions', 'expired_processed')
    op.drop_column('promo_redemptions', 'notify_1d_sent')
    op.drop_column('promo_redemptions', 'notify_3d_sent')


