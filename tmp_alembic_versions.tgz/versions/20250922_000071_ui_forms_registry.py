from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision = '20250922_000071_ui_forms_registry'
down_revision = '20250921_000070_p40'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'ui_forms',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('key', sa.String(length=100), nullable=False),
        sa.Column('name', sa.String(length=200), nullable=False),
        sa.Column('category', sa.String(length=1), nullable=False, server_default='F'),
        sa.Column('route', sa.String(length=255), nullable=False),
        sa.Column('roles', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('enabled', sa.Boolean(), nullable=False, server_default=sa.text('true')),
        sa.Column('owner', sa.String(length=100), nullable=True),
        sa.Column('status', sa.String(length=16), nullable=False, server_default='draft'),
        sa.Column('desc', sa.Text(), nullable=True),
        sa.Column('row_version', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('etag', sa.String(length=80), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('now()')),
        sa.UniqueConstraint('key', name='uq_ui_forms_key')
    )
    op.create_index('idx_ui_forms_category', 'ui_forms', ['category'], unique=False)
    op.create_index('idx_ui_forms_enabled', 'ui_forms', ['enabled'], unique=False)


def downgrade() -> None:
    op.drop_index('idx_ui_forms_enabled', table_name='ui_forms')
    op.drop_index('idx_ui_forms_category', table_name='ui_forms')
    op.drop_table('ui_forms')


