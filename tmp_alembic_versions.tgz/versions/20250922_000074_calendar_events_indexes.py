from __future__ import annotations

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20250922_000074_calendar_events_indexes'
down_revision = '20250922_000073_reminders_add_utc_column'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Индексы для таблицы events (если существует)
    try:
        op.execute("CREATE INDEX IF NOT EXISTS ix_events_start_at ON events(start_at)")
    except Exception:
        pass
    try:
        op.execute("CREATE INDEX IF NOT EXISTS ix_events_end_at ON events(end_at)")
    except Exception:
        pass
    try:
        op.execute("CREATE INDEX IF NOT EXISTS ix_events_status ON events(status)")
    except Exception:
        pass
    # Часто фильтруем по владельцу/организатору (owner_id/tg_id/organizer_id, если такие поля присутствуют)
    for col in ("owner_id", "tg_id", "organizer_id"):
        try:
            op.execute(f"CREATE INDEX IF NOT EXISTS ix_events_{col} ON events({col})")
        except Exception:
            pass


def downgrade() -> None:
    # Удаление индексов (идемпотентность не гарантируется при старых БД)
    for name in (
        "ix_events_start_at",
        "ix_events_end_at",
        "ix_events_status",
        "ix_events_owner_id",
        "ix_events_tg_id",
        "ix_events_organizer_id",
    ):
        try:
            op.execute(f"DROP INDEX IF EXISTS {name}")
        except Exception:
            pass


