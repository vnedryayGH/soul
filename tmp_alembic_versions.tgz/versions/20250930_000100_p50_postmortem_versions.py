"""
P50 Postmortem versions table

Revision ID: 20250930_000100_p50_postmortem_versions
Revises: 20250928_000090_p50_incidents_backfill_from_soul_incidents
Create Date: 2025-09-30 13:00:00

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = '20250930_000100_p50_postmortem_versions'
down_revision = '20250928_000090_p50_incidents_backfill_from_soul_incidents'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'incident_postmortem_versions',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('incident_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('status', sa.Text(), nullable=False),  # 'draft' | 'final'
        sa.Column('content_md', sa.Text(), nullable=False),
        sa.Column('created_by_tg_id', sa.BigInteger(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('now()')),
        sa.ForeignKeyConstraint(['incident_id'], ['incidents.id'], ondelete='CASCADE'),
    )
    op.create_index('ix_postmortem_versions_incident', 'incident_postmortem_versions', ['incident_id'])
    op.create_index('ix_postmortem_versions_status', 'incident_postmortem_versions', ['status'])


def downgrade():
    op.drop_index('ix_postmortem_versions_status', table_name='incident_postmortem_versions')
    op.drop_index('ix_postmortem_versions_incident', table_name='incident_postmortem_versions')
    op.drop_table('incident_postmortem_versions')


