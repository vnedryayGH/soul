"""prompt file architecture

Revision ID: 20250811_000002
Revises: 20250811_000001
Create Date: 2025-01-11 00:00:02.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '20250811_000002'
down_revision = '20250811_000001_init'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Удаляем старые поля и добавляем новые для архитектуры файлов
    op.drop_column('prompts', 'prompt_text')
    op.drop_column('prompts', 'icon_url')
    
    op.add_column('prompts', sa.Column('file_path', sa.String(length=500), nullable=False))
    op.add_column('prompts', sa.Column('icon_emoji', sa.String(length=10), nullable=True))
    op.add_column('prompts', sa.Column('icon_color', sa.String(length=10), nullable=True))
    op.add_column('prompts', sa.Column('category', sa.String(length=100), nullable=True))
    op.add_column('prompts', sa.Column('features', sa.Text(), nullable=True))
    op.add_column('prompts', sa.Column('target_audience', sa.Text(), nullable=True))
    op.add_column('prompts', sa.Column('activation_triggers', sa.Text(), nullable=True))


def downgrade() -> None:
    # Возвращаем старую структуру
    op.drop_column('prompts', 'activation_triggers')
    op.drop_column('prompts', 'target_audience')
    op.drop_column('prompts', 'features')
    op.drop_column('prompts', 'category')
    op.drop_column('prompts', 'icon_color')
    op.drop_column('prompts', 'icon_emoji')
    op.drop_column('prompts', 'file_path')
    
    op.add_column('prompts', sa.Column('icon_url', sa.VARCHAR(length=500), autoincrement=False, nullable=True))
    op.add_column('prompts', sa.Column('prompt_text', sa.TEXT(), autoincrement=False, nullable=True))
