"""P40 Project Management: projects/risks/changes; tasks extensions

Revision ID: 20250921_000070_p40
Revises: 20250920_000064_p11_provenance_edges
Create Date: 2025-09-21 00:00:70

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision = '20250921_000070_p40'
down_revision = '20250920_000064_p11_provenance'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # projects table
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='projects'
            ) THEN
                CREATE TABLE projects (
                    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                    name text NOT NULL,
                    description text NULL,
                    methodology text NULL,
                    priority numeric(3,2) NULL,
                    owner bigint NULL,
                    status text NOT NULL DEFAULT 'active',
                    created_at timestamptz NOT NULL DEFAULT now(),
                    updated_at timestamptz NOT NULL DEFAULT now()
                );
                CREATE INDEX IF NOT EXISTS ix_projects_owner ON projects(owner);
                CREATE INDEX IF NOT EXISTS ix_projects_status ON projects(status);
            END IF;
        END$$;
        """
    )

    # tasks extensions (link to projects, CPM duration)
    op.execute(
        """
        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='tasks'
            ) THEN
                IF NOT EXISTS (
                    SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='tasks' AND column_name='project_id'
                ) THEN
                    ALTER TABLE tasks ADD COLUMN project_id uuid NULL;
                    CREATE INDEX IF NOT EXISTS ix_tasks_project ON tasks(project_id);
                END IF;
                IF NOT EXISTS (
                    SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='tasks' AND column_name='cpm_duration_days'
                ) THEN
                    ALTER TABLE tasks ADD COLUMN cpm_duration_days numeric(10,2) NULL;
                END IF;
            END IF;
        END$$;
        """
    )

    # risks table
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='risks'
            ) THEN
                CREATE TABLE risks (
                    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                    project_id uuid NOT NULL,
                    title text NOT NULL,
                    severity text NOT NULL,
                    probability text NOT NULL,
                    status text NOT NULL DEFAULT 'open',
                    owner bigint NULL,
                    created_at timestamptz NOT NULL DEFAULT now(),
                    updated_at timestamptz NOT NULL DEFAULT now()
                );
                CREATE INDEX IF NOT EXISTS ix_risks_project ON risks(project_id);
            END IF;
        END$$;
        """
    )

    # changes table
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='changes'
            ) THEN
                CREATE TABLE changes (
                    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                    project_id uuid NOT NULL,
                    title text NOT NULL,
                    change_type text NOT NULL,
                    reason text NULL,
                    approved boolean NULL,
                    request_id uuid NULL,
                    created_at timestamptz NOT NULL DEFAULT now(),
                    updated_at timestamptz NOT NULL DEFAULT now()
                );
                CREATE INDEX IF NOT EXISTS ix_changes_project ON changes(project_id);
            END IF;
        END$$;
        """
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS changes")
    op.execute("DROP TABLE IF EXISTS risks")
    # keep tasks columns; do not drop to avoid breaking existing data
    op.execute("DROP TABLE IF EXISTS projects")


