"""Add current_chat_mode to users table

Revision ID: 20250912_add_current_chat_mode
Revises: 20250911_000029_family_activity_comm
Create Date: 2025-09-12 12:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20250912_add_current_chat_mode'
down_revision = '20250911_000036'
branch_labels = None
depends_on = None


def upgrade():
    # Добавляем поле для хранения текущего режима чата пользователя
    op.add_column('users', sa.Column('current_chat_mode', sa.String(32), nullable=True, default='user_dialog'))
    
    # Устанавливаем значение по умолчанию для существующих пользователей
    op.execute("UPDATE users SET current_chat_mode = 'user_dialog' WHERE current_chat_mode IS NULL")
    
    # Делаем поле обязательным
    op.alter_column('users', 'current_chat_mode', nullable=False)


def downgrade():
    op.drop_column('users', 'current_chat_mode')
