"""activities core with row_version

Revision ID: 20250915_090001_activities_core
Revises: 20250915_000046
Create Date: 2025-09-15 09:00:01

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = '20250915_090001_activities_core'
down_revision = '20250915_000046'
branch_labels = None
depends_on = None


def upgrade():
    # activities
    op.create_table(
        'activities',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('name', sa.Text(), nullable=False),
        sa.Column('persona_prompt_id', sa.Integer(), nullable=True),
        sa.Column('priority', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('time_min_min', sa.Integer(), nullable=True),
        sa.Column('time_max_min', sa.Integer(), nullable=True),
        sa.Column('satisfaction_policy', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('actions_prompt', sa.Text(), nullable=True),
        sa.Column('official_identity', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('enabled', sa.Boolean(), nullable=False, server_default=sa.text('true')),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('row_version', sa.Integer(), nullable=False, server_default='1'),
    )
    op.create_index('idx_activities_enabled', 'activities', ['enabled'])
    op.create_index('idx_activities_priority', 'activities', ['priority'])

    # permissions
    op.create_table(
        'activity_permissions',
        sa.Column('activity_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('permission', sa.Text(), nullable=False),
        sa.PrimaryKeyConstraint('activity_id', 'permission'),
        sa.ForeignKeyConstraint(['activity_id'], ['activities.id'], ondelete='CASCADE')
    )

    # goals link
    op.create_table(
        'activity_goals',
        sa.Column('activity_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('goal_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('goal_type', sa.Text(), nullable=False, server_default='regular'),
        sa.Column('metrics', postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.PrimaryKeyConstraint('activity_id', 'goal_id'),
        sa.ForeignKeyConstraint(['activity_id'], ['activities.id'], ondelete='CASCADE')
    )

    # schedules
    op.create_table(
        'activity_schedules',
        sa.Column('activity_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('cron', sa.Text(), nullable=True),
        sa.Column('window', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('timezone', sa.Text(), nullable=True),
        sa.Column('enabled', sa.Boolean(), nullable=False, server_default=sa.text('true')),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.PrimaryKeyConstraint('activity_id'),
        sa.ForeignKeyConstraint(['activity_id'], ['activities.id'], ondelete='CASCADE')
    )
    op.create_index('idx_activity_schedules_enabled', 'activity_schedules', ['enabled'])

    # sensations
    op.create_table(
        'sensation_settings',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('name', sa.Text(), nullable=False),
        sa.Column('enabled', sa.Boolean(), nullable=False, server_default=sa.text('true')),
        sa.Column('severity_min', sa.Float(), nullable=True),
        sa.Column('severity_max', sa.Float(), nullable=True),
        sa.Column('weight', sa.Float(), nullable=True),
        sa.Column('params', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('row_version', sa.Integer(), nullable=False, server_default='1'),
    )

    op.create_table(
        'sensation_events',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('type', sa.Text(), nullable=False),
        sa.Column('severity', sa.Float(), nullable=True),
        sa.Column('payload', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    )
    op.create_index('idx_sensation_events_type', 'sensation_events', ['type'])
    op.create_index('idx_sensation_events_created', 'sensation_events', ['created_at'])


def downgrade():
    op.drop_index('idx_sensation_events_created', table_name='sensation_events')
    op.drop_index('idx_sensation_events_type', table_name='sensation_events')
    op.drop_table('sensation_events')
    op.drop_table('sensation_settings')
    op.drop_index('idx_activity_schedules_enabled', table_name='activity_schedules')
    op.drop_table('activity_schedules')
    op.drop_table('activity_goals')
    op.drop_table('activity_permissions')
    op.drop_index('idx_activities_priority', table_name='activities')
    op.drop_index('idx_activities_enabled', table_name='activities')
    op.drop_table('activities')


