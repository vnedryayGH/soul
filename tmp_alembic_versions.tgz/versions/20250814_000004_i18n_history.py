"""i18n history

Revision ID: 20250814_000004
Revises: 20250814_000003
Create Date: 2025-08-14 00:20:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "20250814_000004"
down_revision = "20250814_000003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "i18n_history",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("namespace", sa.String(length=64), nullable=False),
        sa.Column("key", sa.String(length=190), nullable=False),
        sa.Column("locale", sa.String(length=10), nullable=False),
        sa.Column("value_old", sa.Text(), nullable=True),
        sa.Column("value_new", sa.Text(), nullable=True),
        sa.Column("version_new", sa.Integer(), nullable=False),
        sa.Column("operation", sa.String(length=16), nullable=False),
        sa.Column("changed_by_user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("changed_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_i18n_history_loc_ns_key", "i18n_history", ["locale", "namespace", "key"], unique=False)


def downgrade() -> None:
    op.drop_index("ix_i18n_history_loc_ns_key", table_name="i18n_history")
    op.drop_table("i18n_history")


