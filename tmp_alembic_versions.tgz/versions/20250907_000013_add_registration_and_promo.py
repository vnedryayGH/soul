"""
add registration and promo tables

Revision ID: 20250907_000013
Revises: 20250907_000012
Create Date: 2025-09-07 12:00:13.000000
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20250907_000013'
down_revision = '20250907_000012'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # promo_codes
    op.create_table(
        'promo_codes',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('code', sa.String(length=64), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('role_name', sa.String(length=50), nullable=False),
        sa.Column('total_limit', sa.Integer(), nullable=True),
        sa.Column('redeemed_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('valid_from', sa.DateTime(), nullable=True),
        sa.Column('valid_to', sa.DateTime(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default=sa.text('true')),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.UniqueConstraint('code', name='uq_promo_codes_code')
    )
    op.create_index('idx_promo_active', 'promo_codes', ['is_active'])

    # promo_redemptions
    op.create_table(
        'promo_redemptions',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('promo_code_id', sa.Integer(), sa.ForeignKey('promo_codes.id', ondelete='CASCADE'), nullable=False),
        sa.Column('user_id', sa.Integer(), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=False),
        sa.Column('redeemed_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('note', sa.Text(), nullable=True),
        sa.UniqueConstraint('user_id', 'promo_code_id', name='uq_user_promo_once')
    )
    op.create_index('idx_redemptions_promo', 'promo_redemptions', ['promo_code_id'])
    op.create_index('idx_redemptions_user', 'promo_redemptions', ['user_id'])

    # registration_requests
    op.create_table(
        'registration_requests',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('user_id', sa.Integer(), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=False),
        sa.Column('comment', sa.Text(), nullable=True),
        sa.Column('status', sa.String(length=20), nullable=False, server_default='pending'),
        sa.Column('approved_by_user_id', sa.Integer(), sa.ForeignKey('users.id', ondelete='SET NULL'), nullable=True),
        sa.Column('approved_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
    )
    op.create_index('idx_regreq_status', 'registration_requests', ['status'])


def downgrade() -> None:
    op.drop_index('idx_regreq_status', table_name='registration_requests')
    op.drop_table('registration_requests')
    op.drop_index('idx_redemptions_user', table_name='promo_redemptions')
    op.drop_index('idx_redemptions_promo', table_name='promo_redemptions')
    op.drop_table('promo_redemptions')
    op.drop_index('idx_promo_active', table_name='promo_codes')
    op.drop_table('promo_codes')


