"""
Add updated_at to processor_events and update trigger

Revision ID: 20250924_000090_add_updated_at
Revises: 20250917_000062_p30_proc
Create Date: 2025-09-24 18:05:00
"""

from __future__ import annotations

from alembic import op


revision = "20250924_000090_add_updated_at"
down_revision = "20250917_000062_p30_proc"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Add column updated_at if missing
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns
                WHERE table_schema='public' AND table_name='processor_events' AND column_name='updated_at'
            ) THEN
                ALTER TABLE processor_events
                ADD COLUMN updated_at timestamp without time zone DEFAULT now();
            END IF;
        END$$;
        """
    )

    # Optional: upsert trigger to keep updated_at fresh on updates (idempotent)
    op.execute(
        """
        CREATE OR REPLACE FUNCTION set_updated_at()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at := now();
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        """
    )
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM pg_trigger WHERE tgname = 'trg_processor_events_updated_at'
            ) THEN
                CREATE TRIGGER trg_processor_events_updated_at
                BEFORE UPDATE ON processor_events
                FOR EACH ROW EXECUTE FUNCTION set_updated_at();
            END IF;
        END$$;
        """
    )


def downgrade() -> None:
    # Drop trigger and column if exist (safe rollback)
    op.execute(
        """
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_processor_events_updated_at') THEN
                DROP TRIGGER trg_processor_events_updated_at ON processor_events;
            END IF;
        END$$;
        """
    )
    op.execute(
        """
        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.columns
                WHERE table_schema='public' AND table_name='processor_events' AND column_name='updated_at'
            ) THEN
                ALTER TABLE processor_events DROP COLUMN updated_at;
            END IF;
        END$$;
        """
    )


