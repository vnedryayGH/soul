from __future__ import annotations

"""
P51: Soul Personality core tables (soul_personality, norms, traits, attachments, links, policies)

Revision ID: 20250929_000092
Revises: 20250929_000091
Create Date: 2025-09-29 02:05:00.000000
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision = "20250929_000092"
down_revision = "20250929_000091"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Ensure required extension for UUIDs
    op.execute("CREATE EXTENSION IF NOT EXISTS pgcrypto")

    # soul_personality
    op.create_table(
        "soul_personality",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("version", sa.Text(), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("sex", sa.Text(), nullable=False),
        sa.Column("anima_animus", sa.Float(), nullable=True),
        sa.Column("created_by_tg_id", sa.BigInteger(), nullable=True),
        sa.Column("meta", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )

    # norms
    op.create_table(
        "soul_personality_norms",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("personality_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("soul_personality.id", ondelete="CASCADE"), nullable=False),
        sa.Column("key", sa.Text(), nullable=False, unique=True),
        sa.Column("title", sa.Text(), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("severity", sa.Float(), nullable=False),
        sa.Column("scope", sa.Text(), nullable=False),
        sa.Column("meta", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
    )
    op.create_index("ix_spn_personality", "soul_personality_norms", ["personality_id"]) 

    # traits
    op.create_table(
        "soul_personality_traits",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("personality_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("soul_personality.id", ondelete="CASCADE"), nullable=False),
        sa.Column("key", sa.Text(), nullable=False),
        sa.Column("trait_family", sa.Text(), nullable=True),
        sa.Column("tendency", sa.Float(), nullable=True),
        sa.Column("stability", sa.Float(), nullable=True),
        sa.Column("meta", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
    )
    op.create_index("ix_spt_personality", "soul_personality_traits", ["personality_id"]) 

    # attachments
    op.create_table(
        "soul_personality_attachments",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("personality_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("soul_personality.id", ondelete="CASCADE"), nullable=False),
        sa.Column("key", sa.Text(), nullable=False),
        sa.Column("baseline_weight", sa.Float(), nullable=False),
        sa.Column("growth_policy", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("meta", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
    )
    op.create_index("ix_spa_personality", "soul_personality_attachments", ["personality_id"]) 

    # links
    op.create_table(
        "soul_personality_links",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("personality_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("soul_personality.id", ondelete="CASCADE"), nullable=False),
        sa.Column("element_kind", sa.Text(), nullable=False),
        sa.Column("element_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("core_quant_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("relation_weight", sa.Float(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("ix_spl_personality", "soul_personality_links", ["personality_id"]) 
    op.create_index("ix_spl_core_quant", "soul_personality_links", ["core_quant_id"]) 

    # policies
    op.create_table(
        "soul_personality_policies",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("personality_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("soul_personality.id", ondelete="CASCADE"), nullable=False),
        sa.Column("key", sa.Text(), nullable=False),
        sa.Column("value", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("ix_spp_personality", "soul_personality_policies", ["personality_id"]) 
    # Composite uniqueness per personality
    op.create_unique_constraint("uq_spp_personality_key", "soul_personality_policies", ["personality_id", "key"]) 

    # Optional: ensure core_quants table presence (light shim). Only create if missing explicit cores schema.
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.tables 
                WHERE table_schema = 'public' AND table_name = 'core_quants'
            ) THEN
                CREATE TABLE core_quants (
                  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                  quant_id uuid NOT NULL,
                  is_core boolean NOT NULL DEFAULT true,
                  rank int,
                  weight float,
                  tags text[],
                  meta jsonb DEFAULT '{}'::jsonb,
                  created_at timestamptz DEFAULT now(),
                  updated_at timestamptz DEFAULT now()
                );
                CREATE INDEX IF NOT EXISTS ix_core_quants_quant ON core_quants(quant_id);
            END IF;
        END
        $$;
        """
    )

    # Optional: add class/purpose columns to quants if not exist (per P51 Appx B)
    op.execute("ALTER TABLE IF EXISTS quants ADD COLUMN IF NOT EXISTS class text")
    op.execute("ALTER TABLE IF EXISTS quants ADD COLUMN IF NOT EXISTS purpose text")
    op.execute("CREATE INDEX IF NOT EXISTS ix_quants_class ON quants(class)")

    # P51 GIN Indexes on JSONB for personality tables (meta/value)
    try:
        op.execute("CREATE INDEX IF NOT EXISTS ix_soul_personality_meta_gin ON soul_personality USING gin(meta)")
    except Exception:
        pass
    try:
        op.execute("CREATE INDEX IF NOT EXISTS ix_soul_personality_norms_meta_gin ON soul_personality_norms USING gin(meta)")
    except Exception:
        pass
    try:
        op.execute("CREATE INDEX IF NOT EXISTS ix_soul_personality_traits_meta_gin ON soul_personality_traits USING gin(meta)")
    except Exception:
        pass
    try:
        op.execute("CREATE INDEX IF NOT EXISTS ix_soul_personality_attachments_meta_gin ON soul_personality_attachments USING gin(meta)")
    except Exception:
        pass
    try:
        op.execute("CREATE INDEX IF NOT EXISTS ix_soul_personality_policies_value_gin ON soul_personality_policies USING gin(value)")
    except Exception:
        pass


def downgrade() -> None:
    # Drop in reverse order
    op.drop_index("ix_spp_personality", table_name="soul_personality_policies")
    op.drop_table("soul_personality_policies")

    op.drop_index("ix_spl_core_quant", table_name="soul_personality_links")
    op.drop_index("ix_spl_personality", table_name="soul_personality_links")
    op.drop_table("soul_personality_links")

    op.drop_index("ix_spa_personality", table_name="soul_personality_attachments")
    op.drop_table("soul_personality_attachments")

    op.drop_index("ix_spt_personality", table_name="soul_personality_traits")
    op.drop_table("soul_personality_traits")

    op.drop_index("ix_spn_personality", table_name="soul_personality_norms")
    op.drop_table("soul_personality_norms")

    op.drop_table("soul_personality")


