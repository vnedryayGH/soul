"""
Create persona_voice_profile and user_persona_voice tables (P19)

Revision ID: 20250920_tts_persona_voice
Revises: 
Create Date: 2025-09-20
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20250920_tts_persona_voice'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # persona_voice_profile: один профиль на persona_key
    op.create_table(
        'persona_voice_profile',
        sa.Column('persona_key', sa.Text(), primary_key=True, nullable=False),
        sa.Column('tts_voice_id', sa.Text(), nullable=False),
        sa.Column('tts_rate', sa.Numeric(5, 2), nullable=True, server_default=sa.text('1.00')),
        sa.Column('tts_pitch', sa.Numeric(5, 2), nullable=True, server_default=sa.text('0.00')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('NOW()')),
    )

    # user_persona_voice: переопределение на пользователя
    op.create_table(
        'user_persona_voice',
        sa.Column('user_id', sa.BigInteger(), nullable=False),
        sa.Column('persona_key', sa.Text(), nullable=False),
        sa.Column('tts_voice_id', sa.Text(), nullable=False),
        sa.Column('tts_rate', sa.Numeric(5, 2), nullable=True),
        sa.Column('tts_pitch', sa.Numeric(5, 2), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('NOW()')),
        sa.PrimaryKeyConstraint('user_id', 'persona_key', name='pk_user_persona_voice'),
    )

    # Индексы для быстрых выборок
    op.create_index('idx_user_persona_voice_user', 'user_persona_voice', ['user_id'])
    op.create_index('idx_user_persona_voice_persona', 'user_persona_voice', ['persona_key'])


def downgrade() -> None:
    try:
        op.drop_index('idx_user_persona_voice_user', table_name='user_persona_voice')
    except Exception:
        pass
    try:
        op.drop_index('idx_user_persona_voice_persona', table_name='user_persona_voice')
    except Exception:
        pass
    op.drop_table('user_persona_voice')
    op.drop_table('persona_voice_profile')


