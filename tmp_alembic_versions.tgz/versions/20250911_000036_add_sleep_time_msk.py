"""
add sleep_time_msk to soul_settings

Revision ID: 20250911_000036
Revises: 20250911_000035
Create Date: 2025-09-11 10:55:00
"""

from __future__ import annotations

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250911_000036"
down_revision = "20250911_000035"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Добавляем колонку, если её нет. Тип: time без часового пояса.
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns
                 WHERE table_schema = 'public'
                   AND table_name = 'soul_settings'
                   AND column_name = 'sleep_time_msk'
            ) THEN
                ALTER TABLE soul_settings ADD COLUMN sleep_time_msk time;
            END IF;
        END$$;
        """
    )


def downgrade() -> None:
    # Удаляем колонку при откате, если существует
    op.execute(
        """
        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.columns
                 WHERE table_schema = 'public'
                   AND table_name = 'soul_settings'
                   AND column_name = 'sleep_time_msk'
            ) THEN
                ALTER TABLE soul_settings DROP COLUMN sleep_time_msk;
            END IF;
        END$$;
        """
    )


