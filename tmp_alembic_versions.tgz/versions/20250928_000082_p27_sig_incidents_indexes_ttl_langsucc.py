"""
P27/P48R: индексы signature_incidents; DDL lang_succession_*; TTL policy stubs

Revision ID: 20250928_000082
Revises: 20250925_000081
Create Date: 2025-09-28 23:10:00
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "20250928_000082"
down_revision = "20250925_000081"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # signature_incidents indexes (if table exists)
    try:
        op.execute(
            """
            DO $$
            BEGIN
              IF to_regclass('public.signature_incidents') IS NOT NULL THEN
                CREATE INDEX IF NOT EXISTS idx_sig_inc_created_at ON signature_incidents (created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_sig_inc_type ON signature_incidents (incident_type);
                CREATE INDEX IF NOT EXISTS idx_sig_inc_fn ON signature_incidents (function_id);
              END IF;
            END$$;
            """
        )
    except Exception:
        pass

    # lang_succession_* tables
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS lang_succession_registry (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          lang_from TEXT NOT NULL,
          lang_to   TEXT NOT NULL,
          policy    JSONB,
          created_at TIMESTAMPTZ DEFAULT now(),
          updated_at TIMESTAMPTZ DEFAULT now()
        );
        CREATE UNIQUE INDEX IF NOT EXISTS uq_lang_succession ON lang_succession_registry(lang_from, lang_to);

        CREATE TABLE IF NOT EXISTS lang_succession_history (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          registry_id UUID REFERENCES lang_succession_registry(id) ON DELETE CASCADE,
          changed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          change JSONB
        );
        CREATE INDEX IF NOT EXISTS idx_lang_succ_hist_reg ON lang_succession_history(registry_id);
        """
    )

    # TTL/archive policies (best-effort; executed only if pg_cron/TTL extension configured externally)
    op.execute(
        """
        -- Храним 30 дней signature_incidents; удаление старше 30d (если доступна pg_cron/extension)
        -- Политика задаётся через настройки приложения/cron-сервис и может отсутствовать в окружении; SQL безопасен
        DO $$ BEGIN END $$;
        """
    )


def downgrade() -> None:
    # Safe drops
    op.execute(
        """
        DROP INDEX IF EXISTS idx_sig_inc_created_at;
        DROP INDEX IF EXISTS idx_sig_inc_type;
        DROP INDEX IF EXISTS idx_sig_inc_fn;
        """
    )
    op.execute(
        """
        DROP TABLE IF EXISTS lang_succession_history;
        DROP TABLE IF EXISTS lang_succession_registry;
        """
    )


