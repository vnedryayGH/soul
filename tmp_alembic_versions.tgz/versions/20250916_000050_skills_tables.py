"""
P25: skills tables (create if not exists)

This migration adds tables required for Skills/Routes (P25):
- skills
- skill_steps
- skill_links
- skill_assets

We use raw SQL with IF NOT EXISTS to be resilient to PROD drift.
"""

from typing import Optional

from alembic import op


# Revision identifiers, used by Alembic.
revision: str = "20250916_000050_skills_tables"
down_revision: Optional[str] = "20250915_090004_activity_mvs"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # schemas
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS public.skills (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            name TEXT NOT NULL,
            version TEXT NOT NULL,
            description TEXT,
            tags TEXT[] DEFAULT '{}',
            enabled BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE UNIQUE INDEX IF NOT EXISTS ux_skills_name_version ON public.skills (name, version);

        CREATE TABLE IF NOT EXISTS public.skill_steps (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
            step_order INTEGER NOT NULL,
            name TEXT NOT NULL,
            step_type TEXT NOT NULL,
            dsl JSONB,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE INDEX IF NOT EXISTS ix_skill_steps_skill_id ON public.skill_steps (skill_id);
        CREATE INDEX IF NOT EXISTS ix_skill_steps_order ON public.skill_steps (skill_id, step_order);

        CREATE TABLE IF NOT EXISTS public.skill_links (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
            from_step_id UUID NOT NULL REFERENCES public.skill_steps(id) ON DELETE CASCADE,
            to_step_id UUID NOT NULL REFERENCES public.skill_steps(id) ON DELETE CASCADE,
            relation_type TEXT NOT NULL DEFAULT 'next',
            metadata JSONB,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE INDEX IF NOT EXISTS ix_skill_links_skill_id ON public.skill_links (skill_id);
        CREATE INDEX IF NOT EXISTS ix_skill_links_from_to ON public.skill_links (from_step_id, to_step_id);

        CREATE TABLE IF NOT EXISTS public.skill_assets (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
            step_id UUID REFERENCES public.skill_steps(id) ON DELETE CASCADE,
            asset_type TEXT NOT NULL,
            uri TEXT,
            content JSONB,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE INDEX IF NOT EXISTS ix_skill_assets_skill_id ON public.skill_assets (skill_id);
        CREATE INDEX IF NOT EXISTS ix_skill_assets_step_id ON public.skill_assets (step_id);
        """
    )


def downgrade() -> None:
    # Keep data by default; drop in reverse order for consistency
    op.execute(
        """
        DROP TABLE IF EXISTS public.skill_assets;
        DROP TABLE IF EXISTS public.skill_links;
        DROP TABLE IF EXISTS public.skill_steps;
        DROP TABLE IF EXISTS public.skills;
        """
    )


