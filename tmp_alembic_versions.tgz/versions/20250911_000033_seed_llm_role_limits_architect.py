from __future__ import annotations

"""
Seed Architect role into llm_role_limits once schema is aligned

Revision ID: 20250911_000033
Revises: 20250911_000032
Create Date: 2025-09-11 15:40:00.000000
"""

from alembic import op


revision = "20250911_000033"
down_revision = "20250911_000032"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        do $$ begin
          -- Выполняем seed ТОЛЬКО если в схеме НЕТ столбца role_id (иначе сид выполнит 000035)
          if exists (select 1 from information_schema.tables where table_name='llm_role_limits')
             and not exists (select 1 from information_schema.columns where table_name='llm_role_limits' and column_name='role_id')
             and exists (select 1 from information_schema.columns where table_name='llm_role_limits' and column_name='role') then
            -- Insert using only guaranteed columns to avoid undefined column errors
            if exists (select 1 from information_schema.columns where table_name='llm_role_limits' and column_name='priority_boost') then
              insert into llm_role_limits (role, priority_boost)
              values ('Architect', 1.0)
              on conflict (role) do nothing;
            else
              insert into llm_role_limits (role)
              values ('Architect')
              on conflict (role) do nothing;
            end if;
          end if;
        end $$;
        """
    )


def downgrade() -> None:
    # keep seed
    pass


