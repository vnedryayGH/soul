"""Add row_version (timestamptz) to core P20 tables

Revision ID: 20250915_000042_row_version
Revises: 20250915_000041_p20_stage3
Create Date: 2025-09-15 00:18:42

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20250915_000042_row_version'
down_revision = '20250915_000041_p20_stage3'
branch_labels = None
depends_on = None


def upgrade():
    for table in ('tasks','events','reminders','sprints'):
        op.add_column(table, sa.Column('row_version', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False))
        # обновлять по триггеру БД предпочтительно; временно — on update в приложении


def downgrade():
    for table in ('tasks','events','reminders','sprints'):
        op.drop_column(table, 'row_version')


