"""
P50 backfill: migrate data from legacy soul_incidents to incidents

Revision ID: 20250928_000090_p50_incidents_backfill_from_soul_incidents
Revises: 20250926_000080_p50_incident_management
Create Date: 2025-09-28 12:00:00

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = '20250928_000090_p50_incidents_backfill_from_soul_incidents'
down_revision = '20250926_000080_p50_incident_management'
branch_labels = None
depends_on = None


def upgrade():
    # Map ENUM severity/status to new numeric/status model and copy data best-effort.
    # We reuse same UUIDs to preserve references if any exist in external systems.
    op.execute(
        sa.text(
            """
            DO $$
            BEGIN
                IF EXISTS (
                    SELECT 1 FROM information_schema.tables 
                    WHERE table_schema='public' AND table_name='soul_incidents'
                ) THEN
                    -- Insert rows that don't exist in new table yet
                    INSERT INTO incidents (
                        id, title, description, severity, priority, status,
                        detected_at, acknowledged_at, resolved_at, closed_at,
                        source, trace_id, root_cause, resolution, runbook_id, plan_task_id,
                        reporter_tg_id, assignee_tg_id, tags, meta, created_at, updated_at
                    )
                    SELECT
                        si.id,
                        si.title,
                        si.description,
                        CASE si.severity
                            WHEN 'critical' THEN 1
                            WHEN 'high' THEN 2
                            WHEN 'medium' THEN 3
                            WHEN 'low' THEN 4
                            ELSE 3
                        END as severity,
                        3 as priority,
                        CASE si.status
                            WHEN 'resolved' THEN 'closed'
                            WHEN 'open' THEN 'open'
                            WHEN 'mitigated' THEN 'mitigated'
                            ELSE 'open'
                        END as status,
                        si.detected_at,
                        NULL::timestamptz as acknowledged_at,
                        si.resolved_at,
                        CASE WHEN si.status='resolved' AND si.resolved_at IS NOT NULL THEN si.resolved_at ELSE NULL::timestamptz END as closed_at,
                        'p21' as source,
                        NULL::uuid as trace_id,
                        NULL::text as root_cause,
                        NULL::text as resolution,
                        NULL::uuid as runbook_id,
                        NULL::uuid as plan_task_id,
                        NULL::bigint as reporter_tg_id,
                        si.owner as assignee_tg_id,
                        coalesce(si.tags, ARRAY[]::text[]),
                        jsonb_build_object(
                            'legacy_kind', si.kind,
                            'legacy_snapshot_id', si.snapshot_id::text,
                            'legacy_runbook_url', si.runbook_url,
                            'legacy_affected_components', si.affected_components
                        ) as meta,
                        coalesce(si.created_at, now()),
                        now()
                    FROM soul_incidents si
                    WHERE NOT EXISTS (
                        SELECT 1 FROM incidents i WHERE i.id = si.id
                    );
                END IF;
            END$$;
            """
        )
    )


def downgrade():
    # No-op: do not delete data once copied.
    pass


