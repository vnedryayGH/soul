from __future__ import annotations

"""
P51: Fix uniqueness for soul_personality_policies

Revision ID: 20250929_000094
Revises: 20250929_000093
Create Date: 2025-09-29 14:15:00.000000
"""

from alembic import op


revision = "20250929_000094"
down_revision = "20250929_000093"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Drop any unique constraint that enforces uniqueness on (key) alone
    # Drop any single-column unique on key (best-effort)
    try:
        op.execute("ALTER TABLE soul_personality_policies DROP CONSTRAINT IF EXISTS soul_personality_policies_key_key")
    except Exception:
        pass
    # Ensure desired composite unique exists
    try:
        op.create_unique_constraint("uq_spp_personality_key", "soul_personality_policies", ["personality_id", "key"])
    except Exception:
        pass


def downgrade() -> None:
    # Best-effort: drop composite unique (won't recreate single-key unique)
    try:
        op.drop_constraint("uq_spp_personality_key", "soul_personality_policies", type_="unique")
    except Exception:
        pass


