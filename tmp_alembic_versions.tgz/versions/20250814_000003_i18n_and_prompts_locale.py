"""i18n and prompts locale

Revision ID: 20250814_000003
Revises: 20250811_000002
Create Date: 2025-08-14 00:00:03.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "20250814_000003"
down_revision = "20250811_000002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # users.locale
    op.add_column("users", sa.Column("locale", sa.String(length=10), nullable=False, server_default="ru"))
    op.alter_column("users", "locale", server_default=None)

    # prompts: add locale, group_key, change uniqueness
    op.add_column("prompts", sa.Column("locale", sa.String(length=10), nullable=False, server_default="ru"))
    op.add_column("prompts", sa.Column("group_key", sa.String(length=64), nullable=True))
    op.alter_column("prompts", "locale", server_default=None)

    # drop unique(key) if exists (legacy)
    op.execute("ALTER TABLE prompts DROP CONSTRAINT IF EXISTS prompts_key_key;")
    # add new unique(key, locale)
    op.create_unique_constraint("uq_prompts_key_locale", "prompts", ["key", "locale"])

    # helpful indexes
    op.create_index("ix_prompts_locale_category", "prompts", ["locale", "category"], unique=False)
    op.create_index("ix_prompts_group_key", "prompts", ["group_key"], unique=False)

    # i18n_entries
    op.create_table(
        "i18n_entries",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("namespace", sa.String(length=64), nullable=False),
        sa.Column("key", sa.String(length=190), nullable=False),
        sa.Column("locale", sa.String(length=10), nullable=False),
        sa.Column("value", sa.Text(), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("updated_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_i18n_entries_namespace_locale", "i18n_entries", ["namespace", "locale"], unique=False)
    op.create_unique_constraint("uq_i18n_namespace_key_locale", "i18n_entries", ["namespace", "key", "locale"])


def downgrade() -> None:
    op.drop_constraint("uq_i18n_namespace_key_locale", "i18n_entries", type_="unique")
    op.drop_index("ix_i18n_entries_namespace_locale", table_name="i18n_entries")
    op.drop_table("i18n_entries")

    op.drop_index("ix_prompts_group_key", table_name="prompts")
    op.drop_index("ix_prompts_locale_category", table_name="prompts")
    op.drop_constraint("uq_prompts_key_locale", "prompts", type_="unique")

    op.drop_column("prompts", "group_key")
    op.drop_column("prompts", "locale")

    op.drop_column("users", "locale")


