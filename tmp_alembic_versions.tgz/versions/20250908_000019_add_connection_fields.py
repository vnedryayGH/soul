"""Add connection_type, strength, metadata to quant_connections

Revision ID: 20250908_000019
Revises: 20250908_000018
Create Date: 2025-09-08 15:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '20250908_000019'
down_revision = '20250908_000018'
branch_labels = None
depends_on = None


def upgrade():
    # Проверяем существование столбцов перед добавлением
    conn = op.get_bind()
    inspector = sa.inspect(conn)
    
    if 'quant_connections' in inspector.get_table_names():
        columns = [col['name'] for col in inspector.get_columns('quant_connections')]
        
        # Добавляем connection_type если его нет
        if 'connection_type' not in columns:
            op.add_column('quant_connections', sa.Column('connection_type', sa.String(50), nullable=False, server_default='semantic'))
        
        # Добавляем strength если его нет
        if 'strength' not in columns:
            op.add_column('quant_connections', sa.Column('strength', sa.Float(), nullable=False, server_default='0.5'))
        
        # Добавляем metadata если его нет
        if 'metadata' not in columns:
            op.add_column('quant_connections', sa.Column('metadata', postgresql.JSONB(), nullable=True))
        
        # Копируем данные из connection_strength в strength если нужно
        if 'connection_strength' in columns and 'strength' in columns:
            op.execute("UPDATE quant_connections SET strength = connection_strength WHERE strength = 0.5")
        
        # Удаляем старый столбец connection_strength (если он существует)
        if 'connection_strength' in columns:
            try:
                op.drop_column('quant_connections', 'connection_strength')
            except:
                pass  # Может быть заблокирован связями


def downgrade():
    # Возвращаем изменения
    op.add_column('quant_connections', sa.Column('connection_strength', sa.Float(), nullable=False, server_default='0.5'))
    op.execute("UPDATE quant_connections SET connection_strength = strength")
    
    op.drop_column('quant_connections', 'metadata')
    op.drop_column('quant_connections', 'strength')
    op.drop_column('quant_connections', 'connection_type')
