"""
create soul_prompts, soul_settings and add chat_threads columns

Revision ID: 20250911_000037
Revises: 20250911_000036
Create Date: 2025-09-11 19:45:00
"""

from __future__ import annotations

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250911_000037"
down_revision = "20250911_000036"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create soul_prompts, soul_settings tables if missing
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='soul_prompts'
            ) THEN
                CREATE TABLE soul_prompts (
                    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                    key text NOT NULL UNIQUE,
                    content text NOT NULL,
                    parameters jsonb,
                    is_active boolean NOT NULL DEFAULT true,
                    created_at timestamp without time zone NOT NULL DEFAULT now(),
                    updated_at timestamp without time zone NOT NULL DEFAULT now()
                );
            END IF;
        END$$;
        """
    )
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='soul_settings'
            ) THEN
                CREATE TABLE soul_settings (
                    key text PRIMARY KEY,
                    value text,
                    data_type text,
                    updated_at timestamp without time zone NOT NULL DEFAULT now()
                );
            END IF;
        END$$;
        """
    )

    # Ensure columns on chat_threads
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='chat_threads' AND column_name='type'
            ) THEN
                ALTER TABLE chat_threads ADD COLUMN type varchar(32) DEFAULT 'user_dialog';
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='chat_threads' AND column_name='branch_label'
            ) THEN
                ALTER TABLE chat_threads ADD COLUMN branch_label text;
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='chat_threads' AND column_name='persona_prompt_id'
            ) THEN
                ALTER TABLE chat_threads ADD COLUMN persona_prompt_id integer REFERENCES prompts(id) ON DELETE SET NULL;
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='chat_threads' AND column_name='model'
            ) THEN
                ALTER TABLE chat_threads ADD COLUMN model text;
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='chat_threads' AND column_name='temperature'
            ) THEN
                ALTER TABLE chat_threads ADD COLUMN temperature double precision;
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='chat_threads' AND column_name='max_tokens'
            ) THEN
                ALTER TABLE chat_threads ADD COLUMN max_tokens integer;
            END IF;
        END$$;
        """
    )


def downgrade() -> None:
    # Drop columns if exist (non-destructive optional)
    op.execute(
        """
        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='chat_threads' AND column_name='max_tokens'
            ) THEN
                ALTER TABLE chat_threads DROP COLUMN max_tokens;
            END IF;
            IF EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='chat_threads' AND column_name='temperature'
            ) THEN
                ALTER TABLE chat_threads DROP COLUMN temperature;
            END IF;
            IF EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='chat_threads' AND column_name='model'
            ) THEN
                ALTER TABLE chat_threads DROP COLUMN model;
            END IF;
            IF EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='chat_threads' AND column_name='persona_prompt_id'
            ) THEN
                ALTER TABLE chat_threads DROP COLUMN persona_prompt_id;
            END IF;
            IF EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='chat_threads' AND column_name='branch_label'
            ) THEN
                ALTER TABLE chat_threads DROP COLUMN branch_label;
            END IF;
            IF EXISTS (
                SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='chat_threads' AND column_name='type'
            ) THEN
                ALTER TABLE chat_threads DROP COLUMN type;
            END IF;
        END$$;
        """
    )

    # Keep soul_* tables (no destructive drop on downgrade to avoid data loss)
