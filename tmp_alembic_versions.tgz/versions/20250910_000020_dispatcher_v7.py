from __future__ import annotations

"""
v7: Flow Dispatcher extensions (RBAC×DGW, retries/compensation, validation, dynamic budgets,
cost-aware, A/B policies, safety modes, analytics MV)

Revision ID: 20250910_000020
Revises: 20250908_000018
Create Date: 2025-09-10 12:00:00.000000
"""

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250910_000020"
down_revision = "20250908_000018"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Ensure base tables exist to avoid ordering issues
    op.execute(
        """
        create table if not exists generation_request (
          id uuid primary key,
          activity_id uuid null,
          goal_id uuid null,
          prompt_hint text null,
          dgw_value numeric null,
          dgw_factors jsonb null,
          status text not null default 'queued',
          priority_bucket int not null default 0,
          attempts int not null default 0,
          created_at timestamptz not null default now(),
          updated_at timestamptz not null default now(),
          processed_at timestamptz null,
          dispatcher_queue_id uuid null
        );

        create table if not exists flow_dispatch_queue (
          id uuid primary key,
          created_at timestamptz not null default now(),
          planned_for timestamptz null,
          activity_id uuid null,
          goal_id uuid null,
          request_id uuid null,
          policy text not null,
          expected_energy numeric null,
          expected_entropy numeric null,
          priority numeric null,
          status text not null default 'queued',
          reason jsonb null,
          human_summary text null
        );
        """
    )
    # llm_role_limits
    op.execute(
        """
        create table if not exists llm_role_limits (
          role text primary key,
          max_tokens_per_day int,
          max_rps numeric,
          priority_boost numeric default 0
        );
        """
    )

    # generation_request initiator, retry_count, indexes
    op.execute(
        """
        alter table if exists generation_request
          add column if not exists initiated_by_user_id int,
          add column if not exists initiated_by_role text,
          add column if not exists retry_count int default 0;

        create index if not exists idx_req_initiator on generation_request(initiated_by_role, initiated_by_user_id);
        """
    )

    # flow_dispatch_queue resilience, validation, economics, indexes
    op.execute(
        """
        alter table if exists flow_dispatch_queue
          add column if not exists retry_count int default 0,
          add column if not exists last_error text,
          add column if not exists human_summary text,
          add column if not exists validation_ok boolean,
          add column if not exists validation_issues jsonb,
          add column if not exists estimated_cost numeric,
          add column if not exists value_per_cost numeric;

        create index if not exists idx_flow_q_valuecost on flow_dispatch_queue(value_per_cost desc nulls last);
        create index if not exists idx_flow_q_scheduled on flow_dispatch_queue(status, planned_for);
        """
    )

    # conductor_settings schedules, safety state, fallback policy
    op.execute(
        """
        alter table if exists conductor_settings
          add column if not exists schedule_budgets jsonb,
          add column if not exists dispatcher_state text default 'normal',
          add column if not exists fallback_policy text default 'exploration_min',
          add column if not exists fallback_energy_budget numeric default 1.0,
          add column if not exists fallback_temperature numeric default 0.6;
        """
    )

    # A/B policy assignment
    op.execute(
        """
        alter table if exists conductor_settings
          add column if not exists ab_test_policies jsonb;

        create table if not exists flow_policy_assignment (
          id uuid primary key,
          created_at timestamptz not null default now(),
          cohort text not null,
          policy text not null,
          user_id int null,
          thread_id uuid null,
          request_id uuid null
        );
        """
    )

    # Safety events
    op.execute(
        """
        create table if not exists safety_protocol_events (
          id uuid primary key,
          created_at timestamptz not null default now(),
          level int not null,
          source text not null,
          action text not null,
          meta jsonb
        );
        """
    )

    # Analytics MV
    op.execute(
        """
        create materialized view if not exists flow_dispatch_analytics_mv as
        select date_trunc('hour', created_at) as ts_hour,
               count(*) filter (where policy='goal_driven') as cnt_goal,
               count(*) filter (where policy like 'exploration%') as cnt_explore,
               avg( (reason->>'ml_confidence')::numeric ) as avg_ml_confidence,
               avg(value_per_cost) as avg_value_per_cost
        from flow_dispatch_queue
        group by 1;

        create unique index if not exists uq_flow_dispatch_analytics_mv on flow_dispatch_analytics_mv(ts_hour);
        """
    )


def downgrade() -> None:
    # Non-destructive downgrade placeholder
    pass


