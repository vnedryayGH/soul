"""Health snapshots and incidents tables

Revision ID: 20250915_000044_health
Revises: 20250915_000043_two_keys
Create Date: 2025-09-15 00:36:44

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = '20250915_000044_health'
down_revision = '20250915_000043_two_keys'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'soul_health_snapshots',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('period_start', sa.DateTime(timezone=True), nullable=False),
        sa.Column('period_end', sa.DateTime(timezone=True), nullable=False),
        sa.Column('scope', sa.Text(), nullable=False),
        sa.Column('components', postgresql.ARRAY(sa.Text()), nullable=True),
        sa.Column('metrics', postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column('health_score', sa.Float(), nullable=False, server_default='1'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    )
    op.create_index('ix_health_scope_start', 'soul_health_snapshots', ['scope', 'period_start'])

    op.create_table(
        'soul_incidents',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('kind', sa.Text(), nullable=False),
        sa.Column('severity', sa.Enum('low','medium','high','critical', name='incident_severity'), nullable=False),
        sa.Column('status', sa.Enum('open','mitigated','resolved','false_positive', name='incident_status'), nullable=False, server_default='open'),
        sa.Column('title', sa.Text(), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('affected_components', postgresql.ARRAY(sa.Text()), nullable=True),
        sa.Column('detected_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('now()')),
        sa.Column('resolved_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('snapshot_id', postgresql.UUID(as_uuid=False), nullable=True),
        sa.Column('tags', postgresql.ARRAY(sa.Text()), nullable=True),
        sa.Column('owner', sa.BigInteger(), nullable=True),
        sa.Column('runbook_url', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    )
    op.create_index('ix_incidents_status', 'soul_incidents', ['status'])
    op.create_index('ix_incidents_severity_detected', 'soul_incidents', ['severity','detected_at'])


def downgrade():
    op.drop_index('ix_incidents_severity_detected', table_name='soul_incidents')
    op.drop_index('ix_incidents_status', table_name='soul_incidents')
    op.drop_table('soul_incidents')
    op.drop_index('ix_health_scope_start', table_name='soul_health_snapshots')
    op.drop_table('soul_health_snapshots')


