from __future__ import annotations

"""
v8: Family communication activity tables

Revision ID: 20250911_000029
Revises: 20250911_000028
Create Date: 2025-09-11 14:20:00.000000
"""

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250911_000029"
down_revision = "20250911_000028"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        create table if not exists family_contacts (
          user_id int not null references users(id) on delete cascade,
          contact_tg_id bigint not null,
          relation text null,
          allow_read boolean not null default false,
          allow_send boolean not null default false,
          primary key (user_id, contact_tg_id)
        );

        create table if not exists activity_family_settings (
          activity_id uuid primary key references activities(id) on delete cascade,
          contacts jsonb null,
          policies jsonb null
        );
        """
    )


def downgrade() -> None:
    # Non-destructive downgrade
    pass


