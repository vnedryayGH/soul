"""Add incidents.title and ensure desired_action_type includes ask_architect

Revision ID: 20250929_000091
Revises: 20250926_000080_p50_incident_management
Create Date: 2025-09-29
"""

from __future__ import annotations

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250929_000091"
down_revision = "20250926_000080_p50_incident_management"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # 1) Add title column to incidents if missing
    op.execute(
        "ALTER TABLE IF EXISTS incidents ADD COLUMN IF NOT EXISTS title text;"
    )

    # 2) Ensure enum desired_action_type has ask_architect
    op.execute(
        """
        DO $$
        BEGIN
          IF NOT EXISTS (
            SELECT 1
            FROM pg_type t
            JOIN pg_enum e ON e.enumtypid=t.oid
            WHERE t.typname = 'desired_action_type'
              AND e.enumlabel = 'ask_architect'
          ) THEN
            ALTER TYPE desired_action_type ADD VALUE 'ask_architect';
          END IF;
        END
        $$;
        """
    )


def downgrade() -> None:
    # No-op: enum value removal and column drop are intentionally skipped
    pass


