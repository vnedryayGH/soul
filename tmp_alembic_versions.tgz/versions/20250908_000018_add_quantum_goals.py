"""add quantum_goals table

Revision ID: 20250908_000018
Revises: 20250908_000017
Create Date: 2025-09-08 14:30:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '20250908_000018'
down_revision = '20250908_000017'
branch_labels = None
depends_on = None


def upgrade():
    # Create quantum_goals table
    op.create_table(
        "quantum_goals",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("quant_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("title", sa.String(length=200), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("priority", sa.Float(), nullable=False, server_default="0.5"),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="active"),
        sa.Column("created_at", sa.DateTime(), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(), server_default=sa.text("NOW()"), nullable=False),
    )
    
    # Create indexes
    op.create_index("idx_quantum_goals_quant_id", "quantum_goals", ["quant_id"])
    op.create_index("idx_quantum_goals_priority", "quantum_goals", ["priority"])
    op.create_index("idx_quantum_goals_status", "quantum_goals", ["status"])


def downgrade():
    op.drop_index("idx_quantum_goals_status", "quantum_goals")
    op.drop_index("idx_quantum_goals_priority", "quantum_goals")
    op.drop_index("idx_quantum_goals_quant_id", "quantum_goals")
    op.drop_table("quantum_goals")
