"""
P25: extend skills domain (user_skills, skill_practice, indices) — draft

Adds additive tables and indexes required by P25 Appendix A.
Safe to run multiple times in PROD (IF NOT EXISTS).
"""
from typing import Optional
from alembic import op

revision: str = "20250916_000051_p25_entities_ext"
down_revision: Optional[str] = "20250916_000050_skills_tables"
branch_labels = None
depends_on = None


def upgrade() -> None:
	op.execute(
		"""
		CREATE TABLE IF NOT EXISTS public.user_skills (
		  user_id bigint NOT NULL,
		  skill_id uuid NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
		  level int DEFAULT 1,
		  streak int DEFAULT 0,
		  last_practiced_at timestamptz,
		  next_due_at timestamptz,
		  proficiency double precision DEFAULT 0,
		  meta jsonb DEFAULT '{}'::jsonb,
		  PRIMARY KEY (user_id, skill_id)
		);
		CREATE INDEX IF NOT EXISTS ix_user_skills_due ON public.user_skills(next_due_at);

		CREATE TABLE IF NOT EXISTS public.skill_practice (
		  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
		  user_id bigint NOT NULL,
		  skill_id uuid NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
		  session_at timestamptz DEFAULT now(),
		  duration_sec int,
		  outcome text,
		  score double precision,
		  notes text,
		  meta jsonb DEFAULT '{}'::jsonb
		);
		CREATE INDEX IF NOT EXISTS ix_skill_practice_session ON public.skill_practice(session_at);
		CREATE INDEX IF NOT EXISTS ix_skill_practice_outcome ON public.skill_practice(outcome);
		"""
	)


def downgrade() -> None:
	op.execute(
		"""
		DROP TABLE IF EXISTS public.skill_practice;
		DROP TABLE IF EXISTS public.user_skills;
		"""
	)
