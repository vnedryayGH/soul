from __future__ import annotations

"""
v7 base: create missing dispatcher base tables and align goal schema

Revision ID: 20250910_000021
Revises: 20250910_000020
Create Date: 2025-09-10 23:40:00.000000
"""

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250910_000021"
down_revision = "20250910_000020"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # conductor_settings (base row used by FlowDispatcherService)
    op.execute(
        """
        create table if not exists conductor_settings (
          id uuid primary key default gen_random_uuid(),
          dispatcher_enabled boolean not null default true,
          dispatcher_mode text not null default 'balanced',
          dispatcher_energy_budget numeric not null default 5.0,
          dispatcher_queue_max int not null default 1000,
          dispatcher_exploration_temperature numeric not null default 0.7,
          schedule_budgets jsonb null,
          ab_test_policies jsonb null,
          dispatcher_state text not null default 'normal',
          fallback_policy text not null default 'exploration_min',
          fallback_energy_budget numeric not null default 1.0,
          fallback_temperature numeric not null default 0.6,
          created_at timestamptz not null default now(),
          updated_at timestamptz not null default now()
        );

        -- seed single row if empty
        insert into conductor_settings (id)
        select gen_random_uuid()
        where not exists (select 1 from conductor_settings);
        """
    )

    # flow_dispatch_queue
    op.execute(
        """
        create table if not exists flow_dispatch_queue (
          id uuid primary key,
          created_at timestamptz not null default now(),
          planned_for timestamptz null,
          activity_id uuid null,
          goal_id uuid null,
          request_id uuid null,
          policy text not null,
          expected_energy numeric null,
          expected_entropy numeric null,
          priority numeric null,
          status text not null default 'queued',
          reason jsonb null,
          human_summary text null,
          retry_count int not null default 0,
          last_error text null,
          validation_ok boolean null,
          validation_issues jsonb null,
          estimated_cost numeric null,
          value_per_cost numeric null
        );

        create index if not exists idx_flow_q_valuecost on flow_dispatch_queue (value_per_cost desc nulls last);
        create index if not exists idx_flow_q_scheduled on flow_dispatch_queue (status, planned_for);
        """
    )

    # generation_request (minimal schema used by MaterializerService)
    op.execute(
        """
        create table if not exists generation_request (
          id uuid primary key,
          activity_id uuid null,
          goal_id uuid null,
          prompt_hint text null,
          dgw_value numeric null,
          dgw_factors jsonb null,
          status text not null default 'queued',
          priority_bucket int not null default 0,
          attempts int not null default 0,
          created_at timestamptz not null default now(),
          updated_at timestamptz not null default now(),
          processed_at timestamptz null,
          dispatcher_queue_id uuid null
        );
        """
    )

    # Align quantum_goals to include is_active used by dispatcher
    op.execute(
        """
        do $$ begin
          if not exists (
            select 1 from information_schema.columns
            where table_name = 'quantum_goals' and column_name = 'is_active'
          ) then
            alter table if exists quantum_goals add column is_active boolean;
            -- best-effort backfill based on status if it exists
            begin
              update quantum_goals set is_active = (case when lower(coalesce(status,'active')) = 'active' then true else false end)
              where is_active is null;
            exception when undefined_column then
              update quantum_goals set is_active = true where is_active is null;
            end;
            alter table quantum_goals alter column is_active set default true;
          end if;
        end $$;
        """
    )

    # Seed Architect role boost if table exists with 'role' column
    op.execute(
        """
        do $$ begin
          if exists (select 1 from information_schema.columns where table_name='llm_role_limits' and column_name='role') then
            insert into llm_role_limits (role, max_tokens_per_day, max_rps, priority_boost)
            values ('Architect', null, null, 1.0)
            on conflict (role) do nothing;
          end if;
        end $$;
        """
    )


def downgrade() -> None:
    # non-destructive downgrade: keep created objects
    pass


