from __future__ import annotations

"""
Add sleep_time_msk to soul_settings

Revision ID: 20250908_000017
Revises: 20250908_000016
Create Date: 2025-09-08 13:28:00.000000
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "20250908_000017"
down_revision = "20250908_000016"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # time without time zone is sufficient; MSK semantics handled in app layer
    with op.batch_alter_table("soul_settings") as batch_op:
        batch_op.add_column(sa.Column("sleep_time_msk", sa.Time(), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("soul_settings") as batch_op:
        batch_op.drop_column("sleep_time_msk")


