"""
P11: provenance_edges table (Stage-2)

Revision ID: 20250920_000064_p11_provenance
Revises: 20250920_000063_p39_sensory
Create Date: 2025-09-20 18:40:00
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa  # noqa: F401


revision = "20250920_000064_p11_provenance"
down_revision = "20250920_000063_p39_sensory"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Создать таблицу provenance_edges и индексы, если отсутствуют
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='provenance_edges'
            ) THEN
                CREATE TABLE provenance_edges (
                    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                    created_at timestamp without time zone NOT NULL DEFAULT now(),
                    trace_id text NOT NULL,
                    quant_id uuid NULL,
                    stage text NOT NULL,
                    source_type text NOT NULL,
                    source_id uuid NULL,
                    source_hash text NOT NULL,
                    source_ref jsonb NULL,
                    relation text NOT NULL DEFAULT 'influenced_by',
                    weight numeric NULL,
                    confidence numeric NULL,
                    notes text NULL
                );
            END IF;
            -- Индексы
            IF NOT EXISTS (
                SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
                WHERE c.relname = 'idx_prov_quant' AND n.nspname = 'public'
            ) THEN
                CREATE INDEX idx_prov_quant ON provenance_edges(quant_id);
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
                WHERE c.relname = 'idx_prov_trace' AND n.nspname = 'public'
            ) THEN
                CREATE INDEX idx_prov_trace ON provenance_edges(trace_id);
            END IF;
            -- Уникальный индекс/ограничение
            IF NOT EXISTS (
                SELECT 1 FROM pg_constraint WHERE conname = 'uq_prov_edge'
            ) THEN
                CREATE UNIQUE INDEX uq_prov_edge ON provenance_edges(quant_id, stage, source_type, source_hash);
            END IF;
        END$$;
        """
    )


def downgrade() -> None:
    # Безопасный даунгрейд: не удаляем таблицу и индексы, чтобы не терять данные
    pass


