"""add prefetch/search fields to reminders

Revision ID: 20250915_000046
Revises: 20250915_000045
Create Date: 2025-09-15 00:00:46
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision = '20250915_000046'
down_revision = '20250915_000045'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('reminders', sa.Column('bot_type', sa.String(length=20), nullable=False, server_default='chat_bot'))
    op.add_column('reminders', sa.Column('active_persona', sa.String(length=50), nullable=True))
    op.add_column('reminders', sa.Column('persona_prompt', sa.Text(), nullable=True))
    op.add_column('reminders', sa.Column('active_modules', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('reminders', sa.Column('conversation_context', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('reminders', sa.Column('llm_context_snapshot', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('reminders', sa.Column('notification_preferences', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('reminders', sa.Column('prefetch_done', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('reminders', sa.Column('prefetch_time', sa.DateTime(), nullable=True))
    op.add_column('reminders', sa.Column('prefetch_payload', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('reminders', sa.Column('search_query', sa.Text(), nullable=True))
    op.add_column('reminders', sa.Column('search_url', sa.Text(), nullable=True))


def downgrade() -> None:
    op.drop_column('reminders', 'search_url')
    op.drop_column('reminders', 'search_query')
    op.drop_column('reminders', 'prefetch_payload')
    op.drop_column('reminders', 'prefetch_time')
    op.drop_column('reminders', 'prefetch_done')
    op.drop_column('reminders', 'notification_preferences')
    op.drop_column('reminders', 'llm_context_snapshot')
    op.drop_column('reminders', 'conversation_context')
    op.drop_column('reminders', 'active_modules')
    op.drop_column('reminders', 'persona_prompt')
    op.drop_column('reminders', 'active_persona')
    op.drop_column('reminders', 'bot_type')


