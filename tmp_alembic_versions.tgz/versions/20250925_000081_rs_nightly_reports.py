"""
RS nightly reports table

Stores daily p95/p99 summaries and 7-day diffs for RS metrics.
"""

from __future__ import annotations

from typing import Optional

from alembic import op


# Revision identifiers
revision: str = "20250925_000081"
down_revision: Optional[str] = "20250925_000080_lang_succession_registry"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS public.rs_nightly_reports (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            generated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            window_days INTEGER NOT NULL DEFAULT 1,
            summary JSONB,
            diff_7d JSONB,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );
        CREATE INDEX IF NOT EXISTS ix_rs_nightly_reports_generated_at ON public.rs_nightly_reports (generated_at DESC);
        """
    )


def downgrade() -> None:
    # Keep history by default; no destructive downgrade.
    pass


