"""
P50 Incident Management core tables

Revision ID: 20250926_000080_p50_incident_management
Revises: 20250925_000081_rs_nightly_reports
Create Date: 2025-09-26 10:00:00

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = '20250926_000080_p50_incident_management'
down_revision = '20250925_000082_rs_sec_limits'
branch_labels = None
depends_on = None


def upgrade():
    # incidents
    op.create_table(
        'incidents',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('title', sa.Text(), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('severity', sa.SmallInteger(), nullable=False, server_default='3'),
        sa.Column('priority', sa.SmallInteger(), nullable=False, server_default='3'),
        sa.Column('status', sa.Text(), nullable=False, server_default='open'),
        sa.Column('detected_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('now()')),
        sa.Column('acknowledged_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('resolved_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('closed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('source', sa.Text(), nullable=False),
        sa.Column('trace_id', postgresql.UUID(as_uuid=False), nullable=True),
        sa.Column('root_cause', sa.Text(), nullable=True),
        sa.Column('resolution', sa.Text(), nullable=True),
        sa.Column('runbook_id', postgresql.UUID(as_uuid=False), nullable=True),
        sa.Column('plan_task_id', postgresql.UUID(as_uuid=False), nullable=True),
        sa.Column('reporter_tg_id', sa.BigInteger(), nullable=True),
        sa.Column('assignee_tg_id', sa.BigInteger(), nullable=True),
        sa.Column('tags', postgresql.ARRAY(sa.Text()), nullable=False, server_default=sa.text("'{}'::text[]")),
        sa.Column('meta', postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('now()')),
    )
    op.create_index('ix_incidents_status', 'incidents', ['status'])
    op.create_index('ix_incidents_severity', 'incidents', ['severity'])
    op.create_index('ix_incidents_detected_at', 'incidents', ['detected_at'])
    op.create_index('ix_incidents_trace', 'incidents', ['trace_id'])

    # incident_events
    op.create_table(
        'incident_events',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('incident_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('kind', sa.Text(), nullable=False),
        sa.Column('details', postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column('author_tg_id', sa.BigInteger(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('now()')),
        sa.ForeignKeyConstraint(['incident_id'], ['incidents.id'], ondelete='CASCADE'),
    )
    op.create_index('ix_incident_events_incident', 'incident_events', ['incident_id'])

    # incident_links
    op.create_table(
        'incident_links',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('incident_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('to_kind', sa.Text(), nullable=False),
        sa.Column('to_id', sa.Text(), nullable=False),
        sa.Column('relation', sa.Text(), nullable=False, server_default='relates_to'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('now()')),
        sa.ForeignKeyConstraint(['incident_id'], ['incidents.id'], ondelete='CASCADE'),
    )
    op.create_index('ix_incident_links_target', 'incident_links', ['to_kind', 'to_id'])

    # incident_runbooks
    op.create_table(
        'incident_runbooks',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('title', sa.Text(), nullable=False),
        sa.Column('content', sa.Text(), nullable=False),
        sa.Column('created_by_tg_id', sa.BigInteger(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('now()')),
    )

    # incident_kb
    op.create_table(
        'incident_kb',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('signature', sa.Text(), nullable=False, unique=True),
        sa.Column('summary', sa.Text(), nullable=False),
        sa.Column('recommended_runbook_id', postgresql.UUID(as_uuid=False), nullable=True),
        sa.Column('examples', postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'[]'::jsonb")),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.text('now()')),
        sa.ForeignKeyConstraint(['recommended_runbook_id'], ['incident_runbooks.id'], ondelete='SET NULL'),
    )


def downgrade():
    op.drop_table('incident_kb')
    op.drop_table('incident_runbooks')
    op.drop_index('ix_incident_links_target', table_name='incident_links')
    op.drop_table('incident_links')
    op.drop_index('ix_incident_events_incident', table_name='incident_events')
    op.drop_table('incident_events')
    op.drop_index('ix_incidents_trace', table_name='incidents')
    op.drop_index('ix_incidents_detected_at', table_name='incidents')
    op.drop_index('ix_incidents_severity', table_name='incidents')
    op.drop_index('ix_incidents_status', table_name='incidents')
    op.drop_table('incidents')


