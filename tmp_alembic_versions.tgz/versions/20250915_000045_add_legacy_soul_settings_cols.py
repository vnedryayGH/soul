"""Add legacy columns to soul_settings if missing (compatibility)

Revision ID: 20250915_000045
Revises: 20250915_000044_health
Create Date: 2025-09-15 09:05:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20250915_000045'
down_revision = '20250915_000044_health'
branch_labels = None
depends_on = None


def upgrade():
    # Не разрушаем данные: добавляем недостающие колонки, если их нет
    op.execute("""
    DO $$
    BEGIN
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name='soul_settings' AND column_name='num_candidates'
        ) THEN
            ALTER TABLE soul_settings ADD COLUMN num_candidates integer;
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name='soul_settings' AND column_name='deepseek_quota_per_hour'
        ) THEN
            ALTER TABLE soul_settings ADD COLUMN deepseek_quota_per_hour integer;
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name='soul_settings' AND column_name='gigachat_quota_per_day'
        ) THEN
            ALTER TABLE soul_settings ADD COLUMN gigachat_quota_per_day integer;
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name='soul_settings' AND column_name='auto_publish_enabled'
        ) THEN
            ALTER TABLE soul_settings ADD COLUMN auto_publish_enabled boolean;
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name='soul_settings' AND column_name='publish_min_interval_minutes'
        ) THEN
            ALTER TABLE soul_settings ADD COLUMN publish_min_interval_minutes integer;
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name='soul_settings' AND column_name='q_factor_threshold'
        ) THEN
            ALTER TABLE soul_settings ADD COLUMN q_factor_threshold double precision;
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name='soul_settings' AND column_name='related_archive_threshold'
        ) THEN
            ALTER TABLE soul_settings ADD COLUMN related_archive_threshold double precision;
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name='soul_settings' AND column_name='sleep_time_msk'
        ) THEN
            ALTER TABLE soul_settings ADD COLUMN sleep_time_msk time;
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name='soul_settings' AND column_name='refresh_rank_minutes'
        ) THEN
            ALTER TABLE soul_settings ADD COLUMN refresh_rank_minutes integer;
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name='soul_settings' AND column_name='use_batch_planner'
        ) THEN
            ALTER TABLE soul_settings ADD COLUMN use_batch_planner boolean;
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name='soul_settings' AND column_name='batch_max_quants'
        ) THEN
            ALTER TABLE soul_settings ADD COLUMN batch_max_quants integer;
        END IF;
    END$$;
    """)


def downgrade():
    # Откат не удаляет колонки, чтобы не потерять возможные данные
    pass


