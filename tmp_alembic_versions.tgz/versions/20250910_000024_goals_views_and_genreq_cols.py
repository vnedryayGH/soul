from __future__ import annotations

"""
v7: goals views and generation_request thread/message cols; ml_min_confidence

Revision ID: 20250910_000024
Revises: 20250910_000023
Create Date: 2025-09-11 00:22:00.000000
"""

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250910_000024"
down_revision = "20250910_000023"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        -- add thread/message references to generation_request
        alter table if exists generation_request
          add column if not exists thread_id uuid,
          add column if not exists message_id uuid,
          add column if not exists initiated_by_user_id int,
          add column if not exists initiated_by_role text;

        -- settings: ml gating threshold
        alter table if exists conductor_settings
          add column if not exists ml_min_confidence numeric default 0.0;

        -- goals view (lightweight)
        create or replace view goals_view as
        select id as goal_id,
               quant_id,
               priority,
               coalesce(is_active, (case when lower(coalesce(status,'active'))='active' then true else false end)) as is_active,
               coalesce(updated_at, created_at) as ts
        from quantum_goals;

        -- materialized copy for fast reads
        create materialized view if not exists goals_view_mv as
        select * from goals_view;
        create unique index if not exists uq_goals_view_mv on goals_view_mv(goal_id);
        """
    )


def downgrade() -> None:
    pass


