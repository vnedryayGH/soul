"""Two-keys approval queue tables

Revision ID: 20250915_000043_two_keys
Revises: 20250915_000042_row_version
Create Date: 2025-09-15 00:24:43

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision = '20250915_000043_two_keys'
down_revision = '20250915_000042_row_version'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'sensitive_op_requests',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('action', sa.Text(), nullable=False),
        sa.Column('scopes', postgresql.ARRAY(sa.Text()), nullable=True),
        sa.Column('payload', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('requested_by', sa.BigInteger(), nullable=False),
        sa.Column('required_approvers', postgresql.ARRAY(sa.BigInteger()), nullable=True),
        sa.Column('status', sa.Enum('pending','approved','rejected','expired', name='sensitive_op_status'), nullable=False, server_default='pending'),
        sa.Column('ttl_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    )

    op.create_table(
        'sensitive_op_approvals',
        sa.Column('id', postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column('request_id', postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column('approver_id', sa.BigInteger(), nullable=False),
        sa.Column('decision', sa.Enum('approve','reject', name='sensitive_op_decision'), nullable=False),
        sa.Column('reason', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
    )

    op.create_index('ix_sensitive_requests_status_ttl', 'sensitive_op_requests', ['status','ttl_at'])


def downgrade():
    op.drop_index('ix_sensitive_requests_status_ttl', table_name='sensitive_op_requests')
    op.drop_table('sensitive_op_approvals')
    op.drop_table('sensitive_op_requests')


