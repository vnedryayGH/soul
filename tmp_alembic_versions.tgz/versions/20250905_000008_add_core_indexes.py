"""add core performance indexes

Revision ID: 20250905_000008
Revises: 20250829_000007
Create Date: 2025-09-05 09:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20250905_000008'
down_revision = '20250829_000007'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # messages: ускорение выборки истории по треду
    op.create_index('idx_messages_thread_created_at', 'messages', ['thread_id', 'created_at'])

    # keyword_extractions: быстрый доступ по сообщению и дате/типу
    op.create_index('idx_kw_msg', 'keyword_extractions', ['message_id', 'relevance_score'])
    op.create_index('idx_kw_type_date', 'keyword_extractions', ['keyword_type', 'normalized_date'])
    op.create_index('idx_kw_text', 'keyword_extractions', ['keyword'])

    # reminders: очереди отправки и выборка по пользователю
    op.create_index('idx_rem_user_date', 'reminders', ['user_id', 'reminder_date'])
    op.create_index('idx_rem_sent_date', 'reminders', ['is_sent', 'reminder_date'])


def downgrade() -> None:
    # reminders
    op.drop_index('idx_rem_sent_date', table_name='reminders')
    op.drop_index('idx_rem_user_date', table_name='reminders')

    # keyword_extractions
    op.drop_index('idx_kw_text', table_name='keyword_extractions')
    op.drop_index('idx_kw_type_date', table_name='keyword_extractions')
    op.drop_index('idx_kw_msg', table_name='keyword_extractions')

    # messages
    op.drop_index('idx_messages_thread_created_at', table_name='messages')


