from __future__ import annotations

"""
Ensure llm_role_limits has priority_boost column

Revision ID: 20250911_000031
Revises: 20250911_000030
Create Date: 2025-09-11 15:28:00.000000
"""

from alembic import op


revision = "20250911_000031"
down_revision = "20250911_000030"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        do $$ begin
          if exists (select 1 from information_schema.tables where table_name = 'llm_role_limits') then
            if not exists (
              select 1 from information_schema.columns
               where table_name = 'llm_role_limits' and column_name = 'priority_boost'
            ) then
              alter table llm_role_limits add column priority_boost numeric default 0;
            end if;
          end if;
        end $$;
        """
    )


def downgrade() -> None:
    # keep column for compatibility
    pass


