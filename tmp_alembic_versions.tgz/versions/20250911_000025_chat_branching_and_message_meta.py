from __future__ import annotations

"""
v7+: chat branching (threads) and message meta

Revision ID: 20250911_000025
Revises: 20250910_000024
Create Date: 2025-09-11 12:00:00.000000
"""

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250911_000025"
down_revision = "20250910_000024"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        -- chat_threads branching and config
        alter table if exists chat_threads
          add column if not exists type text not null default 'user_dialog',
          add column if not exists parent_thread_id uuid null references chat_threads(id) on delete set null,
          add column if not exists branch_label text null,
          add column if not exists persona_prompt_id int null references prompts(id) on delete set null,
          add column if not exists model text null,
          add column if not exists temperature numeric(4,2) null,
          add column if not exists max_tokens int null;

        do $$ begin
          if not exists (
            select 1 from pg_indexes where schemaname = current_schema() and indexname = 'idx_chat_threads_parent'
          ) then
            create index idx_chat_threads_parent on chat_threads(parent_thread_id);
          end if;
          if not exists (
            select 1 from pg_indexes where schemaname = current_schema() and indexname = 'idx_chat_threads_type'
          ) then
            create index idx_chat_threads_type on chat_threads(type);
          end if;
        end $$;

        -- messages meta for tokens/roles/provider info
        alter table if exists messages
          add column if not exists meta jsonb;

        do $$ begin
          if not exists (
            select 1 from pg_indexes where schemaname = current_schema() and indexname = 'idx_messages_meta_gin'
          ) then
            create index idx_messages_meta_gin on messages using gin (meta);
          end if;
        end $$;
        """
    )


def downgrade() -> None:
    # Ничего не удаляем для безопасности даунгрейда
    pass




