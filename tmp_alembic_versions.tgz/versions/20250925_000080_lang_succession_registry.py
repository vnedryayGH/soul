"""
P44/P48R: Execution succession registry (lang_succession_*)

Tables:
- lang_succession_modes(id, key, name, description, created_at)
- lang_succession_transitions(id, from_mode, to_mode, reason, triggered_by, created_at)
- lang_succession_windows(id, mode_key, starts_at, ends_at, comment)

Safe for PROD drift: IF NOT EXISTS, minimal constraints.
"""

from __future__ import annotations

from typing import Optional

from alembic import op


# Revision identifiers
revision: str = "20250925_000080_lang_succession_registry"
down_revision: Optional[str] = "20250921_000070_p40"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS public.lang_succession_modes (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            key TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE TABLE IF NOT EXISTS public.lang_succession_transitions (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            from_mode TEXT NOT NULL,
            to_mode TEXT NOT NULL,
            reason TEXT,
            triggered_by TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );
        CREATE INDEX IF NOT EXISTS ix_lang_succ_trans_created ON public.lang_succession_transitions (created_at);

        CREATE TABLE IF NOT EXISTS public.lang_succession_windows (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            mode_key TEXT NOT NULL,
            starts_at TIMESTAMPTZ NOT NULL,
            ends_at TIMESTAMPTZ,
            comment TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );
        CREATE INDEX IF NOT EXISTS ix_lang_succ_windows_mode ON public.lang_succession_windows (mode_key);

        -- seed minimal modes if empty
        INSERT INTO public.lang_succession_modes(key, name, description)
        SELECT t.key, t.name, t.description
        FROM (VALUES
            ('python_only','Python only','Выполнение только через Python без RS'),
            ('rs_shadow','RS shadow','RS в тени, Python основной'),
            ('rs_canary','RS canary','RS канарейка (частичная нагрузка)'),
            ('rs_primary_python_fallback','RS primary with Python fallback','RS основной с откатом на Python'),
            ('rs_primary_no_fallback','RS primary without fallback','RS основной без отката')
        ) AS t(key, name, description)
        WHERE NOT EXISTS (SELECT 1 FROM public.lang_succession_modes);
        """
    )


def downgrade() -> None:
    # No destructive downgrade in PROD; keep registry tables
    pass


