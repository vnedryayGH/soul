"""Security System Initialization

Revision ID: 20250109_000001
Revises: 20250908_000017
Create Date: 2025-01-09 12:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers
revision = '20250109_000001'
down_revision = '20250907_000015'
branch_labels = None
depends_on = None

def upgrade():
    # Создаем enum для уровней безопасности (с проверкой на существование)
    security_level_enum = postgresql.ENUM(
        'LEVEL_0_PAUSE', 'LEVEL_1_ETHICAL_HALT', 'LEVEL_2_SOFT_KILL', 'LEVEL_3_HARD_KILL',
        name='security_level_enum'
    )
    security_level_enum.create(op.get_bind(), checkfirst=True)
    
    alert_level_enum = postgresql.ENUM(
        'INFO', 'WARNING', 'CRITICAL', 'EMERGENCY',
        name='alert_level_enum'
    )
    alert_level_enum.create(op.get_bind(), checkfirst=True)
    
    anomaly_type_enum = postgresql.ENUM(
        'ENERGY_SPIKE', 'PROMPT_MANIPULATION', 'RATE_LIMIT_BREACH', 
        'ETHICAL_VIOLATION', 'PATTERN_ANOMALY', 'SYSTEM_OVERLOAD',
        name='anomaly_type_enum'
    )
    anomaly_type_enum.create(op.get_bind(), checkfirst=True)

    # Таблица настроек системы безопасности
    op.create_table('security_settings',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('created_at', sa.TIMESTAMP(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.TIMESTAMP(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_by', sa.Integer(), nullable=False),
        
        # Настройки детектора аномалий
        sa.Column('anomaly_detection_enabled', sa.Boolean(), server_default=sa.text('true'), nullable=False),
        sa.Column('anomaly_check_interval_seconds', sa.Integer(), server_default=sa.text('30'), nullable=False),
        sa.Column('energy_spike_threshold', sa.Float(), server_default=sa.text('0.8'), nullable=False),
        sa.Column('rate_limit_multiplier', sa.Float(), server_default=sa.text('2.0'), nullable=False),
        sa.Column('pattern_analysis_window_minutes', sa.Integer(), server_default=sa.text('10'), nullable=False),
        
        # Настройки этического модуля
        sa.Column('ethics_watchment_enabled', sa.Boolean(), server_default=sa.text('true'), nullable=False),
        sa.Column('satya_weight', sa.Float(), server_default=sa.text('0.33'), nullable=False),
        sa.Column('dharma_weight', sa.Float(), server_default=sa.text('0.33'), nullable=False),
        sa.Column('rita_weight', sa.Float(), server_default=sa.text('0.34'), nullable=False),
        sa.Column('ethics_threshold', sa.Float(), server_default=sa.text('0.7'), nullable=False),
        
        # Настройки emergency stop
        sa.Column('emergency_stop_enabled', sa.Boolean(), server_default=sa.text('true'), nullable=False),
        sa.Column('auto_escalation_enabled', sa.Boolean(), server_default=sa.text('true'), nullable=False),
        sa.Column('level_0_auto_recovery_minutes', sa.Integer(), server_default=sa.text('5'), nullable=False),
        sa.Column('level_1_require_manual_approval', sa.Boolean(), server_default=sa.text('true'), nullable=False),
        
        # Физическая кнопка
        sa.Column('physical_button_enabled', sa.Boolean(), server_default=sa.text('false'), nullable=False),
        sa.Column('physical_button_port', sa.String(50), nullable=True),
        sa.Column('physical_button_auth_key', sa.String(255), nullable=True),
        
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['updated_by'], ['users.id'], ),
    )

    # Таблица детектора аномалий
    op.create_table('anomaly_detections',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('detected_at', sa.TIMESTAMP(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('anomaly_type', sa.String(50), nullable=False),
        sa.Column('severity_score', sa.Float(), nullable=False),
        sa.Column('confidence_score', sa.Float(), nullable=False),
        sa.Column('description', sa.Text(), nullable=False),
        sa.Column('raw_data', sa.JSON(), nullable=True),
        sa.Column('quant_id', sa.UUID(), nullable=True),
        sa.Column('user_id', sa.Integer(), nullable=True),
        sa.Column('resolved_at', sa.TIMESTAMP(timezone=True), nullable=True),
        sa.Column('resolved_by', sa.Integer(), nullable=True),
        sa.Column('resolution_notes', sa.Text(), nullable=True),
        
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['quant_id'], ['quants.id'], ),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.ForeignKeyConstraint(['resolved_by'], ['users.id'], ),
    )

    # Таблица событий безопасности
    op.create_table('security_events',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('event_time', sa.TIMESTAMP(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('event_type', sa.String(100), nullable=False),
        sa.Column('security_level', sa.String(50), nullable=True),
        sa.Column('alert_level', sa.String(50), nullable=False),
        sa.Column('title', sa.String(255), nullable=False),
        sa.Column('description', sa.Text(), nullable=False),
        sa.Column('triggered_by_user', sa.Integer(), nullable=True),
        sa.Column('triggered_by_system', sa.String(100), nullable=True),
        sa.Column('system_snapshot', sa.JSON(), nullable=True),
        sa.Column('actions_taken', sa.JSON(), nullable=True),
        sa.Column('resolved_at', sa.TIMESTAMP(timezone=True), nullable=True),
        sa.Column('resolved_by', sa.Integer(), nullable=True),
        
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['triggered_by_user'], ['users.id'], ),
        sa.ForeignKeyConstraint(['resolved_by'], ['users.id'], ),
    )

    # Таблица этических проверок
    op.create_table('ethics_checks',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('checked_at', sa.TIMESTAMP(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('quant_id', sa.UUID(), nullable=False),
        sa.Column('satya_score', sa.Float(), nullable=False),
        sa.Column('dharma_score', sa.Float(), nullable=False),
        sa.Column('rita_score', sa.Float(), nullable=False),
        sa.Column('combined_score', sa.Float(), nullable=False),
        sa.Column('passed', sa.Boolean(), nullable=False),
        sa.Column('violation_details', sa.JSON(), nullable=True),
        sa.Column('action_taken', sa.String(100), nullable=True),
        
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['quant_id'], ['quants.id'], ),
    )

    # Таблица состояния системы
    op.create_table('system_state',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('updated_at', sa.TIMESTAMP(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('current_security_level', sa.String(50), server_default=sa.text("'LEVEL_0_PAUSE'"), nullable=False),
        sa.Column('soul_status', sa.String(50), server_default=sa.text("'ACTIVE'"), nullable=False),  # ACTIVE, PAUSED, HALTED, KILLED
        sa.Column('anomaly_detector_status', sa.String(50), server_default=sa.text("'RUNNING'"), nullable=False),
        sa.Column('ethics_watchment_status', sa.String(50), server_default=sa.text("'RUNNING'"), nullable=False),
        sa.Column('last_health_check', sa.TIMESTAMP(timezone=True), nullable=True),
        sa.Column('system_metrics', sa.JSON(), nullable=True),
        sa.Column('active_alerts_count', sa.Integer(), server_default=sa.text('0'), nullable=False),
        sa.Column('emergency_mode', sa.Boolean(), server_default=sa.text('false'), nullable=False),
        
        sa.PrimaryKeyConstraint('id'),
    )

    # Индексы для производительности
    op.create_index('idx_anomaly_detections_detected_at', 'anomaly_detections', ['detected_at'])
    op.create_index('idx_anomaly_detections_type_severity', 'anomaly_detections', ['anomaly_type', 'severity_score'])
    op.create_index('idx_security_events_event_time', 'security_events', ['event_time'])
    op.create_index('idx_security_events_alert_level', 'security_events', ['alert_level'])
    op.create_index('idx_ethics_checks_quant_id', 'ethics_checks', ['quant_id'])
    op.create_index('idx_ethics_checks_passed', 'ethics_checks', ['passed'])

    # Вставляем начальные настройки
    op.execute("""
        DO $$
        BEGIN
          IF EXISTS (SELECT 1 FROM users) THEN
            INSERT INTO security_settings (
                id, updated_by
            ) VALUES (
                gen_random_uuid(), 
                (SELECT id FROM users ORDER BY id LIMIT 1)
            );
          END IF;
        END
        $$;
    """)

    # Вставляем начальное состояние системы
    op.execute("""
        INSERT INTO system_state (
            id
        ) VALUES (
            gen_random_uuid()
        )
    """)

def downgrade():
    op.drop_table('system_state')
    op.drop_table('ethics_checks')
    op.drop_table('security_events')
    op.drop_table('anomaly_detections')
    op.drop_table('security_settings')
    
    # Удаляем enum типы
    op.execute('DROP TYPE IF EXISTS security_level_enum')
    op.execute('DROP TYPE IF EXISTS alert_level_enum')
    op.execute('DROP TYPE IF EXISTS anomaly_type_enum')
