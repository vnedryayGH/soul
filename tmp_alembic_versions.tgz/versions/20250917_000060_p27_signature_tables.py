"""
P27: function_registry, signature_steps, signature_incidents, artifact_records

Revision ID: 20250917_000060_p27_signature_tables
Revises: 20250916_000050_skills_tables
Create Date: 2025-09-17 10:00:00
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = '20250917_000060_p27_signature_tables'
down_revision = '20250916_000050_skills_tables'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # function_registry (lightweight, compatible with existing ORM)
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='function_registry'
            ) THEN
                CREATE TABLE function_registry (
                    id SERIAL PRIMARY KEY,
                    function_id varchar(128) NOT NULL,
                    scope varchar(64),
                    version varchar(32) NOT NULL,
                    description text,
                    is_active boolean NOT NULL DEFAULT true,
                    created_at timestamp without time zone NOT NULL DEFAULT now(),
                    updated_at timestamp without time zone NOT NULL DEFAULT now()
                );
                CREATE UNIQUE INDEX uq_function_registry_id_ver ON function_registry(function_id, version);
                CREATE INDEX idx_function_registry_scope ON function_registry(scope);
            END IF;
        END$$;
        """
    )

    # signature_steps
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='signature_steps'
            ) THEN
                CREATE TABLE signature_steps (
                    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                    trace_id varchar(64),
                    packet_id varchar(64),
                    function_id varchar(128) NOT NULL,
                    function_version varchar(32),
                    scope varchar(64),
                    status varchar(16) NOT NULL DEFAULT 'ok',
                    ts timestamp without time zone NOT NULL DEFAULT now(),
                    input_hash varchar(128),
                    output_hash varchar(128),
                    meta jsonb
                );
                CREATE INDEX idx_sig_steps_trace ON signature_steps(trace_id);
                CREATE INDEX idx_sig_steps_ts ON signature_steps(ts);
                CREATE INDEX idx_sig_steps_fn ON signature_steps(function_id);
            END IF;
        END$$;
        """
    )

    # signature_incidents
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='signature_incidents'
            ) THEN
                CREATE TABLE signature_incidents (
                    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                    trace_id varchar(64),
                    packet_id varchar(64),
                    function_id varchar(128),
                    incident_type varchar(64) NOT NULL,
                    detail text,
                    created_at timestamp without time zone NOT NULL DEFAULT now()
                );
                CREATE INDEX idx_sig_inc_trace ON signature_incidents(trace_id);
                CREATE INDEX idx_sig_inc_type ON signature_incidents(incident_type);
            END IF;
        END$$;
        """
    )

    # artifact_records
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='artifact_records'
            ) THEN
                CREATE TABLE artifact_records (
                    id SERIAL PRIMARY KEY,
                    artifact_name varchar(200) NOT NULL,
                    version varchar(64) NOT NULL,
                    created_at timestamp without time zone NOT NULL DEFAULT now(),
                    mode varchar(16) NOT NULL,
                    algo varchar(32) NOT NULL,
                    size_bytes bigint NOT NULL,
                    mtime_ns bigint NOT NULL,
                    hash varchar(128) NOT NULL,
                    file_path varchar(500)
                );
                CREATE UNIQUE INDEX uq_artifact_name_version ON artifact_records(artifact_name, version);
                CREATE INDEX idx_artifact_name ON artifact_records(artifact_name);
            END IF;
        END$$;
        """
    )


def downgrade() -> None:
    # Не удаляем таблицы (безопасный даунгрейд без потери данных)
    pass


