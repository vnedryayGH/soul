from __future__ import annotations

"""
v8: Activities and Sensations base tables + analytics MVs stubs

Revision ID: 20250911_000028
Revises: 20250911_000027
Create Date: 2025-09-11 13:30:00.000000
"""

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250911_000028"
down_revision = "20250911_000027"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Activities core
    op.execute(
        """
        create table if not exists activities (
          id uuid primary key,
          name text not null,
          persona_prompt_id int null,
          priority int not null default 0,
          time_min_min int null,
          time_max_min int null,
          satisfaction_policy jsonb null,
          actions_prompt text null,
          official_identity jsonb null,
          created_at timestamptz not null default now(),
          updated_at timestamptz not null default now()
        );

        create table if not exists activity_permissions (
          activity_id uuid not null,
          permission text not null,
          primary key (activity_id, permission),
          foreign key (activity_id) references activities(id) on delete cascade
        );

        create table if not exists activity_goals (
          activity_id uuid not null,
          goal_id uuid not null,
          goal_type text not null,
          metrics jsonb null,
          primary key (activity_id, goal_id),
          foreign key (activity_id) references activities(id) on delete cascade
        );

        create table if not exists activity_schedules (
          activity_id uuid primary key,
          cron text null,
          time_window jsonb null,
          foreign key (activity_id) references activities(id) on delete cascade
        );
        """
    )

    # Sensations
    op.execute(
        """
        create table if not exists sensation_settings (
          id uuid primary key,
          name text not null,
          enabled boolean not null default true,
          severity_min numeric null,
          severity_max numeric null,
          weight numeric null,
          params jsonb null
        );

        create table if not exists sensation_events (
          id uuid primary key,
          type text not null,
          severity numeric null,
          payload jsonb null,
          created_at timestamptz not null default now()
        );
        """
    )

    # Analytics MVs (stubs – created if not exists)
    op.execute(
        """
        create materialized view if not exists energy_balance_mv as
        select date_trunc('hour', now()) as ts_hour,
               0::numeric as energy_in,
               0::numeric as energy_out,
               0::numeric as sensations_delta,
               null::numeric as value_per_cost_avg;

        create unique index if not exists uq_energy_balance_mv on energy_balance_mv(ts_hour);

        create materialized view if not exists activity_effectiveness_mv as
        select null::uuid as activity_id,
               date_trunc('day', now()) as ts_day,
               null::numeric as avg_energy,
               0::int as completed_goals,
               null::numeric as queue_share,
               null::numeric as value_per_cost_avg;

        create index if not exists idx_activity_effectiveness_mv on activity_effectiveness_mv(ts_day);
        """
    )


def downgrade() -> None:
    # Non-destructive downgrade
    pass


