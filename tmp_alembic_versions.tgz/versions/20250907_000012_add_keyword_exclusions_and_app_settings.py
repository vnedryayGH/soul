"""
add keyword_exclusions and app_settings tables

Revision ID: 20250907_000012
Revises: 20250905_000011_add_rbac_roles_permissions_and_limits
Create Date: 2025-09-07 00:00:12.000000
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision = '20250907_000012'
down_revision = '20250905_000011'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'keyword_exclusions',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('word', sa.String(length=100), nullable=False, unique=True),
        sa.Column('hit_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
    )
    # уникальный индекс будет создан автоматически за счёт unique=True на колонке

    op.create_table(
        'app_settings',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('key', sa.String(length=190), nullable=False),
        sa.Column('value_text', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.UniqueConstraint('key', name='uq_app_settings_key')
    )


def downgrade() -> None:
    op.drop_table('app_settings')
    op.drop_table('keyword_exclusions')


