from __future__ import annotations

"""
Seed/align llm_role_limits when schema uses role_id (and possibly role text)

Revision ID: 20250911_000035
Revises: 20250911_000034
Create Date: 2025-09-11 17:18:00.000000
"""

from alembic import op


revision = "20250911_000035"
down_revision = "20250911_000034"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        do $$
        declare
          has_roles_name boolean := exists (select 1 from information_schema.columns where table_name='roles' and column_name='name');
          has_roles_role boolean := exists (select 1 from information_schema.columns where table_name='roles' and column_name='role');
          has_llm_role   boolean := exists (select 1 from information_schema.columns where table_name='llm_role_limits' and column_name='role');
          has_llm_role_id boolean := exists (select 1 from information_schema.columns where table_name='llm_role_limits' and column_name='role_id');
        begin
          if has_llm_role_id then
            -- Обновление по roles.name
            if has_roles_name then
              update llm_role_limits l set role_id = r.id
                from roles r
               where l.role_id is null
                 and r.name = 'Architect'
                 and (not has_llm_role or l.role is null or l.role = 'Architect');

              if has_llm_role then
                insert into llm_role_limits (role_id, role, priority_boost)
                select r.id, 'Architect', 1.0 from roles r
                 where r.name = 'Architect'
                   and not exists (select 1 from llm_role_limits l2 where l2.role_id = r.id or l2.role = 'Architect')
                on conflict do nothing;
              else
                insert into llm_role_limits (role_id, priority_boost)
                select r.id, 1.0 from roles r
                 where r.name = 'Architect'
                   and not exists (select 1 from llm_role_limits l2 where l2.role_id = r.id)
                on conflict do nothing;
              end if;
            elsif has_roles_role then
              -- Обновление по roles.role
              update llm_role_limits l set role_id = r.id
                from roles r
               where l.role_id is null
                 and r.role = 'Architect'
                 and (not has_llm_role or l.role is null or l.role = 'Architect');

              if has_llm_role then
                insert into llm_role_limits (role_id, role, priority_boost)
                select r.id, 'Architect', 1.0 from roles r
                 where r.role = 'Architect'
                   and not exists (select 1 from llm_role_limits l2 where l2.role_id = r.id or l2.role = 'Architect')
                on conflict do nothing;
              else
                insert into llm_role_limits (role_id, priority_boost)
                select r.id, 1.0 from roles r
                 where r.role = 'Architect'
                   and not exists (select 1 from llm_role_limits l2 where l2.role_id = r.id)
                on conflict do nothing;
              end if;
            end if;
          end if;
        end $$;
        """
    )


def downgrade() -> None:
    pass


