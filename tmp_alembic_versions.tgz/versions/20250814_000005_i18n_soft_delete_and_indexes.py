"""i18n soft delete and indexes

Revision ID: 20250814_000005
Revises: 20250814_000004
Create Date: 2025-08-14 00:35:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "20250814_000005"
down_revision = "20250814_000004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("i18n_entries", sa.Column("is_deleted", sa.Boolean(), nullable=False, server_default=sa.false()))
    op.alter_column("i18n_entries", "is_deleted", server_default=None)
    op.create_index("ix_i18n_entries_loc_ns_key", "i18n_entries", ["locale", "namespace", "key"], unique=False)


def downgrade() -> None:
    op.drop_index("ix_i18n_entries_loc_ns_key", table_name="i18n_entries")
    op.drop_column("i18n_entries", "is_deleted")


