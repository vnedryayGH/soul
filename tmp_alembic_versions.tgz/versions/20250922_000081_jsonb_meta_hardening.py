from __future__ import annotations

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20250922_000081_jsonb_meta_hardening'
down_revision = '20250922_000080_backman_issues'
branch_labels = None
depends_on = None


def _alter_meta_jsonb(table: str) -> None:
    # Аккуратный ALTER: кастуем только если колонка существует
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.columns
                WHERE table_schema='public' AND table_name='{table}' AND column_name='meta'
            ) THEN
                -- Установим пустой объект по умолчанию
                BEGIN
                    ALTER TABLE {table}
                        ALTER COLUMN meta TYPE jsonb USING (
                            CASE
                                WHEN meta IS NULL THEN '{{}}'::jsonb
                                WHEN pg_typeof(meta)::text = 'json' THEN to_jsonb(meta)
                                WHEN pg_typeof(meta)::text = 'jsonb' THEN meta
                                WHEN pg_typeof(meta)::text = 'text' THEN COALESCE(NULLIF(meta::text, '')::jsonb, '{{}}'::jsonb)
                                ELSE to_jsonb(meta)
                            END
                        ),
                        ALTER COLUMN meta SET DEFAULT '{{}}'::jsonb;
                EXCEPTION WHEN others THEN
                    -- Fallback: грубое приведение
                    BEGIN
                        ALTER TABLE {table}
                            ALTER COLUMN meta TYPE jsonb USING '{{}}'::jsonb,
                            ALTER COLUMN meta SET DEFAULT '{{}}'::jsonb;
                    END;
                END;
                -- Индекс GIN, если отсутствует
                IF NOT EXISTS (
                    SELECT 1 FROM pg_indexes WHERE schemaname=current_schema() AND indexname = 'idx_{table}_meta_gin'
                ) THEN
                    EXECUTE 'CREATE INDEX idx_{table}_meta_gin ON {table} USING gin (meta)';
                END IF;
            END IF;
        END$$;
        """
    )


def upgrade() -> None:
    for t in ('soul_audit_log', 'signature_steps', 'frontman_issues', 'backman_issues', 'skill_assets', 'user_skills', 'skill_practice'):
        _alter_meta_jsonb(t)


def downgrade() -> None:
    # Безопасный даунгрейд: не трогаем тип обратно, оставляем jsonb
    pass


