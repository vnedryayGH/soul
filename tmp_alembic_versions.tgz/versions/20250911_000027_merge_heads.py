from __future__ import annotations

"""
Merge heads: unify parallel branches into a single lineage

Revision ID: 20250911_000027
Revises: 20250109_000001, 20250911_000026
Create Date: 2025-09-11 13:05:00.000000
"""

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250911_000027"
down_revision = ("20250109_000001", "20250911_000026")
branch_labels = None
depends_on = None


def upgrade() -> None:
    # No-op merge
    pass


def downgrade() -> None:
    # No-op
    pass


