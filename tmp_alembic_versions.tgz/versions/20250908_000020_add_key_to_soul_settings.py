"""Add key column to soul_settings

Revision ID: 20250908_000020
Revises: 20250908_000019
Create Date: 2025-09-08 16:00:00.000000

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = '20250908_000020'
down_revision = '20250908_000019'
branch_labels = None
depends_on = None


def upgrade():
    # Проверяем, существует ли таблица soul_settings
    conn = op.get_bind()
    inspector = sa.inspect(conn)
    
    if 'soul_settings' in inspector.get_table_names():
        # Проверяем, есть ли уже столбец key
        columns = [col['name'] for col in inspector.get_columns('soul_settings')]
        
        if 'key' not in columns:
            # Добавляем столбец key
            op.add_column('soul_settings', sa.Column('key', sa.String(100), nullable=True))
            
            # Создаем уникальный индекс на key
            op.create_index('ix_soul_settings_key', 'soul_settings', ['key'], unique=True)
            
            # Заполняем существующие записи значениями по умолчанию
            op.execute("""
                UPDATE soul_settings 
                SET key = CASE 
                    WHEN id IS NOT NULL THEN 'setting_' || id::text
                    ELSE 'unknown_' || random()::text
                END
                WHERE key IS NULL
            """)
            
            # Делаем столбец NOT NULL после заполнения
            op.alter_column('soul_settings', 'key', nullable=False)
    else:
        # Создаем таблицу soul_settings с нуля
        op.create_table('soul_settings',
            sa.Column('id', sa.UUID(), nullable=False, server_default=sa.text('gen_random_uuid()')),
            sa.Column('key', sa.String(100), nullable=False),
            sa.Column('value', sa.Text(), nullable=True),
            sa.Column('description', sa.Text(), nullable=True),
            sa.Column('category', sa.String(50), nullable=True),
            sa.Column('data_type', sa.String(20), nullable=True, server_default='string'),
            sa.Column('is_configurable', sa.Boolean(), nullable=False, server_default='true'),
            sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('NOW()')),
            sa.Column('updated_at', sa.DateTime(), nullable=True),
            sa.PrimaryKeyConstraint('id'),
            sa.UniqueConstraint('key')
        )
        
        # Создаем индексы
        op.create_index('ix_soul_settings_key', 'soul_settings', ['key'], unique=True)
        op.create_index('ix_soul_settings_category', 'soul_settings', ['category'])
        
        # Вставляем базовые настройки
        op.execute("""
            INSERT INTO soul_settings (key, value, description, category, data_type) VALUES
            ('context_size', '20', 'Размер контекста для формирования ответов Soul', 'context', 'integer'),
            ('recent_ratio', '0.3', 'Доля последних квантов в контексте (алгоритм 30/70)', 'context', 'float'),
            ('ranked_ratio', '0.7', 'Доля ранжированных квантов в контексте (алгоритм 30/70)', 'context', 'float'),
            ('max_context_size', '100', 'Максимальный размер контекста', 'context', 'integer'),
            ('energy_decay_rate', '0.01', 'Скорость затухания энергии квантов', 'sleep', 'float'),
            ('connection_threshold', '0.1', 'Минимальная сила связи для сохранения', 'sleep', 'float'),
            ('sleep_interval_hours', '24', 'Интервал запуска процесса сна (часы)', 'sleep', 'integer'),
            ('llm_provider_default', 'gigachat', 'LLM провайдер по умолчанию', 'llm', 'string'),
            ('llm_provider_critical', 'deepseek', 'LLM провайдер для критических операций', 'llm', 'string'),
            ('optimization_enabled', 'true', 'Включена ли автоматическая оптимизация', 'optimization', 'boolean')
        """)


def downgrade():
    # Удаляем индексы
    op.drop_index('ix_soul_settings_key', table_name='soul_settings')
    
    # Проверяем, существует ли столбец key
    conn = op.get_bind()
    inspector = sa.inspect(conn)
    
    if 'soul_settings' in inspector.get_table_names():
        columns = [col['name'] for col in inspector.get_columns('soul_settings')]
        
        if 'key' in columns:
            # Удаляем столбец key
            op.drop_column('soul_settings', 'key')
        
        if 'category' in columns:
            op.drop_index('ix_soul_settings_category', table_name='soul_settings')
    else:
        # Удаляем всю таблицу
        op.drop_table('soul_settings')
