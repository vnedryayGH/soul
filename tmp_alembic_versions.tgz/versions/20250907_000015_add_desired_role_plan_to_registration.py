"""
add desired_role and desired_plan to registration_requests

Revision ID: 20250907_000015
Revises: 20250907_000014
Create Date: 2025-09-07 12:28:15.000000
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20250907_000015'
down_revision = '20250907_000014'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('registration_requests', sa.Column('desired_role', sa.String(length=50), nullable=True))
    op.add_column('registration_requests', sa.Column('desired_plan', sa.String(length=50), nullable=True))


def downgrade() -> None:
    op.drop_column('registration_requests', 'desired_plan')
    op.drop_column('registration_requests', 'desired_role')


