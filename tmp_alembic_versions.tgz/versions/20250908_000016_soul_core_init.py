from __future__ import annotations

"""
Initialize Soul core tables: quants, quant_desired_actions, quant_connections,
soul_settings, soul_audit_log, soul_optimization_settings, soul_optimization_runs,
and materialized view quant_rank_mv.

Revision ID: 20250908_000016
Revises: 20250907_000015
Create Date: 2025-09-08 13:10:00.000000
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision = "20250908_000016"
down_revision = "20250907_000015"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Ensure required extensions
    op.execute("CREATE EXTENSION IF NOT EXISTS pgcrypto")

    # quants
    op.create_table(
        "quants",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("seed_text", sa.Text(), nullable=True),
        sa.Column("llm_response", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("payload", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("thought_form", sa.Text(), nullable=True),
        sa.Column("composite_emotion", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("energy_weight", sa.Float(), nullable=True),
        sa.Column("q_factor", sa.Float(), nullable=True),
        sa.Column("tags", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("created_at", sa.DateTime(), server_default=sa.text("NOW()"), nullable=False),
    )
    op.create_index("idx_quants_created", "quants", ["created_at"])

    # quant_desired_actions (new schema: type + payload)
    op.create_table(
        "quant_desired_actions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("quant_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("type", sa.String(length=50), nullable=False),
        sa.Column("payload", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("created_at", sa.DateTime(), server_default=sa.text("NOW()"), nullable=False),
    )
    op.create_index("idx_qda_quant", "quant_desired_actions", ["quant_id"]) 
    op.create_index("idx_qda_type", "quant_desired_actions", ["type"]) 

    # quant_connections (undirected stored as two directed rows or separate rows)
    op.create_table(
        "quant_connections",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("from_quant_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("to_quant_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("connection_strength", sa.Float(), nullable=False, server_default=sa.text("0")),
        sa.Column("created_at", sa.DateTime(), server_default=sa.text("NOW()"), nullable=False),
    )
    op.create_index("idx_qc_from", "quant_connections", ["from_quant_id"]) 
    op.create_index("idx_qc_to", "quant_connections", ["to_quant_id"]) 
    op.create_index("idx_qc_strength", "quant_connections", ["connection_strength"]) 

    # soul_settings
    op.create_table(
        "soul_settings",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("use_batch_planner", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("batch_max_quants", sa.Integer(), nullable=False, server_default="5"),
        sa.Column("planner_params", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("sleep_params", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("refresh_rank_minutes", sa.Integer(), nullable=True),
        sa.Column("created_at", sa.DateTime(), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(), server_default=sa.text("NOW()"), nullable=False),
    )

    # soul_audit_log
    op.create_table(
        "soul_audit_log",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("timestamp", sa.DateTime(), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("event_type", sa.String(length=100), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("meta", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
    )
    op.create_index("idx_audit_type", "soul_audit_log", ["event_type"]) 

    # Optimization settings
    op.create_table(
        "soul_optimization_settings",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("window_days", sa.Integer(), nullable=False, server_default="7"),
        sa.Column("min_delta", sa.Float(), nullable=False, server_default="0.01"),
        sa.Column("target_metrics", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("parameters", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("auto_apply", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("updated_at", sa.DateTime(), server_default=sa.text("NOW()"), nullable=False),
    )

    # Optimization runs
    op.create_table(
        "soul_optimization_runs",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("started_at", sa.DateTime(), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("completed_at", sa.DateTime(), nullable=True),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="pending"),
        sa.Column("applied", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("error", sa.Text(), nullable=True),
        sa.Column("input_stats", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("llm_prompt", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("llm_response", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
    )
    op.create_index("idx_opt_runs_status", "soul_optimization_runs", ["status"]) 

    # Materialized view for ranking
    op.execute(
        """
        CREATE MATERIALIZED VIEW IF NOT EXISTS quant_rank_mv AS
        WITH edges AS (
            SELECT from_quant_id AS qid, connection_strength AS s FROM quant_connections
            UNION ALL
            SELECT to_quant_id   AS qid, connection_strength AS s FROM quant_connections
        ),
        agg AS (
            SELECT qid, COUNT(*) AS degree, COALESCE(SUM(s),0) AS weighted_degree
            FROM edges
            GROUP BY qid
        )
        SELECT a.qid::uuid AS quant_id,
               a.degree,
               a.weighted_degree,
               COALESCE(q.energy_weight, 0.0) AS energy_weight,
               COALESCE(q.q_factor, 0.0) AS q_factor,
               COALESCE(a.weighted_degree, 0.0) + 0.5*COALESCE(q.energy_weight,0.0) + 0.2*COALESCE(q.q_factor,0.0) AS score
        FROM agg a
        LEFT JOIN quants q ON q.id = a.qid::uuid;
        """
    )
    op.execute("CREATE INDEX IF NOT EXISTS idx_quant_rank_mv_score ON quant_rank_mv (score DESC)")


def downgrade() -> None:
    # Drop MV first
    op.execute("DROP MATERIALIZED VIEW IF EXISTS quant_rank_mv")

    # Drop tables in reverse order
    op.drop_index("idx_opt_runs_status", table_name="soul_optimization_runs")
    op.drop_table("soul_optimization_runs")

    op.drop_table("soul_optimization_settings")

    op.drop_index("idx_audit_type", table_name="soul_audit_log")
    op.drop_table("soul_audit_log")

    op.drop_table("soul_settings")

    op.drop_index("idx_qc_strength", table_name="quant_connections")
    op.drop_index("idx_qc_to", table_name="quant_connections")
    op.drop_index("idx_qc_from", table_name="quant_connections")
    op.drop_table("quant_connections")

    op.drop_index("idx_qda_type", table_name="quant_desired_actions")
    op.drop_index("idx_qda_quant", table_name="quant_desired_actions")
    op.drop_table("quant_desired_actions")

    op.drop_index("idx_quants_created", table_name="quants")
    op.drop_table("quants")


