from __future__ import annotations

"""
P51: Add GIN indexes for JSONB meta/value on personality tables

Revision ID: 20250929_000093
Revises: 20250929_000092
Create Date: 2025-09-29 06:55:00.000000
"""

from alembic import op


revision = "20250929_000093"
down_revision = "20250929_000092"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Ensure composite uniqueness for (personality_id, key)
    try:
        op.create_unique_constraint("uq_spp_personality_key", "soul_personality_policies", ["personality_id", "key"])
    except Exception:
        pass
    try:
        op.execute("CREATE INDEX IF NOT EXISTS ix_soul_personality_meta_gin ON soul_personality USING gin(meta)")
    except Exception:
        pass
    try:
        op.execute("CREATE INDEX IF NOT EXISTS ix_soul_personality_norms_meta_gin ON soul_personality_norms USING gin(meta)")
    except Exception:
        pass
    try:
        op.execute("CREATE INDEX IF NOT EXISTS ix_soul_personality_traits_meta_gin ON soul_personality_traits USING gin(meta)")
    except Exception:
        pass
    try:
        op.execute("CREATE INDEX IF NOT EXISTS ix_soul_personality_attachments_meta_gin ON soul_personality_attachments USING gin(meta)")
    except Exception:
        pass
    try:
        op.execute("CREATE INDEX IF NOT EXISTS ix_soul_personality_policies_value_gin ON soul_personality_policies USING gin(value)")
    except Exception:
        pass


def downgrade() -> None:
    try:
        op.drop_constraint("uq_spp_personality_key", "soul_personality_policies", type_="unique")
    except Exception:
        pass
    try:
        op.execute("DROP INDEX IF EXISTS ix_soul_personality_policies_value_gin")
    except Exception:
        pass
    try:
        op.execute("DROP INDEX IF EXISTS ix_soul_personality_attachments_meta_gin")
    except Exception:
        pass
    try:
        op.execute("DROP INDEX IF EXISTS ix_soul_personality_traits_meta_gin")
    except Exception:
        pass
    try:
        op.execute("DROP INDEX IF EXISTS ix_soul_personality_norms_meta_gin")
    except Exception:
        pass
    try:
        op.execute("DROP INDEX IF EXISTS ix_soul_personality_meta_gin")
    except Exception:
        pass


