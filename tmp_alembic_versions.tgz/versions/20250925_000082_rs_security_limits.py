"""
P48R/P44: RS Security Limits registry (per subject/op) and counters

Tables:
- rs_security_limits(id, subject_type, subject_value, op, window_sec, max_requests,
                     max_size_bytes, max_depth, max_session_calls, enabled, created_at)
- rs_security_counters(id, subject_type, subject_value, op, window_start, window_sec,
                       requests_count, blocked_count, updated_at)
- rs_security_denials(id, subject_type, subject_value, op, code, reason, detail, created_at)

All DDL uses IF NOT EXISTS to be resilient to PROD drift.
"""

from __future__ import annotations

from typing import Optional

from alembic import op


# Revision identifiers
revision: str = "20250925_000082_rs_sec_limits"
down_revision: Optional[str] = "20250925_000080_lang_succession_registry"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS public.rs_security_limits (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            subject_type TEXT NOT NULL DEFAULT 'global', -- global|role|user
            subject_value TEXT,                          -- role name or tg_id as text, NULL for global
            op TEXT NOT NULL DEFAULT 'hyperloop',        -- logical operation key
            window_sec INTEGER NOT NULL DEFAULT 60,      -- sliding window length
            max_requests INTEGER NOT NULL DEFAULT 60,    -- max requests within window
            max_size_bytes INTEGER,                      -- optional payload size limit
            max_depth INTEGER,                           -- optional depth/commands limit
            max_session_calls INTEGER,                   -- optional per-trace/session limit
            enabled BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE INDEX IF NOT EXISTS ix_rs_sec_limits_subject_op
            ON public.rs_security_limits (subject_type, subject_value, op);

        CREATE TABLE IF NOT EXISTS public.rs_security_counters (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            subject_type TEXT NOT NULL DEFAULT 'global',
            subject_value TEXT,
            op TEXT NOT NULL,
            window_start TIMESTAMPTZ NOT NULL,
            window_sec INTEGER NOT NULL,
            requests_count INTEGER NOT NULL DEFAULT 0,
            blocked_count INTEGER NOT NULL DEFAULT 0,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE INDEX IF NOT EXISTS ix_rs_sec_counters_window
            ON public.rs_security_counters (op, window_start);
        CREATE INDEX IF NOT EXISTS ix_rs_sec_counters_subject
            ON public.rs_security_counters (subject_type, subject_value);

        CREATE TABLE IF NOT EXISTS public.rs_security_denials (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            subject_type TEXT NOT NULL DEFAULT 'global',
            subject_value TEXT,
            op TEXT NOT NULL,
            code INTEGER NOT NULL,                       -- error code
            reason TEXT NOT NULL,                        -- short machine reason
            detail TEXT,                                 -- optional human-readable
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE INDEX IF NOT EXISTS ix_rs_sec_denials_created
            ON public.rs_security_denials (created_at);
        CREATE INDEX IF NOT EXISTS ix_rs_sec_denials_subject
            ON public.rs_security_denials (subject_type, subject_value);
        CREATE INDEX IF NOT EXISTS ix_rs_sec_denials_op
            ON public.rs_security_denials (op);

        -- Seed a safe global default if empty: 60 req/min, size 64KB, depth 50
        INSERT INTO public.rs_security_limits(subject_type, subject_value, op, window_sec, max_requests, max_size_bytes, max_depth, max_session_calls, enabled)
        SELECT 'global', NULL, 'hyperloop', 60, 60, 65536, 50, 200, TRUE
        WHERE NOT EXISTS (SELECT 1 FROM public.rs_security_limits);
        """
    )


def downgrade() -> None:
    # Non-destructive in PROD
    pass


