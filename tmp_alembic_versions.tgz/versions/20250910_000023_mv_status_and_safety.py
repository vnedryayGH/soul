from __future__ import annotations

"""
v7: mv_status table and indexes for analytics by policy

Revision ID: 20250910_000023
Revises: 20250910_000022
Create Date: 2025-09-11 00:08:00.000000
"""

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250910_000023"
down_revision = "20250910_000022"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        create table if not exists mv_status (
          mv_name text primary key,
          last_refresh_at timestamptz,
          last_refresh_ok boolean,
          last_error text
        );

        create index if not exists idx_flow_q_policy_created on flow_dispatch_queue(policy, created_at);
        """
    )


def downgrade() -> None:
    pass


