from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = '20250922_000081_code_change_lock_queue'
down_revision = '20250922_000080_backman_issues'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'code_change_locks',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('file_path', sa.String(length=512), nullable=False),
        sa.Column('holder', sa.String(length=100), nullable=False),
        sa.Column('started_at', sa.DateTime(), nullable=False, server_default=sa.text('now()')),
        sa.Column('expires_at', sa.DateTime(), nullable=True),
        sa.Column('meta', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('etag', sa.String(length=80), nullable=True),
    )
    op.create_index('idx_code_change_locks_file', 'code_change_locks', ['file_path'], unique=False)
    op.create_index('idx_code_change_locks_expires', 'code_change_locks', ['expires_at'], unique=False)

    op.create_table(
        'code_change_queue',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('file_path', sa.String(length=512), nullable=False),
        sa.Column('developer', sa.String(length=100), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False, server_default='queued'),  # queued|in_progress|done|cancelled
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('now()')),
        sa.Column('payload', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('etag', sa.String(length=80), nullable=True),
    )
    op.create_index('idx_code_change_queue_file', 'code_change_queue', ['file_path'], unique=False)
    op.create_index('idx_code_change_queue_status', 'code_change_queue', ['status'], unique=False)


def downgrade() -> None:
    op.drop_index('idx_code_change_queue_status', table_name='code_change_queue')
    op.drop_index('idx_code_change_queue_file', table_name='code_change_queue')
    op.drop_table('code_change_queue')
    op.drop_index('idx_code_change_locks_expires', table_name='code_change_locks')
    op.drop_index('idx_code_change_locks_file', table_name='code_change_locks')
    op.drop_table('code_change_locks')


