"""Add 'ask_architect' to desired_action_type enum

Revision ID: 20250928_000090
Revises: 20250926_000080_p50_incident_management
Create Date: 2025-09-28
"""

from __future__ import annotations

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250928_000090_add_ask_architect_enum"
down_revision = "20250926_000080_p50_incident_management"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        DO $$
        BEGIN
          IF NOT EXISTS (
            SELECT 1 FROM pg_type t
            JOIN pg_enum e ON e.enumtypid = t.oid
            WHERE t.typname = 'desired_action_type' AND e.enumlabel = 'ask_architect'
          ) THEN
            ALTER TYPE desired_action_type ADD VALUE 'ask_architect';
          END IF;
        END $$;
        """
    )


def downgrade() -> None:
    # Enum value removal is non-trivial in PostgreSQL; keep as no-op.
    pass


