from __future__ import annotations

"""
Ensure llm_role_limits has 'role' column and unique index

Revision ID: 20250911_000032
Revises: 20250911_000031
Create Date: 2025-09-11 15:34:00.000000
"""

from alembic import op


revision = "20250911_000032"
down_revision = "20250911_000031"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        do $$ begin
          if exists (select 1 from information_schema.tables where table_name='llm_role_limits') then
            if not exists (
              select 1 from information_schema.columns where table_name='llm_role_limits' and column_name='role'
            ) then
              alter table llm_role_limits add column role text;
            end if;
            -- ensure unique index to support ON CONFLICT (role)
            create unique index if not exists uq_llm_role_limits_role on llm_role_limits(role);
          else
            -- create table if it doesn't exist at all
            create table llm_role_limits (
              role text primary key,
              max_tokens_per_day int,
              max_rps numeric,
              priority_boost numeric default 0
            );
          end if;
        end $$;
        """
    )


def downgrade() -> None:
    # keep schema broadenings
    pass


