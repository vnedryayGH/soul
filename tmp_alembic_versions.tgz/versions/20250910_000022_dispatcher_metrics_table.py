from __future__ import annotations

"""
v7: dispatcher metrics table

Revision ID: 20250910_000022
Revises: 20250910_000021
Create Date: 2025-09-10 23:59:00.000000
"""

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250910_000022"
down_revision = "20250910_000021"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        create table if not exists flow_dispatch_metrics (
          ts_hour timestamptz primary key,
          queued int not null default 0,
          scheduled int not null default 0,
          dispatched int not null default 0,
          skipped int not null default 0,
          energy_budget_used numeric null,
          cache_hit_rate numeric null,
          ml_gating_rejects int not null default 0
        );
        """
    )


def downgrade() -> None:
    pass


