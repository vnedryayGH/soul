from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = '20250929_000101_personality_influence_observations'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        sa.text(
            """
            CREATE TABLE IF NOT EXISTS personality_influence_observations (
              id bigserial PRIMARY KEY,
              ts timestamptz NOT NULL DEFAULT now(),
              stage text NOT NULL,
              value double precision NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_pio_stage_ts ON personality_influence_observations(stage, ts DESC);
            """
        )
    )


def downgrade():
    op.execute(sa.text("DROP TABLE IF EXISTS personality_influence_observations"))
