"""i18n unique (locale, namespace, key)

Revision ID: 20250814_000006
Revises: 20250814_000005
Create Date: 2025-08-14 23:45:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "20250814_000006"
down_revision = "20250814_000005"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Удалим возможные дубли, сохраняя самую свежую запись по версии/времени
    op.execute(
        """
        WITH ranked AS (
            SELECT id,
                   ROW_NUMBER() OVER (
                       PARTITION BY locale, namespace, key
                       ORDER BY version DESC, updated_at DESC, id DESC
                   ) AS rn
            FROM i18n_entries
        )
        DELETE FROM i18n_entries WHERE id IN (SELECT id FROM ranked WHERE rn > 1);
        """
    )
    # Уникальность на ключе
    op.create_unique_constraint(
        "uq_i18n_entries_loc_ns_key",
        "i18n_entries",
        ["locale", "namespace", "key"],
    )


def downgrade() -> None:
    op.drop_constraint("uq_i18n_entries_loc_ns_key", "i18n_entries", type_="unique")


