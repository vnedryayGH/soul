"""
P27/P35: core quant_links table with required indexes
"""
from typing import Optional
from alembic import op

revision: str = "20250916_000052_quant_links_core"
down_revision: Optional[str] = "20250916_000051_p25_entities_ext"
branch_labels = None
depends_on = None


def upgrade() -> None:
	op.execute(
		"""
		CREATE TABLE IF NOT EXISTS public.quant_links (
		  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
		  from_quant uuid NOT NULL,
		  to_entity_type text NOT NULL,
		  to_entity_id text NOT NULL,
		  relation_type text NOT NULL,
		  weight double precision,
		  created_at timestamptz DEFAULT now()
		);
		CREATE INDEX IF NOT EXISTS ix_quant_links_to_entity ON public.quant_links (to_entity_type, to_entity_id);
		CREATE INDEX IF NOT EXISTS ix_quant_links_from_quant ON public.quant_links (from_quant);
		CREATE INDEX IF NOT EXISTS ix_quant_links_relation ON public.quant_links (relation_type);
		"""
	)


def downgrade() -> None:
	op.execute(
		"""
		DROP TABLE IF EXISTS public.quant_links;
		"""
	)
