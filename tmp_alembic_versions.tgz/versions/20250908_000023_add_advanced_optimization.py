"""Add advanced optimization results table

Revision ID: 20250908_000023
Revises: 20250908_000022
Create Date: 2025-01-08 12:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '20250908_000023'
down_revision = '20250908_000022'
branch_labels = None
depends_on = None


def upgrade():
    # Создаем таблицу для результатов продвинутой оптимизации
    op.create_table('soul_advanced_optimization_results',
        sa.Column('id', sa.UUID(), nullable=False, server_default=sa.text('gen_random_uuid()')),
        sa.Column('domain', sa.String(50), nullable=False),
        sa.Column('suggested_parameters', postgresql.JSONB(), nullable=True),
        sa.Column('confidence_score', sa.Float(), nullable=False, server_default='0.5'),
        sa.Column('expected_impact', postgresql.JSONB(), nullable=True),
        sa.Column('mathematical_reasoning', sa.Text(), nullable=True),
        sa.Column('llm_reasoning', sa.Text(), nullable=True),
        sa.Column('risk_assessment', postgresql.JSONB(), nullable=True),
        sa.Column('implementation_priority', sa.Integer(), nullable=False, server_default='5'),
        sa.Column('applied', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('applied_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('NOW()')),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    
    # Индексы для быстрого поиска
    op.create_index('ix_soul_advanced_optimization_domain', 'soul_advanced_optimization_results', ['domain'])
    op.create_index('ix_soul_advanced_optimization_created_at', 'soul_advanced_optimization_results', ['created_at'])
    op.create_index('ix_soul_advanced_optimization_priority', 'soul_advanced_optimization_results', ['implementation_priority'])
    op.create_index('ix_soul_advanced_optimization_applied', 'soul_advanced_optimization_results', ['applied'])


def downgrade():
    op.drop_index('ix_soul_advanced_optimization_applied', table_name='soul_advanced_optimization_results')
    op.drop_index('ix_soul_advanced_optimization_priority', table_name='soul_advanced_optimization_results')
    op.drop_index('ix_soul_advanced_optimization_created_at', table_name='soul_advanced_optimization_results')
    op.drop_index('ix_soul_advanced_optimization_domain', table_name='soul_advanced_optimization_results')
    op.drop_table('soul_advanced_optimization_results')
