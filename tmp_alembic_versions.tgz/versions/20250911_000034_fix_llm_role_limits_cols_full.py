from __future__ import annotations

"""
Ensure llm_role_limits has full column set (role, max_tokens_per_day, max_rps, priority_boost)

Revision ID: 20250911_000034
Revises: 20250911_000033
Create Date: 2025-09-11 17:05:00.000000
"""

from alembic import op


revision = "20250911_000034"
down_revision = "20250911_000033"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        do $$ begin
          if exists (select 1 from information_schema.tables where table_name='llm_role_limits') then
            -- add missing columns
            if not exists (select 1 from information_schema.columns where table_name='llm_role_limits' and column_name='role') then
              alter table llm_role_limits add column role text;
            end if;
            if not exists (select 1 from information_schema.columns where table_name='llm_role_limits' and column_name='max_tokens_per_day') then
              alter table llm_role_limits add column max_tokens_per_day int;
            end if;
            if not exists (select 1 from information_schema.columns where table_name='llm_role_limits' and column_name='max_rps') then
              alter table llm_role_limits add column max_rps numeric;
            end if;
            if not exists (select 1 from information_schema.columns where table_name='llm_role_limits' and column_name='priority_boost') then
              alter table llm_role_limits add column priority_boost numeric default 0;
            end if;
            -- ensure uniqueness by role
            create unique index if not exists uq_llm_role_limits_role on llm_role_limits(role);
          else
            -- create table if absent
            create table llm_role_limits (
              role text primary key,
              max_tokens_per_day int,
              max_rps numeric,
              priority_boost numeric default 0
            );
          end if;
        end $$;
        """
    )


def downgrade() -> None:
    # non-destructive
    pass


