"""Restructure soul_settings table

Revision ID: 20250908_000021
Revises: 20250908_000020
Create Date: 2025-09-08 17:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '20250908_000021'
down_revision = '20250908_000020'
branch_labels = None
depends_on = None


def upgrade():
    # Сохраняем существующие данные
    conn = op.get_bind()
    inspector = sa.inspect(conn)
    
    if 'soul_settings' in inspector.get_table_names():
        # Создаем временную таблицу с новой структурой
        op.create_table('soul_settings_new',
            sa.Column('id', sa.UUID(), nullable=False, server_default=sa.text('gen_random_uuid()')),
            sa.Column('key', sa.String(100), nullable=False),
            sa.Column('value', sa.Text(), nullable=True),
            sa.Column('description', sa.Text(), nullable=True),
            sa.Column('category', sa.String(50), nullable=True),
            sa.Column('data_type', sa.String(20), nullable=True, server_default='string'),
            sa.Column('is_configurable', sa.Boolean(), nullable=False, server_default='true'),
            sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('NOW()')),
            sa.Column('updated_at', sa.DateTime(), nullable=True),
            sa.PrimaryKeyConstraint('id'),
            sa.UniqueConstraint('key')
        )
        
        # Мигрируем существующие данные
        op.execute("""
            INSERT INTO soul_settings_new (key, value, description, category, data_type, is_configurable, created_at, updated_at)
            SELECT 
                COALESCE(key, 'legacy_' || id::text) as key,
                COALESCE(
                    CASE 
                        WHEN use_batch_planner THEN 'true' 
                        ELSE 'false' 
                    END, 'false'
                ) as value,
                'Использовать планировщик батчей' as description,
                'batch' as category,
                'boolean' as data_type,
                true as is_configurable,
                created_at,
                updated_at
            FROM soul_settings
            WHERE key IS NOT NULL OR id IS NOT NULL
        """)
        
        # Добавляем дополнительные настройки из старой таблицы
        op.execute("""
            INSERT INTO soul_settings_new (key, value, description, category, data_type, is_configurable)
            SELECT 
                'batch_max_quants',
                batch_max_quants::text,
                'Максимальное количество квантов в батче',
                'batch',
                'integer',
                true
            FROM soul_settings 
            WHERE batch_max_quants IS NOT NULL
            LIMIT 1
        """)
        
        # Удаляем старую таблицу
        op.drop_table('soul_settings')
        
        # Переименовываем новую таблицу
        op.rename_table('soul_settings_new', 'soul_settings')
        
        # Создаем индексы
        op.create_index('ix_soul_settings_key', 'soul_settings', ['key'], unique=True)
        op.create_index('ix_soul_settings_category', 'soul_settings', ['category'])
        
        # Вставляем базовые настройки
        op.execute("""
            INSERT INTO soul_settings (key, value, description, category, data_type, is_configurable) VALUES
            ('context_size', '20', 'Размер контекста для формирования ответов Soul', 'context', 'integer', true),
            ('recent_ratio', '0.3', 'Доля последних квантов в контексте (алгоритм 30/70)', 'context', 'float', true),
            ('ranked_ratio', '0.7', 'Доля ранжированных квантов в контексте (алгоритм 30/70)', 'context', 'float', true),
            ('max_context_size', '100', 'Максимальный размер контекста', 'context', 'integer', true),
            ('energy_decay_rate', '0.01', 'Скорость затухания энергии квантов', 'sleep', 'float', true),
            ('connection_threshold', '0.1', 'Минимальная сила связи для сохранения', 'sleep', 'float', true),
            ('sleep_interval_hours', '24', 'Интервал запуска процесса сна (часы)', 'sleep', 'integer', true),
            ('llm_provider_default', 'gigachat', 'LLM провайдер по умолчанию', 'llm', 'string', true),
            ('llm_provider_critical', 'deepseek', 'LLM провайдер для критических операций', 'llm', 'string', true),
            ('optimization_enabled', 'true', 'Включена ли автоматическая оптимизация', 'optimization', 'boolean', true)
            ON CONFLICT (key) DO NOTHING
        """)


def downgrade():
    # Создаем старую структуру таблицы
    op.create_table('soul_settings_old',
        sa.Column('id', sa.Integer(), nullable=False, autoincrement=True),
        sa.Column('use_batch_planner', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('batch_max_quants', sa.Integer(), nullable=False, server_default='5'),
        sa.Column('planner_params', postgresql.JSONB(), nullable=True),
        sa.Column('sleep_params', postgresql.JSONB(), nullable=True),
        sa.Column('refresh_rank_minutes', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('NOW()')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('NOW()')),
        sa.Column('sleep_time_msk', sa.Time(), nullable=True),
        sa.Column('key', sa.String(100), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    
    # Мигрируем данные обратно (частично)
    op.execute("""
        INSERT INTO soul_settings_old (use_batch_planner, batch_max_quants, created_at, updated_at, key)
        SELECT 
            CASE WHEN value = 'true' THEN true ELSE false END as use_batch_planner,
            CASE WHEN key = 'batch_max_quants' THEN value::integer ELSE 5 END as batch_max_quants,
            created_at,
            updated_at,
            key
        FROM soul_settings
        WHERE key IN ('use_batch_planner', 'batch_max_quants')
        LIMIT 1
    """)
    
    # Удаляем новую таблицу
    op.drop_index('ix_soul_settings_category', table_name='soul_settings')
    op.drop_index('ix_soul_settings_key', table_name='soul_settings')
    op.drop_table('soul_settings')
    
    # Переименовываем старую таблицу обратно
    op.rename_table('soul_settings_old', 'soul_settings')
