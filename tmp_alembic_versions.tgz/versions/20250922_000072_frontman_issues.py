from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = '20250922_000072_frontman_issues'
down_revision = '20250922_000071_ui_forms_registry'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'frontman_issues',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('issue_type', sa.String(length=50), nullable=False),
        sa.Column('severity', sa.String(length=16), nullable=False, server_default='minor'),
        sa.Column('status', sa.String(length=16), nullable=False, server_default='open'),
        sa.Column('form_key', sa.String(length=100), nullable=True),
        sa.Column('route', sa.String(length=255), nullable=True),
        sa.Column('title', sa.String(length=200), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('suggestion', sa.Text(), nullable=True),
        sa.Column('meta', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('row_version', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('etag', sa.String(length=80), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('now()')),
    )
    op.create_index('idx_frontman_issues_status', 'frontman_issues', ['status'], unique=False)
    op.create_index('idx_frontman_issues_severity', 'frontman_issues', ['severity'], unique=False)
    op.create_index('idx_frontman_issues_form', 'frontman_issues', ['form_key'], unique=False)


def downgrade() -> None:
    op.drop_index('idx_frontman_issues_form', table_name='frontman_issues')
    op.drop_index('idx_frontman_issues_severity', table_name='frontman_issues')
    op.drop_index('idx_frontman_issues_status', table_name='frontman_issues')
    op.drop_table('frontman_issues')


