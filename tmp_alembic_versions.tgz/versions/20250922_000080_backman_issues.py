from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = '20250922_000080_backman_issues'
down_revision = '20250922_000073_reminders_add_utc_column'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'backman_issues',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('issue_type', sa.String(length=50), nullable=False),
        sa.Column('severity', sa.String(length=16), nullable=False, server_default='minor'),
        sa.Column('status', sa.String(length=16), nullable=False, server_default='open'),
        sa.Column('route', sa.String(length=255), nullable=True),
        sa.Column('title', sa.String(length=200), nullable=False),
        sa.Column('symptom', sa.Text(), nullable=True),
        sa.Column('recommendation', sa.Text(), nullable=True),
        sa.Column('meta', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('row_version', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('etag', sa.String(length=80), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('now()')),
    )
    op.create_index('idx_backman_issues_status', 'backman_issues', ['status'], unique=False)
    op.create_index('idx_backman_issues_severity', 'backman_issues', ['severity'], unique=False)
    op.create_index('idx_backman_issues_route', 'backman_issues', ['route'], unique=False)


def downgrade() -> None:
    op.drop_index('idx_backman_issues_route', table_name='backman_issues')
    op.drop_index('idx_backman_issues_severity', table_name='backman_issues')
    op.drop_index('idx_backman_issues_status', table_name='backman_issues')
    op.drop_table('backman_issues')


