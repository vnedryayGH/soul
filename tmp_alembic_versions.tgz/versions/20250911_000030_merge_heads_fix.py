from __future__ import annotations

"""
Merge heads to resolve multiple head revisions

Revision ID: 20250911_000030
Revises: 20250908_000023, 20250911_000029
Create Date: 2025-09-11 15:10:00.000000
"""

from alembic import op


revision = "20250911_000030"
down_revision = ("20250908_000023", "20250911_000029")
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass


