"""
P39: sensory_matrix column and GIN indexes (idempotent)

Revision ID: 20250920_000063_p39_sensory
Revises: 20250917_000062_p30_proc
Create Date: 2025-09-20 16:25:00
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa  # noqa: F401


revision = "20250920_000063_p39_sensory"
down_revision = "20250917_000062_p30_proc"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # 1) Добавить колонку quants.sensory_matrix jsonb (если отсутствует)
    op.execute(
        """
        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.tables
                WHERE table_schema='public' AND table_name='quants'
            ) THEN
                IF NOT EXISTS (
                    SELECT 1 FROM information_schema.columns
                    WHERE table_schema='public' AND table_name='quants' AND column_name='sensory_matrix'
                ) THEN
                    ALTER TABLE quants ADD COLUMN sensory_matrix jsonb DEFAULT '{}'::jsonb;
                END IF;
            END IF;
        END$$;
        """
    )

    # 2) Индекс GIN на колонку sensory_matrix (если колонка есть)
    op.execute(
        """
        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.columns
                WHERE table_schema='public' AND table_name='quants' AND column_name='sensory_matrix'
            ) THEN
                IF NOT EXISTS (
                    SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
                    WHERE c.relname = 'ix_quants_sensory_gin' AND n.nspname = 'public'
                ) THEN
                    CREATE INDEX ix_quants_sensory_gin ON quants USING gin (sensory_matrix);
                END IF;
            END IF;
        END$$;
        """
    )

    # 3) Выражение-индекс для текущего доступа к payload->'sensory_matrix'
    op.execute(
        """
        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.columns
                WHERE table_schema='public' AND table_name='quants' AND column_name='payload'
            ) THEN
                IF NOT EXISTS (
                    SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
                    WHERE c.relname = 'ix_quants_payload_sensory_gin' AND n.nspname = 'public'
                ) THEN
                    CREATE INDEX ix_quants_payload_sensory_gin ON quants USING gin ((payload -> 'sensory_matrix'));
                END IF;
            END IF;
        END$$;
        """
    )


def downgrade() -> None:
    # Безопасный даунгрейд: индексы можно удалить, колонку не трогаем
    op.execute(
        """
        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
                WHERE c.relname = 'ix_quants_payload_sensory_gin' AND n.nspname = 'public'
            ) THEN
                DROP INDEX IF EXISTS ix_quants_payload_sensory_gin;
            END IF;
            IF EXISTS (
                SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
                WHERE c.relname = 'ix_quants_sensory_gin' AND n.nspname = 'public'
            ) THEN
                DROP INDEX IF EXISTS ix_quants_sensory_gin;
            END IF;
        END$$;
        """
    )


