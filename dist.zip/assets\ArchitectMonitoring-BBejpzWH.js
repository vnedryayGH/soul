import { a as reactExports, j as jsxRuntimeExports } from "./react-DAIzMmXQ.js";
import { d as dayjs } from "./dayjs.min-Bmc1qNKW.js";
import { j as buildAuthHeaders, s as staticMethods, l as Space, p as Tag, B as Button, T as Typography, I as Input, F as ForwardTable } from "./index-D96S_AGP.js";
import { C as Card } from "./index-D6TbQLqe.js";
import { D as Drawer } from "./index-CAL1mpCo.js";
import "./Skeleton-BpzyhyPF.js";
import "./context-CpvbwDYP.js";
function ArchitectMonitoring() {
  const [loading, setLoading] = reactExports.useState(false);
  const [items, setItems] = reactExports.useState([]);
  const [total, setTotal] = reactExports.useState(0);
  const [page, setPage] = reactExports.useState(1);
  const [pageSize, setPageSize] = reactExports.useState(20);
  const [creating, setCreating] = reactExports.useState(false);
  const [note, setNote] = reactExports.useState("");
  const [detailOpen, setDetailOpen] = reactExports.useState(false);
  const [detailLoading, setDetailLoading] = reactExports.useState(false);
  const [detail, setDetail] = reactExports.useState(null);
  const load = reactExports.useCallback(async (p = page, ps = pageSize) => {
    try {
      setLoading(true);
      const resp = await fetch(`/api/admin/architect/monitoring/snapshots?limit=${ps}&offset=${(p - 1) * ps}`, {
        headers: buildAuthHeaders(),
        credentials: "include"
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();
      setItems(Array.isArray(data.items) ? data.items : []);
      setTotal(Number(data.total || 0));
    } catch (e) {
      staticMethods.error("Не удалось загрузить снимки");
    } finally {
      setLoading(false);
    }
  }, [page, pageSize]);
  const loadDetail = reactExports.useCallback(async (id) => {
    try {
      setDetailLoading(true);
      const resp = await fetch(`/api/admin/architect/monitoring/snapshots/${encodeURIComponent(id)}`, {
        headers: buildAuthHeaders(),
        credentials: "include"
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();
      setDetail(data);
      setDetailOpen(true);
    } catch (e) {
      staticMethods.error("Не удалось загрузить детальный снимок");
    } finally {
      setDetailLoading(false);
    }
  }, []);
  const createSnapshot = reactExports.useCallback(async () => {
    try {
      setCreating(true);
      const resp = await fetch(`/api/admin/architect/monitoring/snapshots`, {
        method: "POST",
        headers: buildAuthHeaders(),
        credentials: "include",
        body: JSON.stringify(note ? { note } : {})
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();
      if (data == null ? void 0 : data.snapshot_id) {
        staticMethods.success("Снимок создан");
        setNote("");
        await load(1, pageSize);
        setPage(1);
      } else {
        staticMethods.warning("Снимок создан, но отсутствует snapshot_id");
        await load(page, pageSize);
      }
    } catch (e) {
      staticMethods.error("Не удалось создать снимок");
    } finally {
      setCreating(false);
    }
  }, [note, page, pageSize, load]);
  reactExports.useEffect(() => {
    load(page, pageSize);
  }, [load, page, pageSize]);
  const columns = reactExports.useMemo(() => [
    {
      title: "Дата",
      dataIndex: "created_at",
      key: "created_at",
      width: 200,
      render: (v) => dayjs(v).format("YYYY-MM-DD HH:mm:ss")
    },
    { title: "Источник", dataIndex: "source", key: "source", width: 160 },
    { title: "Заметка", dataIndex: "note", key: "note" },
    {
      title: "Теги",
      key: "tags",
      width: 220,
      render: (_, r) => Array.isArray(r.tags) && r.tags.length ? /* @__PURE__ */ jsxRuntimeExports.jsx(Space, { wrap: true, children: r.tags.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(Tag, { children: t }, `${r.id}-${t}`)) }) : null
    },
    {
      title: "",
      key: "actions",
      width: 120,
      render: (_, r) => /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "small", onClick: () => loadDetail(r.id), children: "Открыть" })
    }
  ], [loadDetail]);
  const metricsHighlights = reactExports.useMemo(() => {
    const m = (detail == null ? void 0 : detail.metrics) || {};
    const pick = (k) => m[k];
    return {
      wake_ready_time_ms: pick("wake_ready_time_ms"),
      wake_cache_graph_edges: pick("wake_cache_graph_edges"),
      wake_retry_ratio: pick("wake_retry_ratio"),
      hyperloop_execute_latency_ms_p95: pick("hyperloop_execute_latency_ms_p95"),
      processor_time_send_to_recv_ms_p95: pick("processor_time_send_to_recv_ms_p95"),
      processor_guard_error_rate: pick("processor_guard_error_rate"),
      incidents_rate_per_min: pick("incidents_rate_per_min")
    };
  }, [detail]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { padding: "var(--sp-spacing-sm)" }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Typography.Title, { level: 3, style: { marginBottom: 12 }, children: "Monitoring Dashboard" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { style: { marginBottom: 12 }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Space, { wrap: true, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Input,
        {
          placeholder: "Заметка к снимку (опц.)",
          style: { width: 360 },
          value: note,
          onChange: (e) => setNote(e.target.value)
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "primary", onClick: createSnapshot, loading: creating, children: "Создать снимок" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: () => load(page, pageSize), loading, children: "Обновить" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      ForwardTable,
      {
        size: "small",
        rowKey: (r) => r.id,
        loading,
        dataSource: items,
        columns,
        pagination: {
          current: page,
          pageSize,
          total,
          showSizeChanger: true,
          onChange: (p, ps) => {
            setPage(p);
            setPageSize(ps);
          }
        }
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Drawer,
      {
        title: detail ? `Снимок ${dayjs(detail.created_at).format("YYYY-MM-DD HH:mm:ss")}` : "Снимок",
        open: detailOpen,
        onClose: () => setDetailOpen(false),
        width: 720,
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Space, { direction: "vertical", style: { width: "100%" }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { size: "small", title: "Ключевые метрики", children: /* @__PURE__ */ jsxRuntimeExports.jsx("pre", { style: { margin: 0, whiteSpace: "pre-wrap" }, children: JSON.stringify(metricsHighlights, null, 2) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { size: "small", title: "Все метрики", children: detailLoading ? "Загрузка…" : /* @__PURE__ */ jsxRuntimeExports.jsx("pre", { style: { margin: 0, whiteSpace: "pre-wrap" }, children: JSON.stringify((detail == null ? void 0 : detail.metrics) || {}, null, 2) }) })
        ] })
      }
    )
  ] });
}
export {
  ArchitectMonitoring as default
};
//# sourceMappingURL=ArchitectMonitoring-BBejpzWH.js.map
