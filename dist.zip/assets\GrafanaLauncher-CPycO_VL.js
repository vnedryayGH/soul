import { a as reactExports, j as jsxRuntimeExports } from "./react-DAIzMmXQ.js";
import { j as buildAuthHeaders, T as Typography, l as Space, B as Button } from "./index-D96S_AGP.js";
const GrafanaLauncher = () => {
  const [url, setUrl] = reactExports.useState("https://mini.soulpulse.art/grafana");
  const [baseUrl, setBaseUrl] = reactExports.useState("https://mini.soulpulse.art/grafana");
  const [sysUrl] = reactExports.useState("https://mini.soulpulse.art/grafana/d/fezsdipw3hgcgc/system-metrics-e28094-lima-and-services-and-soul");
  const [loading, setLoading] = reactExports.useState(true);
  reactExports.useEffect(() => {
    (async () => {
      try {
        const resp = await fetch("/api/miniapp/grafana/ml", { headers: buildAuthHeaders() });
        if (resp.ok) {
          const data = await resp.json();
          const raw = String((data == null ? void 0 : data.url) || "");
          if (raw.startsWith("http")) {
            try {
              const u = new URL(raw);
              u.searchParams.delete("kiosk");
              setUrl(u.toString());
              const idx = u.pathname.indexOf("/d/");
              if (idx > 0) {
                setBaseUrl(u.origin + u.pathname.slice(0, idx + 1));
              } else {
                setBaseUrl(u.origin + "/");
              }
            } catch (e) {
              setUrl(raw);
            }
          }
        }
      } catch (e) {
      } finally {
        setLoading(false);
      }
    })();
  }, []);
  const openExternal = () => {
    try {
      window.location.hash = "#/soul/dashboard";
    } catch (e) {
      window.location.assign("#/soul/dashboard");
    }
  };
  const openDashboardsList = () => {
    try {
      window.location.hash = "#/soul/dashboard";
    } catch (e) {
      window.location.assign("#/soul/dashboard");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { maxWidth: 520, width: "100%", textAlign: "center", background: "var(--sp-bg-card)", border: "1px solid var(--sp-border-primary)", borderRadius: 12, padding: 24 }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Typography.Title, { level: 3, style: { marginTop: 0, marginBottom: 12 }, children: "ML Grafana" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Typography.Paragraph, { type: "secondary", style: { marginBottom: 16 }, children: "Переход на встроенные панели без открытия Grafana." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Space, { direction: "vertical", size: 12, style: { width: "100%" }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "primary", size: "large", loading, onClick: openExternal, children: "Открыть дефолтный дашборд" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "middle", onClick: openDashboardsList, children: "Список дашбордов" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "middle", onClick: () => {
        try {
          window.location.hash = "#/soul/dashboard";
        } catch (e) {
          window.location.assign("#/soul/dashboard");
        }
      }, children: "System Metrics" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "middle", onClick: () => {
        try {
          window.location.hash = "#/trace";
        } catch (e) {
          window.location.assign("#/trace");
        }
      }, children: "Метрики (Prometheus)" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { fontSize: 12, color: "var(--sp-text-secondary)" }, children: "Переход выполняется напрямую на встроенный дашборд без открытия Grafana." })
    ] })
  ] }) });
};
export {
  GrafanaLauncher as default
};
//# sourceMappingURL=GrafanaLauncher-CPycO_VL.js.map
