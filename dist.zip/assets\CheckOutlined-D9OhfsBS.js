import { a as reactExports } from "./react-DAIzMmXQ.js";
import { aD as CheckOutlined$1 } from "./index-D96S_AGP.js";
import { I as Icon } from "./AntdIcon-BKF1Z4Ac.js";
function _extends() {
  _extends = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}
const CheckOutlined = (props, ref) => /* @__PURE__ */ reactExports.createElement(Icon, _extends({}, props, {
  ref,
  icon: CheckOutlined$1
}));
const RefIcon = /* @__PURE__ */ reactExports.forwardRef(CheckOutlined);
export {
  RefIcon as R
};
//# sourceMappingURL=CheckOutlined-D9OhfsBS.js.map
